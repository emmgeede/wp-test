<?php

namespace WPFaker;

/**
 * Plugin Name: WPfaker
 * Plugin URI: https://wpfaker.com
 * Description: A plugin to generate fake data for WordPress
 * Version: 0.11.0
 * Author: emmgee
 * Author URI: https://emmgee.de
 * Text Domain: wpfaker
 * Domain Path: /languages
 * License: GPL2
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

// Load Composer autoloader
require_once __DIR__ . '/vendor/autoload.php';

// Load config files
$configFiles = glob(__DIR__ . '/config/*.php');
foreach ($configFiles as $file) {
    require_once $file;
}

// Define plugin constants
const WPF_PLUGIN_NAME = 'WPfaker';
const WPF_PLUGIN_SLUG = 'wpfaker';
const WPF_PLUGIN_DIR = __DIR__;
const WPF_PLUGIN_FILE = __FILE__;
const WPF_VERSION = '0.11.0';

$upload_dir = wp_upload_dir();

define('WPF_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('WPF_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WPF_DEBUG_LOG', true);
define('WPF_DEBUG_DIR', trailingslashit($upload_dir['basedir']) . 'wpfaker/debug');
define('WPF_NONCE', 'P@7n2ay!xT_xEUEEr*kALychkGEZrVVbLuTw8TxXnvM*nDUtQa');

// Register activation/deactivation hooks
register_activation_hook(__FILE__, [Plugin::class, 'activate']);
register_deactivation_hook(__FILE__, [Plugin::class, 'deactivate']);

// Filter plugin locale based on user setting
add_filter('plugin_locale', function ($locale, $domain) {
    if ($domain !== 'wpfaker') {
        return $locale;
    }

    $settings = get_option('wpfaker_settings', []);
    $admin_locale = $settings['admin_locale'] ?? 'auto';

    // Return user's selected locale if not 'auto'
    if ($admin_locale !== 'auto') {
        return $admin_locale;
    }

    return $locale;
}, 10, 2);

// Load text domain for translations
add_action('init', function () {
    load_plugin_textdomain('wpfaker', false, dirname(plugin_basename(__FILE__)) . '/languages');
});

// Initialize plugin
add_action('plugins_loaded', function () {
    // Check for plugin updates (internal migrations)
    if (Plugin::needsUpdate()) {
        Plugin::update();
    }

    // Initialize
    Plugin::getInstance()->init();

    // Initialize updater with license check
    Updater::getInstance()->init();

    // Signal that WPFaker is fully loaded — addons hook here
    do_action('wpfaker_loaded', WPF_VERSION);
});
