<?php

namespace WPFaker;

use WP_REST_Controller;
use function add_action;
use function defined;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Api extends WP_REST_Controller {

	public function __construct() {
		add_action( 'rest_api_init', array( new Routes(), 'wpf_register_routes' ) );
	}
}
