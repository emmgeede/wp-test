<?php

namespace WPFaker;

if (!defined('ABSPATH')) {exit;} // Exit if accessed directly


class Helper {

	const POST_STATUS = array(
		'publish',
		'pending',
		'draft',
		'future',
		'private',
		'trash',
	);

	public static function get_random_item( array $array ) {
		return $array[ array_rand( $array ) ];
	}

	public static function get_post_statuses() {
		return self::POST_STATUS;
	}
}
