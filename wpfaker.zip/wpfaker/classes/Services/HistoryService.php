<?php

namespace WPFaker\Services;

/**
 * History Service
 *
 * Tracks generated content for management and cleanup.
 */
class HistoryService
{
    /**
     * Database table name (without prefix)
     */
    protected const TABLE_NAME = 'wpfaker_history';

    /**
     * Get the full table name with prefix
     *
     * @return string
     */
    public static function getTableName(): string
    {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_NAME;
    }

    /**
     * Create the history table
     *
     * @return void
     */
    public static function createTable(): void
    {
        global $wpdb;

        $tableName = self::getTableName();
        $charsetCollate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$tableName} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            content_type VARCHAR(50) NOT NULL,
            content_id BIGINT(20) UNSIGNED NOT NULL,
            content_subtype VARCHAR(100) DEFAULT '',
            meta LONGTEXT,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY content_type (content_type),
            KEY content_id (content_id),
            KEY content_subtype (content_subtype),
            KEY created_at (created_at)
        ) {$charsetCollate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Drop the history table
     *
     * @return void
     */
    public static function dropTable(): void
    {
        global $wpdb;
        $tableName = self::getTableName();
        $wpdb->query("DROP TABLE IF EXISTS {$tableName}");
    }

    /**
     * Log a generated item
     *
     * @param string $type Content type (post, term, user)
     * @param int $id Content ID
     * @param string $subtype Content subtype (post_type, taxonomy, etc.)
     * @param array $meta Additional metadata
     * @return int|false The inserted row ID or false on failure
     */
    public function log(string $type, int $id, string $subtype = '', array $meta = []): int|false
    {
        global $wpdb;

        $result = $wpdb->insert(
            self::getTableName(),
            [
                'content_type'    => $type,
                'content_id'      => $id,
                'content_subtype' => $subtype,
                'meta'            => json_encode($meta),
                'created_at'      => current_time('mysql'),
            ],
            ['%s', '%d', '%s', '%s', '%s']
        );

        return $result ? $wpdb->insert_id : false;
    }

    /**
     * Get history entries
     *
     * @param string|null $type Filter by content type
     * @param int $limit
     * @param int $offset
     * @return array
     */
    public function getHistory(?string $type = null, int $limit = 50, int $offset = 0): array
    {
        global $wpdb;

        $tableName = self::getTableName();
        $where = '';
        $params = [];

        if ($type) {
            $where = 'WHERE content_type = %s';
            $params[] = $type;
        }

        $params[] = $limit;
        $params[] = $offset;

        $sql = "SELECT * FROM {$tableName} {$where} ORDER BY created_at DESC LIMIT %d OFFSET %d";

        $results = $wpdb->get_results(
            $wpdb->prepare($sql, ...$params),
            ARRAY_A
        );

        // Decode meta and enrich with content details
        return array_map(function ($row) {
            $row['meta'] = json_decode($row['meta'], true) ?? [];
            $row['content_title'] = $this->getContentTitle($row['content_type'], $row['content_id']);
            $row['content_exists'] = $this->contentExists($row['content_type'], $row['content_id']);
            $row['template_name'] = $row['meta']['template_name'] ?? null;
            return $row;
        }, $results ?: []);
    }

    /**
     * Get content IDs by type
     *
     * @param string $type
     * @param string|null $subtype
     * @return array
     */
    public function getIdsByType(string $type, ?string $subtype = null): array
    {
        global $wpdb;

        $tableName = self::getTableName();
        $where = 'WHERE content_type = %s';
        $params = [$type];

        if ($subtype) {
            $where .= ' AND content_subtype = %s';
            $params[] = $subtype;
        }

        $sql = "SELECT content_id FROM {$tableName} {$where}";

        $results = $wpdb->get_col($wpdb->prepare($sql, ...$params));

        return array_map('intval', $results);
    }

    /**
     * Delete history entries by IDs
     *
     * @param string $type
     * @param array $ids
     * @return int Number of rows deleted
     */
    public function deleteByIds(string $type, array $ids): int
    {
        global $wpdb;

        if (empty($ids)) {
            return 0;
        }

        $tableName = self::getTableName();
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        $sql = "DELETE FROM {$tableName} WHERE content_type = %s AND content_id IN ({$placeholders})";
        $params = array_merge([$type], $ids);

        return $wpdb->query($wpdb->prepare($sql, ...$params));
    }

    /**
     * Delete all history entries by type
     *
     * @param string $type
     * @return int
     */
    public function deleteByType(string $type): int
    {
        global $wpdb;

        return $wpdb->delete(
            self::getTableName(),
            ['content_type' => $type],
            ['%s']
        );
    }

    /**
     * Clear all history
     *
     * @return int
     */
    public function clearAll(): int
    {
        global $wpdb;
        $tableName = self::getTableName();
        return $wpdb->query("TRUNCATE TABLE {$tableName}");
    }

    /**
     * Get count of history entries
     *
     * @param string|null $type
     * @return int
     */
    public function getCount(?string $type = null): int
    {
        global $wpdb;

        $tableName = self::getTableName();

        if ($type) {
            return (int) $wpdb->get_var(
                $wpdb->prepare("SELECT COUNT(*) FROM {$tableName} WHERE content_type = %s", $type)
            );
        }

        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tableName}");
    }

    /**
     * Get generation statistics
     *
     * @return array
     */
    public function getStats(): array
    {
        global $wpdb;

        $tableName = self::getTableName();

        // Get counts by type
        $typeCounts = $wpdb->get_results(
            "SELECT content_type, COUNT(*) as count FROM {$tableName} GROUP BY content_type",
            ARRAY_A
        );

        // Get counts by subtype
        $subtypeCounts = $wpdb->get_results(
            "SELECT content_type, content_subtype, COUNT(*) as count
             FROM {$tableName}
             GROUP BY content_type, content_subtype",
            ARRAY_A
        );

        // Get recent activity
        $recentActivity = $wpdb->get_results(
            "SELECT DATE(created_at) as date, COUNT(*) as count
             FROM {$tableName}
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
             GROUP BY DATE(created_at)
             ORDER BY date DESC",
            ARRAY_A
        );

        // Check which items still exist
        $existingCounts = $this->getExistingCounts();

        return [
            'total'           => $this->getCount(),
            'by_type'         => $this->formatTypeCounts($typeCounts),
            'by_subtype'      => $subtypeCounts,
            'recent_activity' => $recentActivity,
            'existing'        => $existingCounts,
        ];
    }

    /**
     * Format type counts as associative array
     *
     * @param array $counts
     * @return array
     */
    protected function formatTypeCounts(array $counts): array
    {
        $result = [
            'post'    => 0,
            'term'    => 0,
            'user'    => 0,
            'comment' => 0,
            'media'   => 0,
        ];

        foreach ($counts as $row) {
            $result[$row['content_type']] = (int) $row['count'];
        }

        return $result;
    }

    /**
     * Get counts of existing (not deleted) content
     *
     * @return array
     */
    protected function getExistingCounts(): array
    {
        $counts = [
            'post'    => 0,
            'term'    => 0,
            'user'    => 0,
            'comment' => 0,
            'media'   => 0,
        ];

        foreach (['post', 'term', 'user', 'comment', 'media'] as $type) {
            $ids = $this->getIdsByType($type);
            foreach ($ids as $id) {
                if ($this->contentExists($type, $id)) {
                    $counts[$type]++;
                }
            }
        }

        return $counts;
    }

    /**
     * Check if content still exists
     *
     * @param string $type
     * @param int $id
     * @return bool
     */
    protected function contentExists(string $type, int $id): bool
    {
        return match ($type) {
            'post'    => get_post($id) !== null,
            'term'    => term_exists($id) !== null,
            'user'    => get_user_by('ID', $id) !== false,
            'comment' => get_comment($id) !== null,
            'media'   => get_post($id) !== null && get_post_type($id) === 'attachment',
            default   => false,
        };
    }

    /**
     * Get content title/name
     *
     * @param string $type
     * @param int $id
     * @return string
     */
    protected function getContentTitle(string $type, int $id): string
    {
        return match ($type) {
            'post'    => get_the_title($id) ?: "(Post #{$id})",
            'term'    => ($term = get_term($id)) && !is_wp_error($term) ? $term->name : "(Term #{$id})",
            'user'    => ($user = get_user_by('ID', $id)) ? $user->display_name : "(User #{$id})",
            'comment' => ($c = get_comment($id)) ? wp_trim_words($c->comment_content, 8, '...') : "(Comment #{$id})",
            'media'   => get_the_title($id) ?: "(Media #{$id})",
            default   => "#{$id}",
        };
    }

    /**
     * Clean up history entries for deleted content
     *
     * @return int Number of entries cleaned up
     */
    public function cleanup(): int
    {
        $cleaned = 0;

        foreach (['post', 'term', 'user', 'comment', 'media'] as $type) {
            $ids = $this->getIdsByType($type);
            $toDelete = [];

            foreach ($ids as $id) {
                if (!$this->contentExists($type, $id)) {
                    $toDelete[] = $id;
                }
            }

            if (!empty($toDelete)) {
                $cleaned += $this->deleteByIds($type, $toDelete);
            }
        }

        return $cleaned;
    }

    /**
     * Get a single history entry by ID
     *
     * @param int $id History entry ID
     * @return array|null
     */
    public function getEntryById(int $id): ?array
    {
        global $wpdb;

        $tableName = self::getTableName();
        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$tableName} WHERE id = %d", $id),
            ARRAY_A
        );

        if (!$row) {
            return null;
        }

        $row['meta'] = json_decode($row['meta'], true) ?? [];
        return $row;
    }

    /**
     * Delete a single history entry and optionally its content
     *
     * @param int $id History entry ID
     * @param bool $deleteContent Also delete the WordPress content
     * @return array Result with details
     */
    public function deleteEntry(int $id, bool $deleteContent = true): array
    {
        global $wpdb;

        // Get the entry first
        $entry = $this->getEntryById($id);

        if (!$entry) {
            return [
                'success' => false,
                'message' => 'History entry not found',
            ];
        }

        $contentDeleted = false;
        $contentType = $entry['content_type'];
        $contentId = (int) $entry['content_id'];

        // Delete the WordPress content if requested and it exists
        if ($deleteContent && $this->contentExists($contentType, $contentId)) {
            $contentDeleted = $this->deleteContent($contentType, $contentId);
        }

        // Delete the history entry
        $tableName = self::getTableName();
        $deleted = $wpdb->delete($tableName, ['id' => $id], ['%d']);

        return [
            'success'         => $deleted !== false,
            'entry_deleted'   => $deleted !== false,
            'content_deleted' => $contentDeleted,
            'content_type'    => $contentType,
            'content_id'      => $contentId,
        ];
    }

    /**
     * Delete WordPress content by type and ID
     *
     * @param string $type
     * @param int $id
     * @return bool
     */
    protected function deleteContent(string $type, int $id): bool
    {
        // wp_delete_user() is in wp-admin/includes/user.php, not loaded during REST requests
        if (!function_exists('wp_delete_user')) {
            require_once ABSPATH . 'wp-admin/includes/user.php';
        }

        return match ($type) {
            'post'    => wp_delete_post($id, true) !== false,
            'term'    => !is_wp_error(wp_delete_term($id, $this->getTermTaxonomy($id))),
            'user'    => wp_delete_user($id),
            'comment' => wp_delete_comment($id, true) !== false,
            'media'   => wp_delete_attachment($id, true) !== false,
            default   => false,
        };
    }

    /**
     * Get taxonomy for a term
     *
     * @param int $termId
     * @return string
     */
    protected function getTermTaxonomy(int $termId): string
    {
        $term = get_term($termId);
        return ($term && !is_wp_error($term)) ? $term->taxonomy : '';
    }

    /**
     * Delete history entry by content type and ID
     *
     * @param string $type Content type (post, term, user)
     * @param int $contentId Content ID
     * @return bool
     */
    public function deleteByContentId(string $type, int $contentId): bool
    {
        global $wpdb;

        $deleted = $wpdb->delete(
            self::getTableName(),
            [
                'content_type' => $type,
                'content_id'   => $contentId,
            ],
            ['%s', '%d']
        );

        return $deleted !== false;
    }

    /**
     * Initialize WordPress hooks for automatic cleanup
     */
    public static function initHooks(): void
    {
        $instance = new self();

        // Post and attachment deletion
        add_action('before_delete_post', function ($postId) use ($instance) {
            // Only handle actual posts, not revisions
            if (wp_is_post_revision($postId)) {
                return;
            }
            $type = get_post_type($postId) === 'attachment' ? 'media' : 'post';
            $instance->deleteByContentId($type, $postId);
        });

        // Term deletion
        add_action('pre_delete_term', function ($termId) use ($instance) {
            $instance->deleteByContentId('term', $termId);
        });

        // User deletion
        add_action('delete_user', function ($userId) use ($instance) {
            $instance->deleteByContentId('user', $userId);
        });

        // Comment deletion
        add_action('delete_comment', function ($commentId) use ($instance) {
            $instance->deleteByContentId('comment', $commentId);
        });
    }
}
