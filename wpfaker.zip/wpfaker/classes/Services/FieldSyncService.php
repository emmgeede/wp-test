<?php

namespace WPFaker\Services;

class FieldSyncService
{
    const OPTION_HASHES = 'wpfaker_field_sync_hashes';

    /**
     * Compute a hash for a field definition to detect changes.
     */
    public static function computeFieldHash(array $field): string
    {
        $parts = implode('|', [
            $field['field_key'] ?? '',
            $field['field_name'] ?? '',
            $field['field_label'] ?? '',
            $field['field_type'] ?? '',
            $field['faker_method'] ?? '',
            is_array($field['faker_params'] ?? null) ? json_encode($field['faker_params']) : ($field['faker_params'] ?? ''),
        ]);
        return md5($parts);
    }

    /**
     * Filter fields to only those that have changed since last sync.
     */
    public function filterChangedFields(array $allFields, array $storedHashes): array
    {
        $changed = [];
        foreach ($allFields as $field) {
            $key = $field['field_key'] ?? $field['field_name'];
            $hash = self::computeFieldHash($field);
            if (!isset($storedHashes[$key]) || $storedHashes[$key] !== $hash) {
                $field['field_hash'] = $hash;
                $changed[] = $field;
            }
        }
        return $changed;
    }

    /**
     * Collect all field definitions from all active adapters for all registered CPTs.
     * Returns flat array of field definitions with faker method assignments.
     */
    public function collectAllFields(): array
    {
        $adapters = AdapterFactory::getActiveAdapters();
        $allFields = [];
        $postTypes = get_post_types(['public' => true], 'objects');

        foreach ($postTypes as $postType) {
            foreach ($adapters as $adapterKey => $adapter) {
                $fields = $adapter->getFieldsForPostType($postType->name);
                if (empty($fields)) {
                    continue;
                }

                foreach ($fields as $field) {
                    if (!empty($field['parent_field'])) {
                        continue;
                    }

                    $fakerMethod = $adapter->mapFieldTypeToFaker($field);

                    $allFields[] = [
                        'field_key' => $field['key'] ?? $field['name'],
                        'field_name' => $field['name'],
                        'field_label' => $field['label'] ?? '',
                        'field_type' => $field['type'] ?? 'text',
                        'plugin' => $adapterKey,
                        'plugin_type' => $field['type'] ?? 'text',
                        'post_type' => $postType->name,
                        'post_type_label' => $postType->label,
                        'faker_method' => $fakerMethod,
                        'faker_params' => null,
                    ];
                }
            }
        }

        return $allFields;
    }

    /**
     * Get fields that have changed since last sync.
     */
    public function getChangedFields(): array
    {
        $allFields = $this->collectAllFields();
        $storedHashes = get_option(self::OPTION_HASHES, []);
        return $this->filterChangedFields($allFields, $storedHashes);
    }

    /**
     * Update stored hashes after successful sync.
     */
    public function updateHashes(array $sentFields): void
    {
        $hashes = get_option(self::OPTION_HASHES, []);
        foreach ($sentFields as $field) {
            $key = $field['field_key'] ?? $field['field_name'];
            $hashes[$key] = $field['field_hash'] ?? self::computeFieldHash($field);
        }
        update_option(self::OPTION_HASHES, $hashes, false);
    }

    /**
     * Cleanup all stored data.
     */
    public static function cleanup(): void
    {
        delete_option(self::OPTION_HASHES);
    }
}
