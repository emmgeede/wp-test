<?php

namespace WPFaker\Services;

use WPFaker\Contracts\FieldPluginAdapterInterface;
use WPFaker\Adapters\AcfAdapter;
use WPFaker\Adapters\AcfProAdapter;
use WPFaker\Adapters\AcfeAdapter;
use WPFaker\Adapters\JetEngineAdapter;
use WPFaker\Adapters\MetaBoxAdapter;
use WPFaker\Adapters\AcptAdapter;
use WPFaker\Adapters\CptuiAdapter;
use WPFaker\Adapters\NativeMetaAdapter;

/**
 * Adapter Factory
 *
 * Factory class for creating field plugin adapters.
 * Detects which plugins are active and returns the appropriate adapter(s).
 */
class AdapterFactory
{
    /**
     * Registry of available adapters
     *
     * @var array<string, class-string<FieldPluginAdapterInterface>>
     */
    protected static array $adapters = [
        'acf'         => AcfAdapter::class,
        'acf_pro'     => AcfProAdapter::class,
        'acfe'        => AcfeAdapter::class,
        'jet_engine'  => JetEngineAdapter::class,
        'meta_box'    => MetaBoxAdapter::class,
        'acpt'        => AcptAdapter::class,
        'cptui'       => CptuiAdapter::class,
        'native_meta' => NativeMetaAdapter::class,
    ];

    /**
     * Cached adapter instances
     *
     * @var array<string, FieldPluginAdapterInterface>
     */
    protected static array $instances = [];

    /**
     * The Faker service instance
     *
     * @var FakerService|null
     */
    protected static ?FakerService $faker = null;

    /**
     * Set the Faker service to use for all adapters
     *
     * @param FakerService $faker
     * @return void
     */
    public static function setFaker(FakerService $faker): void
    {
        self::$faker = $faker;
    }

    /**
     * Get the Faker service
     *
     * @return FakerService
     */
    public static function getFaker(): FakerService
    {
        if (self::$faker === null) {
            self::$faker = new FakerService();
        }

        return self::$faker;
    }

    /**
     * Create an adapter by key
     *
     * @param string $key The adapter key (e.g., 'acf', 'acf_pro')
     * @return FieldPluginAdapterInterface|null
     */
    public static function create(string $key): ?FieldPluginAdapterInterface
    {
        $key = strtolower($key);

        if (!isset(self::$adapters[$key])) {
            return null;
        }

        if (!isset(self::$instances[$key])) {
            $class = self::$adapters[$key];
            self::$instances[$key] = new $class(self::getFaker());
        }

        return self::$instances[$key];
    }

    /**
     * Get all active adapters
     *
     * @return array<string, FieldPluginAdapterInterface>
     */
    public static function getActiveAdapters(): array
    {
        $active = [];

        foreach (self::$adapters as $key => $class) {
            $adapter = self::create($key);

            if ($adapter && $adapter->isActive()) {
                $active[$key] = $adapter;
            }
        }

        return $active;
    }

    /**
     * Get the primary active adapter
     *
     * Returns the first active adapter found, preferring Pro versions.
     *
     * @return FieldPluginAdapterInterface|null
     */
    public static function getPrimaryAdapter(): ?FieldPluginAdapterInterface
    {
        // Priority order: Extended/Pro versions first, native meta as fallback
        $priority = ['acfe', 'acf_pro', 'acf', 'jet_engine', 'meta_box', 'acpt', 'native_meta'];
        $priority = apply_filters('wpfaker_adapter_priority', $priority);

        foreach ($priority as $key) {
            if (isset(self::$adapters[$key])) {
                $adapter = self::create($key);

                if ($adapter && $adapter->isActive()) {
                    return $adapter;
                }
            }
        }

        return null;
    }

    /**
     * Check if any supported field plugin is active
     *
     * @return bool
     */
    public static function hasActiveAdapter(): bool
    {
        return self::getPrimaryAdapter() !== null;
    }

    /**
     * Register a custom adapter
     *
     * @param string $key The adapter key
     * @param class-string<FieldPluginAdapterInterface> $class The adapter class
     * @return void
     * @throws \InvalidArgumentException If class does not implement FieldPluginAdapterInterface
     */
    public static function register(string $key, string $class): void
    {
        if (!is_subclass_of($class, FieldPluginAdapterInterface::class)) {
            throw new \InvalidArgumentException(
                sprintf('Adapter class "%s" must implement FieldPluginAdapterInterface', $class)
            );
        }

        self::$adapters[strtolower($key)] = $class;

        // Clear cached instance if exists
        unset(self::$instances[strtolower($key)]);
    }

    /**
     * Get all registered adapter keys
     *
     * @return array
     */
    public static function getRegisteredAdapters(): array
    {
        return array_keys(self::$adapters);
    }

    /**
     * Clear all cached instances
     *
     * @return void
     */
    public static function clearCache(): void
    {
        self::$instances = [];
    }

    /**
     * Reset registry to core adapters only
     *
     * Removes any dynamically registered adapters and clears cached instances.
     * Intended for test cleanup.
     *
     * @return void
     */
    public static function resetRegistry(): void
    {
        self::$adapters = [
            'acf'         => AcfAdapter::class,
            'acf_pro'     => AcfProAdapter::class,
            'acfe'        => AcfeAdapter::class,
            'jet_engine'  => JetEngineAdapter::class,
            'meta_box'    => MetaBoxAdapter::class,
            'acpt'        => AcptAdapter::class,
            'cptui'       => CptuiAdapter::class,
            'native_meta' => NativeMetaAdapter::class,
        ];
        self::$instances = [];
    }

    /**
     * Get adapter information
     *
     * Returns detailed information about all adapters and their status.
     *
     * @return array
     */
    public static function getAdapterInfo(): array
    {
        $info = [];

        foreach (self::$adapters as $key => $class) {
            $adapter = self::create($key);

            $info[$key] = [
                'class'     => $class,
                'active'    => $adapter ? $adapter->isActive() : false,
                'name'      => $adapter ? $adapter->getName() : 'Unknown',
                'version'   => $adapter && $adapter->isActive() ? $adapter->getVersion() : null,
            ];
        }

        return $info;
    }

    /**
     * Get adapters that support a specific content type
     *
     * @param string $contentType e.g., 'post_type', 'taxonomy', 'user', 'options'
     * @return array<FieldPluginAdapterInterface>
     */
    public static function getAdaptersForContentType(string $contentType): array
    {
        $matching = [];
        $active = self::getActiveAdapters();

        foreach ($active as $key => $adapter) {
            // All adapters support post types and taxonomies
            if (in_array($contentType, ['post_type', 'taxonomy'])) {
                $matching[$key] = $adapter;
                continue;
            }

            // Check for Pro-specific features
            if ($contentType === 'options' && $adapter instanceof AcfProAdapter) {
                if ($adapter->hasProFeature('options')) {
                    $matching[$key] = $adapter;
                }
            }
        }

        return $matching;
    }

    /**
     * Get the best adapter for a specific post type
     *
     * Returns the first active adapter that has fields for the given post type.
     * Falls back to native meta adapter if no other adapter has fields.
     *
     * @param string $postType The post type slug
     * @return FieldPluginAdapterInterface|null
     */
    public static function getAdapterForPostType(string $postType): ?FieldPluginAdapterInterface
    {
        // Priority order: Extended/Pro versions first, native meta as fallback
        $priority = ['acfe', 'acf_pro', 'acf', 'jet_engine', 'meta_box', 'acpt', 'native_meta'];
        $priority = apply_filters('wpfaker_adapter_priority', $priority);

        // Also check any dynamically registered adapters not in the priority list
        $allKeys = array_unique(array_merge($priority, array_keys(self::$adapters)));

        foreach ($allKeys as $key) {
            if (!isset(self::$adapters[$key])) {
                continue;
            }

            $adapter = self::create($key);
            if (!$adapter || !$adapter->isActive()) {
                continue;
            }

            // Check if this adapter has fields for the post type
            $fields = $adapter->getFieldsForPostType($postType);
            if (!empty($fields)) {
                return $adapter;
            }
        }

        return null;
    }

    /**
     * Get all adapters that have fields for a specific post type
     *
     * @param string $postType The post type slug
     * @return array<string, FieldPluginAdapterInterface>
     */
    public static function getAdaptersWithFieldsForPostType(string $postType): array
    {
        $matching = [];
        $active = self::getActiveAdapters();

        foreach ($active as $key => $adapter) {
            $fields = $adapter->getFieldsForPostType($postType);
            if (!empty($fields)) {
                $matching[$key] = $adapter;
            }
        }

        return $matching;
    }
}
