<?php

declare(strict_types=1);

namespace WPFaker\Services;

/**
 * System Capacity Detection Service
 *
 * Dynamically calculates safe chunk sizes for generation based on PHP memory_limit
 * and max_execution_time. The chunk size tells the frontend how many items to
 * request per AJAX chunk.
 *
 * Formula:
 * - Memory-based: (available memory * 0.70) / 3MB per post
 * - Time-based: (max_execution_time * 0.80) / 1.5s per post
 * - Final: min(memory, time), clamped to [10, 500], rounded to nice number
 */
class SystemCapacityService
{
    public const CACHE_KEY = 'wpfaker_system_capacity';
    public const CACHE_TTL = 3600; // 1 hour transient

    public const ABSOLUTE_MIN = 10;
    public const ABSOLUTE_MAX = 500;

    /** Memory overhead estimate for WordPress + plugins (bytes) */
    private const MEMORY_OVERHEAD = 40 * 1024 * 1024; // 40 MB

    /** Estimated memory per generated post (bytes) */
    private const MEMORY_PER_POST = 3 * 1024 * 1024; // 3 MB

    /** Estimated average time per post (seconds) */
    private const TIME_PER_POST = 1.5;

    /** Memory safety reserve (70% usable) */
    private const MEMORY_SAFETY_FACTOR = 0.70;

    /** Time safety reserve (80% usable) */
    private const TIME_SAFETY_FACTOR = 0.80;

    /** Fallback memory when unlimited (-1) */
    private const FALLBACK_MEMORY = 512 * 1024 * 1024; // 512 MB

    /** Fallback execution time when unlimited (0) */
    private const FALLBACK_TIME = 300; // 5 minutes

    /** Nice numbers for rounding */
    private const NICE_NUMBERS = [10, 20, 25, 50, 75, 100, 150, 200, 250, 300, 500];

    /** In-memory cache */
    private static ?array $cache = null;

    /**
     * Get complete capacity info (cached)
     */
    public static function getCapacity(bool $fresh = false): array
    {
        if (!$fresh && self::$cache !== null) {
            return self::$cache;
        }

        if (!$fresh && function_exists('get_transient')) {
            $cached = get_transient(self::CACHE_KEY);
            if ($cached !== false) {
                self::$cache = $cached;
                return $cached;
            }
        }

        $memoryLimitRaw = function_exists('ini_get') ? (string) ini_get('memory_limit') : '128M';
        $memoryLimitBytes = self::parseMemoryValue($memoryLimitRaw);
        $maxExecutionTime = function_exists('ini_get') ? (int) ini_get('max_execution_time') : 30;

        $calculated = self::calculateLimits($memoryLimitBytes, $maxExecutionTime);

        $capacity = [
            'chunk_size' => $calculated['max_posts'],
        ];

        if (function_exists('set_transient')) {
            set_transient(self::CACHE_KEY, $capacity, self::CACHE_TTL);
        }

        self::$cache = $capacity;

        return $capacity;
    }

    /**
     * Get the chunk size for generation requests
     */
    public static function getChunkSize(): int
    {
        return self::getCapacity()['chunk_size'];
    }

    /**
     * Clear all caches
     */
    public static function clearCache(): void
    {
        self::$cache = null;

        if (function_exists('delete_transient')) {
            delete_transient(self::CACHE_KEY);
        }
    }

    /**
     * Calculate limits from memory and time constraints
     *
     * @param int $memoryLimitBytes PHP memory_limit in bytes (-1 for unlimited)
     * @param int $maxExecutionTime PHP max_execution_time in seconds (0 for unlimited)
     * @return array{max_posts: int, max_terms: int, max_users: int, memory_limit_bytes: int, max_execution_time: int, memory_based_max: int, time_based_max: int}
     */
    protected static function calculateLimits(int $memoryLimitBytes, int $maxExecutionTime): array
    {
        $originalMemory = $memoryLimitBytes;
        $originalTime = $maxExecutionTime;

        // Handle unlimited memory
        if ($memoryLimitBytes <= 0) {
            $memoryLimitBytes = self::FALLBACK_MEMORY;
        }

        // Handle unlimited execution time
        $effectiveTime = $maxExecutionTime;
        if ($effectiveTime <= 0) {
            $effectiveTime = self::FALLBACK_TIME;
        }

        // Memory-based limit
        $availableMemory = $memoryLimitBytes - self::MEMORY_OVERHEAD;
        $safeMemory = $availableMemory * self::MEMORY_SAFETY_FACTOR;
        $memoryMax = (int) floor($safeMemory / self::MEMORY_PER_POST);

        // Time-based limit
        $safeTime = $effectiveTime * self::TIME_SAFETY_FACTOR;
        $timeMax = (int) floor($safeTime / self::TIME_PER_POST);

        // Take the more restrictive limit
        $calculated = min($memoryMax, $timeMax);

        // Clamp and round
        $clamped = max(self::ABSOLUTE_MIN, min(self::ABSOLUTE_MAX, $calculated));
        $maxPosts = self::roundToNiceNumber($clamped);

        // Derive terms (same as posts) and users (roughly half, clamped)
        $maxTerms = $maxPosts;
        $maxUsers = self::roundToNiceNumber(max(self::ABSOLUTE_MIN, min(self::ABSOLUTE_MAX, (int) floor($maxPosts * 0.5))));

        return [
            'max_posts' => $maxPosts,
            'max_terms' => $maxTerms,
            'max_users' => $maxUsers,
            'memory_limit_bytes' => $originalMemory,
            'max_execution_time' => $originalTime,
            'memory_based_max' => max(self::ABSOLUTE_MIN, $memoryMax),
            'time_based_max' => max(self::ABSOLUTE_MIN, $timeMax),
        ];
    }

    /**
     * Parse PHP memory value string to bytes
     *
     * Handles formats: "128M", "1G", "131072K", "67108864", "-1"
     */
    protected static function parseMemoryValue(string $value): int
    {
        $value = trim($value);

        if ($value === '-1') {
            return -1;
        }

        $last = strtoupper(substr($value, -1));
        $numericValue = (int) $value;

        return match ($last) {
            'G' => $numericValue * 1024 * 1024 * 1024,
            'M' => $numericValue * 1024 * 1024,
            'K' => $numericValue * 1024,
            default => $numericValue,
        };
    }

    /**
     * Round a value down to the nearest "nice" number
     *
     * Nice numbers: 10, 20, 25, 50, 75, 100, 150, 200, 250, 300, 500
     */
    protected static function roundToNiceNumber(int $value): int
    {
        if ($value <= self::NICE_NUMBERS[0]) {
            return self::NICE_NUMBERS[0];
        }

        $result = self::NICE_NUMBERS[0];

        foreach (self::NICE_NUMBERS as $nice) {
            if ($nice <= $value) {
                $result = $nice;
            } else {
                break;
            }
        }

        return $result;
    }
}
