<?php

namespace WPFaker\Services;

class VideoService
{
    const DEFAULT_VIDEOS = [
        [
            'id' => 0,
            'title' => 'Getting Started',
            'description' => 'Create your first template and generate posts',
            'video_url' => 'https://wpfaker.com/docs/getting-started',
            'video_type' => 'youtube',
            'embed_url' => 'https://wpfaker.com/docs/getting-started',
            'thumbnail_url' => '',
            'duration' => '3:24',
        ],
    ];

    /**
     * Get tutorial videos from API
     */
    public static function getVideos(): array
    {
        $apiUrl = defined('WPFAKER_API_URL') ? WPFAKER_API_URL : 'https://api.wpfaker.com/api/v1';
        $apiUrl = rtrim($apiUrl, '/');

        $response = wp_remote_get($apiUrl . '/videos', [
            'timeout' => 10,
            'headers' => ['Accept' => 'application/json'],
        ]);

        if (is_wp_error($response)) {
            return self::DEFAULT_VIDEOS;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            return self::DEFAULT_VIDEOS;
        }

        $videos = json_decode(wp_remote_retrieve_body($response), true);

        return is_array($videos) ? $videos : self::DEFAULT_VIDEOS;
    }
}
