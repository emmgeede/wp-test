<?php

namespace WPFaker\Services;

/**
 * Logo Service
 *
 * Generates logo attachments for the WordPress media library.
 * Downloads real company logos from Hetzner Object Storage (pool of 100).
 * Falls back to bundled SVG logos if download fails.
 */
class LogoService
{
    public const PROVIDER_REMOTE = 'remote';
    public const PROVIDER_BUNDLED = 'bundled';

    private const LOGO_BASE_URL = 'https://wpfaker-company-logos.fsn1.your-objectstorage.com';
    private const SVG_LOGO_COUNT = 90;
    private const PNG_LOGO_COUNT = 71;

    /**
     * Generate a logo and return a WP attachment ID.
     *
     * @param string $seed Company/brand name used as seed
     * @return int Attachment ID (0 on failure)
     */
    public static function generateLogo(string $seed): int
    {
        $id = self::generateRemoteLogo($seed);
        if ($id > 0) {
            return $id;
        }

        return self::generateBundledLogo($seed);
    }

    /**
     * Get a deterministic logo number for a given seed.
     *
     * @param string $seed Company/brand name
     * @param string $format 'svg' or 'png'
     * @return int Logo number (1-90 for SVG, 1-71 for PNG)
     */
    public static function getLogoNumber(string $seed, string $format = 'svg'): int
    {
        $count = $format === 'svg' ? self::SVG_LOGO_COUNT : self::PNG_LOGO_COUNT;
        return (abs(crc32($seed)) % $count) + 1;
    }

    /**
     * Get the remote URL for a logo number.
     *
     * @param int $number Logo number
     * @param string $format 'svg' or 'png'
     * @return string Full URL
     */
    public static function getLogoUrl(int $number, string $format = 'svg'): string
    {
        $padded = str_pad((string)$number, 3, '0', STR_PAD_LEFT);
        if ($format === 'svg') {
            return self::LOGO_BASE_URL . '/svg/logo-' . $padded . '.svg';
        }
        return self::LOGO_BASE_URL . '/logo-' . $padded . '.png';
    }

    /**
     * Get all bundled SVG logo file paths.
     *
     * @return array<string> Array of absolute file paths
     */
    public static function getBundledLogos(): array
    {
        $dir = WPF_PLUGIN_DIR . '/assets/logos';
        if (!is_dir($dir)) {
            return [];
        }

        $files = glob($dir . '/*.svg');
        return $files ?: [];
    }

    /**
     * Get a random bundled logo file path.
     *
     * @return string Absolute file path (empty string on failure)
     */
    public static function getRandomBundledLogo(): string
    {
        $logos = self::getBundledLogos();
        if (empty($logos)) {
            return '';
        }

        return $logos[array_rand($logos)];
    }

    /**
     * Download a logo from Hetzner Object Storage and insert into media library.
     * Tries SVG first, falls back to PNG.
     *
     * @param string $seed Company/brand name (determines which logo is picked)
     * @return int Attachment ID (0 on failure)
     */
    protected static function generateRemoteLogo(string $seed): int
    {
        if (!function_exists('wp_remote_get')) {
            return 0;
        }

        // Try SVG first
        $number = self::getLogoNumber($seed, 'svg');
        $url = self::getLogoUrl($number, 'svg');
        $response = wp_remote_get($url, ['timeout' => 15]);

        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $svgData = wp_remote_retrieve_body($response);
            if (!empty($svgData)) {
                return self::createSvgAttachment($seed, $svgData, self::PROVIDER_REMOTE);
            }
        }

        // Fall back to PNG
        $number = self::getLogoNumber($seed, 'png');
        $url = self::getLogoUrl($number, 'png');
        $response = wp_remote_get($url, ['timeout' => 15]);

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return 0;
        }

        $pngData = wp_remote_retrieve_body($response);
        if (empty($pngData)) {
            return 0;
        }

        return self::createPngAttachment($seed, $pngData, self::PROVIDER_REMOTE);
    }

    /**
     * Use a bundled SVG logo as fallback.
     *
     * @param string $seed Company/brand name for attachment title
     * @return int Attachment ID (0 on failure)
     */
    protected static function generateBundledLogo(string $seed): int
    {
        $svgPath = self::getRandomBundledLogo();
        if ($svgPath === '') {
            return 0;
        }

        $svgData = file_get_contents($svgPath);
        if ($svgData === false || $svgData === '') {
            return 0;
        }

        $filename = 'wpfaker-logo-' . sanitize_file_name($seed) . '-' . wp_generate_password(6, false) . '.svg';
        $uploadDir = wp_upload_dir();
        $targetPath = $uploadDir['path'] . '/' . $filename;

        if (file_put_contents($targetPath, $svgData) === false) {
            return 0;
        }

        $attachmentId = wp_insert_attachment([
            'post_title'     => $seed . ' Logo',
            'post_mime_type' => 'image/svg+xml',
            'post_status'    => 'inherit',
        ], $targetPath);

        if (is_wp_error($attachmentId) || !$attachmentId) {
            return 0;
        }

        update_post_meta($attachmentId, '_wpfaker_generated', true);
        update_post_meta($attachmentId, '_wpfaker_logo_provider', self::PROVIDER_BUNDLED);
        update_post_meta($attachmentId, '_wpfaker_logo_seed', $seed);

        return $attachmentId;
    }

    /**
     * Create a WP attachment from SVG data.
     *
     * @param string $seed For title and filename
     * @param string $svgData Raw SVG content
     * @param string $provider Provider identifier for meta
     * @return int Attachment ID (0 on failure)
     */
    private static function createSvgAttachment(string $seed, string $svgData, string $provider): int
    {
        $filename = 'wpfaker-logo-' . sanitize_file_name($seed) . '-' . wp_generate_password(6, false) . '.svg';
        $uploadDir = wp_upload_dir();
        $targetPath = $uploadDir['path'] . '/' . $filename;

        if (file_put_contents($targetPath, $svgData) === false) {
            return 0;
        }

        $attachmentId = wp_insert_attachment([
            'post_title'     => $seed . ' Logo',
            'post_mime_type' => 'image/svg+xml',
            'post_status'    => 'inherit',
        ], $targetPath);

        if (is_wp_error($attachmentId) || !$attachmentId) {
            return 0;
        }

        update_post_meta($attachmentId, '_wpfaker_generated', true);
        update_post_meta($attachmentId, '_wpfaker_logo_provider', $provider);
        update_post_meta($attachmentId, '_wpfaker_logo_seed', $seed);

        return $attachmentId;
    }

    /**
     * Create a WP attachment from PNG data.
     *
     * @param string $seed For title and filename
     * @param string $pngData Raw PNG binary
     * @param string $provider Provider identifier for meta
     * @return int Attachment ID (0 on failure)
     */
    private static function createPngAttachment(string $seed, string $pngData, string $provider): int
    {
        $filename = 'wpfaker-logo-' . sanitize_file_name($seed) . '-' . wp_generate_password(6, false) . '.png';
        $uploadDir = wp_upload_dir();
        $targetPath = $uploadDir['path'] . '/' . $filename;

        if (file_put_contents($targetPath, $pngData) === false) {
            return 0;
        }

        $attachmentId = wp_insert_attachment([
            'post_title'     => $seed . ' Logo',
            'post_mime_type' => 'image/png',
            'post_status'    => 'inherit',
        ], $targetPath);

        if (is_wp_error($attachmentId) || !$attachmentId) {
            return 0;
        }

        require_once ABSPATH . 'wp-admin/includes/image.php';
        wp_update_attachment_metadata($attachmentId, wp_generate_attachment_metadata($attachmentId, $targetPath));

        update_post_meta($attachmentId, '_wpfaker_generated', true);
        update_post_meta($attachmentId, '_wpfaker_logo_provider', $provider);
        update_post_meta($attachmentId, '_wpfaker_logo_seed', $seed);

        return $attachmentId;
    }
}
