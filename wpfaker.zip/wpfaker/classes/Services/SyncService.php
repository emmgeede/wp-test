<?php

namespace WPFaker\Services;

class SyncService
{
    const OPTION_NEXT_SEND = 'wpfaker_sync_next_send';
    const OPTION_LAST_RESULT = 'wpfaker_sync_last_result';
    const CRON_HOOK = 'wpfaker_sync_send';

    private const API_BASE_URL = 'https://api.wpfaker.com/api/v1';
    private const API_SECRET = 'wpf_8k3mX9pL2nR7vQ4wY6tB1cF5hJ0sA3dG';

    /**
     * Check if a sync is due and execute it.
     * Called via piggyback on REST API calls.
     */
    public static function maybeSend(): void
    {
        $nextSend = get_option(self::OPTION_NEXT_SEND, 0);

        // No scheduled sync yet? Schedule first one for 1 hour from now
        if ($nextSend === 0) {
            update_option(self::OPTION_NEXT_SEND, time() + 3600, false);
            return;
        }

        if (time() < $nextSend) {
            return;
        }

        // Prevent concurrent sends
        $lockKey = 'wpfaker_sync_lock';
        if (get_transient($lockKey)) {
            return;
        }
        set_transient($lockKey, true, 300); // 5-minute lock

        try {
            (new self())->send();
        } finally {
            delete_transient($lockKey);
        }
    }

    /**
     * Send combined telemetry + field data to the API.
     */
    public function send(): void
    {
        $telemetryService = new TelemetryService();
        $fieldSyncService = new FieldSyncService();
        $hiveService = new HiveService();

        // Build telemetry portion (always, if telemetry enabled)
        $telemetry = null;
        if ($telemetryService->isEnabled()) {
            $telemetry = $telemetryService->buildSnapshot();
        }

        // Build fields portion (only if hive enabled)
        $fields = [];
        if ($hiveService->isEnabled()) {
            $fields = $fieldSyncService->getChangedFields();
        }

        // Nothing to send?
        if ($telemetry === null && empty($fields)) {
            // Still schedule next check
            update_option(self::OPTION_NEXT_SEND, time() + 86400, false); // retry tomorrow
            return;
        }

        $payload = [
            'telemetry' => $telemetry,
            'fields' => $fields,
        ];

        $jsonBody = wp_json_encode($payload);
        $timestamp = (string) time();
        $apiSecret = defined('WPFAKER_API_SECRET')
            ? WPFAKER_API_SECRET
            : self::API_SECRET;
        $signature = hash_hmac('sha256', $timestamp . $jsonBody, $apiSecret);

        $apiUrl = defined('WPFAKER_API_URL')
            ? WPFAKER_API_URL . '/sync'
            : self::API_BASE_URL . '/sync';

        $response = wp_remote_post($apiUrl, [
            'headers' => [
                'Content-Type' => 'application/json',
                'X-WPfaker-Timestamp' => $timestamp,
                'X-WPfaker-Signature' => $signature,
            ],
            'body' => $jsonBody,
            'timeout' => 15,
            'blocking' => true,
        ]);

        if (is_wp_error($response)) {
            error_log('WPFaker Sync failed: ' . $response->get_error_message());
            // Retry in 6 hours
            update_option(self::OPTION_NEXT_SEND, time() + 21600, false);
            return;
        }

        $statusCode = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($statusCode !== 200 || empty($body['status']) || $body['status'] !== 'ok') {
            error_log('WPFaker Sync failed with status ' . $statusCode);
            update_option(self::OPTION_NEXT_SEND, time() + 21600, false);
            return;
        }

        // Success: update local state
        if (!empty($fields)) {
            $fieldSyncService->updateHashes($fields);
        }

        // Clear telemetry buffer
        update_option(TelemetryService::OPTION_BUFFER, [], false);
        update_option(TelemetryService::OPTION_LAST_SENT, time(), false);

        // Store server-assigned next send time
        $nextSendAt = $body['next_send_at'] ?? (time() + 604800); // fallback: 7 days
        update_option(self::OPTION_NEXT_SEND, $nextSendAt, false);

        // Store result for dashboard display
        $result = [
            'timestamp' => time(),
            'fields_sent' => count($fields),
            'fields_accepted' => $body['fields_accepted'] ?? 0,
            'fields_rejected' => $body['fields_rejected'] ?? 0,
            'telemetry_sent' => $telemetry !== null,
            'fields' => array_map(function ($f) {
                return [
                    'field_name' => $f['field_name'],
                    'field_type' => $f['field_type'],
                    'faker_method' => $f['faker_method'],
                    'post_type' => $f['post_type'],
                ];
            }, $fields),
            'seen' => false, // Dashboard will set to true after showing
        ];
        update_option(self::OPTION_LAST_RESULT, $result, false);
    }

    /**
     * Get sync status for dashboard.
     */
    public static function getStatus(): array
    {
        $hiveService = new HiveService();
        $telemetryService = new TelemetryService();
        $settings = get_option('wpfaker_settings', []);

        return [
            'hive_enabled' => $hiveService->isEnabled(),
            'telemetry_enabled' => $settings['telemetry_enabled'] ?? true,
            'next_send_at' => get_option(self::OPTION_NEXT_SEND, 0),
            'last_sync' => get_option(self::OPTION_LAST_RESULT, null),
            'local_stats' => self::getLocalStats(),
        ];
    }

    /**
     * Get local telemetry stats for dashboard.
     */
    private static function getLocalStats(): array
    {
        $buffer = get_option(TelemetryService::OPTION_BUFFER, []);
        $historyTable = $GLOBALS['wpdb']->prefix . 'wpfaker_history';

        // Get generation counts from history table (each row = 1 generated item)
        $counts = $GLOBALS['wpdb']->get_row(
            "SELECT
                COALESCE(SUM(CASE WHEN content_type = 'post' THEN 1 ELSE 0 END), 0) as generated_posts,
                COALESCE(SUM(CASE WHEN content_type = 'term' THEN 1 ELSE 0 END), 0) as generated_terms,
                COALESCE(SUM(CASE WHEN content_type = 'user' THEN 1 ELSE 0 END), 0) as generated_users,
                COALESCE(SUM(CASE WHEN content_type = 'comment' THEN 1 ELSE 0 END), 0) as generated_comments
            FROM {$historyTable}",
            ARRAY_A
        );

        $settings = get_option('wpfaker_settings', []);

        return [
            'generated_posts' => (int) ($counts['generated_posts'] ?? 0),
            'generated_terms' => (int) ($counts['generated_terms'] ?? 0),
            'generated_users' => (int) ($counts['generated_users'] ?? 0),
            'generated_comments' => (int) ($counts['generated_comments'] ?? 0),
            'ai_detections' => (int) ($buffer['ai_detections'] ?? 0),
            'hive_submissions' => (int) ($buffer['hive_submissions'] ?? 0),
            'template_generations' => (int) ($buffer['template_generations'] ?? 0),
            'time_saved_seconds' => (new TimeSavingsService())->getTotalTimeSaved(),
            'hourly_rate' => (float) ($settings['hourly_rate'] ?? 75),
        ];
    }

    /**
     * Mark last sync result as seen (for dashboard notification).
     */
    public static function markResultSeen(): void
    {
        $result = get_option(self::OPTION_LAST_RESULT);
        if ($result && isset($result['seen'])) {
            $result['seen'] = true;
            update_option(self::OPTION_LAST_RESULT, $result, false);
        }
    }

    /**
     * Cleanup all sync options.
     */
    public static function cleanup(): void
    {
        delete_option(self::OPTION_NEXT_SEND);
        delete_option(self::OPTION_LAST_RESULT);
        FieldSyncService::cleanup();
    }
}
