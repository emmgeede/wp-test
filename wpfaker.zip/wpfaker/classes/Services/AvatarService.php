<?php

namespace WPFaker\Services;

/**
 * Avatar Service
 *
 * Downloads portrait images from image providers and assigns them
 * as profile pictures to users and commenters via WordPress's
 * pre_get_avatar_data filter.
 */
class AvatarService
{
    /**
     * Meta keys for avatar attachment IDs
     */
    public const USER_AVATAR_META = '_wpfaker_avatar_id';
    public const COMMENT_AVATAR_META = '_wpfaker_avatar_id';

    /**
     * Search query for portrait images
     */
    public const PORTRAIT_QUERY = 'portrait face headshot person';

    /**
     * Default avatar image size (square)
     */
    public const AVATAR_SIZE = 400;

    /**
     * Maximum pool size to prevent excessive downloads
     */
    public const MAX_POOL_SIZE = 20;

    /**
     * Pool of downloaded avatar attachment IDs
     */
    protected array $avatarPool = [];

    /**
     * Current index for round-robin assignment
     */
    protected int $poolIndex = 0;

    /**
     * Download a pool of portrait images for use as avatars
     *
     * @param int $count Number of avatars to download
     * @param string $provider Image provider to use
     * @return array Array of attachment IDs
     */
    public function downloadAvatarPool(int $count, string $provider = 'unsplash'): array
    {
        $count = min($count, self::MAX_POOL_SIZE);

        $imageService = new ImageService();
        $imageService->setProvider($provider);
        $imageService->setDimensions(self::AVATAR_SIZE, self::AVATAR_SIZE);
        $imageService->setAspectRatio('1:1');

        $this->avatarPool = [];
        $this->poolIndex = 0;

        for ($i = 0; $i < $count; $i++) {
            $attachmentId = $imageService->downloadImage(
                'Avatar Portrait ' . ($i + 1),
                'portrait'
            );

            if ($attachmentId) {
                update_post_meta($attachmentId, '_wpfaker_avatar', true);
                $this->avatarPool[] = $attachmentId;
            }

            // Rate limiting between downloads
            if ($i < $count - 1) {
                usleep(200000); // 200ms
            }
        }

        return $this->avatarPool;
    }

    /**
     * Get the next avatar from the pool (round-robin)
     *
     * @return int|null Attachment ID or null if pool is empty
     */
    public function getNextAvatar(): ?int
    {
        if (empty($this->avatarPool)) {
            return null;
        }

        $id = $this->avatarPool[$this->poolIndex % count($this->avatarPool)];
        $this->poolIndex++;

        return $id;
    }

    /**
     * Set the avatar pool manually (e.g. from existing attachments)
     *
     * @param array $attachmentIds
     * @return void
     */
    public function setAvatarPool(array $attachmentIds): void
    {
        $this->avatarPool = $attachmentIds;
        $this->poolIndex = 0;
    }

    /**
     * Assign an avatar to a WordPress user
     *
     * @param int $userId
     * @param int $attachmentId
     * @return void
     */
    public function assignAvatarToUser(int $userId, int $attachmentId): void
    {
        update_user_meta($userId, self::USER_AVATAR_META, $attachmentId);
    }

    /**
     * Assign an avatar to a comment
     *
     * @param int $commentId
     * @param int $attachmentId
     * @return void
     */
    public function assignAvatarToComment(int $commentId, int $attachmentId): void
    {
        update_comment_meta($commentId, self::COMMENT_AVATAR_META, $attachmentId);
    }

    /**
     * Register WordPress hooks for avatar filtering
     *
     * @return void
     */
    public static function initHooks(): void
    {
        add_filter('pre_get_avatar_data', [static::class, 'filterAvatarData'], 10, 2);
    }

    /**
     * Filter avatar data to serve local WPFaker avatars instead of Gravatar
     *
     * @param array $args Avatar data args
     * @param mixed $idOrEmail User ID, email, WP_User, or WP_Comment
     * @return array Modified args
     */
    public static function filterAvatarData(array $args, $idOrEmail): array
    {
        $avatarId = null;

        if ($idOrEmail instanceof \WP_User) {
            $avatarId = get_user_meta($idOrEmail->ID, self::USER_AVATAR_META, true);
        } elseif ($idOrEmail instanceof \WP_Comment) {
            // Check comment meta first
            $avatarId = get_comment_meta($idOrEmail->comment_ID, self::COMMENT_AVATAR_META, true);

            // Fallback: if comment has a user_id, check user meta
            if (!$avatarId && $idOrEmail->user_id) {
                $avatarId = get_user_meta((int) $idOrEmail->user_id, self::USER_AVATAR_META, true);
            }
        } elseif (is_numeric($idOrEmail)) {
            $avatarId = get_user_meta((int) $idOrEmail, self::USER_AVATAR_META, true);
        } elseif (is_string($idOrEmail) && is_email($idOrEmail)) {
            // Email string: try user lookup first
            $user = get_user_by('email', $idOrEmail);
            if ($user) {
                $avatarId = get_user_meta($user->ID, self::USER_AVATAR_META, true);
            }

            // Fallback: find latest comment with this email that has an avatar
            if (!$avatarId) {
                global $wpdb;
                $avatarId = $wpdb->get_var($wpdb->prepare(
                    "SELECT cm.meta_value FROM {$wpdb->commentmeta} cm
                     INNER JOIN {$wpdb->comments} c ON cm.comment_id = c.comment_ID
                     WHERE cm.meta_key = %s AND c.comment_author_email = %s
                     ORDER BY c.comment_ID DESC LIMIT 1",
                    self::COMMENT_AVATAR_META,
                    $idOrEmail
                ));
            }
        }

        if ($avatarId) {
            $avatarId = (int) $avatarId;
            $url = wp_get_attachment_image_url($avatarId, 'thumbnail');
            if ($url) {
                $args['url'] = $url;
                $args['found_avatar'] = true;
            }
        }

        return $args;
    }
}
