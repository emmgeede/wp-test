<?php

namespace WPFaker\Services;

class NewsService
{
    /**
     * Get news HTML from API
     */
    public static function getNews(): array
    {
        $apiUrl = defined('WPFAKER_API_URL') ? WPFAKER_API_URL : 'https://api.wpfaker.com/api/v1';
        $apiUrl = rtrim($apiUrl, '/');

        $response = wp_remote_get($apiUrl . '/settings/news', [
            'timeout' => 10,
            'headers' => ['Accept' => 'application/json'],
        ]);

        if (is_wp_error($response)) {
            return ['html' => ''];
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            return ['html' => ''];
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);

        return is_array($data) ? $data : ['html' => ''];
    }
}
