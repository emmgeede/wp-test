<?php

namespace WPFaker\Services;

use WPFaker\Contracts\AiProviderInterface;

/**
 * Abstract AI Provider
 *
 * Shared logic for all AI providers: settings, caching, prompts, orchestration.
 * Concrete providers only implement the API call methods.
 */
abstract class AbstractAiProvider implements AiProviderInterface
{
    /**
     * Option name for settings
     */
    public const OPTION_NAME = 'wpfaker_ai_settings';

    /**
     * Cache duration in seconds (1 hour)
     */
    protected const CACHE_DURATION = 3600;

    /**
     * API key for this provider
     */
    protected ?string $apiKey = null;

    /**
     * Whether AI is enabled globally
     */
    protected bool $enabled = false;

    /**
     * Last error message from API call (for testConnection reporting)
     */
    protected ?string $lastError = null;

    /**
     * Get the last error message from an API call
     */
    public function getLastError(): ?string
    {
        return $this->lastError;
    }

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->loadSettings();
    }

    /**
     * Load settings from WordPress options
     */
    protected function loadSettings(): void
    {
        $settings = get_option(self::OPTION_NAME, []);
        $this->enabled = !empty($settings['enabled']);

        // Determine which API key to load based on provider
        $providerKey = $this->getProviderKey();
        $keyField = $providerKey . '_api_key';

        if (!empty($settings[$keyField])) {
            $this->apiKey = $settings[$keyField];
        } elseif ($providerKey === 'gemini' && !empty($settings['api_key'])) {
            // Backward compatibility: old 'api_key' maps to gemini
            $this->apiKey = $settings['api_key'];
        }
    }

    /**
     * Check if AI detection is enabled and configured
     */
    public function isAvailable(): bool
    {
        return $this->enabled && !empty($this->apiKey);
    }

    /**
     * Check if AI is enabled (regardless of API key)
     */
    public function isEnabled(): bool
    {
        return $this->enabled;
    }

    /**
     * Get the API key (masked for display)
     */
    public function getMaskedApiKey(): string
    {
        if (empty($this->apiKey)) {
            return '';
        }

        $length = strlen($this->apiKey);
        if ($length <= 8) {
            return str_repeat('*', $length);
        }

        return substr($this->apiKey, 0, 4) . str_repeat('*', $length - 8) . substr($this->apiKey, -4);
    }

    /**
     * Detect field type using AI
     */
    public function detectFieldType(
        string $fieldName,
        string $fieldLabel = '',
        string $fieldType = 'text',
        ?string $locale = null
    ): ?array {
        if (!$this->isAvailable()) {
            return null;
        }

        // Check cache first
        $cacheKey = $this->getCacheKey($fieldName, $fieldLabel, $locale);
        $cached = get_transient($cacheKey);
        if ($cached !== false) {
            return $cached;
        }

        $prompt = $this->buildDetectionPrompt($fieldName, $fieldLabel, $fieldType, $locale);
        $result = $this->callApi($prompt, 0.1, 2048);

        if ($result) {
            $parsed = $this->parseJsonResponse($result);

            if ($parsed) {
                // Check if this is a single field result
                if (!empty($parsed['type']) && $parsed['type'] !== 'unknown') {
                    $detection = [
                        'type' => $parsed['type'],
                        'confidence' => $parsed['confidence'] ?? 0.5,
                    ];
                    set_transient($cacheKey, $detection, self::CACHE_DURATION);
                    return $detection;
                }
            }
        }

        return null;
    }

    /**
     * Detect field types for all fields of a CPT in a single batch API call
     */
    public function detectFieldsBatch(
        array $fields,
        string $postType,
        ?string $postTypeLabel = null,
        ?string $locale = null
    ): ?array {
        if (!$this->isAvailable() || empty($fields)) {
            return null;
        }

        $prompt = $this->buildBatchDetectionPrompt($fields, $postType, $postTypeLabel, $locale);
        $result = $this->callApi($prompt, 0.1, 2048);

        if (!$result) {
            return null;
        }

        $parsed = $this->parseJsonResponse($result);

        if (!$parsed || isset($parsed['type'])) {
            return null;
        }

        // Batch result: filter out unknowns
        $filtered = [];
        foreach ($parsed as $fieldName => $detection) {
            if (is_array($detection) && !empty($detection['type']) && $detection['type'] !== 'unknown') {
                $filtered[$fieldName] = [
                    'type' => $detection['type'],
                    'confidence' => $detection['confidence'] ?? 0.5,
                ];
            }
        }

        if (!empty($filtered)) {
            TelemetryService::incrementCounter('ai_detections');
            return $filtered;
        }

        return null;
    }

    /**
     * Detect field types with complete faker configs
     */
    public function detectFieldsBatchWithConfig(
        array $fields,
        string $postType,
        ?string $postTypeLabel = null,
        ?string $locale = null
    ): ?array {
        if (!$this->isAvailable() || empty($fields)) {
            return null;
        }

        $prompt = $this->buildBatchConfigPrompt($fields, $postType, $postTypeLabel, $locale);
        $result = $this->callApiWithJsonMode($prompt, 0.1, 4096);

        if (!$result) {
            return null;
        }

        $parsed = $this->parseJsonResponse($result);

        if (!$parsed || !is_array($parsed)) {
            return null;
        }

        // Validate and filter results
        $filtered = [];
        foreach ($parsed as $fieldName => $config) {
            if (!is_array($config) || empty($config['method'])) {
                continue;
            }
            $filtered[$fieldName] = [
                'method' => $config['method'],
                'params' => $config['params'] ?? [],
                'confidence' => (float) ($config['confidence'] ?? 0.5),
            ];
        }

        return !empty($filtered) ? $filtered : null;
    }

    /**
     * Generate title templates for a CPT using AI
     */
    public function generateTitleTemplates(
        string $postType,
        ?string $postTypeLabel = null,
        ?string $locale = null,
        ?array $cptContext = null
    ): ?array {
        if (!$this->isAvailable()) {
            return null;
        }

        // Check cache first (24h duration — templates are stable)
        $cacheKey = 'wpfaker_ai_titles_' . md5($postType . '|' . ($locale ?? ''));
        $cached = get_transient($cacheKey);
        if ($cached !== false) {
            return $cached;
        }

        $prompt = $this->buildTitleTemplatePrompt($postType, $postTypeLabel, $locale, $cptContext);
        $result = $this->callApiWithJsonMode($prompt, 0.5, 4096);

        if (!$result) {
            error_log("WPFaker Titles: AI call returned null for CPT '{$postType}'");
            return null;
        }

        $parsed = $this->parseJsonResponse($result);

        if (!$parsed || empty($parsed['templates']) || empty($parsed['data'])) {
            error_log("WPFaker Titles: AI response missing templates/data for CPT '{$postType}': " . substr((string) $result, 0, 200));
            return null;
        }

        // Transform into the standard format: array of ['template' => ..., 'placeholderData' => ...]
        $templates = [];
        foreach ($parsed['templates'] as $template) {
            if (!is_string($template) || empty($template)) {
                continue;
            }
            // Validate template contains at least one placeholder
            if (!str_contains($template, '{')) {
                error_log("WPFaker Titles: Skipping template without placeholders: '{$template}'");
                continue;
            }
            $templates[] = [
                'template' => $template,
                'placeholderData' => $parsed['data'],
            ];
        }

        if (empty($templates)) {
            error_log("WPFaker Titles: No valid templates after filtering for CPT '{$postType}'");
            return null;
        }

        // Cache for 24 hours
        set_transient($cacheKey, $templates, 86400);

        return $templates;
    }

    /**
     * Generate comprehensive CPT context for unknown/niche post types
     */
    public function generateCptContext(
        string $cptSlug,
        ?string $cptLabel = null,
        ?string $locale = null,
        ?array $taxonomies = null,
        ?array $parentCptInfo = null
    ): ?array {
        if (!$this->isAvailable()) {
            return null;
        }

        $prompt = $this->buildCptContextPrompt($cptSlug, $cptLabel, $locale, $taxonomies, $parentCptInfo);
        $result = $this->callApiWithJsonMode($prompt, 0.5, 4096);

        if (!$result) {
            error_log("WPFaker CptContext: AI call failed for CPT '{$cptSlug}'");
            return null;
        }

        $parsed = $this->parseJsonResponse($result);

        if (!$parsed || !is_array($parsed)) {
            error_log("WPFaker CptContext: Failed to parse AI response for CPT '{$cptSlug}'");
            return null;
        }

        // Validate required fields
        if (empty($parsed['domain']) || empty($parsed['topics'])) {
            error_log("WPFaker CptContext: AI response missing required fields for CPT '{$cptSlug}'");
            return null;
        }

        // Normalize structure with defaults
        return [
            'domain'         => $parsed['domain'],
            'description'    => $parsed['description'] ?? '',
            'topics'         => (array) ($parsed['topics'] ?? []),
            'image_keywords' => (array) ($parsed['image_keywords'] ?? []),
            'comment_tones'  => (array) ($parsed['comment_tones'] ?? []),
            'content_themes' => (array) ($parsed['content_themes'] ?? []),
            'term_seeds'     => (array) ($parsed['term_seeds'] ?? []),
        ];
    }

    /**
     * Test the API connection
     */
    public function testConnection(): array
    {
        if (empty($this->apiKey)) {
            return [
                'success' => false,
                'message' => __('API key is not configured', 'wpfaker'),
            ];
        }

        $prompt = 'Respond with exactly: {"status": "ok"}';
        $this->lastError = null;
        $result = $this->callApi($prompt, 0, 50);

        if ($result !== null) {
            return [
                'success' => true,
                'message' => sprintf(
                    __('Connection successful! %s is ready to use.', 'wpfaker'),
                    $this->getProviderName()
                ),
            ];
        }

        return [
            'success' => false,
            'message' => $this->lastError
                ?? __('Connection failed. Please check your API key.', 'wpfaker'),
        ];
    }

    // =========================================================================
    // Abstract methods — each provider implements these
    // =========================================================================

    /**
     * Call the provider's API and return raw response text
     *
     * @param string $prompt The prompt to send
     * @param float $temperature Temperature setting
     * @param int $maxTokens Maximum tokens in response
     * @return string|null Raw text response, or null on failure
     */
    abstract protected function callApi(string $prompt, float $temperature, int $maxTokens): ?string;

    /**
     * Call the provider's API with JSON mode enabled (if supported)
     *
     * Providers without native JSON mode should fall back to callApi().
     *
     * @param string $prompt The prompt to send
     * @param float $temperature Temperature setting
     * @param int $maxTokens Maximum tokens in response
     * @return string|null Raw text response, or null on failure
     */
    abstract protected function callApiWithJsonMode(string $prompt, float $temperature, int $maxTokens): ?string;

    // =========================================================================
    // Static methods — shared across all providers
    // =========================================================================

    /**
     * Get current settings
     */
    public static function getSettings(): array
    {
        $settings = get_option(self::OPTION_NAME, []);
        return [
            'enabled' => !empty($settings['enabled']),
            'provider' => $settings['provider'] ?? 'gemini',
            'has_api_key' => !empty($settings['gemini_api_key']) || !empty($settings['api_key']),
            'hive_enabled' => !empty($settings['hive_enabled']),
            'providers' => [
                'gemini' => [
                    'has_api_key' => !empty($settings['gemini_api_key']) || !empty($settings['api_key']),
                ],
                'anthropic' => [
                    'has_api_key' => !empty($settings['anthropic_api_key']),
                ],
                'openai' => [
                    'has_api_key' => !empty($settings['openai_api_key']),
                ],
            ],
        ];
    }

    /**
     * Save settings
     */
    public static function saveSettings(array $settings): bool
    {
        $existing = get_option(self::OPTION_NAME, []);

        $newSettings = [
            'enabled' => !empty($settings['enabled']),
            'provider' => sanitize_text_field($settings['provider'] ?? ($existing['provider'] ?? 'gemini')),
            'hive_enabled' => !empty($settings['hive_enabled']),
        ];

        // Handle per-provider API keys — only update if provided
        foreach (['gemini', 'anthropic', 'openai'] as $provider) {
            $keyField = $provider . '_api_key';
            if (!empty($settings[$keyField])) {
                $newSettings[$keyField] = sanitize_text_field($settings[$keyField]);
            } else {
                // Preserve existing key
                $newSettings[$keyField] = $existing[$keyField] ?? '';
            }
        }

        // Backward compat: if 'api_key' is provided (old format), map to gemini
        if (!empty($settings['api_key']) && empty($settings['gemini_api_key'])) {
            $newSettings['gemini_api_key'] = sanitize_text_field($settings['api_key']);
        }

        return update_option(self::OPTION_NAME, $newSettings);
    }

    /**
     * Clear all AI detection caches
     */
    public static function clearCache(): void
    {
        global $wpdb;
        $wpdb->query(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wpfaker_ai_%'"
        );
        $wpdb->query(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_wpfaker_ai_%'"
        );
    }

    // =========================================================================
    // Shared prompt builders
    // =========================================================================

    /**
     * Build the detection prompt for a single field
     */
    protected function buildDetectionPrompt(
        string $fieldName,
        string $fieldLabel,
        string $fieldType,
        ?string $locale,
        ?string $postType = null
    ): string {
        $localeInfo = $locale ? "Generate data in locale: {$locale}" : "Generate data in German (de_DE) by default";
        $cptInfo = $postType ? "Post Type: {$postType}\n" : '';

        return <<<PROMPT
You are a data type detector for a WordPress fake data generator. Analyze the following field and determine what type of fake data should be generated.

{$cptInfo}Field Name: {$fieldName}
Field Label: {$fieldLabel}
Field Type: {$fieldType}
{$localeInfo}

Based on the field name and label, determine the most appropriate fake data type from this list:
- iban: International Bank Account Number (e.g., DE89370400440532013000)
- bic: Bank Identifier Code / SWIFT (e.g., COBADEFFXXX)
- bank_name: Name of a bank (e.g., Deutsche Bank, Sparkasse)
- credit_card: Credit card number
- first_name: Person's first name
- last_name: Person's last name
- full_name: Person's full name
- salutation: Mr., Mrs., Herr, Frau, etc.
- email: Email address
- phone: Phone number
- website: Website URL
- street: Street name
- house_number: Building/house number
- postal_code: Postal/ZIP code
- city: City name
- state: State/Province/Bundesland
- country: Country name
- address: Full address
- latitude: Geographic latitude
- longitude: Geographic longitude
- company: Company name
- job_title: Job title/position
- vat_number: VAT/Tax ID number
- username: User login name
- password: Password
- date: Date value
- time: Time value
- year: Year value
- price: Price/monetary amount
- percentage: Percentage value
- area: Area measurement (square meters)
- count: Count/quantity number
- title: Title/heading text
- description: Description/longer text
- content: Full content/article text
- reference_code: Reference/ID code
- product_name: Product/item name (not a person's name)
- sku: SKU/article number/product code
- brand: Brand/manufacturer name
- model: Product model designation
- ean: EAN/barcode/GTIN number
- isbn: ISBN book number
- rating: Rating/review score (1-5)
- stock: Stock/inventory quantity
- discount: Discount/rebate percentage
- event_name: Event/conference name
- project_name: Project/initiative name
- unknown: Cannot determine, use default text

Respond with ONLY a JSON object in this exact format (no markdown, no explanation):
{"type": "detected_type", "confidence": 0.95}

Where "type" is one of the types listed above, and "confidence" is a number between 0 and 1.
PROMPT;
    }

    /**
     * Build prompt for batch field detection
     */
    protected function buildBatchDetectionPrompt(
        array $fields,
        string $postType,
        ?string $postTypeLabel,
        ?string $locale
    ): string {
        $localeInfo = $locale ? "Locale: {$locale}" : "Default locale: de_DE";
        $cptInfo = $postTypeLabel ? "{$postType} ({$postTypeLabel})" : $postType;

        $fieldList = '';
        foreach ($fields as $field) {
            $fieldList .= sprintf(
                "- Name: %s | Label: %s | Type: %s\n",
                $field['name'],
                $field['label'] ?? '',
                $field['type'] ?? 'text'
            );
        }

        return <<<PROMPT
You are a data type detector for a WordPress fake data generator. Analyze ALL the following fields that belong to the custom post type "{$cptInfo}" and determine what type of fake data should be generated for each.

{$localeInfo}

Fields to analyze:
{$fieldList}

Determine the most appropriate fake data type for EACH field from this list:
- iban, bic, bank_name, credit_card
- first_name, last_name, full_name, salutation, gender, birthday, age
- email, phone, website
- street, house_number, postal_code, city, state, country, address, latitude, longitude
- company, company_suffix, job_title, department, vat_number
- username, password, ip_address, uuid, slug
- date, time, year
- price, percentage, area, weight, height, width, length, count, floor, rooms
- object_number, commission, energy_class, heating_type
- title, description, summary, notes, content
- reference_code
- product_name, sku, brand, model, ean, isbn, rating, stock, discount
- event_name, project_name, category_name
- unknown: Cannot determine

Respond with ONLY a JSON object in this exact format (no markdown, no explanation):
{"field_name_1": {"type": "detected_type", "confidence": 0.95}, "field_name_2": {"type": "detected_type", "confidence": 0.90}}

Use the actual field names as keys.
PROMPT;
    }

    /**
     * Build prompt for batch field detection with faker configs
     */
    protected function buildBatchConfigPrompt(
        array $fields,
        string $postType,
        ?string $postTypeLabel,
        ?string $locale
    ): string {
        $localeInfo = $locale ? "Locale: {$locale}" : "Default locale: de_DE";
        $cptInfo = $postTypeLabel ? "{$postType} ({$postTypeLabel})" : $postType;

        $fieldList = '';
        foreach ($fields as $field) {
            $fieldList .= sprintf(
                "- Name: %s | Label: %s | Type: %s\n",
                $field['name'],
                $field['label'] ?? '',
                $field['type'] ?? 'text'
            );
        }

        return <<<PROMPT
You are a fake data configuration expert for a WordPress plugin using FakerPHP. Analyze the following fields belonging to the custom post type "{$cptInfo}" and return the BEST FakerPHP method with domain-appropriate parameters for each field.

{$localeInfo}

Fields to analyze:
{$fieldList}

IMPORTANT: Consider the CPT domain context! A "year" field in a Cars CPT should generate manufacturing years (2005-2026), not random years. A "mileage" field should generate realistic mileage (5000-250000), not random small numbers.

CRITICAL RULE FOR TEXT FIELDS:
For text/textarea/wysiwyg fields that have domain-specific content (names, types, titles, categories, descriptions, summaries, notes, labels, statuses, etc.), ALWAYS use "randomElement" with 8-10 realistic seed values instead of "sentence", "paragraph", or "text".
Only use "sentence"/"paragraph"/"text" for truly generic fields with no clear domain meaning.
Maximum 10 seed values per randomElement array (the system will automatically expand small lists to 80+ values).

Allowed FakerPHP methods (use ONLY these):
- numberBetween(min, max) — integer in range
- randomFloat(decimals, min, max) — float with precision
- randomDigit() — single digit 0-9
- randomNumber(nbDigits, strict) — number with N digits
- regexify(regex) — string from regex pattern
- bothify(pattern) — replace # with digit, ? with letter
- numerify(pattern) — replace # with digit
- lexify(pattern) — replace ? with letter
- sentence(nbWords) — sentence with N words
- word() — single word
- words(nb, asText) — multiple words
- paragraph(nbSentences) — paragraph
- paragraphs(nb, asText) — multiple paragraphs
- text(maxNbChars) — text up to N chars
- name() — full person name
- firstName() — first name
- lastName() — last name
- email() — email address
- safeEmail() — safe email
- phoneNumber() — phone number
- url() — URL
- address() — full address
- streetName() — street name
- city() — city name
- postcode() — postal code
- country() — country name
- company() — company name
- jobTitle() — job title
- iban(countryCode) — IBAN number
- swiftBicNumber() — SWIFT/BIC
- creditCardNumber() — credit card
- uuid() — UUID
- ean13() — EAN-13 barcode
- isbn13() — ISBN-13
- ipv4() — IPv4 address
- macAddress() — MAC address
- slug(nbWords) — URL slug
- date(format, max) — date string
- time(format) — time string
- year(max) — year
- dateTimeBetween(startDate, endDate) — datetime in range
- randomElement(array) — pick from array
- randomElements(array, count) — pick N from array
- boolean(chanceOfTrue) — true/false
- hexColor() — hex color
- latitude(min, max) — latitude
- longitude(min, max) — longitude

Respond with a JSON object where each key is the field name and the value contains:
- "method": the FakerPHP method name (from the list above)
- "params": array of parameters for the method (use domain-appropriate values!)
- "confidence": float 0-1 indicating confidence

Example for a Volcanoes CPT:
{"volcano_name": {"method": "randomElement", "params": [["Mount Vesuvius", "Mount Etna", "Mount Fuji", "Krakatoa", "Eyjafjallajökull", "Kilauea", "Mount St. Helens", "Pinatubo"]], "confidence": 0.95}, "eruption_type": {"method": "randomElement", "params": [["Effusive", "Explosive", "Phreatic", "Strombolian", "Vulcanian", "Plinian", "Hawaiian", "Surtseyan"]], "confidence": 0.95}, "eruption_description": {"method": "randomElement", "params": [["Violent eruption with pyroclastic flows", "Slow lava flow reaching nearby villages", "Minor steam eruption with ash clouds", "Submarine eruption forming new island", "Explosive event with massive ash column", "Effusive eruption with lava fountains", "Phreatic blast triggered by groundwater", "Caldera collapse after magma drainage"]], "confidence": 0.90}, "elevation_meters": {"method": "numberBetween", "params": [500, 6800], "confidence": 0.95}}

Skip fields you cannot determine a good method for. Only include fields where confidence >= 0.7.
PROMPT;
    }

    /**
     * Build prompt for AI title template generation
     */
    protected function buildTitleTemplatePrompt(
        string $postType,
        ?string $postTypeLabel,
        ?string $locale,
        ?array $cptContext = null
    ): string {
        $localeDescription = $locale ?: 'en_US';
        $langName = match (substr($localeDescription, 0, 2)) {
            'de' => 'German',
            'fr' => 'French',
            'es' => 'Spanish',
            'it' => 'Italian',
            'nl' => 'Dutch',
            'pt' => 'Portuguese',
            'pl' => 'Polish',
            'ru' => 'Russian',
            'ja' => 'Japanese',
            'zh' => 'Chinese',
            default => 'English',
        };
        $labelInfo = $postTypeLabel ? " (Label: {$postTypeLabel})" : '';

        $domainContext = '';
        if ($cptContext) {
            $domain = $cptContext['domain'] ?? '';
            $description = $cptContext['description'] ?? '';
            $topics = !empty($cptContext['topics']) ? implode(', ', $cptContext['topics']) : '';
            if ($domain || $description || $topics) {
                $domainContext = "\n\nDomain Context:";
                if ($domain) {
                    $domainContext .= "\n- Domain: {$domain}";
                }
                if ($description) {
                    $domainContext .= "\n- Description: {$description}";
                }
                if ($topics) {
                    $domainContext .= "\n- Related topics: {$topics}";
                }
                $domainContext .= "\nUse this context to generate domain-appropriate title templates.";
            }
        }

        return <<<PROMPT
You are a title template generator for a WordPress fake content generator plugin.

Given a Custom Post Type (CPT), create 5 realistic title templates that look like authentic listings or entries someone would create in a real WordPress site for this type of content.

CPT Slug: {$postType}{$labelInfo}
Language/Locale: {$localeDescription} ({$langName}){$domainContext}

Rules:
- Templates use {placeholder} syntax for variable parts
- Each placeholder needs an array of 8-15 realistic replacement values
- Provide ALL values in {$langName}
- Use "FAKER_CITY" as a placeholder value to indicate it should be replaced by a locale-aware city name from Faker
- Use "FAKER_YEAR" as a placeholder value for a realistic year
- Titles should be concise (3-10 words) and look like real content titles
- Consider the domain: real estate titles differ from recipe titles differ from product titles
- Do NOT use generic placeholders like "word1" — use meaningful names like "brand", "color", "material"
- Do NOT generate literary text, Lorem ipsum, or generic filler
- Every template MUST contain at least one {placeholder}

Respond with ONLY valid JSON (no markdown, no explanation):
{
  "templates": [
    "template string with {placeholders}",
    "another {template} string"
  ],
  "data": {
    "placeholder_name": ["value1", "value2", "value3", "value4", "value5", "value6", "value7", "value8"],
    "another_placeholder": ["value1", "value2", "value3", "value4", "value5", "value6", "value7", "value8"]
  }
}
PROMPT;
    }

    /**
     * Build prompt for CPT context generation
     */
    protected function buildCptContextPrompt(
        string $cptSlug,
        ?string $cptLabel,
        ?string $locale,
        ?array $taxonomies,
        ?array $parentCptInfo = null
    ): string {
        $localeDescription = $locale ?: 'en_US';
        $langName = match (substr($localeDescription, 0, 2)) {
            'de' => 'German',
            'fr' => 'French',
            'es' => 'Spanish',
            'it' => 'Italian',
            'nl' => 'Dutch',
            'pt' => 'Portuguese',
            'pl' => 'Polish',
            'ru' => 'Russian',
            'ja' => 'Japanese',
            'zh' => 'Chinese',
            default => 'English',
        };
        $labelInfo = $cptLabel ? " (Label: {$cptLabel})" : '';

        $taxonomySection = '';
        if (!empty($taxonomies)) {
            $taxList = implode(', ', $taxonomies);
            $taxonomySection = <<<SECTION

This CPT has the following taxonomies registered: {$taxList}
For each taxonomy slug, provide 10-15 realistic term names in the "term_seeds" object.
SECTION;
        }

        $parentSection = '';
        if ($parentCptInfo) {
            $parentSlug = $parentCptInfo['slug'] ?? '';
            $parentLabel = $parentCptInfo['label'] ?? $parentSlug;
            $parentContext = $parentCptInfo['context'] ?? [];
            $parentDomain = $parentContext['domain'] ?? '';
            $parentTopics = !empty($parentContext['topics']) ? implode(', ', $parentContext['topics']) : '';

            $parentSection = "\n\nCRITICAL — RELATIONAL CONTEXT (THIS OVERRIDES GENERIC INTERPRETATION):";
            $parentSection .= "\nThis \"{$cptSlug}\" CPT exists SPECIFICALLY in the context of \"{$parentLabel}\"";
            if ($parentDomain) {
                $parentSection .= " (domain: \"{$parentDomain}\")";
            }
            $parentSection .= ".";
            $parentSection .= "\nDo NOT generate generic \"{$cptSlug}\" context. Instead, generate context for \"{$cptSlug}\" AS USED WITHIN the \"{$parentLabel}\" domain.";
            $parentSection .= "\nExample: if parent is \"Volcanoes\" and this CPT is \"satellites\", the domain should be \"volcanological remote sensing\" — NOT generic \"aerospace\".";
            $parentSection .= "\nExample: if parent is \"Volcanoes\" and this CPT is \"fossils\", the domain should be \"volcanic paleontology\" — NOT generic \"paleontology\".";
            $parentSection .= "\nThe domain, topics, image_keywords, and ALL other fields MUST reflect the relationship to \"{$parentLabel}\".";
            if ($parentDomain) {
                $parentSection .= "\nParent domain: {$parentDomain}";
            }
            if ($parentTopics) {
                $parentSection .= "\nParent topics: {$parentTopics}";
            }
        }

        return <<<PROMPT
You are a domain analyst for a WordPress fake content generator plugin. Given a Custom Post Type (CPT), analyze its domain and generate a comprehensive context object that helps ALL content pipelines produce relevant, realistic fake data.

CPT Slug: {$cptSlug}{$labelInfo}
Language/Locale: {$localeDescription} ({$langName})
{$taxonomySection}{$parentSection}

Generate a JSON context object with these fields:
- "domain": The primary domain/industry (1-2 words, e.g. "geology", "culinary arts", "real estate")
- "description": Brief description of what this CPT represents (1 sentence)
- "topics": Array of 8-12 specific topics/subjects within this domain (used for content generation)
- "image_keywords": Array of 3-5 search queries for finding relevant stock photos (each 2-4 words)
- "comment_tones": Array of 3-4 appropriate comment tones (e.g. "scientific", "enthusiastic", "professional")
- "content_themes": Array of 5-8 themes that articles/posts about this topic would cover
- "term_seeds": Object where each key is a taxonomy slug (if taxonomies provided) with an array of 10-15 realistic term names in {$langName}

All text values (topics, themes, term names) MUST be in {$langName}.

Examples:

For CPT "volcanoes" with taxonomy "eruption_types":
{
  "domain": "geology",
  "description": "Volcanoes and volcanic activity around the world",
  "topics": ["eruptions", "magma chambers", "tectonic plates", "lava flows", "pyroclastic flows", "volcanic ash", "calderas", "geothermal energy", "seismic activity", "volcanic islands"],
  "image_keywords": ["volcano eruption lava", "volcanic landscape crater", "magma geological", "volcanic island aerial", "lava flow nature"],
  "comment_tones": ["scientific", "observational", "educational", "curious"],
  "content_themes": ["geological formation processes", "eruption history and prediction", "safety zones and evacuation", "environmental impact", "geothermal energy potential", "famous volcanoes worldwide"],
  "term_seeds": {"eruption_types": ["Effusive", "Explosive", "Phreatic", "Strombolian", "Vulcanian", "Plinian", "Hawaiian", "Surtseyan", "Submarine", "Hydrothermal"]}
}

For CPT "recipes" with taxonomies "cuisine", "difficulty":
{
  "domain": "culinary arts",
  "description": "Cooking recipes and food preparation guides",
  "topics": ["ingredients", "cooking techniques", "flavor profiles", "meal planning", "nutrition", "plating", "seasoning", "baking", "fermentation", "food pairing"],
  "image_keywords": ["cooking food preparation", "gourmet dish plated", "fresh ingredients kitchen", "recipe meal closeup"],
  "comment_tones": ["enthusiastic", "helpful", "appreciative", "conversational"],
  "content_themes": ["step-by-step preparation", "ingredient substitutions", "cooking tips and tricks", "nutritional information", "serving suggestions", "storage and leftovers"],
  "term_seeds": {"cuisine": ["Italian", "Japanese", "Mexican", "French", "Thai", "Indian", "Mediterranean", "Chinese", "Korean", "Middle Eastern", "Greek", "Vietnamese"], "difficulty": ["Beginner", "Easy", "Intermediate", "Advanced", "Expert"]}
}

Respond with ONLY valid JSON (no markdown, no explanation).
PROMPT;
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    /**
     * Generate cache key for a field
     */
    protected function getCacheKey(string $fieldName, string $fieldLabel, ?string $locale): string
    {
        return 'wpfaker_ai_' . md5($fieldName . '|' . $fieldLabel . '|' . ($locale ?? ''));
    }

    /**
     * Parse a JSON response, handling potential markdown wrapping
     */
    protected function parseJsonResponse(string $text): ?array
    {
        $text = trim($text);

        // Strip markdown code fences if present
        if (str_starts_with($text, '```')) {
            $text = preg_replace('/^```(?:json)?\s*/', '', $text);
            $text = preg_replace('/\s*```$/', '', $text);
            $text = trim($text);
        }

        $result = json_decode($text, true);

        if ($result !== null) {
            return $result;
        }

        // Try to extract JSON from the response if it contains extra text
        if (preg_match('/\{[\s\S]*\}/', $text, $matches)) {
            $result = json_decode($matches[0], true);
        }

        return $result;
    }

    /**
     * Make an HTTP request with error logging
     *
     * @param string $url The endpoint URL
     * @param array $args wp_remote_post arguments
     * @param string $context Log context string
     * @return array|null Response data or null on failure
     */
    protected function httpPost(string $url, array $args, string $context = ''): ?array
    {
        $response = wp_remote_post($url, $args);

        if (is_wp_error($response)) {
            $this->lastError = $response->get_error_message();
            error_log("WPFaker {$context} API error: " . $this->lastError);
            return null;
        }

        $statusCode = wp_remote_retrieve_response_code($response);
        if ($statusCode !== 200) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            $errorMessage = $body['error']['message'] ?? ($body['error']['type'] ?? 'Unknown error');
            $this->lastError = sprintf(__('API Error (%d): %s', 'wpfaker'), $statusCode, $errorMessage);
            error_log("WPFaker {$context} API returned status {$statusCode}: {$errorMessage}");
            return null;
        }

        $responseBody = wp_remote_retrieve_body($response);
        return json_decode($responseBody, true);
    }
}
