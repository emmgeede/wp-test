<?php

namespace WPFaker\Services;

use WPFaker\Schema\FieldConfigSchema;

/**
 * Template Service
 *
 * Manages post generation templates with taxonomy and field configuration.
 */
class TemplateService
{
    /**
     * Database table name (without prefix)
     */
    protected const TABLE_NAME = 'wpfaker_templates';

    /**
     * Get the full table name with prefix
     *
     * @return string
     */
    public static function getTableName(): string
    {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_NAME;
    }

    /**
     * Create the templates table
     *
     * @return void
     */
    public static function createTable(): void
    {
        global $wpdb;

        $tableName = self::getTableName();
        $charsetCollate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$tableName} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            slug VARCHAR(255) NOT NULL,
            description TEXT,
            post_type VARCHAR(100) NOT NULL DEFAULT 'post',
            config LONGTEXT NOT NULL,
            taxonomy_config LONGTEXT NOT NULL,
            field_config LONGTEXT,
            is_default TINYINT(1) DEFAULT 0,
            is_system TINYINT(1) DEFAULT 0,
            parent_id BIGINT(20) UNSIGNED DEFAULT NULL,
            config_overrides LONGTEXT,
            author_id BIGINT(20) UNSIGNED,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug),
            KEY post_type (post_type),
            KEY is_default (is_default),
            KEY parent_id (parent_id),
            KEY author_id (author_id)
        ) {$charsetCollate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Drop the templates table
     *
     * @return void
     */
    public static function dropTable(): void
    {
        global $wpdb;
        $tableName = self::getTableName();
        $wpdb->query("DROP TABLE IF EXISTS {$tableName}");
    }

    /**
     * Run migrations to update the table schema
     *
     * @return void
     */
    public static function runMigrations(): void
    {
        global $wpdb;

        $tableName = self::getTableName();

        // Check if field_config column exists
        $columnExists = $wpdb->get_results(
            $wpdb->prepare(
                "SHOW COLUMNS FROM {$tableName} LIKE %s",
                'field_config'
            )
        );

        if (empty($columnExists)) {
            // Add field_config column after taxonomy_config
            $wpdb->query("ALTER TABLE {$tableName} ADD COLUMN field_config LONGTEXT AFTER taxonomy_config");
        }

        // Add parent_id column if not exists
        $parentIdExists = $wpdb->get_results(
            $wpdb->prepare("SHOW COLUMNS FROM {$tableName} LIKE %s", 'parent_id')
        );
        if (empty($parentIdExists)) {
            $wpdb->query("ALTER TABLE {$tableName} ADD COLUMN parent_id BIGINT(20) UNSIGNED DEFAULT NULL AFTER is_system");
            $wpdb->query("ALTER TABLE {$tableName} ADD KEY parent_id (parent_id)");
        }

        // Add config_overrides column if not exists
        $overridesExists = $wpdb->get_results(
            $wpdb->prepare("SHOW COLUMNS FROM {$tableName} LIKE %s", 'config_overrides')
        );
        if (empty($overridesExists)) {
            $wpdb->query("ALTER TABLE {$tableName} ADD COLUMN config_overrides LONGTEXT AFTER parent_id");
        }
    }

    /**
     * Create a new template
     *
     * @param array $data Template data
     * @return int|false The inserted template ID or false on failure
     */
    public function create(array $data): int|false
    {
        global $wpdb;

        $name = sanitize_text_field($data['name'] ?? '');
        $slug = $this->generateUniqueSlug($data['slug'] ?? $name);
        $description = sanitize_textarea_field($data['description'] ?? '');
        $postType = sanitize_key($data['post_type'] ?? 'post');
        $config = $data['config'] ?? [];
        $taxonomyConfig = $data['taxonomy_config'] ?? [];
        $fieldConfig = $data['field_config'] ?? FieldConfigSchema::getDefaultFieldConfig();
        $isDefault = !empty($data['is_default']);
        $isSystem = !empty($data['is_system']);
        $authorId = get_current_user_id();

        if (empty($name)) {
            return false;
        }

        // Auto-set as default if this is the first template for this post type
        if (!$isDefault) {
            $existingCount = $this->getCount(['post_type' => $postType]);
            if ($existingCount === 0) {
                $isDefault = true;
            }
        }

        // If setting as default, unset other defaults for this post type
        if ($isDefault) {
            $this->unsetDefaultsForPostType($postType);
        }

        $result = $wpdb->insert(
            self::getTableName(),
            [
                'name'            => $name,
                'slug'            => $slug,
                'description'     => $description,
                'post_type'       => $postType,
                'config'          => json_encode($config),
                'taxonomy_config' => json_encode($taxonomyConfig),
                'field_config'    => json_encode($fieldConfig),
                'is_default'      => $isDefault ? 1 : 0,
                'is_system'       => $isSystem ? 1 : 0,
                'author_id'       => $authorId,
                'created_at'      => current_time('mysql'),
                'updated_at'      => current_time('mysql'),
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%s', '%s']
        );

        return $result ? $wpdb->insert_id : false;
    }

    /**
     * Update an existing template
     *
     * @param int $id Template ID
     * @param array $data Template data
     * @return bool
     */
    public function update(int $id, array $data): bool
    {
        global $wpdb;

        $existing = $this->get($id);
        if (!$existing) {
            return false;
        }

        // Don't allow editing system templates
        if ($existing['is_system']) {
            return false;
        }

        $updateData = [];
        $updateFormats = [];

        if (isset($data['name'])) {
            $updateData['name'] = sanitize_text_field($data['name']);
            $updateFormats[] = '%s';
        }

        if (isset($data['slug'])) {
            $newSlug = $this->generateUniqueSlug($data['slug'], $id);
            $updateData['slug'] = $newSlug;
            $updateFormats[] = '%s';
        }

        if (isset($data['description'])) {
            $updateData['description'] = sanitize_textarea_field($data['description']);
            $updateFormats[] = '%s';
        }

        if (isset($data['post_type'])) {
            $updateData['post_type'] = sanitize_key($data['post_type']);
            $updateFormats[] = '%s';
        }

        if (isset($data['config'])) {
            $updateData['config'] = json_encode($data['config']);
            $updateFormats[] = '%s';
        }

        if (isset($data['taxonomy_config'])) {
            $updateData['taxonomy_config'] = json_encode($data['taxonomy_config']);
            $updateFormats[] = '%s';
        }

        if (isset($data['field_config'])) {
            $updateData['field_config'] = json_encode($data['field_config']);
            $updateFormats[] = '%s';
        }

        if (isset($data['is_default'])) {
            $isDefault = !empty($data['is_default']);
            if ($isDefault) {
                $postType = $data['post_type'] ?? $existing['post_type'];
                $this->unsetDefaultsForPostType($postType, $id);
            }
            $updateData['is_default'] = $isDefault ? 1 : 0;
            $updateFormats[] = '%d';
        }

        $updateData['updated_at'] = current_time('mysql');
        $updateFormats[] = '%s';

        if (empty($updateData)) {
            return true;
        }

        $result = $wpdb->update(
            self::getTableName(),
            $updateData,
            ['id' => $id],
            $updateFormats,
            ['%d']
        );

        if ($result === false) {
            return false;
        }

        // Fire event for each newly linked CPT so siblings get unlinked
        if (isset($data['config']['related_cpt_options'])) {
            $postType = $existing['post_type'];
            $oldOpts = $existing['config']['related_cpt_options'] ?? [];
            $newOpts = $data['config']['related_cpt_options'] ?? [];

            foreach ($newOpts as $targetCpt => $cptConfig) {
                if (!is_array($cptConfig)) {
                    continue;
                }
                $newTemplateId = $cptConfig['template_id'] ?? null;
                $oldTemplateId = $oldOpts[$targetCpt]['template_id'] ?? null;

                // Only fire when a link is newly established or changed
                if ($newTemplateId && $newTemplateId !== $oldTemplateId) {
                    do_action('wpfaker_template_cpt_linked', $id, $postType, $targetCpt, $newTemplateId);
                }
            }
        }

        return true;
    }

    /**
     * Delete a template
     *
     * @param int $id Template ID
     * @return bool
     */
    public function delete(int $id): bool
    {
        global $wpdb;

        $existing = $this->get($id);
        if (!$existing) {
            return false;
        }

        // Don't allow deleting system templates
        if ($existing['is_system']) {
            return false;
        }

        // Cascade-delete variants if this is a root template
        if ($existing['parent_id'] === null) {
            $variants = $this->getVariantsForTemplate($id);
            foreach ($variants as $variant) {
                $this->unlinkTemplateReferences($variant['id']);
                $wpdb->delete(self::getTableName(), ['id' => $variant['id']], ['%d']);
            }
        }

        // Remove references to this template from other templates' related_cpt_options
        $this->unlinkTemplateReferences($id);

        $result = $wpdb->delete(
            self::getTableName(),
            ['id' => $id],
            ['%d']
        );

        return $result !== false;
    }

    /**
     * Delete a default template with transfer of default status to another template.
     *
     * @param int $id Template ID to delete
     * @param int|null $newDefaultId Template ID to promote as new default (null for auto-promote or last-template)
     * @return array{success: bool, variants_deleted: int, error?: string}
     */
    public function deleteWithDefaultTransfer(int $id, ?int $newDefaultId = null): array
    {
        $template = $this->get($id);
        if (!$template) {
            return ['success' => false, 'variants_deleted' => 0, 'error' => 'template_not_found'];
        }

        if ($template['is_system']) {
            return ['success' => false, 'variants_deleted' => 0, 'error' => 'cannot_delete_system'];
        }

        // Count variants before deletion
        $variants = $template['parent_id'] === null ? $this->getVariantsForTemplate($id) : [];
        $variantCount = count($variants);

        // Handle default transfer if this is the default template
        if ($template['is_default'] && $newDefaultId !== null) {
            $newDefault = $this->get($newDefaultId);
            if (!$newDefault) {
                return ['success' => false, 'variants_deleted' => 0, 'error' => 'new_default_not_found'];
            }

            // Must be same post type
            if ($newDefault['post_type'] !== $template['post_type']) {
                return ['success' => false, 'variants_deleted' => 0, 'error' => 'cross_post_type_transfer'];
            }

            // Must be a root template
            if ($newDefault['parent_id'] !== null) {
                return ['success' => false, 'variants_deleted' => 0, 'error' => 'cannot_promote_variant'];
            }

            $this->setDefault($newDefaultId);
        }

        $deleted = $this->delete($id);

        if (!$deleted) {
            return ['success' => false, 'variants_deleted' => 0, 'error' => 'delete_failed'];
        }

        return ['success' => true, 'variants_deleted' => $variantCount];
    }

    /**
     * Get a template by ID
     *
     * @param int $id Template ID
     * @return array|null
     */
    public function get(int $id): ?array
    {
        global $wpdb;

        $tableName = self::getTableName();
        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$tableName} WHERE id = %d", $id),
            ARRAY_A
        );

        return $row ? $this->formatTemplate($row) : null;
    }

    /**
     * Get a template by slug
     *
     * @param string $slug Template slug
     * @return array|null
     */
    public function getBySlug(string $slug): ?array
    {
        global $wpdb;

        $tableName = self::getTableName();
        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$tableName} WHERE slug = %s", $slug),
            ARRAY_A
        );

        return $row ? $this->formatTemplate($row) : null;
    }

    /**
     * Get all templates
     *
     * @param array $filters Optional filters (post_type, is_default, is_system)
     * @return array
     */
    public function getAll(array $filters = []): array
    {
        global $wpdb;

        $tableName = self::getTableName();
        $where = [];
        $params = [];

        if (isset($filters['post_type'])) {
            $where[] = 'post_type = %s';
            $params[] = $filters['post_type'];
        }

        if (isset($filters['is_default'])) {
            $where[] = 'is_default = %d';
            $params[] = $filters['is_default'] ? 1 : 0;
        }

        if (isset($filters['is_system'])) {
            $where[] = 'is_system = %d';
            $params[] = $filters['is_system'] ? 1 : 0;
        }

        if (isset($filters['is_root'])) {
            $where[] = $filters['is_root'] ? 'parent_id IS NULL' : 'parent_id IS NOT NULL';
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
        $sql = "SELECT * FROM {$tableName} {$whereClause} ORDER BY is_system DESC, name ASC";

        if (!empty($params)) {
            $results = $wpdb->get_results($wpdb->prepare($sql, ...$params), ARRAY_A);
        } else {
            $results = $wpdb->get_results($sql, ARRAY_A);
        }

        return array_map([$this, 'formatTemplate'], $results ?: []);
    }

    /**
     * Get templates for a specific post type
     *
     * @param string $postType
     * @return array
     */
    public function getForPostType(string $postType): array
    {
        return $this->getAll(['post_type' => $postType]);
    }

    /**
     * Get only root templates (non-variants) for a post type
     *
     * @param string $postType
     * @return array
     */
    public function getRootTemplatesForPostType(string $postType): array
    {
        return $this->getAll(['post_type' => $postType, 'is_root' => true]);
    }

    /**
     * Get all variants for a given root template
     *
     * @param int $parentId Root template ID
     * @return array
     */
    public function getVariantsForTemplate(int $parentId): array
    {
        global $wpdb;

        $tableName = self::getTableName();
        $results = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$tableName} WHERE parent_id = %d", $parentId),
            ARRAY_A
        );

        return array_map([$this, 'formatTemplate'], $results ?: []);
    }

    /**
     * Get the default template for a post type
     *
     * @param string $postType
     * @return array|null
     */
    public function getDefault(string $postType): ?array
    {
        $templates = $this->getAll([
            'post_type' => $postType,
            'is_default' => true,
        ]);

        return !empty($templates) ? $templates[0] : null;
    }

    /**
     * Set a template as the default for its post type
     *
     * @param int $id Template ID
     * @return bool
     */
    public function setDefault(int $id): bool
    {
        $template = $this->get($id);
        if (!$template) {
            return false;
        }

        return $this->update($id, ['is_default' => true]);
    }

    /**
     * Duplicate a template
     *
     * @param int $id Template ID to duplicate
     * @param string|null $newName Optional new name
     * @return int|false The new template ID or false on failure
     */
    public function duplicate(int $id, ?string $newName = null): int|false
    {
        $template = $this->get($id);
        if (!$template) {
            return false;
        }

        $name = $newName ?? $template['name'] . ' (Copy)';

        return $this->create([
            'name'            => $name,
            'description'     => $template['description'],
            'post_type'       => $template['post_type'],
            'config'          => $template['config'],
            'taxonomy_config' => $template['taxonomy_config'],
            'field_config'    => $template['field_config'] ?? FieldConfigSchema::getDefaultFieldConfig(),
            'is_default'      => false,
            'is_system'       => false,
        ]);
    }

    /**
     * Export a template as array (for JSON export)
     *
     * @param int $id Template ID
     * @return array|null
     */
    public function export(int $id): ?array
    {
        $template = $this->get($id);
        if (!$template) {
            return null;
        }

        // Remove internal fields
        unset($template['id'], $template['author_id'], $template['created_at'], $template['updated_at']);

        return $template;
    }

    /**
     * Export all templates
     *
     * @param array $filters Optional filters
     * @return array
     */
    public function exportAll(array $filters = []): array
    {
        $templates = $this->getAll($filters);

        return array_map(function ($template) {
            unset($template['id'], $template['author_id'], $template['created_at'], $template['updated_at']);
            return $template;
        }, $templates);
    }

    /**
     * Import a template from array
     *
     * @param array $data Template data
     * @return int|false The new template ID or false on failure
     */
    public function import(array $data): int|false
    {
        // Ensure we don't import as system template
        $data['is_system'] = false;

        // Generate new slug to avoid conflicts
        if (isset($data['slug'])) {
            $data['slug'] = $this->generateUniqueSlug($data['slug']);
        }

        return $this->create($data);
    }

    /**
     * Import multiple templates
     *
     * @param array $templates Array of template data
     * @return array Array of results with 'success' and 'id' or 'error'
     */
    public function importAll(array $templates): array
    {
        $results = [];

        foreach ($templates as $index => $template) {
            $id = $this->import($template);
            if ($id) {
                $results[] = [
                    'success' => true,
                    'id'      => $id,
                    'name'    => $template['name'] ?? "Template {$index}",
                ];
            } else {
                $results[] = [
                    'success' => false,
                    'error'   => 'Failed to import template',
                    'name'    => $template['name'] ?? "Template {$index}",
                ];
            }
        }

        return $results;
    }

    /**
     * Get template count
     *
     * @param array $filters Optional filters
     * @return int
     */
    public function getCount(array $filters = []): int
    {
        global $wpdb;

        $tableName = self::getTableName();
        $where = [];
        $params = [];

        if (isset($filters['post_type'])) {
            $where[] = 'post_type = %s';
            $params[] = $filters['post_type'];
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
        $sql = "SELECT COUNT(*) FROM {$tableName} {$whereClause}";

        if (!empty($params)) {
            return (int) $wpdb->get_var($wpdb->prepare($sql, ...$params));
        }

        return (int) $wpdb->get_var($sql);
    }

    /**
     * Generate a unique slug
     *
     * @param string $base Base slug
     * @param int|null $excludeId Exclude this template ID from uniqueness check
     * @return string
     */
    protected function generateUniqueSlug(string $base, ?int $excludeId = null): string
    {
        $slug = sanitize_title($base);
        $originalSlug = $slug;
        $counter = 1;

        while ($this->slugExists($slug, $excludeId)) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }

        return $slug;
    }

    /**
     * Check if a slug exists
     *
     * @param string $slug
     * @param int|null $excludeId
     * @return bool
     */
    protected function slugExists(string $slug, ?int $excludeId = null): bool
    {
        global $wpdb;

        $tableName = self::getTableName();

        if ($excludeId) {
            $count = $wpdb->get_var(
                $wpdb->prepare("SELECT COUNT(*) FROM {$tableName} WHERE slug = %s AND id != %d", $slug, $excludeId)
            );
        } else {
            $count = $wpdb->get_var(
                $wpdb->prepare("SELECT COUNT(*) FROM {$tableName} WHERE slug = %s", $slug)
            );
        }

        return (int) $count > 0;
    }

    /**
     * Unset default flag for all templates of a post type
     *
     * @param string $postType
     * @param int|null $excludeId
     * @return void
     */
    protected function unsetDefaultsForPostType(string $postType, ?int $excludeId = null): void
    {
        global $wpdb;

        $tableName = self::getTableName();

        if ($excludeId) {
            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$tableName} SET is_default = 0 WHERE post_type = %s AND id != %d",
                    $postType,
                    $excludeId
                )
            );
        } else {
            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$tableName} SET is_default = 0 WHERE post_type = %s",
                    $postType
                )
            );
        }
    }

    /**
     * Format a template row from the database
     *
     * @param array $row
     * @return array
     */
    protected function formatTemplate(array $row): array
    {
        return [
            'id'               => (int) $row['id'],
            'name'             => $row['name'],
            'slug'             => $row['slug'],
            'description'      => $row['description'] ?? '',
            'post_type'        => $row['post_type'],
            'post_type_label'  => get_post_type_object($row['post_type'])?->labels->name ?? $row['post_type'],
            'config'           => json_decode($row['config'], true) ?? [],
            'taxonomy_config'  => json_decode($row['taxonomy_config'], true) ?? [],
            'field_config'     => json_decode($row['field_config'] ?? '{}', true) ?? FieldConfigSchema::getDefaultFieldConfig(),
            'is_default'       => (bool) $row['is_default'],
            'is_system'        => (bool) $row['is_system'],
            'author_id'        => (int) $row['author_id'],
            'parent_id'        => isset($row['parent_id']) ? (int) $row['parent_id'] : null,
            'config_overrides' => json_decode($row['config_overrides'] ?? '{}', true) ?? [],
            'created_at'       => $row['created_at'],
            'updated_at'       => $row['updated_at'],
            'is_compatible'       => post_type_exists($row['post_type']),
            'incompatible_reason' => !post_type_exists($row['post_type'])
                ? sprintf(__("Post type '%s' not found on this site", 'wpfaker'), $row['post_type'])
                : null,
        ];
    }

    /**
     * Remove all references to a template ID from other templates' related_cpt_options.
     */
    /**
     * Unlink sibling templates from a target CPT.
     *
     * When template A (for post type X) links to target CPT Y,
     * all other templates for post type X must be unlinked from CPT Y
     * to prevent duplicate cross-CPT dependencies.
     *
     * @param int $templateId The template that just linked
     * @param string $postType The post type of the linking template
     * @param string $targetCpt The target CPT being linked to
     * @param int $targetTemplateId The target template ID being linked
     */
    public function unlinkSiblingTemplates(int $templateId, string $postType, string $targetCpt, int $targetTemplateId): void
    {
        $siblings = $this->getForPostType($postType);

        foreach ($siblings as $sibling) {
            if ($sibling['id'] === $templateId) {
                continue;
            }

            $config = $sibling['config'];
            $relatedOpts = $config['related_cpt_options'] ?? [];

            if (!isset($relatedOpts[$targetCpt]) || !is_array($relatedOpts[$targetCpt])) {
                continue;
            }

            $siblingLinkedId = $relatedOpts[$targetCpt]['template_id'] ?? null;
            if (!$siblingLinkedId) {
                continue;
            }

            unset($relatedOpts[$targetCpt]['template_id']);
            unset($relatedOpts[$targetCpt]['template_name']);
            $config['related_cpt_options'] = $relatedOpts;
            $this->update($sibling['id'], ['config' => $config]);
        }
    }

    private function unlinkTemplateReferences(int $templateId): void
    {
        $parents = $this->getLinkedParents($templateId);

        foreach ($parents as $parent) {
            $template = $this->get($parent['id']);
            if (!$template) {
                continue;
            }

            $config = $template['config'];
            $relatedOpts = $config['related_cpt_options'] ?? [];
            $changed = false;

            foreach ($relatedOpts as $cpt => $cptConfig) {
                if (is_array($cptConfig) && ($cptConfig['template_id'] ?? null) === $templateId) {
                    unset($relatedOpts[$cpt]['template_id']);
                    unset($relatedOpts[$cpt]['template_name']);
                    $changed = true;
                }
            }

            if ($changed) {
                $config['related_cpt_options'] = $relatedOpts;
                $this->update($parent['id'], ['config' => $config]);
            }
        }
    }

    /**
     * Find all templates that reference a given template ID in their related_cpt_options.
     *
     * @param int $templateId
     * @return array Array of ['id' => int, 'name' => string, 'post_type' => string]
     */
    public function getLinkedParents(int $templateId): array
    {
        global $wpdb;

        $tableName = self::getTableName();

        // Collect all IDs to search for: the template itself + its variants
        $searchIds = [$templateId];
        $variants = $this->getVariantsForTemplate($templateId);
        foreach ($variants as $variant) {
            $searchIds[] = (int) $variant['id'];
        }

        // Build LIKE conditions for all IDs
        $conditions = [];
        $values = [];
        foreach ($searchIds as $id) {
            $conditions[] = 'config LIKE %s';
            $values[] = '%"template_id":' . (int) $id . '%';
        }

        $where = implode(' OR ', $conditions);
        $results = $wpdb->get_results(
            $wpdb->prepare("SELECT id, name, post_type FROM {$tableName} WHERE {$where}", ...$values),
            ARRAY_A
        );

        if (empty($results)) {
            return [];
        }

        $searchIdSet = array_flip($searchIds);

        // Verify the match is actually in related_cpt_options (not a false positive from LIKE)
        return array_values(array_filter(array_map(function ($row) {
            return [
                'id'        => (int) $row['id'],
                'name'      => $row['name'],
                'post_type' => $row['post_type'],
            ];
        }, $results), function ($row) use ($searchIdSet) {
            // Re-fetch the full template to verify the template_id reference
            $template = $this->get($row['id']);
            if (!$template) {
                return false;
            }
            $relatedOpts = $template['config']['related_cpt_options'] ?? [];
            foreach ($relatedOpts as $cptConfig) {
                if (is_array($cptConfig) && isset($searchIdSet[$cptConfig['template_id'] ?? null])) {
                    return true;
                }
            }
            return false;
        }));
    }

    /**
     * Get the effective (merged) config for a template.
     * For root templates, returns config directly.
     * For variants, deep-merges parent config with config_overrides.
     *
     * @param int $templateId
     * @return array|null Merged config, or null if template not found
     */
    public function getEffectiveConfig(int $templateId): ?array
    {
        $template = $this->get($templateId);
        if (!$template) {
            return null;
        }

        // Root template — return config with field and taxonomy configs
        if ($template['parent_id'] === null) {
            return array_merge($template['config'], [
                'field_config'    => $template['field_config'],
                'taxonomy_config' => $template['taxonomy_config'],
            ]);
        }

        // Variant — merge parent config with overrides
        $parent = $this->get($template['parent_id']);
        if (!$parent) {
            // Parent deleted — fall back to own config
            return array_merge($template['config'], [
                'field_config'    => $template['field_config'],
                'taxonomy_config' => $template['taxonomy_config'],
            ]);
        }

        $config = self::deepMerge($parent['config'], $template['config_overrides']);

        // Use variant's field/taxonomy config if set, otherwise inherit from parent
        $config['field_config']    = !empty($template['field_config']) ? $template['field_config'] : $parent['field_config'];
        $config['taxonomy_config'] = !empty($template['taxonomy_config']) ? $template['taxonomy_config'] : $parent['taxonomy_config'];

        // For complex fields (repeater/group/flexible_content) in the variant,
        // inherit parent's sub_fields when the variant doesn't have them.
        // This handles variants saved before sub_field inheritance was fixed.
        if (!empty($template['field_config']) && !empty($parent['field_config'])) {
            $parentCustom = $parent['field_config']['custom_fields'] ?? [];
            foreach ($parentCustom as $fieldName => $parentField) {
                $parentSubFields = $parentField['create']['sub_fields'] ?? [];
                if (empty($parentSubFields)) {
                    continue;
                }
                $variantField = $config['field_config']['custom_fields'][$fieldName] ?? null;
                if ($variantField && empty($variantField['create']['sub_fields'])) {
                    $config['field_config']['custom_fields'][$fieldName]['create']['sub_fields'] = $parentSubFields;
                }
            }
        }

        return $config;
    }

    /**
     * Create a variant template that inherits from a parent.
     * Max 1 level deep — parent must be a root template (parent_id = null).
     *
     * @param int $parentId Parent template ID
     * @param string $name Variant name
     * @param array $overrides Config overrides
     * @return int|false Variant template ID or false on failure
     */
    public function createVariant(int $parentId, string $name, array $overrides = []): int|false
    {
        $parent = $this->get($parentId);
        if (!$parent) {
            return false;
        }

        // Prevent nesting: parent must be a root template
        if ($parent['parent_id'] !== null) {
            return false;
        }

        global $wpdb;

        $slug = $this->generateUniqueSlug($name);

        $result = $wpdb->insert(
            self::getTableName(),
            [
                'name'             => sanitize_text_field($name),
                'slug'             => $slug,
                'description'      => '',
                'post_type'        => $parent['post_type'],
                'config'           => '{}',
                'taxonomy_config'  => '{}',
                'field_config'     => '{}',
                'is_default'       => 0,
                'is_system'        => 0,
                'author_id'        => get_current_user_id(),
                'parent_id'        => $parentId,
                'config_overrides' => json_encode($overrides),
                'created_at'       => current_time('mysql'),
                'updated_at'       => current_time('mysql'),
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s', '%s', '%s']
        );

        return $result ? $wpdb->insert_id : false;
    }

    /**
     * Get CPT slugs that don't have a default template yet.
     *
     * @param array $cptSlugs List of registered CPT slugs
     * @return array CPT slugs without default templates
     */
    protected function getMissingDefaultCpts(array $cptSlugs): array
    {
        $existingDefaults = $this->getAll(['is_default' => true]);
        $coveredCpts = array_column($existingDefaults, 'post_type');

        return array_values(array_diff($cptSlugs, $coveredCpts));
    }

    /**
     * Ensure default templates exist for all public CPTs.
     * Creates missing ones with standard Faker defaults.
     *
     * @return array List of created CPT slugs
     */
    public function ensureDefaultTemplates(): array
    {
        $publicCpts = get_post_types(['public' => true], 'objects');
        $cptSlugs = array_keys($publicCpts);

        $missing = $this->getMissingDefaultCpts($cptSlugs);
        $created = [];

        foreach ($missing as $slug) {
            $label = $publicCpts[$slug]->label ?? ucfirst($slug);
            $id = $this->create([
                'name'            => $label,
                'post_type'       => $slug,
                'is_default'      => true,
                'config'          => self::getDefaultConfig(),
                'taxonomy_config' => [],
                'field_config'    => [],
            ]);
            if ($id) {
                $created[] = $slug;
            }
        }

        return $created;
    }

    /**
     * Detect templates whose post_type is no longer registered.
     *
     * @return array Array of stale templates [['id' => int, 'name' => string, 'post_type' => string, 'parent_id' => int|null], ...]
     */
    public function detectStaleTemplates(): array
    {
        $allTemplates = $this->getAll();
        $registeredCpts = array_keys(get_post_types([], 'objects'));

        $stale = [];
        foreach ($allTemplates as $template) {
            if (!in_array($template['post_type'], $registeredCpts, true)) {
                $stale[] = [
                    'id'        => $template['id'],
                    'name'      => $template['name'],
                    'post_type' => $template['post_type'],
                    'parent_id' => $template['parent_id'] ?? null,
                ];
            }
        }

        return $stale;
    }

    /**
     * Remove related_cpt_options entries that reference non-existent CPTs.
     *
     * @return array Array of cleaned template IDs
     */
    public function cleanupRelatedCptReferences(): array
    {
        $registeredCpts = array_keys(get_post_types([], 'objects'));
        $allTemplates = $this->getAll();
        $cleaned = [];

        foreach ($allTemplates as $template) {
            $config = $template['config'];
            $relatedOpts = $config['related_cpt_options'] ?? [];

            if (empty($relatedOpts)) {
                continue;
            }

            $changed = false;
            foreach (array_keys($relatedOpts) as $cptSlug) {
                if (!in_array($cptSlug, $registeredCpts, true)) {
                    unset($relatedOpts[$cptSlug]);
                    $changed = true;
                }
            }

            if ($changed) {
                $config['related_cpt_options'] = $relatedOpts;
                $this->update($template['id'], ['config' => $config]);
                $cleaned[] = $template['id'];
            }
        }

        return $cleaned;
    }

    /**
     * Compare template field config against live fields.
     * Returns list of new field names (present in live but not in template).
     *
     * @param array $templateFieldConfig Current template field_config
     * @param array $liveFields Live fields grouped by source (core, custom)
     * @return array ['new' => string[]] New field names
     */
    protected static function diffFields(array $templateFieldConfig, array $liveFields): array
    {
        $newFields = [];

        foreach ($liveFields as $source => $fields) {
            $existingNames = array_keys($templateFieldConfig[$source] ?? []);

            foreach ($fields as $field) {
                $name = $field['name'] ?? '';
                if ($name && !in_array($name, $existingNames, true)) {
                    $newFields[] = $name;
                }
            }
        }

        return ['new' => $newFields];
    }

    /**
     * Sync a template's field config against live CPT fields.
     * Adds new fields with mode=create, returns list of added field names.
     *
     * @param int $templateId
     * @param array $liveFields Live fields from AdapterFactory
     * @return array Added field names
     */
    public function syncFieldsForTemplate(int $templateId, array $liveFields): array
    {
        $template = $this->get($templateId);
        if (!$template) {
            return [];
        }

        $fieldConfig = $template['field_config'] ?: [];
        $diff = self::diffFields($fieldConfig, $liveFields);

        if (empty($diff['new'])) {
            return [];
        }

        // Add new fields with default config
        foreach ($liveFields as $source => $fields) {
            foreach ($fields as $field) {
                if (in_array($field['name'] ?? '', $diff['new'], true)) {
                    if (!isset($fieldConfig[$source])) {
                        $fieldConfig[$source] = [];
                    }
                    $fieldConfig[$source][$field['name']] = [
                        'mode'       => 'create',
                        'field_type' => $field['type'] ?? 'text',
                    ];
                }
            }
        }

        $this->update($templateId, ['field_config' => $fieldConfig]);

        return $diff['new'];
    }

    /**
     * Deep merge two arrays. Associative arrays are merged recursively,
     * indexed arrays are replaced entirely.
     */
    protected static function deepMerge(array $base, array $overrides): array
    {
        $result = $base;

        foreach ($overrides as $key => $value) {
            if (
                is_array($value)
                && isset($result[$key])
                && is_array($result[$key])
                && self::isAssociative($value)
                && self::isAssociative($result[$key])
            ) {
                $result[$key] = self::deepMerge($result[$key], $value);
            } else {
                $result[$key] = $value;
            }
        }

        return $result;
    }

    /**
     * Check if array is associative (has string keys).
     */
    private static function isAssociative(array $arr): bool
    {
        if (empty($arr)) {
            return false;
        }
        return array_keys($arr) !== range(0, count($arr) - 1);
    }

    /**
     * Get default config values
     *
     * @return array
     */
    public static function getDefaultConfig(): array
    {
        return [
            'count'                  => 10,
            'post_status'            => 'publish',
            'set_featured_image'     => true,
            'download_images'        => true,
            'image_provider'         => get_option('wpfaker_options', [])['default_image_provider'] ?? 'unsplash',
            'image_category'         => '',
            'populate_custom_fields' => true,
            'enable_variation'       => true,
            'variation_profile'      => 'random',
            'auto_create_authors'    => true,
            'auto_create_taxonomies' => false,
            'locale'                 => '',
        ];
    }

    /**
     * Get default taxonomy config
     *
     * @param string $mode
     * @return array
     */
    public static function getDefaultTaxonomyConfig(string $mode = 'none'): array
    {
        return match ($mode) {
            'choose' => [
                'mode'         => 'choose',
                'terms'        => [],
                'include_none' => false,
                'randomly'     => false,
                'multiple'     => false,
                'min_terms'    => 1,
                'max_terms'    => 3,
            ],
            'create' => [
                'mode'                  => 'create',
                'create_mode'           => 'random',
                'custom_names'          => [],
                'count'                 => 5,
                'include_subcategories' => false,
                'depth'                 => 2,
                'breadth'               => 3,
            ],
            default => [
                'mode' => 'none',
            ],
        };
    }
}
