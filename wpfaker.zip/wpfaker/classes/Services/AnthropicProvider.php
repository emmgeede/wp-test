<?php

namespace WPFaker\Services;

/**
 * Anthropic Claude AI Provider
 *
 * Implements the AI provider interface for Anthropic's Claude API.
 */
class AnthropicProvider extends AbstractAiProvider
{
    protected const API_ENDPOINT = 'https://api.anthropic.com/v1/messages';

    public function getProviderKey(): string
    {
        return 'anthropic';
    }

    public function getProviderName(): string
    {
        return 'Anthropic Claude';
    }

    protected function callApi(string $prompt, float $temperature, int $maxTokens): ?string
    {
        $body = [
            'model' => 'claude-sonnet-4-5-20250929',
            'max_tokens' => $maxTokens,
            'temperature' => $temperature,
            'messages' => [
                [
                    'role' => 'user',
                    'content' => $prompt,
                ],
            ],
        ];

        $data = $this->httpPost(self::API_ENDPOINT, [
            'headers' => [
                'Content-Type' => 'application/json',
                'x-api-key' => $this->apiKey,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => wp_json_encode($body),
            'timeout' => 30,
        ], 'Anthropic');

        if (!$data || empty($data['content'][0]['text'])) {
            return null;
        }

        return trim($data['content'][0]['text']);
    }

    /**
     * Anthropic doesn't have a native JSON mode, so we fall back to regular API call
     * with a prompt that emphasizes JSON output.
     */
    protected function callApiWithJsonMode(string $prompt, float $temperature, int $maxTokens): ?string
    {
        // Anthropic has no native JSON mode — the prompt already requests JSON
        return $this->callApi($prompt, $temperature, $maxTokens);
    }
}
