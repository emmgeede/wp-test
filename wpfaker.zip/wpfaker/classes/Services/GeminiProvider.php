<?php

namespace WPFaker\Services;

/**
 * Google Gemini AI Provider
 *
 * Implements the AI provider interface for Google's Gemini API.
 */
class GeminiProvider extends AbstractAiProvider
{
    protected const API_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

    public function getProviderKey(): string
    {
        return 'gemini';
    }

    public function getProviderName(): string
    {
        return 'Google Gemini';
    }

    protected function callApi(string $prompt, float $temperature, int $maxTokens): ?string
    {
        $url = self::API_ENDPOINT . '?key=' . $this->apiKey;

        $body = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt]
                    ]
                ]
            ],
            'generationConfig' => [
                'temperature' => $temperature,
                'maxOutputTokens' => $maxTokens,
            ],
        ];

        $data = $this->httpPost($url, [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode($body),
            'timeout' => 30,
        ], 'Gemini');

        if (!$data || empty($data['candidates'][0]['content']['parts'][0]['text'])) {
            return null;
        }

        return trim($data['candidates'][0]['content']['parts'][0]['text']);
    }

    protected function callApiWithJsonMode(string $prompt, float $temperature, int $maxTokens): ?string
    {
        $url = self::API_ENDPOINT . '?key=' . $this->apiKey;

        $body = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt]
                    ]
                ]
            ],
            'generationConfig' => [
                'temperature' => $temperature,
                'maxOutputTokens' => $maxTokens,
                'responseMimeType' => 'application/json',
            ],
        ];

        $data = $this->httpPost($url, [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode($body),
            'timeout' => 30,
        ], 'Gemini');

        if (!$data || empty($data['candidates'][0]['content']['parts'][0]['text'])) {
            return null;
        }

        return trim($data['candidates'][0]['content']['parts'][0]['text']);
    }
}
