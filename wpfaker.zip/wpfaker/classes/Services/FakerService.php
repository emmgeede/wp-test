<?php

namespace WPFaker\Services;

use Faker\Factory;
use Faker\Generator;
use WPFaker\Contracts\AiProviderInterface;
use WPFaker\Providers\ModernTextProvider;

/**
 * Faker Service
 *
 * Wrapper service for the FakerPHP library.
 * Provides a centralized way to access Faker functionality with WordPress-specific features.
 * Supports multilingual content generation.
 */
class FakerService
{
    /**
     * Available languages
     */
    public const LANG_ENGLISH = 'en_US';
    public const LANG_GERMAN = 'de_DE';
    public const LANG_FRENCH = 'fr_FR';
    public const LANG_SPANISH = 'es_ES';
    public const LANG_ITALIAN = 'it_IT';
    public const LANG_DUTCH = 'nl_NL';
    public const LANG_PORTUGUESE = 'pt_BR';
    public const LANG_POLISH = 'pl_PL';
    public const LANG_RUSSIAN = 'ru_RU';
    public const LANG_JAPANESE = 'ja_JP';
    public const LANG_CHINESE = 'zh_CN';

    /**
     * The primary Faker generator instance
     *
     * @var Generator
     */
    protected Generator $faker;

    /**
     * Cache of Faker instances per locale
     *
     * @var array<string, Generator>
     */
    protected static array $instances = [];

    /**
     * The primary locale for generating fake data
     *
     * @var string
     */
    protected string $locale;

    /**
     * Available locales for multilingual generation
     *
     * @var array
     */
    protected array $availableLocales = [
        self::LANG_ENGLISH,
        self::LANG_GERMAN,
    ];

    /**
     * Seed for reproducible results
     *
     * @var int|null
     */
    protected ?int $seed = null;

    /**
     * Constructor
     *
     * @param string|null $locale The locale for Faker (e.g., 'de_DE', 'en_US')
     */
    public function __construct(?string $locale = null)
    {
        $this->locale = $locale ?? $this->getWordPressLocale();
        $this->faker = $this->getOrCreateInstance($this->locale);
    }

    /**
     * Get or create a Faker instance for a locale
     *
     * @param string $locale
     * @return Generator
     */
    protected function getOrCreateInstance(string $locale): Generator
    {
        if (!isset(self::$instances[$locale])) {
            $instance = Factory::create($locale);

            if (ModernTextProvider::hasLocale($locale)) {
                $instance->addProvider(new ModernTextProvider($instance, $locale));
            }

            self::$instances[$locale] = $instance;
        }
        return self::$instances[$locale];
    }

    /**
     * Get a Faker instance for a specific locale
     *
     * @param string $locale
     * @return Generator
     */
    public function forLocale(string $locale): Generator
    {
        return $this->getOrCreateInstance($locale);
    }

    /**
     * Set available locales for multilingual generation
     *
     * @param array $locales
     * @return self
     */
    public function setAvailableLocales(array $locales): self
    {
        $this->availableLocales = $locales;
        return $this;
    }

    /**
     * Get available locales
     *
     * @return array
     */
    public function getAvailableLocales(): array
    {
        return $this->availableLocales;
    }

    /**
     * Get a random locale from available locales
     *
     * @return string
     */
    public function getRandomLocale(): string
    {
        return $this->availableLocales[array_rand($this->availableLocales)];
    }

    /**
     * Get supported languages with labels
     *
     * @return array
     */
    public static function getSupportedLanguages(): array
    {
        return [
            self::LANG_ENGLISH => [
                'code' => 'en_US',
                'name' => 'English',
                'native' => 'English',
                'flag' => '🇺🇸',
            ],
            self::LANG_GERMAN => [
                'code' => 'de_DE',
                'name' => 'German',
                'native' => 'Deutsch',
                'flag' => '🇩🇪',
            ],
            self::LANG_FRENCH => [
                'code' => 'fr_FR',
                'name' => 'French',
                'native' => 'Français',
                'flag' => '🇫🇷',
            ],
            self::LANG_SPANISH => [
                'code' => 'es_ES',
                'name' => 'Spanish',
                'native' => 'Español',
                'flag' => '🇪🇸',
            ],
            self::LANG_ITALIAN => [
                'code' => 'it_IT',
                'name' => 'Italian',
                'native' => 'Italiano',
                'flag' => '🇮🇹',
            ],
            self::LANG_DUTCH => [
                'code' => 'nl_NL',
                'name' => 'Dutch',
                'native' => 'Nederlands',
                'flag' => '🇳🇱',
            ],
            self::LANG_PORTUGUESE => [
                'code' => 'pt_BR',
                'name' => 'Portuguese',
                'native' => 'Português',
                'flag' => '🇧🇷',
            ],
            self::LANG_POLISH => [
                'code' => 'pl_PL',
                'name' => 'Polish',
                'native' => 'Polski',
                'flag' => '🇵🇱',
            ],
            self::LANG_RUSSIAN => [
                'code' => 'ru_RU',
                'name' => 'Russian',
                'native' => 'Русский',
                'flag' => '🇷🇺',
            ],
            self::LANG_JAPANESE => [
                'code' => 'ja_JP',
                'name' => 'Japanese',
                'native' => '日本語',
                'flag' => '🇯🇵',
            ],
            self::LANG_CHINESE => [
                'code' => 'zh_CN',
                'name' => 'Chinese',
                'native' => '中文',
                'flag' => '🇨🇳',
            ],
        ];
    }

    /**
     * Get the current locale
     *
     * @return string
     */
    public function getLocale(): string
    {
        return $this->locale;
    }

    /**
     * Set the primary locale
     *
     * @param string $locale
     * @return self
     */
    public function setLocale(string $locale): self
    {
        $this->locale = $locale;
        $this->faker = $this->getOrCreateInstance($locale);
        return $this;
    }

    /**
     * Get the Faker generator instance
     *
     * @return Generator
     */
    public function getInstance(): Generator
    {
        return $this->faker;
    }

    /**
     * Magic method to proxy calls to the underlying Faker Generator
     *
     * This allows calling Faker methods directly on FakerService:
     * $fakerService->name() instead of $fakerService->getInstance()->name()
     *
     * @param string $method
     * @param array $arguments
     * @return mixed
     */
    public function __call(string $method, array $arguments)
    {
        return $this->faker->$method(...$arguments);
    }

    /**
     * Get the WordPress locale converted to Faker format
     *
     * @return string
     */
    protected function getWordPressLocale(): string
    {
        $wpLocale = get_locale();

        // Map WordPress locale to Faker locale
        $localeMap = [
            'de_DE'          => 'de_DE',
            'de_DE_formal'   => 'de_DE',
            'de_AT'          => 'de_AT',
            'de_CH'          => 'de_CH',
            'de_CH_informal' => 'de_CH',
            'en_US'          => 'en_US',
            'en_GB'          => 'en_GB',
            'en_AU'          => 'en_AU',
            'fr_FR'          => 'fr_FR',
            'fr_BE'          => 'fr_BE',
            'fr_CA'          => 'fr_CA',
            'fr_CH'          => 'fr_CH',
            'es_ES'          => 'es_ES',
            'es_MX'          => 'es_MX',
            'it_IT'          => 'it_IT',
            'nl_NL'          => 'nl_NL',
            'nl_BE'          => 'nl_BE',
            'pt_PT'          => 'pt_PT',
            'pt_BR'          => 'pt_BR',
            'ru_RU'          => 'ru_RU',
            'ja'             => 'ja_JP',
            'zh_CN'          => 'zh_CN',
            'zh_TW'          => 'zh_TW',
            'ko_KR'          => 'ko_KR',
            'ar'             => 'ar_SA',
            'pl_PL'          => 'pl_PL',
            'tr_TR'          => 'tr_TR',
            'sv_SE'          => 'sv_SE',
            'da_DK'          => 'da_DK',
            'nb_NO'          => 'nb_NO',
            'fi'             => 'fi_FI',
            'cs_CZ'          => 'cs_CZ',
            'hu_HU'          => 'hu_HU',
            'ro_RO'          => 'ro_RO',
            'el'             => 'el_GR',
            'he_IL'          => 'he_IL',
            'uk'             => 'uk_UA',
        ];

        return $localeMap[$wpLocale] ?? 'en_US';
    }

    /**
     * Set a seed for reproducible results
     *
     * @param int $seed
     * @return self
     */
    public function seed(int $seed): self
    {
        $this->seed = $seed;
        $this->faker->seed($seed);
        return $this;
    }

    /**
     * Generate a unique value
     *
     * @return \Faker\UniqueGenerator
     */
    public function unique(): \Faker\UniqueGenerator
    {
        return $this->faker->unique();
    }

    /**
     * Generate an optional value (may return null)
     *
     * @param float $weight Probability of getting a value (0.0 to 1.0)
     * @return \Faker\ChanceGenerator
     */
    public function optional(float $weight = 0.5): \Faker\ChanceGenerator
    {
        return $this->faker->optional($weight);
    }

    /**
     * Generate valid value that passes a callback validation
     *
     * @param callable $validator
     * @param int $maxRetries
     * @return Generator
     */
    public function valid(callable $validator, int $maxRetries = 10000): Generator
    {
        return $this->faker->valid($validator, $maxRetries);
    }

    /**
     * Get the configured text source (realtext or lorem).
     */
    public static function getTextSource(): string
    {
        $settings = get_option('wpfaker_settings', []);
        return ($settings['text_source'] ?? 'realtext') === 'lorem' ? 'lorem' : 'realtext';
    }

    /**
     * Check if a Faker instance supports realText (locale-aware text generation)
     *
     * @param Generator $faker
     * @return bool
     */
    protected function hasRealText(Generator $faker): bool
    {
        // If user chose Lorem, skip realText entirely
        if (self::getTextSource() === 'lorem') {
            return false;
        }

        try {
            $faker->realText(20);
            return true;
        } catch (\InvalidArgumentException $e) {
            return false;
        }
    }

    /**
     * Generate locale-aware text with fallback to Lorem
     *
     * @param Generator $faker
     * @param int $maxNbChars
     * @return string
     */
    protected function realTextSafe(Generator $faker, int $maxNbChars = 200): string
    {
        // If user chose Lorem, go straight to sentence fallback
        if (self::getTextSource() === 'lorem') {
            $wordCount = max(3, (int) ($maxNbChars / 6));
            return $faker->sentence($wordCount);
        }

        try {
            // realText requires minimum 10 chars
            return $faker->realText(max($maxNbChars, 10));
        } catch (\InvalidArgumentException $e) {
            // Fallback: approximate word count from char count
            $wordCount = max(3, (int) ($maxNbChars / 6));
            return $faker->sentence($wordCount);
        }
    }

    // =========================================================================
    // Convenience methods for WordPress-specific content
    // =========================================================================

    /**
     * Generate a post title
     *
     * @param int $minWords
     * @param int $maxWords
     * @param string|null $locale Optional locale override
     * @return string
     */
    public function postTitle(int $minWords = 4, int $maxWords = 10, ?string $locale = null, string $cptSlug = '', string $cptLabel = ''): string
    {
        // Try contextual title first
        if ($cptSlug || $cptLabel) {
            $contextual = $this->contextualPostTitle($cptSlug, $cptLabel, $locale);
            if ($contextual !== '') {
                return $contextual;
            }
        }

        $faker = $locale ? $this->forLocale($locale) : $this->faker;

        // Use realText for locale-aware titles (non-Lorem Ipsum)
        try {
            $minChars = $minWords * 6;
            $maxChars = max($maxWords * 7, $minChars + 10);
            $text = $faker->realText(rand($minChars, $maxChars));
            // Strip trailing period/punctuation for cleaner titles
            $text = rtrim($text, '.!?…');
            return $text;
        } catch (\InvalidArgumentException $e) {
            // Fallback to Lorem if realText not available for this locale
            return ucfirst($faker->words(rand($minWords, $maxWords), true));
        }
    }

    /**
     * CPT-specific title templates
     */
    protected const CPT_TITLE_TEMPLATES = [

    // =========================================================================
    // 1. VEHICLE
    // =========================================================================
    'vehicle|car|auto|fahrzeug|kfz|voiture|véhicule|coche|vehículo|veicolo|voertuig|pojazd|автомобиль|車|车' => [
        'en' => [
            '{year} {brand} {model} {trim}',
            '{brand} {model} - {condition}',
            '{brand} {model} {fuel} {year}',
            'Used {year} {brand} {model}',
            '{brand} {model} with {mileage} miles',
        ],
        'de' => [
            '{brand} {model} {trim} ({year})',
            '{brand} {model} - {condition}',
            '{brand} {model} {fuel} Baujahr {year}',
            '{brand} {model} mit {mileage} km',
            'Gebrauchter {brand} {model} ({year})',
        ],
        'fr' => [
            '{brand} {model} {trim} ({year})',
            '{brand} {model} - {condition}',
            '{brand} {model} {fuel} {year}',
            '{brand} {model} {year} {mileage} km',
            '{brand} {model} d\'occasion ({year})',
        ],
        'es' => [
            '{brand} {model} {trim} ({year})',
            '{brand} {model} - {condition}',
            '{brand} {model} {fuel} {year}',
            '{brand} {model} con {mileage} km',
            '{brand} {model} de segunda mano ({year})',
        ],
        'it' => [
            '{brand} {model} {trim} ({year})',
            '{brand} {model} - {condition}',
            '{brand} {model} {fuel} anno {year}',
            '{brand} {model} con {mileage} km',
            '{brand} {model} usata ({year})',
        ],
        'nl' => [
            '{brand} {model} {trim} ({year})',
            '{brand} {model} - {condition}',
            '{brand} {model} {fuel} bouwjaar {year}',
            '{brand} {model} met {mileage} km',
            'Occasion {brand} {model} ({year})',
        ],
        'pt' => [
            '{brand} {model} {trim} ({year})',
            '{brand} {model} - {condition}',
            '{brand} {model} {fuel} {year}',
            '{brand} {model} com {mileage} km',
            '{brand} {model} seminovo ({year})',
        ],
        'pl' => [
            '{brand} {model} {trim} ({year})',
            '{brand} {model} - {condition}',
            '{brand} {model} {fuel} rocznik {year}',
            '{brand} {model} z przebiegiem {mileage} km',
            'Używany {brand} {model} ({year})',
        ],
        'ru' => [
            '{brand} {model} {trim} ({year})',
            '{brand} {model} — {condition}',
            '{brand} {model} {fuel} {year} года',
            '{brand} {model}, пробег {mileage} км',
            '{brand} {model} с пробегом ({year})',
        ],
        'ja' => [
            '{year}年式 {brand} {model} {trim}',
            '{brand} {model} — {condition}',
            '{brand} {model} {fuel} {year}年',
            '{brand} {model} 走行{mileage}km',
            '中古 {brand} {model}（{year}年式）',
        ],
        'zh' => [
            '{year} {brand} {model} {trim}',
            '{brand} {model} - {condition}',
            '{brand} {model} {fuel} {year}款',
            '{brand} {model} 里程{mileage}公里',
            '二手 {brand} {model}（{year}年）',
        ],
    ],

    // =========================================================================
    // 2. RECIPE
    // =========================================================================
    'recipe|rezept|food|gericht|essen|recette|ricetta|receta|receita|przepis|рецепт|レシピ|食谱' => [
        'en' => [
            '{adjective} {ingredient} {dish}',
            '{cuisine} {dish} with {ingredient}',
            'Easy {adjective} {dish}',
            '{ingredient} and {ingredient2} {dish}',
            'Homemade {adjective} {cuisine} {dish}',
        ],
        'de' => [
            '{adjective} {ingredient}-{dish}',
            '{cuisine} {dish} mit {ingredient}',
            'Einfaches {adjective} {dish}',
            '{ingredient}-{ingredient2}-{dish}',
            'Hausgemachtes {cuisine} {dish}',
        ],
        'fr' => [
            '{dish} {adjective} aux {ingredient}',
            '{dish} {cuisine} au {ingredient}',
            '{dish} facile au {ingredient} et {ingredient2}',
            'Recette de {dish} {adjective}',
            '{dish} maison au {ingredient}',
        ],
        'es' => [
            '{dish} {adjective} con {ingredient}',
            '{dish} {cuisine} de {ingredient}',
            '{dish} fácil de {ingredient} y {ingredient2}',
            'Receta de {dish} {adjective}',
            '{dish} casero con {ingredient}',
        ],
        'it' => [
            '{dish} {adjective} con {ingredient}',
            '{dish} {cuisine} al {ingredient}',
            '{dish} facile con {ingredient} e {ingredient2}',
            'Ricetta di {dish} {adjective}',
            '{dish} della nonna con {ingredient}',
        ],
        'nl' => [
            '{adjective} {dish} met {ingredient}',
            '{cuisine} {dish} met {ingredient}',
            'Makkelijk {adjective} {dish}',
            '{ingredient} en {ingredient2} {dish}',
            'Huisgemaakt {cuisine} {dish}',
        ],
        'pt' => [
            '{dish} {adjective} com {ingredient}',
            '{dish} {cuisine} de {ingredient}',
            '{dish} fácil de {ingredient} e {ingredient2}',
            'Receita de {dish} {adjective}',
            '{dish} caseiro com {ingredient}',
        ],
        'pl' => [
            '{adjective} {dish} z {ingredient}',
            '{cuisine} {dish} z {ingredient}',
            'Łatwy {dish} z {ingredient} i {ingredient2}',
            'Przepis na {adjective} {dish}',
            'Domowy {dish} z {ingredient}',
        ],
        'ru' => [
            '{adjective} {dish} с {ingredient}',
            '{cuisine} {dish} с {ingredient}',
            'Простой {dish} из {ingredient} и {ingredient2}',
            'Рецепт {adjective} {dish}',
            'Домашний {dish} с {ingredient}',
        ],
        'ja' => [
            '{adjective}{ingredient}の{dish}',
            '{cuisine}風{ingredient}{dish}',
            '簡単{adjective}{dish}',
            '{ingredient}と{ingredient2}の{dish}',
            '自家製{cuisine}{dish}',
        ],
        'zh' => [
            '{adjective}{ingredient}{dish}',
            '{cuisine}风味{ingredient}{dish}',
            '简单{adjective}{dish}',
            '{ingredient}和{ingredient2}{dish}',
            '自制{cuisine}{dish}',
        ],
    ],

    // =========================================================================
    // 3. PRODUCT
    // =========================================================================
    'product|produkt|shop|artikel|ware|produit|prodotto|producto|produto|produkt|товар|製品|产品' => [
        'en' => [
            '{adjective} {material} {item}',
            '{brand} {item} in {color}',
            '{adjective} {item} for {audience}',
            '{brand} {variant} {item}',
            '{material} {item} - {color}',
        ],
        'de' => [
            '{adjective} {material} {item}',
            '{brand} {item} in {color}',
            '{adjective} {item} für {audience}',
            '{brand} {variant} {item}',
            '{material}-{item} in {color}',
        ],
        'fr' => [
            '{item} {adjective} en {material}',
            '{item} {brand} {color}',
            '{item} {adjective} pour {audience}',
            '{brand} {item} {variant}',
            '{item} en {material} - {color}',
        ],
        'es' => [
            '{item} {adjective} de {material}',
            '{item} {brand} en {color}',
            '{item} {adjective} para {audience}',
            '{brand} {item} {variant}',
            '{item} de {material} - {color}',
        ],
        'it' => [
            '{item} {adjective} in {material}',
            '{item} {brand} {color}',
            '{item} {adjective} per {audience}',
            '{brand} {item} {variant}',
            '{item} in {material} - {color}',
        ],
        'nl' => [
            '{adjective} {material} {item}',
            '{brand} {item} in {color}',
            '{adjective} {item} voor {audience}',
            '{brand} {variant} {item}',
            '{material} {item} - {color}',
        ],
        'pt' => [
            '{item} {adjective} de {material}',
            '{item} {brand} em {color}',
            '{item} {adjective} para {audience}',
            '{brand} {item} {variant}',
            '{item} de {material} - {color}',
        ],
        'pl' => [
            '{adjective} {item} z {material}',
            '{brand} {item} w kolorze {color}',
            '{adjective} {item} dla {audience}',
            '{brand} {variant} {item}',
            '{item} z {material} - {color}',
        ],
        'ru' => [
            '{adjective} {item} из {material}',
            '{brand} {item} {color}',
            '{adjective} {item} для {audience}',
            '{brand} {item} {variant}',
            '{item} из {material} — {color}',
        ],
        'ja' => [
            '{adjective}{material}{item}',
            '{brand} {item}（{color}）',
            '{audience}向け{adjective}{item}',
            '{brand} {variant} {item}',
            '{material}製{item} - {color}',
        ],
        'zh' => [
            '{adjective}{material}{item}',
            '{brand} {item}（{color}）',
            '{audience}款{adjective}{item}',
            '{brand} {variant} {item}',
            '{material}{item} - {color}',
        ],
    ],

    // =========================================================================
    // 4. PROPERTY
    // =========================================================================
    'property|immobili|real.?estate|listing|objekt|wohnung|haus|bien|propriété|inmueble|imóvel|nieruchomość|недвижимость|不動産|房产' => [
        'en' => [
            '{adjective} {rooms}-Bedroom {property_type} in {city}',
            '{property_type} for {sale_type} near {landmark}',
            '{rooms}-Bed {property_type} with {feature} in {city}',
            '{adjective} {property_type} - {city}',
            '{property_type} for {sale_type} in {city}',
        ],
        'de' => [
            '{adjective} {rooms}-Zimmer {property_type} in {city}',
            '{property_type} zu {sale_type} nahe {landmark}',
            '{rooms}-Zimmer {property_type} mit {feature} in {city}',
            '{adjective} {property_type} — {city}',
            '{property_type} zur {sale_type} in {city}',
        ],
        'fr' => [
            '{property_type} {adjective} de {rooms} pièces à {city}',
            '{property_type} à {sale_type} près de {landmark}',
            '{property_type} {rooms} pièces avec {feature} à {city}',
            '{adjective} {property_type} — {city}',
            '{property_type} à {sale_type} à {city}',
        ],
        'es' => [
            '{property_type} {adjective} de {rooms} habitaciones en {city}',
            '{property_type} en {sale_type} cerca de {landmark}',
            '{property_type} de {rooms} habitaciones con {feature} en {city}',
            '{adjective} {property_type} — {city}',
            '{property_type} en {sale_type} en {city}',
        ],
        'it' => [
            '{property_type} {adjective} di {rooms} locali a {city}',
            '{property_type} in {sale_type} vicino a {landmark}',
            '{property_type} {rooms} locali con {feature} a {city}',
            '{adjective} {property_type} — {city}',
            '{property_type} in {sale_type} a {city}',
        ],
        'nl' => [
            '{adjective} {rooms}-kamer {property_type} in {city}',
            '{property_type} te {sale_type} nabij {landmark}',
            '{rooms}-kamer {property_type} met {feature} in {city}',
            '{adjective} {property_type} — {city}',
            '{property_type} te {sale_type} in {city}',
        ],
        'pt' => [
            '{property_type} {adjective} com {rooms} quartos em {city}',
            '{property_type} para {sale_type} perto de {landmark}',
            '{property_type} de {rooms} quartos com {feature} em {city}',
            '{adjective} {property_type} — {city}',
            '{property_type} para {sale_type} em {city}',
        ],
        'pl' => [
            '{adjective} {property_type} {rooms}-pokojowe w {city}',
            '{property_type} na {sale_type} przy {landmark}',
            '{property_type} {rooms} pokoje z {feature} w {city}',
            '{adjective} {property_type} — {city}',
            '{property_type} na {sale_type} w {city}',
        ],
        'ru' => [
            '{adjective} {rooms}-комнатная {property_type} в {city}',
            '{property_type} на {sale_type} рядом с {landmark}',
            '{rooms}-комнатная {property_type} с {feature} в {city}',
            '{adjective} {property_type} — {city}',
            '{property_type} на {sale_type} в {city}',
        ],
        'ja' => [
            '{city}の{adjective}{rooms}部屋{property_type}',
            '{landmark}近くの{property_type}（{sale_type}）',
            '{city} {rooms}部屋 {feature}付き{property_type}',
            '{adjective}{property_type} — {city}',
            '{city}の{property_type}（{sale_type}）',
        ],
        'zh' => [
            '{city}{adjective}{rooms}居室{property_type}',
            '{landmark}附近{property_type}（{sale_type}）',
            '{city} {rooms}居室 带{feature}{property_type}',
            '{adjective}{property_type} — {city}',
            '{city}{property_type}（{sale_type}）',
        ],
    ],

    // =========================================================================
    // 5. EVENT
    // =========================================================================
    'event|veranstaltung|événement|evento|evenement|wydarzenie|мероприятие|イベント|活动' => [
        'en' => [
            '{event_type}: {topic} in {city}',
            '{adjective} {event_type} — {topic}',
            '{topic} {event_type} by {organizer}',
            '{organizer} presents: {adjective} {topic}',
            '{event_type} in {city} — {topic}',
        ],
        'de' => [
            '{event_type}: {topic} in {city}',
            '{adjective} {event_type} — {topic}',
            '{topic}-{event_type} von {organizer}',
            '{organizer} präsentiert: {adjective} {topic}',
            '{event_type} in {city} — {topic}',
        ],
        'fr' => [
            '{event_type} : {topic} à {city}',
            '{event_type} {adjective} — {topic}',
            '{event_type} {topic} par {organizer}',
            '{organizer} présente : {topic} {adjective}',
            '{event_type} à {city} — {topic}',
        ],
        'es' => [
            '{event_type}: {topic} en {city}',
            '{event_type} {adjective} — {topic}',
            '{event_type} de {topic} por {organizer}',
            '{organizer} presenta: {topic} {adjective}',
            '{event_type} en {city} — {topic}',
        ],
        'it' => [
            '{event_type}: {topic} a {city}',
            '{event_type} {adjective} — {topic}',
            '{event_type} su {topic} di {organizer}',
            '{organizer} presenta: {topic} {adjective}',
            '{event_type} a {city} — {topic}',
        ],
        'nl' => [
            '{event_type}: {topic} in {city}',
            '{adjective} {event_type} — {topic}',
            '{topic} {event_type} door {organizer}',
            '{organizer} presenteert: {adjective} {topic}',
            '{event_type} in {city} — {topic}',
        ],
        'pt' => [
            '{event_type}: {topic} em {city}',
            '{event_type} {adjective} — {topic}',
            '{event_type} de {topic} por {organizer}',
            '{organizer} apresenta: {topic} {adjective}',
            '{event_type} em {city} — {topic}',
        ],
        'pl' => [
            '{event_type}: {topic} w {city}',
            '{adjective} {event_type} — {topic}',
            '{event_type} na temat {topic} od {organizer}',
            '{organizer} zaprasza: {adjective} {topic}',
            '{event_type} w {city} — {topic}',
        ],
        'ru' => [
            '{event_type}: {topic} в {city}',
            '{adjective} {event_type} — {topic}',
            '{event_type} по теме {topic} от {organizer}',
            '{organizer} представляет: {adjective} {topic}',
            '{event_type} в {city} — {topic}',
        ],
        'ja' => [
            '{event_type}：{city}で{topic}',
            '{adjective}{event_type} — {topic}',
            '{organizer}主催 {topic}{event_type}',
            '{organizer}が贈る{adjective}{topic}',
            '{city}にて{event_type} — {topic}',
        ],
        'zh' => [
            '{event_type}：{city}{topic}',
            '{adjective}{event_type} — {topic}',
            '{organizer}举办的{topic}{event_type}',
            '{organizer}呈现：{adjective}{topic}',
            '{city}{event_type} — {topic}',
        ],
    ],

    // =========================================================================
    // 6. TEAM / STAFF
    // =========================================================================
    'team|staff|member|mitarbeiter|person|employee|équipe|squadra|equipo|equipe|zespół|команда|チーム|团队' => [
        'en' => [
            '{first_name} {last_name} - {role}',
            '{first_name} {last_name}, {department}',
            '{role}: {first_name} {last_name}',
            '{first_name} {last_name} — {adjective} {role}',
            '{department} - {first_name} {last_name}',
        ],
        'de' => [
            '{first_name} {last_name} – {role}',
            '{first_name} {last_name}, {department}',
            '{role}: {first_name} {last_name}',
            '{first_name} {last_name} — {adjective} {role}',
            '{department} – {first_name} {last_name}',
        ],
        'fr' => [
            '{first_name} {last_name} — {role}',
            '{first_name} {last_name}, {department}',
            '{role} : {first_name} {last_name}',
            '{first_name} {last_name} — {role} {adjective}',
            '{department} — {first_name} {last_name}',
        ],
        'es' => [
            '{first_name} {last_name} — {role}',
            '{first_name} {last_name}, {department}',
            '{role}: {first_name} {last_name}',
            '{first_name} {last_name} — {role} {adjective}',
            '{department} — {first_name} {last_name}',
        ],
        'it' => [
            '{first_name} {last_name} — {role}',
            '{first_name} {last_name}, {department}',
            '{role}: {first_name} {last_name}',
            '{first_name} {last_name} — {role} {adjective}',
            '{department} — {first_name} {last_name}',
        ],
        'nl' => [
            '{first_name} {last_name} – {role}',
            '{first_name} {last_name}, {department}',
            '{role}: {first_name} {last_name}',
            '{first_name} {last_name} — {adjective} {role}',
            '{department} – {first_name} {last_name}',
        ],
        'pt' => [
            '{first_name} {last_name} — {role}',
            '{first_name} {last_name}, {department}',
            '{role}: {first_name} {last_name}',
            '{first_name} {last_name} — {role} {adjective}',
            '{department} — {first_name} {last_name}',
        ],
        'pl' => [
            '{first_name} {last_name} – {role}',
            '{first_name} {last_name}, {department}',
            '{role}: {first_name} {last_name}',
            '{first_name} {last_name} — {adjective} {role}',
            '{department} – {first_name} {last_name}',
        ],
        'ru' => [
            '{first_name} {last_name} — {role}',
            '{first_name} {last_name}, {department}',
            '{role}: {first_name} {last_name}',
            '{first_name} {last_name} — {adjective} {role}',
            '{department} — {first_name} {last_name}',
        ],
        'ja' => [
            '{last_name} {first_name} — {role}',
            '{last_name} {first_name}（{department}）',
            '{role}：{last_name} {first_name}',
            '{last_name} {first_name} — {adjective}{role}',
            '{department} — {last_name} {first_name}',
        ],
        'zh' => [
            '{last_name}{first_name} — {role}',
            '{last_name}{first_name}（{department}）',
            '{role}：{last_name}{first_name}',
            '{last_name}{first_name} — {adjective}{role}',
            '{department} — {last_name}{first_name}',
        ],
    ],

    // =========================================================================
    // 7. PORTFOLIO / PROJECT
    // =========================================================================
    'portfolio|projekt|project|work|showcase|progetto|proyecto|projeto|проект|ポートフォリオ|作品集' => [
        'en' => [
            '{project_name} — {service_type} for {client}',
            '{adjective} {service_type} Project ({year})',
            '{client}: {project_name}',
            '{service_type} — {project_name}',
            '{project_name} ({year}) — {client}',
        ],
        'de' => [
            '{project_name} — {service_type} für {client}',
            '{adjective} {service_type}-Projekt ({year})',
            '{client}: {project_name}',
            '{service_type} — {project_name}',
            '{project_name} ({year}) — {client}',
        ],
        'fr' => [
            '{project_name} — {service_type} pour {client}',
            'Projet {service_type} {adjective} ({year})',
            '{client} : {project_name}',
            '{service_type} — {project_name}',
            '{project_name} ({year}) — {client}',
        ],
        'es' => [
            '{project_name} — {service_type} para {client}',
            'Proyecto de {service_type} {adjective} ({year})',
            '{client}: {project_name}',
            '{service_type} — {project_name}',
            '{project_name} ({year}) — {client}',
        ],
        'it' => [
            '{project_name} — {service_type} per {client}',
            'Progetto di {service_type} {adjective} ({year})',
            '{client}: {project_name}',
            '{service_type} — {project_name}',
            '{project_name} ({year}) — {client}',
        ],
        'nl' => [
            '{project_name} — {service_type} voor {client}',
            '{adjective} {service_type}-project ({year})',
            '{client}: {project_name}',
            '{service_type} — {project_name}',
            '{project_name} ({year}) — {client}',
        ],
        'pt' => [
            '{project_name} — {service_type} para {client}',
            'Projeto de {service_type} {adjective} ({year})',
            '{client}: {project_name}',
            '{service_type} — {project_name}',
            '{project_name} ({year}) — {client}',
        ],
        'pl' => [
            '{project_name} — {service_type} dla {client}',
            '{adjective} projekt {service_type} ({year})',
            '{client}: {project_name}',
            '{service_type} — {project_name}',
            '{project_name} ({year}) — {client}',
        ],
        'ru' => [
            '{project_name} — {service_type} для {client}',
            '{adjective} проект {service_type} ({year})',
            '{client}: {project_name}',
            '{service_type} — {project_name}',
            '{project_name} ({year}) — {client}',
        ],
        'ja' => [
            '{project_name} — {client}向け{service_type}',
            '{adjective}{service_type}プロジェクト（{year}）',
            '{client}：{project_name}',
            '{service_type} — {project_name}',
            '{project_name}（{year}）— {client}',
        ],
        'zh' => [
            '{project_name} — 为{client}提供的{service_type}',
            '{adjective}{service_type}项目（{year}）',
            '{client}：{project_name}',
            '{service_type} — {project_name}',
            '{project_name}（{year}）— {client}',
        ],
    ],

    // =========================================================================
    // 8. JOB / CAREER
    // =========================================================================
    'job|stelle|career|position|vacancy|emploi|lavoro|empleo|vaga|praca|вакансия|求人|职位' => [
        'en' => [
            '{level} {role} at {company}',
            '{role} — {company}, {city}',
            '{company} is hiring: {level} {role}',
            '{role} ({type}) — {city}',
            '{level} {role} — {company}',
        ],
        'de' => [
            '{level} {role} bei {company}',
            '{role} — {company}, {city}',
            '{company} sucht: {level} {role}',
            '{role} ({type}) — {city}',
            '{level} {role} — {company}',
        ],
        'fr' => [
            '{role} {level} chez {company}',
            '{role} — {company}, {city}',
            '{company} recrute : {role} {level}',
            '{role} ({type}) — {city}',
            '{role} {level} — {company}',
        ],
        'es' => [
            '{role} {level} en {company}',
            '{role} — {company}, {city}',
            '{company} busca: {role} {level}',
            '{role} ({type}) — {city}',
            '{role} {level} — {company}',
        ],
        'it' => [
            '{role} {level} presso {company}',
            '{role} — {company}, {city}',
            '{company} cerca: {role} {level}',
            '{role} ({type}) — {city}',
            '{role} {level} — {company}',
        ],
        'nl' => [
            '{level} {role} bij {company}',
            '{role} — {company}, {city}',
            '{company} zoekt: {level} {role}',
            '{role} ({type}) — {city}',
            '{level} {role} — {company}',
        ],
        'pt' => [
            '{role} {level} na {company}',
            '{role} — {company}, {city}',
            '{company} contrata: {role} {level}',
            '{role} ({type}) — {city}',
            '{role} {level} — {company}',
        ],
        'pl' => [
            '{level} {role} w {company}',
            '{role} — {company}, {city}',
            '{company} szuka: {level} {role}',
            '{role} ({type}) — {city}',
            '{level} {role} — {company}',
        ],
        'ru' => [
            '{level} {role} в {company}',
            '{role} — {company}, {city}',
            '{company} ищет: {level} {role}',
            '{role} ({type}) — {city}',
            '{level} {role} — {company}',
        ],
        'ja' => [
            '{company} — {level}{role}募集',
            '{role} — {company}（{city}）',
            '{company}が{level}{role}を募集中',
            '{role}（{type}）— {city}',
            '{level}{role} — {company}',
        ],
        'zh' => [
            '{company} — 招聘{level}{role}',
            '{role} — {company}（{city}）',
            '{company}招聘：{level}{role}',
            '{role}（{type}）— {city}',
            '{level}{role} — {company}',
        ],
    ],

    // =========================================================================
    // 9. COURSE / EDUCATION
    // =========================================================================
    'course|kurs|class|lesson|training|cours|corso|curso|kurs|курс|コース|课程' => [
        'en' => [
            '{level} {topic} {format}',
            '{topic} for Beginners — {duration}',
            '{adjective} {topic} {format} ({level})',
            'Learn {topic}: {level} {format}',
            '{topic} {format} — {duration}',
        ],
        'de' => [
            '{level} {topic} {format}',
            '{topic} für Anfänger — {duration}',
            '{adjective} {topic}-{format} ({level})',
            '{topic} lernen: {level} {format}',
            '{topic}-{format} — {duration}',
        ],
        'fr' => [
            '{format} {topic} — niveau {level}',
            '{topic} pour débutants — {duration}',
            '{format} {adjective} de {topic} ({level})',
            'Apprendre {topic} : {format} {level}',
            '{format} {topic} — {duration}',
        ],
        'es' => [
            '{format} de {topic} — nivel {level}',
            '{topic} para principiantes — {duration}',
            '{format} {adjective} de {topic} ({level})',
            'Aprende {topic}: {format} {level}',
            '{format} de {topic} — {duration}',
        ],
        'it' => [
            '{format} di {topic} — livello {level}',
            '{topic} per principianti — {duration}',
            '{format} {adjective} di {topic} ({level})',
            'Impara {topic}: {format} {level}',
            '{format} di {topic} — {duration}',
        ],
        'nl' => [
            '{level} {topic} {format}',
            '{topic} voor beginners — {duration}',
            '{adjective} {topic}-{format} ({level})',
            'Leer {topic}: {level} {format}',
            '{topic} {format} — {duration}',
        ],
        'pt' => [
            '{format} de {topic} — nível {level}',
            '{topic} para iniciantes — {duration}',
            '{format} {adjective} de {topic} ({level})',
            'Aprenda {topic}: {format} {level}',
            '{format} de {topic} — {duration}',
        ],
        'pl' => [
            '{level} {format} {topic}',
            '{topic} dla początkujących — {duration}',
            '{adjective} {format} {topic} ({level})',
            'Naucz się {topic}: {level} {format}',
            '{format} {topic} — {duration}',
        ],
        'ru' => [
            '{level} {format} по {topic}',
            '{topic} для начинающих — {duration}',
            '{adjective} {format} по {topic} ({level})',
            'Изучите {topic}: {level} {format}',
            '{format} {topic} — {duration}',
        ],
        'ja' => [
            '{level}{topic}{format}',
            '初心者向け{topic} — {duration}',
            '{adjective}{topic}{format}（{level}）',
            '{topic}を学ぶ：{level}{format}',
            '{topic}{format} — {duration}',
        ],
        'zh' => [
            '{level}{topic}{format}',
            '{topic}入门 — {duration}',
            '{adjective}{topic}{format}（{level}）',
            '学习{topic}：{level}{format}',
            '{topic}{format} — {duration}',
        ],
    ],

    // =========================================================================
    // 10. TESTIMONIAL / REVIEW
    // =========================================================================
    'testimonial|review|bewertung|feedback|referenz|avis|recensione|reseña|avaliação|recenzja|отзыв|レビュー|评价' => [
        'en' => [
            '"{adjective} {product}!" — {author}',
            '{author} on {product}: {rating} Stars',
            'Review: {adjective} {product}',
            '{author}\'s Take on {product}',
            '{product} — {rating}-Star Review by {author}',
        ],
        'de' => [
            '"{adjective} {product}!" — {author}',
            '{author} über {product}: {rating} Sterne',
            'Bewertung: {adjective} {product}',
            '{author}s Meinung zu {product}',
            '{product} — {rating}-Sterne-Bewertung von {author}',
        ],
        'fr' => [
            '"{product} {adjective} !" — {author}',
            '{author} sur {product} : {rating} étoiles',
            'Avis : {product} {adjective}',
            'L\'avis de {author} sur {product}',
            '{product} — {rating} étoiles par {author}',
        ],
        'es' => [
            '"¡{product} {adjective}!" — {author}',
            '{author} sobre {product}: {rating} estrellas',
            'Reseña: {product} {adjective}',
            'La opinión de {author} sobre {product}',
            '{product} — {rating} estrellas por {author}',
        ],
        'it' => [
            '"{product} {adjective}!" — {author}',
            '{author} su {product}: {rating} stelle',
            'Recensione: {product} {adjective}',
            'Il parere di {author} su {product}',
            '{product} — {rating} stelle da {author}',
        ],
        'nl' => [
            '"{adjective} {product}!" — {author}',
            '{author} over {product}: {rating} sterren',
            'Review: {adjective} {product}',
            'De mening van {author} over {product}',
            '{product} — {rating}-sterren review van {author}',
        ],
        'pt' => [
            '"{product} {adjective}!" — {author}',
            '{author} sobre {product}: {rating} estrelas',
            'Avaliação: {product} {adjective}',
            'A opinião de {author} sobre {product}',
            '{product} — {rating} estrelas por {author}',
        ],
        'pl' => [
            '"{adjective} {product}!" — {author}',
            '{author} o {product}: {rating} gwiazdek',
            'Recenzja: {adjective} {product}',
            'Opinia {author} o {product}',
            '{product} — {rating} gwiazdek od {author}',
        ],
        'ru' => [
            '"{adjective} {product}!" — {author}',
            '{author} о {product}: {rating} звёзд',
            'Отзыв: {adjective} {product}',
            'Мнение {author} о {product}',
            '{product} — {rating} звёзд от {author}',
        ],
        'ja' => [
            '「{adjective}{product}」— {author}',
            '{author}の{product}レビュー：{rating}つ星',
            'レビュー：{adjective}{product}',
            '{author}による{product}の感想',
            '{product} — {author}の{rating}つ星レビュー',
        ],
        'zh' => [
            '"{adjective}{product}！" — {author}',
            '{author}评价{product}：{rating}星',
            '评测：{adjective}{product}',
            '{author}对{product}的评价',
            '{product} — {author}的{rating}星评价',
        ],
    ],

    // =========================================================================
    // 11. STUDIO / COMPANY / ORGANIZATION (company name)
    // =========================================================================
    'studio|agency|agentur|company|firma|unternehmen|organization|organisation|brand|label|publisher|verlag|production|produktion|société|entreprise|empresa|azienda|bedrijf|компания|スタジオ|工作室' => [
        'en' => [
            '{company_name}',
        ],
        'de' => [
            '{company_name}',
        ],
        'fr' => [
            '{company_name}',
        ],
        'es' => [
            '{company_name}',
        ],
        'it' => [
            '{company_name}',
        ],
        'nl' => [
            '{company_name}',
        ],
        'pt' => [
            '{company_name}',
        ],
        'pl' => [
            '{company_name}',
        ],
        'ru' => [
            '{company_name}',
        ],
        'ja' => [
            '{company_name}',
        ],
        'zh' => [
            '{company_name}',
        ],
    ],

    // =========================================================================
    // 12. MOVIE / FILM
    // =========================================================================
    'movie|film|kino|cinema|cinéma|película|filme|фильм|映画|电影|motion.*picture|spielfilm|dokumentarfilm|kurzfilm|court.*métrage|cortometraje|curta' => [
        'en' => [
            'The {adjective} {noun}',
            '{noun}: {subtitle}',
            'The Last {noun}',
            '{adjective} {noun}',
            'Beyond the {noun}',
        ],
        'de' => [
            'Der {adjective} {noun}',
            '{noun}: {subtitle}',
            'Der letzte {noun}',
            '{adjective} {noun}',
            'Jenseits der {noun}',
        ],
        'fr' => [
            'Le {noun} {adjective}',
            '{noun}: {subtitle}',
            'Le dernier {noun}',
            '{adjective} {noun}',
            'Au-delà du {noun}',
        ],
        'es' => [
            'El {noun} {adjective}',
            '{noun}: {subtitle}',
            'El último {noun}',
            '{adjective} {noun}',
            'Más allá del {noun}',
        ],
        'it' => [
            'Il {noun} {adjective}',
            '{noun}: {subtitle}',
            'L\'ultimo {noun}',
            '{adjective} {noun}',
            'Oltre il {noun}',
        ],
        'nl' => [
            'De {adjective} {noun}',
            '{noun}: {subtitle}',
            'De laatste {noun}',
            '{adjective} {noun}',
            'Voorbij de {noun}',
        ],
        'pt' => [
            'O {noun} {adjective}',
            '{noun}: {subtitle}',
            'O último {noun}',
            '{adjective} {noun}',
            'Além do {noun}',
        ],
        'pl' => [
            '{adjective} {noun}',
            '{noun}: {subtitle}',
            'Ostatni {noun}',
            '{adjective} {noun}',
            'Poza {noun}',
        ],
        'ru' => [
            '{adjective} {noun}',
            '{noun}: {subtitle}',
            'Последний {noun}',
            '{adjective} {noun}',
            'За пределами {noun}',
        ],
        'ja' => [
            '{adjective}{noun}',
            '{noun}：{subtitle}',
            '最後の{noun}',
            '{adjective}{noun}',
            '{noun}の彼方',
        ],
        'zh' => [
            '{adjective}{noun}',
            '{noun}：{subtitle}',
            '最后的{noun}',
            '{adjective}{noun}',
            '{noun}之外',
        ],
    ],

    // =========================================================================
    // 13. AGENT / PERSON (simple name only)
    // =========================================================================
    'agent|makler|berater|advisor|consultant|représentant|agente|doradca|агент|エージェント|经纪人|attorney|lawyer|anwalt|avocat|abogado|director|actor|actress|artist|author|writer|speaker|coach|trainer|instructor|regisseur|schauspieler|künstler|auteur|artiste|acteur|réalisateur|監督|导演|俳優|演员' => [
        'en' => [
            '{first_name} {last_name}',
        ],
        'de' => [
            '{first_name} {last_name}',
        ],
        'fr' => [
            '{first_name} {last_name}',
        ],
        'es' => [
            '{first_name} {last_name}',
        ],
        'it' => [
            '{first_name} {last_name}',
        ],
        'nl' => [
            '{first_name} {last_name}',
        ],
        'pt' => [
            '{first_name} {last_name}',
        ],
        'pl' => [
            '{first_name} {last_name}',
        ],
        'ru' => [
            '{last_name} {first_name}',
        ],
        'ja' => [
            '{last_name} {first_name}',
        ],
        'zh' => [
            '{last_name}{first_name}',
        ],
    ],

    ];

    /**
     * Title placeholder data per CPT domain
     */
    protected const CPT_TITLE_DATA = [

    // =========================================================================
    // 1. VEHICLE
    // =========================================================================
    'vehicle' => [
        'brand' => ['BMW', 'Mercedes-Benz', 'Audi', 'Volkswagen', 'Toyota', 'Honda', 'Ford', 'Porsche', 'Volvo', 'Hyundai', 'Kia', 'Mazda', 'Nissan', 'Opel', 'Tesla', 'Škoda', 'Renault'],
        'model' => ['X3', 'X5', 'A4', 'A6', 'Golf', 'Passat', 'Corolla', 'Civic', 'Focus', 'Cayenne', '3er', 'C-Klasse', 'E-Klasse', 'Tiguan', 'Octavia', 'Model 3', 'Tucson', 'Sportage', 'CX-5', 'Qashqai', 'Corsa', 'Clio'],
        'trim' => ['Sport', 'Luxury', 'Premium', 'Base', 'GT', 'S-Line', 'AMG', 'M Sport', 'R-Line', 'GTI', 'RS', 'TDI', 'TFSI', 'xDrive', '4MATIC', 'Quattro'],
        'condition' => [
            'en' => ['Excellent Condition', 'Low Mileage', 'One Owner', 'Certified Pre-Owned', 'Like New'],
            'de' => ['Top Zustand', 'Wenig Kilometer', 'Erstbesitz', 'Geprüftes Gebrauchtfahrzeug', 'Wie Neu'],
            'fr' => ['Excellent État', 'Faible Kilométrage', 'Premier Propriétaire', 'Occasion Certifiée', 'Comme Neuf'],
            'es' => ['Excelente Estado', 'Bajo Kilometraje', 'Único Dueño', 'Seminuevo Certificado', 'Como Nuevo'],
            'it' => ['Ottime Condizioni', 'Basso Chilometraggio', 'Primo Proprietario', 'Usato Certificato', 'Come Nuovo'],
            'nl' => ['Uitstekende Staat', 'Weinig Kilometers', 'Eerste Eigenaar', 'Gecertificeerd', 'Als Nieuw'],
            'pt' => ['Excelente Estado', 'Baixa Quilometragem', 'Único Dono', 'Seminovo Certificado', 'Como Novo'],
            'pl' => ['Stan Idealny', 'Niski Przebieg', 'Pierwszy Właściciel', 'Certyfikowany', 'Jak Nowy'],
            'ru' => ['Отличное состояние', 'Малый пробег', 'Один владелец', 'Сертифицированный', 'Как новый'],
            'ja' => ['極上コンディション', '低走行', 'ワンオーナー', '認定中古車', '新車同様'],
            'zh' => ['极佳状态', '低里程', '一手车', '认证二手车', '准新车'],
        ],
        'fuel' => [
            'en' => ['Diesel', 'Gasoline', 'Electric', 'Hybrid', 'PHEV'],
            'de' => ['Diesel', 'Benzin', 'Elektro', 'Hybrid', 'PHEV'],
            'fr' => ['Diesel', 'Essence', 'Électrique', 'Hybride', 'PHEV'],
            'es' => ['Diésel', 'Gasolina', 'Eléctrico', 'Híbrido', 'PHEV'],
            'it' => ['Diesel', 'Benzina', 'Elettrico', 'Ibrido', 'PHEV'],
            'nl' => ['Diesel', 'Benzine', 'Elektrisch', 'Hybride', 'PHEV'],
            'pt' => ['Diesel', 'Gasolina', 'Elétrico', 'Híbrido', 'PHEV'],
            'pl' => ['Diesel', 'Benzyna', 'Elektryczny', 'Hybrydowy', 'PHEV'],
            'ru' => ['Дизель', 'Бензин', 'Электро', 'Гибрид', 'PHEV'],
            'ja' => ['ディーゼル', 'ガソリン', '電気', 'ハイブリッド', 'PHEV'],
            'zh' => ['柴油', '汽油', '纯电动', '混合动力', '插电混动'],
        ],
        'mileage' => ['12.500', '28.000', '45.000', '67.000', '89.000', '105.000', '132.000', '8.900', '55.000', '73.000'],
    ],

    // =========================================================================
    // 2. RECIPE
    // =========================================================================
    'recipe' => [
        'adjective' => [
            'en' => ['Spicy', 'Creamy', 'Crispy', 'Fresh', 'Savory', 'Sweet', 'Smoky', 'Tangy'],
            'de' => ['Würzige', 'Cremige', 'Knusprige', 'Frische', 'Herzhafte', 'Süße', 'Geräucherte', 'Pikante'],
            'fr' => ['Épicé', 'Crémeux', 'Croustillant', 'Frais', 'Savoureux', 'Sucré', 'Fumé', 'Acidulé'],
            'es' => ['Picante', 'Cremoso', 'Crujiente', 'Fresco', 'Sabroso', 'Dulce', 'Ahumado', 'Ácido'],
            'it' => ['Piccante', 'Cremoso', 'Croccante', 'Fresco', 'Saporito', 'Dolce', 'Affumicato', 'Agrumato'],
            'nl' => ['Pittig', 'Romig', 'Knapperig', 'Fris', 'Hartig', 'Zoet', 'Gerookt', 'Zuur'],
            'pt' => ['Picante', 'Cremoso', 'Crocante', 'Fresco', 'Saboroso', 'Doce', 'Defumado', 'Agridoce'],
            'pl' => ['Pikantny', 'Kremowy', 'Chrupiący', 'Świeży', 'Aromatyczny', 'Słodki', 'Wędzony', 'Kwaśny'],
            'ru' => ['Острый', 'Сливочный', 'Хрустящий', 'Свежий', 'Пикантный', 'Сладкий', 'Копчёный', 'Пряный'],
            'ja' => ['スパイシー', 'クリーミー', 'カリカリ', 'フレッシュ', '旨味', '甘い', 'スモーキー', 'ピリ辛'],
            'zh' => ['香辣', '奶油', '酥脆', '清爽', '鲜美', '甜蜜', '烟熏', '酸甜'],
        ],
        'ingredient' => [
            'en' => ['Chicken', 'Salmon', 'Mushroom', 'Tomato', 'Avocado', 'Garlic', 'Lemon', 'Spinach', 'Cheese'],
            'de' => ['Hähnchen', 'Lachs', 'Pilz', 'Tomaten', 'Avocado', 'Knoblauch', 'Zitronen', 'Spinat', 'Käse'],
            'fr' => ['Poulet', 'Saumon', 'Champignon', 'Tomate', 'Avocat', 'Ail', 'Citron', 'Épinard', 'Fromage'],
            'es' => ['Pollo', 'Salmón', 'Champiñón', 'Tomate', 'Aguacate', 'Ajo', 'Limón', 'Espinaca', 'Queso'],
            'it' => ['Pollo', 'Salmone', 'Funghi', 'Pomodoro', 'Avocado', 'Aglio', 'Limone', 'Spinaci', 'Formaggio'],
            'nl' => ['Kip', 'Zalm', 'Champignon', 'Tomaat', 'Avocado', 'Knoflook', 'Citroen', 'Spinazie', 'Kaas'],
            'pt' => ['Frango', 'Salmão', 'Cogumelo', 'Tomate', 'Abacate', 'Alho', 'Limão', 'Espinafre', 'Queijo'],
            'pl' => ['Kurczak', 'Łosoś', 'Pieczarki', 'Pomidor', 'Awokado', 'Czosnek', 'Cytryna', 'Szpinak', 'Ser'],
            'ru' => ['Курица', 'Лосось', 'Грибы', 'Томат', 'Авокадо', 'Чеснок', 'Лимон', 'Шпинат', 'Сыр'],
            'ja' => ['チキン', 'サーモン', 'きのこ', 'トマト', 'アボカド', 'にんにく', 'レモン', 'ほうれん草', 'チーズ'],
            'zh' => ['鸡肉', '三文鱼', '蘑菇', '番茄', '牛油果', '大蒜', '柠檬', '菠菜', '奶酪'],
        ],
        'ingredient2' => [
            'en' => ['Herbs', 'Parmesan', 'Olive Oil', 'Basil', 'Bacon', 'Rice'],
            'de' => ['Kräutern', 'Parmesan', 'Olivenöl', 'Basilikum', 'Speck', 'Reis'],
            'fr' => ['Herbes', 'Parmesan', 'Huile d\'Olive', 'Basilic', 'Lardons', 'Riz'],
            'es' => ['Hierbas', 'Parmesano', 'Aceite de Oliva', 'Albahaca', 'Tocino', 'Arroz'],
            'it' => ['Erbe', 'Parmigiano', 'Olio d\'Oliva', 'Basilico', 'Pancetta', 'Riso'],
            'nl' => ['Kruiden', 'Parmezaan', 'Olijfolie', 'Basilicum', 'Spek', 'Rijst'],
            'pt' => ['Ervas', 'Parmesão', 'Azeite', 'Manjericão', 'Bacon', 'Arroz'],
            'pl' => ['Zioła', 'Parmezan', 'Oliwa', 'Bazylia', 'Boczek', 'Ryż'],
            'ru' => ['Травы', 'Пармезан', 'Оливковое масло', 'Базилик', 'Бекон', 'Рис'],
            'ja' => ['ハーブ', 'パルメザン', 'オリーブオイル', 'バジル', 'ベーコン', 'ライス'],
            'zh' => ['香草', '帕玛森', '橄榄油', '罗勒', '培根', '米饭'],
        ],
        'dish' => [
            'en' => ['Soup', 'Pasta', 'Salad', 'Stew', 'Curry', 'Pie', 'Bowl', 'Wrap', 'Risotto'],
            'de' => ['Suppe', 'Pasta', 'Salat', 'Eintopf', 'Curry', 'Auflauf', 'Bowl', 'Wrap', 'Risotto'],
            'fr' => ['Soupe', 'Pâtes', 'Salade', 'Ragoût', 'Curry', 'Tarte', 'Bowl', 'Wrap', 'Risotto'],
            'es' => ['Sopa', 'Pasta', 'Ensalada', 'Guiso', 'Curry', 'Empanada', 'Bowl', 'Wrap', 'Risotto'],
            'it' => ['Zuppa', 'Pasta', 'Insalata', 'Stufato', 'Curry', 'Torta', 'Bowl', 'Wrap', 'Risotto'],
            'nl' => ['Soep', 'Pasta', 'Salade', 'Stoofpot', 'Curry', 'Taart', 'Bowl', 'Wrap', 'Risotto'],
            'pt' => ['Sopa', 'Massa', 'Salada', 'Ensopado', 'Curry', 'Torta', 'Bowl', 'Wrap', 'Risotto'],
            'pl' => ['Zupa', 'Makaron', 'Sałatka', 'Gulasz', 'Curry', 'Zapiekanka', 'Bowl', 'Wrap', 'Risotto'],
            'ru' => ['Суп', 'Паста', 'Салат', 'Рагу', 'Карри', 'Пирог', 'Боул', 'Ролл', 'Ризотто'],
            'ja' => ['スープ', 'パスタ', 'サラダ', 'シチュー', 'カレー', 'パイ', 'ボウル', 'ラップ', 'リゾット'],
            'zh' => ['汤', '意面', '沙拉', '炖菜', '咖喱', '派', '碗', '卷饼', '烩饭'],
        ],
        'cuisine' => [
            'en' => ['Italian', 'Thai', 'Mexican', 'Japanese', 'Indian', 'French', 'Greek', 'Korean'],
            'de' => ['Italienische', 'Thai', 'Mexikanische', 'Japanische', 'Indische', 'Französische', 'Griechische', 'Koreanische'],
            'fr' => ['Italienne', 'Thaïlandaise', 'Mexicaine', 'Japonaise', 'Indienne', 'Française', 'Grecque', 'Coréenne'],
            'es' => ['Italiana', 'Tailandesa', 'Mexicana', 'Japonesa', 'India', 'Francesa', 'Griega', 'Coreana'],
            'it' => ['Italiana', 'Thailandese', 'Messicana', 'Giapponese', 'Indiana', 'Francese', 'Greca', 'Coreana'],
            'nl' => ['Italiaans', 'Thais', 'Mexicaans', 'Japans', 'Indiaas', 'Frans', 'Grieks', 'Koreaans'],
            'pt' => ['Italiana', 'Tailandesa', 'Mexicana', 'Japonesa', 'Indiana', 'Francesa', 'Grega', 'Coreana'],
            'pl' => ['Włoska', 'Tajska', 'Meksykańska', 'Japońska', 'Indyjska', 'Francuska', 'Grecka', 'Koreańska'],
            'ru' => ['Итальянская', 'Тайская', 'Мексиканская', 'Японская', 'Индийская', 'Французская', 'Греческая', 'Корейская'],
            'ja' => ['イタリアン', 'タイ', 'メキシカン', '和風', 'インド', 'フレンチ', 'ギリシャ', '韓国'],
            'zh' => ['意大利', '泰式', '墨西哥', '日式', '印度', '法式', '希腊', '韩式'],
        ],
    ],

    // =========================================================================
    // 3. PRODUCT
    // =========================================================================
    'product' => [
        'adjective' => [
            'en' => ['Premium', 'Handcrafted', 'Organic', 'Vintage', 'Modern', 'Elegant'],
            'de' => ['Premium', 'Handgefertigtes', 'Bio', 'Vintage', 'Modernes', 'Elegantes'],
            'fr' => ['Premium', 'Artisanal', 'Bio', 'Vintage', 'Moderne', 'Élégant'],
            'es' => ['Premium', 'Artesanal', 'Orgánico', 'Vintage', 'Moderno', 'Elegante'],
            'it' => ['Premium', 'Artigianale', 'Biologico', 'Vintage', 'Moderno', 'Elegante'],
            'nl' => ['Premium', 'Handgemaakt', 'Biologisch', 'Vintage', 'Modern', 'Elegant'],
            'pt' => ['Premium', 'Artesanal', 'Orgânico', 'Vintage', 'Moderno', 'Elegante'],
            'pl' => ['Ekskluzywny', 'Ręcznie robiony', 'Organiczny', 'Vintage', 'Nowoczesny', 'Elegancki'],
            'ru' => ['Премиум', 'Ручной работы', 'Органический', 'Винтажный', 'Современный', 'Элегантный'],
            'ja' => ['プレミアム', '手作り', 'オーガニック', 'ヴィンテージ', 'モダン', 'エレガント'],
            'zh' => ['高端', '手工', '有机', '复古', '现代', '优雅'],
        ],
        'material' => [
            'en' => ['Leather', 'Cotton', 'Bamboo', 'Ceramic', 'Wood', 'Steel', 'Silk'],
            'de' => ['Leder', 'Baumwoll', 'Bambus', 'Keramik', 'Holz', 'Stahl', 'Seiden'],
            'fr' => ['Cuir', 'Coton', 'Bambou', 'Céramique', 'Bois', 'Acier', 'Soie'],
            'es' => ['Cuero', 'Algodón', 'Bambú', 'Cerámica', 'Madera', 'Acero', 'Seda'],
            'it' => ['Pelle', 'Cotone', 'Bambù', 'Ceramica', 'Legno', 'Acciaio', 'Seta'],
            'nl' => ['Leer', 'Katoen', 'Bamboe', 'Keramiek', 'Hout', 'Staal', 'Zijde'],
            'pt' => ['Couro', 'Algodão', 'Bambu', 'Cerâmica', 'Madeira', 'Aço', 'Seda'],
            'pl' => ['Skóra', 'Bawełna', 'Bambus', 'Ceramika', 'Drewno', 'Stal', 'Jedwab'],
            'ru' => ['Кожа', 'Хлопок', 'Бамбук', 'Керамика', 'Дерево', 'Сталь', 'Шёлк'],
            'ja' => ['レザー', 'コットン', 'バンブー', 'セラミック', 'ウッド', 'スチール', 'シルク'],
            'zh' => ['皮革', '棉质', '竹制', '陶瓷', '木质', '钢制', '丝绸'],
        ],
        'item' => [
            'en' => ['Bag', 'Watch', 'Lamp', 'Chair', 'Mug', 'Notebook', 'Wallet', 'Scarf'],
            'de' => ['Tasche', 'Uhr', 'Lampe', 'Stuhl', 'Tasse', 'Notizbuch', 'Geldbörse', 'Schal'],
            'fr' => ['Sac', 'Montre', 'Lampe', 'Chaise', 'Tasse', 'Carnet', 'Portefeuille', 'Écharpe'],
            'es' => ['Bolso', 'Reloj', 'Lámpara', 'Silla', 'Taza', 'Cuaderno', 'Cartera', 'Bufanda'],
            'it' => ['Borsa', 'Orologio', 'Lampada', 'Sedia', 'Tazza', 'Quaderno', 'Portafoglio', 'Sciarpa'],
            'nl' => ['Tas', 'Horloge', 'Lamp', 'Stoel', 'Mok', 'Notitieboek', 'Portemonnee', 'Sjaal'],
            'pt' => ['Bolsa', 'Relógio', 'Luminária', 'Cadeira', 'Caneca', 'Caderno', 'Carteira', 'Cachecol'],
            'pl' => ['Torba', 'Zegarek', 'Lampa', 'Krzesło', 'Kubek', 'Notatnik', 'Portfel', 'Szalik'],
            'ru' => ['Сумка', 'Часы', 'Лампа', 'Стул', 'Кружка', 'Блокнот', 'Кошелёк', 'Шарф'],
            'ja' => ['バッグ', '腕時計', 'ランプ', 'チェア', 'マグカップ', 'ノートブック', '財布', 'スカーフ'],
            'zh' => ['包', '手表', '台灯', '椅子', '马克杯', '笔记本', '钱包', '围巾'],
        ],
        'color' => [
            'en' => ['Black', 'Navy Blue', 'Forest Green', 'Burgundy', 'Sand', 'Ivory'],
            'de' => ['Schwarz', 'Marineblau', 'Waldgrün', 'Bordeaux', 'Sand', 'Elfenbein'],
            'fr' => ['Noir', 'Bleu Marine', 'Vert Forêt', 'Bordeaux', 'Sable', 'Ivoire'],
            'es' => ['Negro', 'Azul Marino', 'Verde Bosque', 'Burdeos', 'Arena', 'Marfil'],
            'it' => ['Nero', 'Blu Navy', 'Verde Foresta', 'Borgogna', 'Sabbia', 'Avorio'],
            'nl' => ['Zwart', 'Marineblauw', 'Bosgroen', 'Bordeaux', 'Zand', 'Ivoor'],
            'pt' => ['Preto', 'Azul Marinho', 'Verde Floresta', 'Bordô', 'Areia', 'Marfim'],
            'pl' => ['Czarny', 'Granatowy', 'Leśna Zieleń', 'Bordowy', 'Piaskowy', 'Kość Słoniowa'],
            'ru' => ['Чёрный', 'Тёмно-синий', 'Лесной зелёный', 'Бордовый', 'Песочный', 'Слоновая кость'],
            'ja' => ['ブラック', 'ネイビーブルー', 'フォレストグリーン', 'バーガンディ', 'サンド', 'アイボリー'],
            'zh' => ['黑色', '藏青色', '森林绿', '酒红色', '沙色', '象牙白'],
        ],
        'brand' => ['Artisan', 'Maison', 'Studio', 'Atelier', 'Nordic', 'Heritage'],
        'variant' => ['S', 'M', 'L', 'XL', 'Limited Edition', 'Classic', 'Pro'],
        'audience' => [
            'en' => ['Women', 'Men', 'Kids', 'Professionals', 'Travelers'],
            'de' => ['Damen', 'Herren', 'Kinder', 'Profis', 'Reisende'],
            'fr' => ['Femmes', 'Hommes', 'Enfants', 'Professionnels', 'Voyageurs'],
            'es' => ['Mujeres', 'Hombres', 'Niños', 'Profesionales', 'Viajeros'],
            'it' => ['Donne', 'Uomini', 'Bambini', 'Professionisti', 'Viaggiatori'],
            'nl' => ['Dames', 'Heren', 'Kinderen', 'Professionals', 'Reizigers'],
            'pt' => ['Mulheres', 'Homens', 'Crianças', 'Profissionais', 'Viajantes'],
            'pl' => ['Kobiety', 'Mężczyźni', 'Dzieci', 'Profesjonaliści', 'Podróżnicy'],
            'ru' => ['Женщины', 'Мужчины', 'Дети', 'Профессионалы', 'Путешественники'],
            'ja' => ['レディース', 'メンズ', 'キッズ', 'プロフェッショナル', 'トラベラー'],
            'zh' => ['女性', '男性', '儿童', '专业人士', '旅行者'],
        ],
    ],

    // =========================================================================
    // 4. PROPERTY
    // =========================================================================
    'property' => [
        'property_type' => [
            'en' => ['Apartment', 'House', 'Condo', 'Villa', 'Studio', 'Loft', 'Penthouse'],
            'de' => ['Wohnung', 'Haus', 'Eigentumswohnung', 'Villa', 'Studio', 'Loft', 'Penthouse'],
            'fr' => ['Appartement', 'Maison', 'Copropriété', 'Villa', 'Studio', 'Loft', 'Penthouse'],
            'es' => ['Apartamento', 'Casa', 'Condominio', 'Villa', 'Estudio', 'Loft', 'Ático'],
            'it' => ['Appartamento', 'Casa', 'Condominio', 'Villa', 'Monolocale', 'Loft', 'Attico'],
            'nl' => ['Appartement', 'Huis', 'Condo', 'Villa', 'Studio', 'Loft', 'Penthouse'],
            'pt' => ['Apartamento', 'Casa', 'Condomínio', 'Villa', 'Estúdio', 'Loft', 'Cobertura'],
            'pl' => ['Mieszkanie', 'Dom', 'Apartament', 'Willa', 'Kawalerka', 'Loft', 'Penthouse'],
            'ru' => ['Квартира', 'Дом', 'Кондоминиум', 'Вилла', 'Студия', 'Лофт', 'Пентхаус'],
            'ja' => ['マンション', '一戸建て', 'コンドミニアム', '別荘', 'ワンルーム', 'ロフト', 'ペントハウス'],
            'zh' => ['公寓', '别墅', '共管公寓', '庄园', '单间', '阁楼', '顶层公寓'],
        ],
        'rooms' => ['1', '2', '3', '4', '5'],
        'sale_type' => [
            'en' => ['Sale', 'Rent'],
            'de' => ['Verkauf', 'Miete'],
            'fr' => ['Vente', 'Location'],
            'es' => ['Venta', 'Alquiler'],
            'it' => ['Vendita', 'Affitto'],
            'nl' => ['Koop', 'Huur'],
            'pt' => ['Venda', 'Aluguel'],
            'pl' => ['Sprzedaż', 'Wynajem'],
            'ru' => ['Продажа', 'Аренда'],
            'ja' => ['売買', '賃貸'],
            'zh' => ['出售', '出租'],
        ],
        'feature' => [
            'en' => ['Garden', 'Balcony', 'Garage', 'Pool', 'Terrace', 'Sea View'],
            'de' => ['Garten', 'Balkon', 'Garage', 'Pool', 'Terrasse', 'Seeblick'],
            'fr' => ['Jardin', 'Balcon', 'Garage', 'Piscine', 'Terrasse', 'Vue Mer'],
            'es' => ['Jardín', 'Balcón', 'Garaje', 'Piscina', 'Terraza', 'Vista al Mar'],
            'it' => ['Giardino', 'Balcone', 'Garage', 'Piscina', 'Terrazza', 'Vista Mare'],
            'nl' => ['Tuin', 'Balkon', 'Garage', 'Zwembad', 'Terras', 'Zeezicht'],
            'pt' => ['Jardim', 'Varanda', 'Garagem', 'Piscina', 'Terraço', 'Vista para o Mar'],
            'pl' => ['Ogród', 'Balkon', 'Garaż', 'Basen', 'Taras', 'Widok na Morze'],
            'ru' => ['Сад', 'Балкон', 'Гараж', 'Бассейн', 'Терраса', 'Вид на море'],
            'ja' => ['庭園', 'バルコニー', 'ガレージ', 'プール', 'テラス', 'オーシャンビュー'],
            'zh' => ['花园', '阳台', '车库', '泳池', '露台', '海景'],
        ],
        'adjective' => [
            'en' => ['Bright', 'Modern', 'Renovated', 'Charming', 'Luxury'],
            'de' => ['Helle', 'Moderne', 'Renovierte', 'Charmante', 'Luxuriöse'],
            'fr' => ['Lumineux', 'Moderne', 'Rénové', 'Charmant', 'Luxueux'],
            'es' => ['Luminoso', 'Moderno', 'Renovado', 'Encantador', 'Lujoso'],
            'it' => ['Luminoso', 'Moderno', 'Ristrutturato', 'Affascinante', 'Lussuoso'],
            'nl' => ['Licht', 'Modern', 'Gerenoveerd', 'Charmant', 'Luxe'],
            'pt' => ['Luminoso', 'Moderno', 'Renovado', 'Encantador', 'Luxuoso'],
            'pl' => ['Jasne', 'Nowoczesne', 'Odnowione', 'Urokliwe', 'Luksusowe'],
            'ru' => ['Светлая', 'Современная', 'Отремонтированная', 'Уютная', 'Роскошная'],
            'ja' => ['明るい', 'モダン', 'リノベーション済み', '魅力的な', '高級'],
            'zh' => ['明亮', '现代', '翻新', '迷人', '豪华'],
        ],
        'landmark' => [
            'en' => ['City Center', 'Park', 'River', 'School', 'Station'],
            'de' => ['Stadtzentrum', 'Park', 'Fluss', 'Schule', 'Bahnhof'],
            'fr' => ['Centre-Ville', 'Parc', 'Rivière', 'École', 'Gare'],
            'es' => ['Centro', 'Parque', 'Río', 'Colegio', 'Estación'],
            'it' => ['Centro Città', 'Parco', 'Fiume', 'Scuola', 'Stazione'],
            'nl' => ['Stadscentrum', 'Park', 'Rivier', 'School', 'Station'],
            'pt' => ['Centro da Cidade', 'Parque', 'Rio', 'Escola', 'Estação'],
            'pl' => ['Centrum', 'Park', 'Rzeka', 'Szkoła', 'Dworzec'],
            'ru' => ['Центр города', 'Парк', 'Река', 'Школа', 'Вокзал'],
            'ja' => ['市街地', '公園', '川沿い', '学校', '駅前'],
            'zh' => ['市中心', '公园', '河畔', '学校', '车站'],
        ],
    ],

    // =========================================================================
    // 5. EVENT
    // =========================================================================
    'event' => [
        'event_type' => [
            'en' => ['Conference', 'Workshop', 'Meetup', 'Webinar', 'Summit'],
            'de' => ['Konferenz', 'Workshop', 'Meetup', 'Webinar', 'Gipfeltreffen'],
            'fr' => ['Conférence', 'Atelier', 'Meetup', 'Webinaire', 'Sommet'],
            'es' => ['Conferencia', 'Taller', 'Meetup', 'Webinar', 'Cumbre'],
            'it' => ['Conferenza', 'Workshop', 'Meetup', 'Webinar', 'Summit'],
            'nl' => ['Conferentie', 'Workshop', 'Meetup', 'Webinar', 'Top'],
            'pt' => ['Conferência', 'Workshop', 'Meetup', 'Webinar', 'Cúpula'],
            'pl' => ['Konferencja', 'Warsztaty', 'Meetup', 'Webinar', 'Szczyt'],
            'ru' => ['Конференция', 'Мастер-класс', 'Митап', 'Вебинар', 'Саммит'],
            'ja' => ['カンファレンス', 'ワークショップ', 'ミートアップ', 'ウェビナー', 'サミット'],
            'zh' => ['大会', '研讨会', '交流会', '网络研讨会', '峰会'],
        ],
        'topic' => [
            'en' => ['AI & Machine Learning', 'Digital Marketing', 'Web Development', 'UX Design', 'Leadership', 'Data Science', 'Cloud Computing', 'Sustainability'],
            'de' => ['KI & Maschinelles Lernen', 'Digitales Marketing', 'Webentwicklung', 'UX Design', 'Führung', 'Data Science', 'Cloud Computing', 'Nachhaltigkeit'],
            'fr' => ['IA & Machine Learning', 'Marketing Digital', 'Développement Web', 'UX Design', 'Leadership', 'Science des Données', 'Cloud Computing', 'Développement Durable'],
            'es' => ['IA & Machine Learning', 'Marketing Digital', 'Desarrollo Web', 'Diseño UX', 'Liderazgo', 'Ciencia de Datos', 'Computación en la Nube', 'Sostenibilidad'],
            'it' => ['IA & Machine Learning', 'Marketing Digitale', 'Sviluppo Web', 'UX Design', 'Leadership', 'Data Science', 'Cloud Computing', 'Sostenibilità'],
            'nl' => ['AI & Machine Learning', 'Digitale Marketing', 'Webontwikkeling', 'UX Design', 'Leiderschap', 'Data Science', 'Cloud Computing', 'Duurzaamheid'],
            'pt' => ['IA & Machine Learning', 'Marketing Digital', 'Desenvolvimento Web', 'UX Design', 'Liderança', 'Ciência de Dados', 'Computação em Nuvem', 'Sustentabilidade'],
            'pl' => ['AI & Machine Learning', 'Marketing Cyfrowy', 'Tworzenie Stron', 'UX Design', 'Przywództwo', 'Data Science', 'Chmura Obliczeniowa', 'Zrównoważony Rozwój'],
            'ru' => ['ИИ и машинное обучение', 'Цифровой маркетинг', 'Веб-разработка', 'UX-дизайн', 'Лидерство', 'Наука о данных', 'Облачные технологии', 'Устойчивое развитие'],
            'ja' => ['AI・機械学習', 'デジタルマーケティング', 'Web開発', 'UXデザイン', 'リーダーシップ', 'データサイエンス', 'クラウドコンピューティング', 'サステナビリティ'],
            'zh' => ['人工智能与机器学习', '数字营销', 'Web开发', 'UX设计', '领导力', '数据科学', '云计算', '可持续发展'],
        ],
        'adjective' => [
            'en' => ['Annual', 'International', 'Virtual', 'Interactive', 'Exclusive'],
            'de' => ['Jährliche', 'Internationale', 'Virtuelle', 'Interaktive', 'Exklusive'],
            'fr' => ['Annuel', 'International', 'Virtuel', 'Interactif', 'Exclusif'],
            'es' => ['Anual', 'Internacional', 'Virtual', 'Interactivo', 'Exclusivo'],
            'it' => ['Annuale', 'Internazionale', 'Virtuale', 'Interattivo', 'Esclusivo'],
            'nl' => ['Jaarlijkse', 'Internationale', 'Virtuele', 'Interactieve', 'Exclusieve'],
            'pt' => ['Anual', 'Internacional', 'Virtual', 'Interativo', 'Exclusivo'],
            'pl' => ['Coroczna', 'Międzynarodowa', 'Wirtualna', 'Interaktywna', 'Ekskluzywna'],
            'ru' => ['Ежегодная', 'Международная', 'Виртуальная', 'Интерактивная', 'Эксклюзивная'],
            'ja' => ['年次', '国際', 'バーチャル', 'インタラクティブ', '限定'],
            'zh' => ['年度', '国际', '线上', '互动', '专属'],
        ],
        'organizer' => ['TechHub', 'Digital Academy', 'Innovation Lab', 'Creative Network', 'Business Forum'],
    ],

    // =========================================================================
    // 6. TEAM
    // =========================================================================
    'team' => [
        'role' => [
            'en' => ['CEO', 'CTO', 'Designer', 'Developer', 'Marketing Manager', 'Sales Director', 'Project Manager', 'HR Manager'],
            'de' => ['CEO', 'CTO', 'Designer', 'Entwickler', 'Marketing Manager', 'Vertriebsleiter', 'Projektmanager', 'Personalleiter'],
            'fr' => ['PDG', 'CTO', 'Designer', 'Développeur', 'Responsable Marketing', 'Directeur Commercial', 'Chef de Projet', 'DRH'],
            'es' => ['CEO', 'CTO', 'Diseñador', 'Desarrollador', 'Director de Marketing', 'Director de Ventas', 'Gerente de Proyecto', 'Director de RRHH'],
            'it' => ['CEO', 'CTO', 'Designer', 'Sviluppatore', 'Responsabile Marketing', 'Direttore Vendite', 'Project Manager', 'Responsabile HR'],
            'nl' => ['CEO', 'CTO', 'Ontwerper', 'Ontwikkelaar', 'Marketing Manager', 'Sales Directeur', 'Projectmanager', 'HR Manager'],
            'pt' => ['CEO', 'CTO', 'Designer', 'Desenvolvedor', 'Gerente de Marketing', 'Diretor de Vendas', 'Gerente de Projetos', 'Gerente de RH'],
            'pl' => ['Prezes', 'CTO', 'Projektant', 'Programista', 'Kierownik Marketingu', 'Dyrektor Sprzedaży', 'Kierownik Projektu', 'Kierownik HR'],
            'ru' => ['Генеральный директор', 'Технический директор', 'Дизайнер', 'Разработчик', 'Менеджер по маркетингу', 'Директор по продажам', 'Руководитель проекта', 'HR-менеджер'],
            'ja' => ['CEO', 'CTO', 'デザイナー', 'エンジニア', 'マーケティングマネージャー', '営業部長', 'プロジェクトマネージャー', '人事マネージャー'],
            'zh' => ['首席执行官', '首席技术官', '设计师', '开发工程师', '市场经理', '销售总监', '项目经理', '人力资源经理'],
        ],
        'department' => [
            'en' => ['Engineering', 'Design', 'Marketing', 'Sales', 'Operations', 'Management'],
            'de' => ['Technik', 'Design', 'Marketing', 'Vertrieb', 'Betrieb', 'Geschäftsleitung'],
            'fr' => ['Ingénierie', 'Design', 'Marketing', 'Ventes', 'Opérations', 'Direction'],
            'es' => ['Ingeniería', 'Diseño', 'Marketing', 'Ventas', 'Operaciones', 'Dirección'],
            'it' => ['Ingegneria', 'Design', 'Marketing', 'Vendite', 'Operazioni', 'Direzione'],
            'nl' => ['Engineering', 'Ontwerp', 'Marketing', 'Verkoop', 'Operaties', 'Management'],
            'pt' => ['Engenharia', 'Design', 'Marketing', 'Vendas', 'Operações', 'Gestão'],
            'pl' => ['Inżynieria', 'Projektowanie', 'Marketing', 'Sprzedaż', 'Operacje', 'Zarząd'],
            'ru' => ['Разработка', 'Дизайн', 'Маркетинг', 'Продажи', 'Операции', 'Управление'],
            'ja' => ['エンジニアリング', 'デザイン', 'マーケティング', '営業', 'オペレーション', '経営'],
            'zh' => ['工程部', '设计部', '市场部', '销售部', '运营部', '管理层'],
        ],
        'adjective' => [
            'en' => ['Senior', 'Lead', 'Head of', 'Chief', 'Junior'],
            'de' => ['Senior', 'Lead', 'Leiter', 'Chief', 'Junior'],
            'fr' => ['Senior', 'Lead', 'Responsable', 'Chef', 'Junior'],
            'es' => ['Senior', 'Lead', 'Jefe de', 'Director', 'Junior'],
            'it' => ['Senior', 'Lead', 'Responsabile', 'Chief', 'Junior'],
            'nl' => ['Senior', 'Lead', 'Hoofd', 'Chief', 'Junior'],
            'pt' => ['Sênior', 'Lead', 'Chefe de', 'Diretor', 'Júnior'],
            'pl' => ['Starszy', 'Główny', 'Kierownik', 'Szef', 'Młodszy'],
            'ru' => ['Старший', 'Ведущий', 'Руководитель', 'Главный', 'Младший'],
            'ja' => ['シニア', 'リード', '部門長', 'チーフ', 'ジュニア'],
            'zh' => ['高级', '首席', '部门主管', '总监', '初级'],
        ],
    ],

    // =========================================================================
    // 7. PORTFOLIO
    // =========================================================================
    'portfolio' => [
        'project_name' => ['Aurora', 'Nexus', 'Horizon', 'Zenith', 'Pulse', 'Vertex', 'Orbit', 'Catalyst'],
        'client' => ['TechCorp', 'MediaHouse', 'StartupXYZ', 'GreenEnergy', 'FinanceHub', 'HealthPlus', 'EduLearn', 'RetailMax'],
        'service_type' => [
            'en' => ['Web Design', 'Branding', 'App Development', 'Marketing Campaign', 'UI/UX Design'],
            'de' => ['Webdesign', 'Branding', 'App-Entwicklung', 'Marketingkampagne', 'UI/UX Design'],
            'fr' => ['Conception Web', 'Branding', 'Développement d\'App', 'Campagne Marketing', 'Design UI/UX'],
            'es' => ['Diseño Web', 'Branding', 'Desarrollo de Apps', 'Campaña de Marketing', 'Diseño UI/UX'],
            'it' => ['Web Design', 'Branding', 'Sviluppo App', 'Campagna Marketing', 'Design UI/UX'],
            'nl' => ['Webdesign', 'Branding', 'App-Ontwikkeling', 'Marketingcampagne', 'UI/UX Design'],
            'pt' => ['Web Design', 'Branding', 'Desenvolvimento de Apps', 'Campanha de Marketing', 'Design UI/UX'],
            'pl' => ['Projektowanie Stron', 'Branding', 'Tworzenie Aplikacji', 'Kampania Marketingowa', 'Projektowanie UI/UX'],
            'ru' => ['Веб-дизайн', 'Брендинг', 'Разработка приложений', 'Маркетинговая кампания', 'UI/UX дизайн'],
            'ja' => ['Webデザイン', 'ブランディング', 'アプリ開発', 'マーケティングキャンペーン', 'UI/UXデザイン'],
            'zh' => ['网页设计', '品牌策划', '应用开发', '营销活动', 'UI/UX设计'],
        ],
        'adjective' => [
            'en' => ['Award-Winning', 'Innovative', 'Full-Stack', 'Custom', 'Responsive'],
            'de' => ['Preisgekrönt', 'Innovativ', 'Full-Stack', 'Maßgeschneidert', 'Responsiv'],
            'fr' => ['Primé', 'Innovant', 'Full-Stack', 'Sur Mesure', 'Responsive'],
            'es' => ['Premiado', 'Innovador', 'Full-Stack', 'Personalizado', 'Responsive'],
            'it' => ['Premiato', 'Innovativo', 'Full-Stack', 'Personalizzato', 'Responsive'],
            'nl' => ['Bekroond', 'Innovatief', 'Full-Stack', 'Op Maat', 'Responsive'],
            'pt' => ['Premiado', 'Inovador', 'Full-Stack', 'Personalizado', 'Responsivo'],
            'pl' => ['Nagradzany', 'Innowacyjny', 'Full-Stack', 'Na Zamówienie', 'Responsywny'],
            'ru' => ['Отмеченный наградами', 'Инновационный', 'Full-Stack', 'Индивидуальный', 'Адаптивный'],
            'ja' => ['受賞', '革新的', 'フルスタック', 'カスタム', 'レスポンシブ'],
            'zh' => ['获奖', '创新', '全栈', '定制', '响应式'],
        ],
    ],

    // =========================================================================
    // 8. JOB
    // =========================================================================
    'job' => [
        'role' => [
            'en' => ['Software Engineer', 'Product Manager', 'UX Designer', 'Data Analyst', 'Marketing Manager', 'Sales Representative', 'DevOps Engineer', 'Content Writer'],
            'de' => ['Softwareentwickler', 'Produktmanager', 'UX Designer', 'Datenanalyst', 'Marketing Manager', 'Vertriebsmitarbeiter', 'DevOps Engineer', 'Content Writer'],
            'fr' => ['Ingénieur Logiciel', 'Chef de Produit', 'UX Designer', 'Analyste de Données', 'Responsable Marketing', 'Commercial', 'Ingénieur DevOps', 'Rédacteur Web'],
            'es' => ['Ingeniero de Software', 'Product Manager', 'Diseñador UX', 'Analista de Datos', 'Gerente de Marketing', 'Representante de Ventas', 'Ingeniero DevOps', 'Redactor de Contenidos'],
            'it' => ['Ingegnere Software', 'Product Manager', 'UX Designer', 'Analista Dati', 'Responsabile Marketing', 'Rappresentante Vendite', 'DevOps Engineer', 'Content Writer'],
            'nl' => ['Software Engineer', 'Product Manager', 'UX Designer', 'Data Analist', 'Marketing Manager', 'Verkoopmedewerker', 'DevOps Engineer', 'Content Schrijver'],
            'pt' => ['Engenheiro de Software', 'Gerente de Produto', 'UX Designer', 'Analista de Dados', 'Gerente de Marketing', 'Representante de Vendas', 'Engenheiro DevOps', 'Redator de Conteúdo'],
            'pl' => ['Programista', 'Menedżer Produktu', 'Projektant UX', 'Analityk Danych', 'Kierownik Marketingu', 'Przedstawiciel Handlowy', 'Inżynier DevOps', 'Copywriter'],
            'ru' => ['Инженер-программист', 'Продуктовый менеджер', 'UX-дизайнер', 'Аналитик данных', 'Менеджер по маркетингу', 'Менеджер по продажам', 'DevOps-инженер', 'Контент-менеджер'],
            'ja' => ['ソフトウェアエンジニア', 'プロダクトマネージャー', 'UXデザイナー', 'データアナリスト', 'マーケティングマネージャー', '営業担当', 'DevOpsエンジニア', 'コンテンツライター'],
            'zh' => ['软件工程师', '产品经理', 'UX设计师', '数据分析师', '市场经理', '销售代表', 'DevOps工程师', '内容编辑'],
        ],
        'company' => ['TechCorp', 'InnoSoft', 'Digital Solutions', 'CloudBase', 'DataDrive', 'WebPro', 'AppForge', 'NetVision'],
        'level' => [
            'en' => ['Junior', 'Mid-Level', 'Senior', 'Lead', 'Principal'],
            'de' => ['Junior', 'Mid-Level', 'Senior', 'Lead', 'Principal'],
            'fr' => ['Junior', 'Intermédiaire', 'Senior', 'Lead', 'Principal'],
            'es' => ['Junior', 'Semi-Senior', 'Senior', 'Lead', 'Principal'],
            'it' => ['Junior', 'Mid-Level', 'Senior', 'Lead', 'Principal'],
            'nl' => ['Junior', 'Medior', 'Senior', 'Lead', 'Principal'],
            'pt' => ['Júnior', 'Pleno', 'Sênior', 'Lead', 'Principal'],
            'pl' => ['Młodszy', 'Regularny', 'Starszy', 'Główny', 'Ekspert'],
            'ru' => ['Младший', 'Средний', 'Старший', 'Ведущий', 'Главный'],
            'ja' => ['ジュニア', 'ミドル', 'シニア', 'リード', 'プリンシパル'],
            'zh' => ['初级', '中级', '高级', '首席', '资深'],
        ],
        'type' => [
            'en' => ['Full-Time', 'Part-Time', 'Remote', 'Hybrid', 'Contract'],
            'de' => ['Vollzeit', 'Teilzeit', 'Remote', 'Hybrid', 'Freiberuflich'],
            'fr' => ['Temps Plein', 'Temps Partiel', 'Télétravail', 'Hybride', 'Freelance'],
            'es' => ['Tiempo Completo', 'Medio Tiempo', 'Remoto', 'Híbrido', 'Contrato'],
            'it' => ['Full-Time', 'Part-Time', 'Da Remoto', 'Ibrido', 'Contratto'],
            'nl' => ['Fulltime', 'Parttime', 'Remote', 'Hybride', 'Freelance'],
            'pt' => ['Tempo Integral', 'Meio Período', 'Remoto', 'Híbrido', 'Contrato'],
            'pl' => ['Pełny Etat', 'Pół Etatu', 'Zdalnie', 'Hybrydowo', 'Kontrakt'],
            'ru' => ['Полная занятость', 'Частичная занятость', 'Удалённо', 'Гибрид', 'Контракт'],
            'ja' => ['正社員', 'パートタイム', 'リモート', 'ハイブリッド', '業務委託'],
            'zh' => ['全职', '兼职', '远程', '混合办公', '合同制'],
        ],
    ],

    // =========================================================================
    // 9. COURSE
    // =========================================================================
    'course' => [
        'topic' => [
            'en' => ['Python Programming', 'Web Development', 'Data Science', 'Digital Marketing', 'UX Design', 'Project Management', 'Photography', 'Machine Learning'],
            'de' => ['Python-Programmierung', 'Webentwicklung', 'Data Science', 'Digitales Marketing', 'UX Design', 'Projektmanagement', 'Fotografie', 'Maschinelles Lernen'],
            'fr' => ['Programmation Python', 'Développement Web', 'Science des Données', 'Marketing Digital', 'UX Design', 'Gestion de Projet', 'Photographie', 'Machine Learning'],
            'es' => ['Programación Python', 'Desarrollo Web', 'Ciencia de Datos', 'Marketing Digital', 'Diseño UX', 'Gestión de Proyectos', 'Fotografía', 'Machine Learning'],
            'it' => ['Programmazione Python', 'Sviluppo Web', 'Data Science', 'Marketing Digitale', 'UX Design', 'Gestione Progetti', 'Fotografia', 'Machine Learning'],
            'nl' => ['Python Programmeren', 'Webontwikkeling', 'Data Science', 'Digitale Marketing', 'UX Design', 'Projectmanagement', 'Fotografie', 'Machine Learning'],
            'pt' => ['Programação Python', 'Desenvolvimento Web', 'Ciência de Dados', 'Marketing Digital', 'UX Design', 'Gestão de Projetos', 'Fotografia', 'Machine Learning'],
            'pl' => ['Programowanie w Pythonie', 'Tworzenie Stron', 'Data Science', 'Marketing Cyfrowy', 'Projektowanie UX', 'Zarządzanie Projektami', 'Fotografia', 'Machine Learning'],
            'ru' => ['Программирование на Python', 'Веб-разработка', 'Наука о данных', 'Цифровой маркетинг', 'UX-дизайн', 'Управление проектами', 'Фотография', 'Машинное обучение'],
            'ja' => ['Pythonプログラミング', 'Web開発', 'データサイエンス', 'デジタルマーケティング', 'UXデザイン', 'プロジェクト管理', '写真撮影', '機械学習'],
            'zh' => ['Python编程', 'Web开发', '数据科学', '数字营销', 'UX设计', '项目管理', '摄影', '机器学习'],
        ],
        'level' => [
            'en' => ['Beginner', 'Intermediate', 'Advanced', 'Masterclass'],
            'de' => ['Anfänger', 'Fortgeschritten', 'Experte', 'Masterclass'],
            'fr' => ['Débutant', 'Intermédiaire', 'Avancé', 'Masterclass'],
            'es' => ['Principiante', 'Intermedio', 'Avanzado', 'Masterclass'],
            'it' => ['Principiante', 'Intermedio', 'Avanzato', 'Masterclass'],
            'nl' => ['Beginner', 'Gemiddeld', 'Gevorderd', 'Masterclass'],
            'pt' => ['Iniciante', 'Intermediário', 'Avançado', 'Masterclass'],
            'pl' => ['Początkujący', 'Średniozaawansowany', 'Zaawansowany', 'Masterclass'],
            'ru' => ['Начальный', 'Средний', 'Продвинутый', 'Мастер-класс'],
            'ja' => ['初級', '中級', '上級', 'マスタークラス'],
            'zh' => ['入门', '中级', '高级', '大师班'],
        ],
        'format' => [
            'en' => ['Course', 'Bootcamp', 'Workshop', 'Certification', 'Tutorial'],
            'de' => ['Kurs', 'Bootcamp', 'Workshop', 'Zertifizierung', 'Tutorial'],
            'fr' => ['Cours', 'Bootcamp', 'Atelier', 'Certification', 'Tutoriel'],
            'es' => ['Curso', 'Bootcamp', 'Taller', 'Certificación', 'Tutorial'],
            'it' => ['Corso', 'Bootcamp', 'Workshop', 'Certificazione', 'Tutorial'],
            'nl' => ['Cursus', 'Bootcamp', 'Workshop', 'Certificering', 'Tutorial'],
            'pt' => ['Curso', 'Bootcamp', 'Workshop', 'Certificação', 'Tutorial'],
            'pl' => ['Kurs', 'Bootcamp', 'Warsztaty', 'Certyfikacja', 'Poradnik'],
            'ru' => ['Курс', 'Буткемп', 'Мастер-класс', 'Сертификация', 'Руководство'],
            'ja' => ['コース', 'ブートキャンプ', 'ワークショップ', '認定資格', 'チュートリアル'],
            'zh' => ['课程', '训练营', '研讨班', '认证', '教程'],
        ],
        'duration' => ['4 Weeks', '8 Weeks', '12 Weeks', '3 Months', '6 Months'],
        'adjective' => [
            'en' => ['Complete', 'Intensive', 'Hands-On', 'Professional', 'Practical'],
            'de' => ['Vollständiger', 'Intensiver', 'Praxisnaher', 'Professioneller', 'Praktischer'],
            'fr' => ['Complet', 'Intensif', 'Pratique', 'Professionnel', 'Concret'],
            'es' => ['Completo', 'Intensivo', 'Práctico', 'Profesional', 'Aplicado'],
            'it' => ['Completo', 'Intensivo', 'Pratico', 'Professionale', 'Applicato'],
            'nl' => ['Compleet', 'Intensief', 'Praktisch', 'Professioneel', 'Hands-On'],
            'pt' => ['Completo', 'Intensivo', 'Prático', 'Profissional', 'Aplicado'],
            'pl' => ['Kompletny', 'Intensywny', 'Praktyczny', 'Profesjonalny', 'Stosowany'],
            'ru' => ['Полный', 'Интенсивный', 'Практический', 'Профессиональный', 'Прикладной'],
            'ja' => ['完全', '集中', '実践的', 'プロフェッショナル', '実用的'],
            'zh' => ['完整', '密集', '实操', '专业', '实用'],
        ],
    ],

    // =========================================================================
    // 10. TESTIMONIAL
    // =========================================================================
    'testimonial' => [
        'product' => [
            'en' => ['service', 'product', 'experience', 'support', 'platform', 'tool', 'solution'],
            'de' => ['Service', 'Produkt', 'Erfahrung', 'Support', 'Plattform', 'Tool', 'Lösung'],
            'fr' => ['service', 'produit', 'expérience', 'assistance', 'plateforme', 'outil', 'solution'],
            'es' => ['servicio', 'producto', 'experiencia', 'soporte', 'plataforma', 'herramienta', 'solución'],
            'it' => ['servizio', 'prodotto', 'esperienza', 'assistenza', 'piattaforma', 'strumento', 'soluzione'],
            'nl' => ['service', 'product', 'ervaring', 'ondersteuning', 'platform', 'tool', 'oplossing'],
            'pt' => ['serviço', 'produto', 'experiência', 'suporte', 'plataforma', 'ferramenta', 'solução'],
            'pl' => ['usługa', 'produkt', 'doświadczenie', 'wsparcie', 'platforma', 'narzędzie', 'rozwiązanie'],
            'ru' => ['сервис', 'продукт', 'опыт', 'поддержка', 'платформа', 'инструмент', 'решение'],
            'ja' => ['サービス', '製品', '体験', 'サポート', 'プラットフォーム', 'ツール', 'ソリューション'],
            'zh' => ['服务', '产品', '体验', '支持', '平台', '工具', '解决方案'],
        ],
        'rating' => ['5/5', '4.5/5', '4/5', "\u{2605}\u{2605}\u{2605}\u{2605}\u{2605}", "\u{2605}\u{2605}\u{2605}\u{2605}\u{2606}"],
        'adjective' => [
            'en' => ['Outstanding', 'Excellent', 'Amazing', 'Fantastic', 'Incredible', 'Wonderful'],
            'de' => ['Hervorragend', 'Ausgezeichnet', 'Erstaunlich', 'Fantastisch', 'Unglaublich', 'Wunderbar'],
            'fr' => ['Exceptionnel', 'Excellent', 'Incroyable', 'Fantastique', 'Formidable', 'Merveilleux'],
            'es' => ['Excepcional', 'Excelente', 'Increíble', 'Fantástico', 'Asombroso', 'Maravilloso'],
            'it' => ['Eccezionale', 'Eccellente', 'Incredibile', 'Fantastico', 'Straordinario', 'Meraviglioso'],
            'nl' => ['Uitmuntend', 'Uitstekend', 'Geweldig', 'Fantastisch', 'Ongelooflijk', 'Prachtig'],
            'pt' => ['Excepcional', 'Excelente', 'Incrível', 'Fantástico', 'Impressionante', 'Maravilhoso'],
            'pl' => ['Wybitny', 'Doskonały', 'Niesamowity', 'Fantastyczny', 'Niezwykły', 'Wspaniały'],
            'ru' => ['Выдающийся', 'Отличный', 'Потрясающий', 'Фантастический', 'Невероятный', 'Замечательный'],
            'ja' => ['卓越した', '素晴らしい', '驚くべき', 'ファンタスティック', '信じられない', '最高の'],
            'zh' => ['杰出', '卓越', '惊人', '出色', '令人难以置信', '精彩'],
        ],
    ],

    // =========================================================================
    // 11. STUDIO (no data needed — company_name/suffix resolved via Faker)
    // =========================================================================
    'studio' => [],

    // =========================================================================
    // 12. MOVIE
    // =========================================================================
    'movie' => [
        'adjective' => [
            'en' => ['Dark', 'Silent', 'Broken', 'Eternal', 'Hidden', 'Crimson', 'Fallen', 'Savage', 'Hollow', 'Burning', 'Frozen', 'Wicked'],
            'de' => ['Dunkler', 'Stiller', 'Verlorener', 'Ewiger', 'Verborgener', 'Blutiger', 'Gefallener', 'Wilder', 'Hohler', 'Brennender', 'Eisiger', 'Böser'],
            'fr' => ['Sombre', 'Silencieux', 'Brisé', 'Éternel', 'Caché', 'Écarlate', 'Déchu', 'Sauvage', 'Creux', 'Ardent', 'Glacé', 'Maudit'],
            'es' => ['Oscuro', 'Silencioso', 'Roto', 'Eterno', 'Oculto', 'Carmesí', 'Caído', 'Salvaje', 'Hueco', 'Ardiente', 'Helado', 'Maldito'],
            'it' => ['Oscuro', 'Silenzioso', 'Spezzato', 'Eterno', 'Nascosto', 'Cremisi', 'Caduto', 'Selvaggio', 'Vuoto', 'Ardente', 'Gelido', 'Maledetto'],
            'nl' => ['Duister', 'Stil', 'Gebroken', 'Eeuwig', 'Verborgen', 'Karmozijn', 'Gevallen', 'Woest', 'Hol', 'Brandend', 'Bevroren', 'Vervloekt'],
            'pt' => ['Sombrio', 'Silencioso', 'Partido', 'Eterno', 'Oculto', 'Carmesim', 'Caído', 'Selvagem', 'Oco', 'Ardente', 'Gelado', 'Maldito'],
            'pl' => ['Mroczny', 'Cichy', 'Złamany', 'Wieczny', 'Ukryty', 'Szkarłatny', 'Upadły', 'Dziki', 'Pusty', 'Płonący', 'Zamrożony', 'Przeklęty'],
            'ru' => ['Тёмный', 'Тихий', 'Сломленный', 'Вечный', 'Скрытый', 'Багровый', 'Падший', 'Дикий', 'Пустой', 'Пылающий', 'Ледяной', 'Проклятый'],
            'ja' => ['暗き', '静寂の', '壊れた', '永遠の', '隠された', '深紅の', '堕ちた', '荒ぶる', '虚ろな', '燃える', '凍てつく', '禍々しき'],
            'zh' => ['暗黑', '沉默', '破碎', '永恒', '隐秘', '猩红', '堕落', '狂野', '空洞', '燃烧', '冰封', '邪恶'],
        ],
        'noun' => [
            'en' => ['Shadow', 'Knight', 'Horizon', 'Legacy', 'Protocol', 'Verdict', 'Reckoning', 'Prophecy', 'Stranger', 'Storm', 'Requiem', 'Frontier'],
            'de' => ['Schatten', 'Ritter', 'Horizont', 'Vermächtnis', 'Protokoll', 'Urteil', 'Abrechnung', 'Prophezeiung', 'Fremde', 'Sturm', 'Requiem', 'Grenze'],
            'fr' => ['Ombre', 'Chevalier', 'Horizon', 'Héritage', 'Protocole', 'Verdict', 'Jugement', 'Prophétie', 'Étranger', 'Tempête', 'Requiem', 'Frontière'],
            'es' => ['Sombra', 'Caballero', 'Horizonte', 'Legado', 'Protocolo', 'Veredicto', 'Ajuste de cuentas', 'Profecía', 'Extraño', 'Tormenta', 'Réquiem', 'Frontera'],
            'it' => ['Ombra', 'Cavaliere', 'Orizzonte', 'Eredità', 'Protocollo', 'Verdetto', 'Resa dei conti', 'Profezia', 'Straniero', 'Tempesta', 'Requiem', 'Frontiera'],
            'nl' => ['Schaduw', 'Ridder', 'Horizon', 'Nalatenschap', 'Protocol', 'Vonnis', 'Afrekening', 'Profetie', 'Vreemdeling', 'Storm', 'Requiem', 'Grens'],
            'pt' => ['Sombra', 'Cavaleiro', 'Horizonte', 'Legado', 'Protocolo', 'Veredicto', 'Acerto', 'Profecia', 'Estranho', 'Tempestade', 'Réquiem', 'Fronteira'],
            'pl' => ['Cień', 'Rycerz', 'Horyzont', 'Dziedzictwo', 'Protokół', 'Werdykt', 'Rozliczenie', 'Proroctwo', 'Nieznajomy', 'Burza', 'Requiem', 'Granica'],
            'ru' => ['Тень', 'Рыцарь', 'Горизонт', 'Наследие', 'Протокол', 'Вердикт', 'Расплата', 'Пророчество', 'Незнакомец', 'Шторм', 'Реквием', 'Рубеж'],
            'ja' => ['影', '騎士', '地平線', '遺産', 'プロトコル', '判決', '報い', '予言', '異邦人', '嵐', 'レクイエム', '辺境'],
            'zh' => ['暗影', '骑士', '地平线', '遗产', '协议', '裁决', '清算', '预言', '陌生人', '风暴', '安魂曲', '边境'],
        ],
        'subtitle' => [
            'en' => ['Redemption', 'Awakening', 'Origins', 'Resurrection', 'Eclipse', 'Revelations', 'The Final Chapter', 'Uprising', 'Reloaded', 'Genesis'],
            'de' => ['Erlösung', 'Erwachen', 'Ursprünge', 'Auferstehung', 'Finsternis', 'Offenbarungen', 'Das letzte Kapitel', 'Aufstand', 'Neustart', 'Genesis'],
            'fr' => ['Rédemption', 'Éveil', 'Origines', 'Résurrection', 'Éclipse', 'Révélations', 'Le dernier chapitre', 'Soulèvement', 'Renaissance', 'Genèse'],
            'es' => ['Redención', 'Despertar', 'Orígenes', 'Resurrección', 'Eclipse', 'Revelaciones', 'El capítulo final', 'Rebelión', 'Renacimiento', 'Génesis'],
            'it' => ['Redenzione', 'Risveglio', 'Origini', 'Resurrezione', 'Eclissi', 'Rivelazioni', 'L\'ultimo capitolo', 'Rivolta', 'Rinascita', 'Genesi'],
            'nl' => ['Verlossing', 'Ontwaken', 'Oorsprong', 'Opstanding', 'Eclips', 'Onthullingen', 'Het laatste hoofdstuk', 'Opstand', 'Herladen', 'Genesis'],
            'pt' => ['Redenção', 'Despertar', 'Origens', 'Ressurreição', 'Eclipse', 'Revelações', 'O capítulo final', 'Revolta', 'Renascimento', 'Gênesis'],
            'pl' => ['Odkupienie', 'Przebudzenie', 'Początki', 'Zmartwychwstanie', 'Zaćmienie', 'Objawienia', 'Ostatni rozdział', 'Powstanie', 'Przeładowanie', 'Geneza'],
            'ru' => ['Искупление', 'Пробуждение', 'Истоки', 'Воскрешение', 'Затмение', 'Откровения', 'Последняя глава', 'Восстание', 'Перезагрузка', 'Генезис'],
            'ja' => ['贖罪', '覚醒', '起源', '復活', '蝕', '黙示録', '最終章', '蜂起', '再臨', '創世記'],
            'zh' => ['救赎', '觉醒', '起源', '复活', '日蚀', '启示录', '终章', '起义', '重启', '创世纪'],
        ],
    ],

    // =========================================================================
    // 13. AGENT (no data needed — first_name/last_name resolved via Faker)
    // =========================================================================
    'agent' => [],

    ];

    /**
     * Generate a contextual post title based on CPT
     */
    public function contextualPostTitle(string $cptSlug, string $cptLabel = '', ?string $locale = null): string
    {
        $lang = $this->extractLangPrefix($locale);
        $matchKey = strtolower($cptSlug . ' ' . $cptLabel);

        // ── Stufe 1: Hardcoded CPT_TITLE_TEMPLATES (regex-basiert) ──
        $matchedPattern = null;
        $dataKey = null;
        foreach (self::CPT_TITLE_TEMPLATES as $pattern => $localeTemplates) {
            if (preg_match('/' . $pattern . '/i', $matchKey)) {
                $dataKey = explode('|', $pattern)[0];
                $matchedPattern = $pattern;
                break;
            }
        }

        // Report hardcoded templates to FI API (even if language doesn't match)
        if ($matchedPattern && $dataKey && $this->hive) {
            $reportTemplates = [];
            $allLocaleTemplates = self::CPT_TITLE_TEMPLATES[$matchedPattern] ?? [];
            foreach ($allLocaleTemplates as $tplLang => $tplList) {
                $placeholderData = self::CPT_TITLE_DATA[$dataKey] ?? [];
                foreach ($tplList as $tpl) {
                    $reportTemplates[] = [
                        'template' => $tpl,
                        'placeholderData' => $placeholderData,
                        'confidence' => 0.9,
                    ];
                }
            }
            $this->hive->reportTitleTemplates($cptSlug, $cptLabel, $reportTemplates, $locale);
        }

        // Only use Stufe 1 if templates exist for the EXACT requested language
        // (no English fallback — let AI generate locale-appropriate titles instead)
        $templates = $matchedPattern ? (self::CPT_TITLE_TEMPLATES[$matchedPattern][$lang] ?? null) : null;

        if ($templates && $dataKey && isset(self::CPT_TITLE_DATA[$dataKey])) {
            $template = $templates[array_rand($templates)];
            return $this->resolveTitleTemplate($template, self::CPT_TITLE_DATA[$dataKey], $lang, $locale);
        }

        // ── Stufe 2: Field Intelligence DB (API-Query) ──
        if ($this->hive) {
            $apiTemplates = $this->hive->queryTitleTemplates($cptSlug, $locale);
            if ($apiTemplates && !empty($apiTemplates)) {
                $picked = $apiTemplates[array_rand($apiTemplates)];
                $template = $picked['template'] ?? '';
                $data = $picked['placeholderData'] ?? [];
                if (is_string($data)) {
                    $data = json_decode($data, true) ?: [];
                }
                if ($template && !empty($data)) {
                    return $this->resolveTitleTemplate($template, $data, $lang, $locale);
                }
            }
        }

        // ── Stufe 3: AI Provider (LLM-Call → Templates generieren → cachen → an FI DB melden) ──
        if ($this->aiProvider && $this->aiProvider->isAvailable()) {
            $aiTemplates = $this->aiProvider->generateTitleTemplates($cptSlug, $cptLabel, $locale, $this->cptContext);
            if ($aiTemplates && !empty($aiTemplates)) {
                // Report AI-generated templates to FI DB (Lernschleife)
                if ($this->hive) {
                    $reportEntries = array_map(fn($t) => [
                        'template' => $t['template'],
                        'placeholderData' => $t['placeholderData'] ?? [],
                        'confidence' => 0.75,
                    ], $aiTemplates);
                    $this->hive->reportTitleTemplates($cptSlug, $cptLabel, $reportEntries, $locale);
                }
                // Pick one template and resolve placeholders
                $picked = $aiTemplates[array_rand($aiTemplates)];
                return $this->resolveTitleTemplate($picked['template'], $picked['placeholderData'] ?? [], $lang, $locale);
            }
        }

        // ── Stufe 4: Fallback (generischer Text via Faker) ──
        return '';
    }

    /**
     * Resolve a title template by replacing {placeholders} with data values
     */
    protected function resolveTitleTemplate(string $template, array $data, string $lang, ?string $locale): string
    {
        $faker = $locale ? $this->forLocale($locale) : $this->faker;

        $title = preg_replace_callback('/\{(\w+)\}/', function ($matches) use ($data, $lang, $faker) {
            $key = $matches[1];
            // Skip built-in Faker placeholders — handled below
            if (in_array($key, ['year', 'city'], true)) {
                return $matches[0];
            }
            // Resolve name tokens directly via Faker
            if ($key === 'first_name') {
                return $faker->firstName();
            }
            if ($key === 'last_name') {
                return $faker->lastName();
            }
            if ($key === 'company_name') {
                return $faker->company();
            }
            if ($key === 'suffix') {
                return $faker->companySuffix();
            }
            if (!isset($data[$key])) {
                return $matches[0];
            }
            $values = $data[$key];

            // Handle FAKER_YEAR / FAKER_CITY as direct string value
            if ($values === 'FAKER_YEAR') {
                return (string) rand(2018, (int) date('Y'));
            }
            if ($values === 'FAKER_CITY') {
                return $faker->city();
            }

            // Resolve locale-specific values
            if (is_array($values) && isset($values['en'])) {
                $values = $values[$lang] ?? $values['en'];
            }
            if (!is_array($values)) {
                return (string) $values;
            }

            // Handle FAKER_YEAR / FAKER_CITY inside array values
            $picked = $values[array_rand($values)];
            if ($picked === 'FAKER_YEAR') {
                return (string) rand(2018, (int) date('Y'));
            }
            if ($picked === 'FAKER_CITY') {
                return $faker->city();
            }
            return $picked;
        }, $template);

        // Replace built-in Faker placeholders
        $title = str_replace('{year}', (string) rand(2018, (int) date('Y')), $title);
        $title = str_replace('{city}', $faker->city(), $title);

        // Replace bare FAKER_ tokens in template string (safety net)
        $title = str_replace('FAKER_YEAR', (string) rand(2018, (int) date('Y')), $title);
        $title = str_replace('FAKER_CITY', $faker->city(), $title);

        return $title;
    }

    /**
     * Generate varied post content with specific paragraph count
     *
     * @param int $paragraphs Number of paragraphs
     * @param bool $includeHeadings Include h2 headings
     * @param bool $includeLists Include bullet lists
     * @param bool $includeBlockquotes Include blockquotes
     * @param string|null $locale Optional locale override
     * @return string
     */
    public function postContentVaried(
        int $paragraphs = 5,
        bool $includeHeadings = true,
        bool $includeLists = true,
        bool $includeBlockquotes = true,
        ?string $locale = null
    ): string {
        $faker = $locale ? $this->forLocale($locale) : $this->faker;
        $useRealText = $this->hasRealText($faker);
        $content = [];

        for ($i = 0; $i < $paragraphs; $i++) {
            // Randomly add different content types
            $rand = rand(0, 10);

            if ($includeHeadings && $i > 0 && $rand < 2) {
                $heading = $useRealText ? $this->realTextSafe($faker, rand(20, 50)) : $faker->sentence(rand(3, 6));
                $content[] = '<h2>' . rtrim($heading, '.') . '</h2>';
            } elseif ($includeLists && $rand === 2) {
                $items = [];
                for ($j = 0; $j < rand(3, 6); $j++) {
                    $items[] = '<li>' . ($useRealText ? $this->realTextSafe($faker, rand(40, 100)) : $faker->sentence(rand(5, 12))) . '</li>';
                }
                $content[] = '<ul>' . implode("\n", $items) . '</ul>';
            } elseif ($includeBlockquotes && $rand === 3) {
                $content[] = '<blockquote><p>' . ($useRealText ? $this->realTextSafe($faker, rand(100, 300)) : $faker->paragraph(rand(2, 4))) . '</p></blockquote>';
            } else {
                $content[] = '<p>' . ($useRealText ? $this->realTextSafe($faker, rand(200, 500)) : $faker->paragraph(rand(4, 8))) . '</p>';
            }
        }

        return implode("\n\n", $content);
    }

    /**
     * Generate contextual post content using CPT context.
     * Produces HTML content with domain-relevant topics and themes.
     * Returns null if no CPT context is available — caller falls back to postContentVaried().
     *
     * @param int $paragraphs Number of paragraphs
     * @param string|null $locale Optional locale override
     * @return string|null HTML content or null
     */
    public function contextualPostContent(int $paragraphs = 5, ?string $locale = null): ?string
    {
        if (!$this->cptContext || empty($this->cptContext['content_themes']) || empty($this->cptContext['topics'])) {
            return null;
        }

        $faker = $locale ? $this->forLocale($locale) : $this->faker;
        $topics = $this->cptContext['topics'];
        $themes = $this->cptContext['content_themes'];
        $content = [];

        for ($i = 0; $i < $paragraphs; $i++) {
            $rand = rand(0, 10);

            if ($i > 0 && $rand < 2) {
                // Heading using a theme
                $theme = $themes[array_rand($themes)];
                $content[] = '<h2>' . ucfirst($theme) . '</h2>';
            } elseif ($rand === 2) {
                // List of topics
                $items = [];
                $listTopics = (array) array_rand(array_flip($topics), min(rand(3, 5), count($topics)));
                foreach ($listTopics as $topic) {
                    $items[] = '<li>' . ucfirst($topic) . ': ' . $faker->sentence(rand(5, 10)) . '</li>';
                }
                $content[] = '<ul>' . implode("\n", $items) . '</ul>';
            } else {
                // Paragraph with topic keyword woven in
                $topic = $topics[array_rand($topics)];
                $sentences = [];
                $sentenceCount = rand(3, 6);
                for ($s = 0; $s < $sentenceCount; $s++) {
                    if ($s === 0) {
                        // First sentence mentions the topic
                        $sentences[] = ucfirst($topic) . ' ' . lcfirst($faker->sentence(rand(6, 12)));
                    } else {
                        $sentences[] = $faker->sentence(rand(5, 12));
                    }
                }
                $content[] = '<p>' . implode(' ', $sentences) . '</p>';
            }
        }

        return implode("\n\n", $content);
    }

    /**
     * Generate a post slug
     *
     * @param int $words
     * @return string
     */
    public function postSlug(int $words = 4): string
    {
        return sanitize_title($this->faker->words($words, true));
    }

    /**
     * Generate post content with HTML
     *
     * @param int $paragraphs
     * @param bool $includeHeadings
     * @return string
     */
    public function postContent(int $paragraphs = 5, bool $includeHeadings = true): string
    {
        $content = [];

        for ($i = 0; $i < $paragraphs; $i++) {
            // Add a heading before some paragraphs
            if ($includeHeadings && $i > 0 && rand(0, 2) === 0) {
                $content[] = '<h2>' . $this->faker->sentence(rand(3, 6)) . '</h2>';
            }

            $content[] = '<p>' . $this->faker->paragraph(rand(4, 8)) . '</p>';
        }

        return implode("\n\n", $content);
    }

    /**
     * Generate a post excerpt
     *
     * @param int $sentences
     * @return string
     */
    public function postExcerpt(int $sentences = 2, ?string $locale = null): string
    {
        $faker = $locale ? $this->forLocale($locale) : $this->faker;
        return $faker->sentences($sentences, true);
    }

    /**
     * Generate WordPress-compatible date
     *
     * @param string $startDate
     * @param string $endDate
     * @return string
     */
    public function wpDate(string $startDate = '-1 year', string $endDate = 'now'): string
    {
        return $this->faker->dateTimeBetween($startDate, $endDate)->format('Y-m-d H:i:s');
    }

    /**
     * Generate a user login name
     *
     * @return string
     */
    public function userLogin(): string
    {
        return sanitize_user(strtolower($this->faker->userName()), true);
    }

    /**
     * Generate a display name
     *
     * @return string
     */
    public function displayName(?string $locale = null): string
    {
        $faker = $locale ? $this->forLocale($locale) : $this->faker;
        return $faker->name();
    }

    /**
     * Generate a meta key
     *
     * @param string $prefix
     * @return string
     */
    public function metaKey(string $prefix = ''): string
    {
        $key = $this->faker->slug(rand(2, 4));
        return $prefix ? $prefix . '_' . $key : $key;
    }

    /**
     * Contextual term lists keyed by taxonomy detection pattern.
     * Patterns are matched against taxonomy slug and label (case-insensitive).
     * Values can be either:
     *  - string[] (flat list, language-neutral)
     *  - array{en: string[], de: string[], ...} (locale-aware)
     */
    protected const TAXONOMY_TERM_MAP = [
    // === Vehicle / Automotive (specific patterns FIRST, before generic brand/type) ===
    'fuel|treibstoff|kraftstoff|antrieb(?!s.*art)|benzin|sprit|carburant|combustible|combustível|paliwo|топливо|燃料' => [
        'en' => ['Gasoline', 'Diesel', 'Electric', 'Hybrid', 'Plugin Hybrid', 'LPG', 'CNG', 'Hydrogen'],
        'de' => ['Benzin', 'Diesel', 'Elektro', 'Hybrid', 'Plug-in-Hybrid', 'Autogas', 'Erdgas', 'Wasserstoff'],
        'fr' => ['Essence', 'Diesel', 'Électrique', 'Hybride', 'Hybride rechargeable', 'GPL', 'GNV', 'Hydrogène'],
        'es' => ['Gasolina', 'Diésel', 'Eléctrico', 'Híbrido', 'Híbrido enchufable', 'GLP', 'GNC', 'Hidrógeno'],
        'it' => ['Benzina', 'Diesel', 'Elettrico', 'Ibrido', 'Ibrido plug-in', 'GPL', 'Metano', 'Idrogeno'],
        'nl' => ['Benzine', 'Diesel', 'Elektrisch', 'Hybride', 'Plug-in hybride', 'LPG', 'CNG', 'Waterstof'],
        'pt' => ['Gasolina', 'Diesel', 'Elétrico', 'Híbrido', 'Híbrido plug-in', 'GLP', 'GNV', 'Hidrogénio'],
        'pl' => ['Benzyna', 'Diesel', 'Elektryczny', 'Hybryda', 'Hybryda plug-in', 'LPG', 'CNG', 'Wodór'],
        'ru' => ['Бензин', 'Дизель', 'Электро', 'Гибрид', 'Подключаемый гибрид', 'Газ', 'Метан', 'Водород'],
        'ja' => ['ガソリン', 'ディーゼル', '電気', 'ハイブリッド', 'プラグインハイブリッド', 'LPG', 'CNG', '水素'],
        'zh' => ['汽油', '柴油', '纯电动', '混合动力', '插电混动', '液化气', '天然气', '氢能源'],
    ],
    'vehicle.*(type|class|kind|art|kategori)|fahrzeug.*(typ|klasse|art)|karosserie|body.*(style|type)|tipo.*veh|type.*véhicule|tipo.*veicolo|voertuig.*type|тип.*авто|車種|车型' => [
        'en' => ['SUV', 'Sedan', 'Hatchback', 'Coupe', 'Convertible', 'Wagon', 'Van', 'Truck', 'Minivan', 'Crossover'],
        'de' => ['SUV', 'Limousine', 'Kombi', 'Coupé', 'Cabrio', 'Kleinwagen', 'Van', 'Geländewagen', 'Transporter', 'Kompaktvan'],
        'fr' => ['SUV', 'Berline', 'Citadine', 'Coupé', 'Cabriolet', 'Break', 'Monospace', 'Utilitaire', 'Crossover', 'Pick-up'],
        'es' => ['SUV', 'Sedán', 'Hatchback', 'Coupé', 'Descapotable', 'Familiar', 'Furgoneta', 'Camioneta', 'Monovolumen', 'Crossover'],
        'it' => ['SUV', 'Berlina', 'Utilitaria', 'Coupé', 'Cabrio', 'Station wagon', 'Monovolume', 'Fuoristrada', 'Furgone', 'Crossover'],
        'nl' => ['SUV', 'Sedan', 'Hatchback', 'Coupé', 'Cabrio', 'Stationwagen', 'Bestelwagen', 'Pick-up', 'MPV', 'Crossover'],
        'pt' => ['SUV', 'Sedã', 'Hatchback', 'Coupé', 'Conversível', 'Perua', 'Van', 'Picape', 'Monovolume', 'Crossover'],
        'pl' => ['SUV', 'Sedan', 'Hatchback', 'Coupé', 'Kabriolet', 'Kombi', 'Van', 'Pickup', 'Minivan', 'Crossover'],
        'ru' => ['Внедорожник', 'Седан', 'Хэтчбек', 'Купе', 'Кабриолет', 'Универсал', 'Минивэн', 'Пикап', 'Кроссовер', 'Лифтбек'],
        'ja' => ['SUV', 'セダン', 'ハッチバック', 'クーペ', 'オープンカー', 'ワゴン', 'ミニバン', 'トラック', 'コンパクト', 'クロスオーバー'],
        'zh' => ['SUV', '轿车', '掀背车', '跑车', '敞篷车', '旅行车', '面包车', '皮卡', 'MPV', '跨界车'],
    ],
    'vehicle.*(brand|make|marke)|fahrzeug.*(marke)|auto.*(marke|brand|hersteller)|car.*(brand|make)|hersteller|manufacturer|marque|marca|merk|производитель|メーカー|品牌' => [
        'en' => ['BMW', 'Mercedes-Benz', 'Audi', 'Volkswagen', 'Toyota', 'Honda', 'Ford', 'Porsche', 'Volvo', 'Hyundai', 'Kia', 'Mazda', 'Nissan', 'Opel', 'Skoda', 'Renault', 'Peugeot', 'Fiat', 'Seat', 'Tesla'],
        'de' => ['BMW', 'Mercedes-Benz', 'Audi', 'Volkswagen', 'Toyota', 'Honda', 'Ford', 'Porsche', 'Volvo', 'Hyundai', 'Kia', 'Mazda', 'Nissan', 'Opel', 'Škoda', 'Renault', 'Peugeot', 'Fiat', 'Seat', 'Tesla'],
        'fr' => ['Renault', 'Peugeot', 'Citroën', 'BMW', 'Mercedes-Benz', 'Audi', 'Volkswagen', 'Toyota', 'Ford', 'Porsche', 'Volvo', 'Hyundai', 'Kia', 'Nissan', 'Fiat', 'Opel', 'Škoda', 'Seat', 'Tesla', 'DS'],
        'es' => ['Seat', 'BMW', 'Mercedes-Benz', 'Audi', 'Volkswagen', 'Toyota', 'Honda', 'Ford', 'Porsche', 'Volvo', 'Hyundai', 'Kia', 'Renault', 'Peugeot', 'Citroën', 'Fiat', 'Nissan', 'Opel', 'Škoda', 'Tesla'],
        'it' => ['Fiat', 'Alfa Romeo', 'Ferrari', 'Lamborghini', 'Maserati', 'BMW', 'Mercedes-Benz', 'Audi', 'Volkswagen', 'Toyota', 'Ford', 'Porsche', 'Volvo', 'Hyundai', 'Renault', 'Peugeot', 'Nissan', 'Opel', 'Škoda', 'Tesla'],
        'nl' => ['BMW', 'Mercedes-Benz', 'Audi', 'Volkswagen', 'Toyota', 'Honda', 'Ford', 'Porsche', 'Volvo', 'Hyundai', 'Kia', 'Mazda', 'Nissan', 'Opel', 'Škoda', 'Renault', 'Peugeot', 'Fiat', 'Seat', 'Tesla'],
        'pt' => ['BMW', 'Mercedes-Benz', 'Audi', 'Volkswagen', 'Toyota', 'Honda', 'Ford', 'Porsche', 'Volvo', 'Hyundai', 'Kia', 'Renault', 'Peugeot', 'Fiat', 'Nissan', 'Citroën', 'Opel', 'Seat', 'Škoda', 'Tesla'],
        'pl' => ['BMW', 'Mercedes-Benz', 'Audi', 'Volkswagen', 'Toyota', 'Honda', 'Ford', 'Porsche', 'Volvo', 'Hyundai', 'Kia', 'Mazda', 'Nissan', 'Opel', 'Škoda', 'Renault', 'Peugeot', 'Fiat', 'Seat', 'Tesla'],
        'ru' => ['BMW', 'Mercedes-Benz', 'Audi', 'Volkswagen', 'Toyota', 'Honda', 'Ford', 'Porsche', 'Volvo', 'Hyundai', 'Kia', 'Mazda', 'Nissan', 'Renault', 'Škoda', 'Peugeot', 'Fiat', 'Lada', 'ГАЗ', 'Tesla'],
        'ja' => ['トヨタ', 'ホンダ', '日産', 'マツダ', 'スバル', 'スズキ', 'ダイハツ', '三菱', 'レクサス', 'BMW', 'メルセデス・ベンツ', 'アウディ', 'フォルクスワーゲン', 'フォード', 'ポルシェ', 'ボルボ', 'ヒュンダイ', 'テスラ', 'フィアット', 'プジョー'],
        'zh' => ['宝马', '奔驰', '奥迪', '大众', '丰田', '本田', '福特', '保时捷', '沃尔沃', '现代', '起亚', '马自达', '日产', '雷诺', '标致', '菲亚特', '特斯拉', '比亚迪', '吉利', '蔚来'],
    ],
    'transmission|getriebe|schaltung|boîte.*vitesse|transmisión|trasmissione|transmissão|skrzynia.*biegów|коробка.*передач|トランスミッション|变速箱' => [
        'en' => ['Automatic', 'Manual', 'CVT', 'Dual-Clutch', 'Semi-Automatic'],
        'de' => ['Automatik', 'Schaltgetriebe', 'CVT', 'Doppelkupplung', 'Halbautomatik'],
        'fr' => ['Automatique', 'Manuelle', 'CVT', 'Double embrayage', 'Semi-automatique'],
        'es' => ['Automático', 'Manual', 'CVT', 'Doble embrague', 'Semiautomático'],
        'it' => ['Automatico', 'Manuale', 'CVT', 'Doppia frizione', 'Semiautomatico'],
        'nl' => ['Automaat', 'Handgeschakeld', 'CVT', 'Dubbele koppeling', 'Semi-automaat'],
        'pt' => ['Automático', 'Manual', 'CVT', 'Dupla embreagem', 'Semiautomático'],
        'pl' => ['Automatyczna', 'Manualna', 'CVT', 'Dwusprzęgłowa', 'Półautomatyczna'],
        'ru' => ['Автомат', 'Механика', 'Вариатор', 'Робот', 'Полуавтомат'],
        'ja' => ['オートマチック', 'マニュアル', 'CVT', 'デュアルクラッチ', 'セミオートマチック'],
        'zh' => ['自动挡', '手动挡', 'CVT无级变速', '双离合', '半自动'],
    ],
    'drive.*(type|train)|antriebsart|allrad|traction|tracción|trazione|aandrijving|napęd|привод|駆動|驱动' => [
        'en' => ['Front-Wheel Drive', 'Rear-Wheel Drive', 'All-Wheel Drive', '4WD'],
        'de' => ['Frontantrieb', 'Heckantrieb', 'Allradantrieb', '4WD'],
        'fr' => ['Traction avant', 'Propulsion', 'Intégrale', '4x4'],
        'es' => ['Tracción delantera', 'Tracción trasera', 'Tracción integral', '4x4'],
        'it' => ['Trazione anteriore', 'Trazione posteriore', 'Integrale', '4x4'],
        'nl' => ['Voorwielaandrijving', 'Achterwielaandrijving', 'Vierwielaandrijving', '4WD'],
        'pt' => ['Tração dianteira', 'Tração traseira', 'Tração integral', '4x4'],
        'pl' => ['Napęd przedni', 'Napęd tylny', 'Napęd na 4 koła', '4WD'],
        'ru' => ['Передний привод', 'Задний привод', 'Полный привод', '4WD'],
        'ja' => ['前輪駆動', '後輪駆動', '全輪駆動', '4WD'],
        'zh' => ['前轮驱动', '后轮驱动', '全轮驱动', '四驱'],
    ],
    'condition|zustand|état|estado|condizione|conditie|stan|состояние|状態|状况' => [
        'en' => ['New', 'Used', 'Certified Pre-Owned', 'Like New', 'Fair', 'Good', 'Excellent'],
        'de' => ['Neu', 'Gebraucht', 'Jahreswagen', 'Neuwertig', 'Unfallfahrzeug', 'Tageszulassung', 'Vorführwagen'],
        'fr' => ['Neuf', 'Occasion', 'Certifié', 'Comme neuf', 'Correct', 'Bon état', 'Excellent état'],
        'es' => ['Nuevo', 'Usado', 'Certificado', 'Como nuevo', 'Aceptable', 'Bueno', 'Excelente'],
        'it' => ['Nuovo', 'Usato', 'Certificato', 'Come nuovo', 'Discreto', 'Buono', 'Eccellente'],
        'nl' => ['Nieuw', 'Gebruikt', 'Gecertificeerd', 'Als nieuw', 'Redelijk', 'Goed', 'Uitstekend'],
        'pt' => ['Novo', 'Usado', 'Seminovo', 'Como novo', 'Razoável', 'Bom', 'Excelente'],
        'pl' => ['Nowy', 'Używany', 'Certyfikowany', 'Jak nowy', 'Dostateczny', 'Dobry', 'Doskonały'],
        'ru' => ['Новый', 'С пробегом', 'Сертифицированный', 'Как новый', 'Удовлетворительный', 'Хороший', 'Отличный'],
        'ja' => ['新車', '中古', '認定中古車', '新車同様', '普通', '良好', '極上'],
        'zh' => ['全新', '二手', '官方认证', '准新车', '一般', '良好', '极好'],
    ],

    // === Portfolio / Agency ===
    'project.*(type|categor|kind)|tipo.*proyecto|type.*projet|tipo.*progetto|project.*type|тип.*проект|プロジェクト.*種類|项目.*类型' => [
        'en' => ['Web Design', 'Branding', 'Photography', 'Print Design', 'UI/UX Design', 'Mobile App', 'Illustration', 'Motion Graphics', 'Packaging', 'Social Media', 'Editorial', 'Identity Design', 'Art Direction', 'Typography', 'Environmental Design'],
        'de' => ['Webdesign', 'Branding', 'Fotografie', 'Printdesign', 'UI/UX-Design', 'Mobile App', 'Illustration', 'Motion Graphics', 'Verpackungsdesign', 'Social Media', 'Editorial', 'Corporate Design', 'Art Direction', 'Typografie', 'Umgebungsdesign'],
        'fr' => ['Design web', 'Image de marque', 'Photographie', 'Design print', 'Design UI/UX', 'Application mobile', 'Illustration', 'Motion design', 'Packaging', 'Réseaux sociaux', 'Éditorial', 'Identité visuelle', 'Direction artistique', 'Typographie', 'Design environnemental'],
        'es' => ['Diseño web', 'Branding', 'Fotografía', 'Diseño impreso', 'Diseño UI/UX', 'App móvil', 'Ilustración', 'Motion Graphics', 'Packaging', 'Redes sociales', 'Editorial', 'Diseño de identidad', 'Dirección de arte', 'Tipografía', 'Diseño ambiental'],
        'it' => ['Web design', 'Branding', 'Fotografia', 'Design per la stampa', 'UI/UX Design', 'App mobile', 'Illustrazione', 'Motion graphics', 'Packaging', 'Social media', 'Editoriale', 'Identity design', 'Art direction', 'Tipografia', 'Design ambientale'],
        'nl' => ['Webdesign', 'Branding', 'Fotografie', 'Printdesign', 'UI/UX-design', 'Mobiele app', 'Illustratie', 'Motion graphics', 'Verpakkingsdesign', 'Social media', 'Redactioneel', 'Huisstijl', 'Art direction', 'Typografie', 'Omgevingsdesign'],
        'pt' => ['Web design', 'Branding', 'Fotografia', 'Design gráfico', 'Design UI/UX', 'App mobile', 'Ilustração', 'Motion graphics', 'Embalagem', 'Mídias sociais', 'Editorial', 'Identidade visual', 'Direção de arte', 'Tipografia', 'Design ambiental'],
        'pl' => ['Projektowanie stron', 'Branding', 'Fotografia', 'Projektowanie druku', 'UI/UX Design', 'Aplikacja mobilna', 'Ilustracja', 'Motion graphics', 'Opakowania', 'Media społecznościowe', 'Projekt redakcyjny', 'Identyfikacja wizualna', 'Kierownictwo artystyczne', 'Typografia', 'Projektowanie przestrzeni'],
        'ru' => ['Веб-дизайн', 'Брендинг', 'Фотография', 'Полиграфический дизайн', 'UI/UX-дизайн', 'Мобильное приложение', 'Иллюстрация', 'Моушн-графика', 'Упаковка', 'Социальные сети', 'Редакционный дизайн', 'Айдентика', 'Арт-дирекшн', 'Типографика', 'Средовой дизайн'],
        'ja' => ['Webデザイン', 'ブランディング', '写真撮影', '印刷デザイン', 'UI/UXデザイン', 'モバイルアプリ', 'イラストレーション', 'モーショングラフィックス', 'パッケージデザイン', 'ソーシャルメディア', 'エディトリアル', 'アイデンティティデザイン', 'アートディレクション', 'タイポグラフィ', '環境デザイン'],
        'zh' => ['网页设计', '品牌设计', '摄影', '印刷设计', 'UI/UX设计', '移动应用', '插画', '动态图形', '包装设计', '社交媒体', '编辑设计', '品牌标识', '艺术指导', '字体设计', '环境设计'],
    ],
    'skill|tech.*stack|technolog|expertise|competenc' => ['PHP', 'JavaScript', 'React', 'WordPress', 'CSS', 'Node.js', 'Python', 'Docker', 'TypeScript', 'Vue.js', 'Laravel', 'Figma', 'Git', 'AWS', 'Tailwind CSS', 'GraphQL', 'PostgreSQL', 'Swift', 'Kotlin', 'Go'],
    'service.*(type|categor)?|dienstleistung|leistung|prestation|servicio|servizio|dienst|serviço|usługa|услуга|サービス|服务' => [
        'en' => ['Consulting', 'Web Development', 'Graphic Design', 'Strategy', 'SEO', 'Content Writing', 'Marketing', 'Support', 'Training', 'Analytics', 'Brand Strategy', 'Social Media Management', 'Email Marketing', 'Photography', 'Video Production'],
        'de' => ['Beratung', 'Webentwicklung', 'Grafikdesign', 'Strategie', 'SEO', 'Content-Erstellung', 'Marketing', 'Support', 'Schulung', 'Analyse', 'Markenstrategie', 'Social Media Management', 'E-Mail-Marketing', 'Fotografie', 'Videoproduktion'],
        'fr' => ['Conseil', 'Développement web', 'Design graphique', 'Stratégie', 'SEO', 'Rédaction', 'Marketing', 'Support', 'Formation', 'Analyse', 'Stratégie de marque', 'Gestion réseaux sociaux', 'E-mailing', 'Photographie', 'Production vidéo'],
        'es' => ['Consultoría', 'Desarrollo web', 'Diseño gráfico', 'Estrategia', 'SEO', 'Redacción de contenido', 'Marketing', 'Soporte', 'Formación', 'Analítica', 'Estrategia de marca', 'Gestión de redes sociales', 'Email marketing', 'Fotografía', 'Producción de vídeo'],
        'it' => ['Consulenza', 'Sviluppo web', 'Grafica', 'Strategia', 'SEO', 'Copywriting', 'Marketing', 'Supporto', 'Formazione', 'Analisi', 'Strategia di marca', 'Social media management', 'Email marketing', 'Fotografia', 'Produzione video'],
        'nl' => ['Advies', 'Webontwikkeling', 'Grafisch ontwerp', 'Strategie', 'SEO', 'Contentcreatie', 'Marketing', 'Ondersteuning', 'Training', 'Analyse', 'Merkstrategie', 'Social media beheer', 'E-mailmarketing', 'Fotografie', 'Videoproductie'],
        'pt' => ['Consultoria', 'Desenvolvimento web', 'Design gráfico', 'Estratégia', 'SEO', 'Redação de conteúdo', 'Marketing', 'Suporte', 'Treinamento', 'Análise', 'Estratégia de marca', 'Gestão de mídias sociais', 'E-mail marketing', 'Fotografia', 'Produção de vídeo'],
        'pl' => ['Doradztwo', 'Tworzenie stron', 'Projektowanie graficzne', 'Strategia', 'SEO', 'Copywriting', 'Marketing', 'Wsparcie', 'Szkolenia', 'Analityka', 'Strategia marki', 'Zarządzanie mediami społecznościowymi', 'E-mail marketing', 'Fotografia', 'Produkcja wideo'],
        'ru' => ['Консалтинг', 'Веб-разработка', 'Графический дизайн', 'Стратегия', 'SEO', 'Копирайтинг', 'Маркетинг', 'Поддержка', 'Обучение', 'Аналитика', 'Бренд-стратегия', 'SMM', 'Email-маркетинг', 'Фотография', 'Видеопроизводство'],
        'ja' => ['コンサルティング', 'Web開発', 'グラフィックデザイン', '戦略', 'SEO', 'コンテンツ制作', 'マーケティング', 'サポート', '研修', 'アナリティクス', 'ブランド戦略', 'SNS運用', 'メールマーケティング', '写真撮影', '映像制作'],
        'zh' => ['咨询', '网站开发', '平面设计', '战略', 'SEO', '内容创作', '营销', '技术支持', '培训', '数据分析', '品牌战略', '社交媒体管理', '邮件营销', '摄影', '视频制作'],
    ],
    'client.*(type|categor)|kunden.*(typ|art)|type.*client|tipo.*cliente|tipo.*cliente|klanttype|тип.*клиент|顧客.*種類|客户.*类型' => [
        'en' => ['Enterprise', 'Startup', 'Non-Profit', 'Agency', 'Government', 'E-Commerce', 'SaaS', 'Healthcare', 'Education', 'Media', 'Finance', 'Real Estate', 'Hospitality', 'Manufacturing', 'Retail'],
        'de' => ['Großunternehmen', 'Startup', 'Non-Profit', 'Agentur', 'Behörde', 'E-Commerce', 'SaaS', 'Gesundheitswesen', 'Bildung', 'Medien', 'Finanzen', 'Immobilien', 'Gastronomie', 'Industrie', 'Einzelhandel'],
        'fr' => ['Grande entreprise', 'Startup', 'Association', 'Agence', 'Secteur public', 'E-commerce', 'SaaS', 'Santé', 'Éducation', 'Médias', 'Finance', 'Immobilier', 'Hôtellerie', 'Industrie', 'Commerce de détail'],
        'es' => ['Gran empresa', 'Startup', 'ONG', 'Agencia', 'Gobierno', 'E-commerce', 'SaaS', 'Salud', 'Educación', 'Medios', 'Finanzas', 'Inmobiliaria', 'Hostelería', 'Manufactura', 'Comercio minorista'],
        'it' => ['Grande impresa', 'Startup', 'No profit', 'Agenzia', 'Pubblica amministrazione', 'E-commerce', 'SaaS', 'Sanità', 'Istruzione', 'Media', 'Finanza', 'Immobiliare', 'Hospitality', 'Manifattura', 'Retail'],
        'nl' => ['Grootbedrijf', 'Startup', 'Non-profit', 'Bureau', 'Overheid', 'E-commerce', 'SaaS', 'Gezondheidszorg', 'Onderwijs', 'Media', 'Financiën', 'Vastgoed', 'Horeca', 'Maakindustrie', 'Detailhandel'],
        'pt' => ['Grande empresa', 'Startup', 'ONG', 'Agência', 'Governo', 'E-commerce', 'SaaS', 'Saúde', 'Educação', 'Mídia', 'Finanças', 'Imobiliário', 'Hotelaria', 'Manufatura', 'Varejo'],
        'pl' => ['Korporacja', 'Startup', 'Organizacja non-profit', 'Agencja', 'Administracja publiczna', 'E-commerce', 'SaaS', 'Ochrona zdrowia', 'Edukacja', 'Media', 'Finanse', 'Nieruchomości', 'Hotelarstwo', 'Produkcja', 'Handel detaliczny'],
        'ru' => ['Корпорация', 'Стартап', 'Некоммерческая организация', 'Агентство', 'Госсектор', 'Интернет-магазин', 'SaaS', 'Здравоохранение', 'Образование', 'Медиа', 'Финансы', 'Недвижимость', 'Гостиничный бизнес', 'Производство', 'Розничная торговля'],
        'ja' => ['大企業', 'スタートアップ', 'NPO', '代理店', '官公庁', 'EC', 'SaaS', 'ヘルスケア', '教育', 'メディア', '金融', '不動産', '観光・ホスピタリティ', '製造業', '小売'],
        'zh' => ['大型企业', '初创企业', '非营利组织', '代理商', '政府', '电子商务', 'SaaS', '医疗', '教育', '媒体', '金融', '房地产', '酒店', '制造业', '零售'],
    ],

    // === Events ===
    'event.*(type|categor|kind|art)|veranstaltung|événement|evento|evenement|wydarzenie|мероприятие|イベント|活动类型' => [
        'en' => ['Conference', 'Workshop', 'Webinar', 'Meetup', 'Seminar', 'Hackathon', 'Panel Discussion', 'Networking Event', 'Product Launch', 'Trade Show', 'Keynote', 'Bootcamp', 'Roundtable', 'Summit', 'Symposium'],
        'de' => ['Konferenz', 'Workshop', 'Webinar', 'Meetup', 'Seminar', 'Hackathon', 'Podiumsdiskussion', 'Networking-Event', 'Produktvorstellung', 'Messe', 'Keynote', 'Bootcamp', 'Runder Tisch', 'Gipfeltreffen', 'Symposium'],
        'fr' => ['Conférence', 'Atelier', 'Webinaire', 'Meetup', 'Séminaire', 'Hackathon', 'Table ronde', 'Événement networking', 'Lancement de produit', 'Salon professionnel', 'Conférence plénière', 'Bootcamp', 'Discussion en panel', 'Sommet', 'Symposium'],
        'es' => ['Conferencia', 'Taller', 'Webinar', 'Meetup', 'Seminario', 'Hackathon', 'Mesa redonda', 'Evento de networking', 'Lanzamiento de producto', 'Feria comercial', 'Ponencia', 'Bootcamp', 'Debate', 'Cumbre', 'Simposio'],
        'it' => ['Conferenza', 'Workshop', 'Webinar', 'Meetup', 'Seminario', 'Hackathon', 'Tavola rotonda', 'Evento di networking', 'Lancio prodotto', 'Fiera', 'Keynote', 'Bootcamp', 'Panel', 'Summit', 'Simposio'],
        'nl' => ['Conferentie', 'Workshop', 'Webinar', 'Meetup', 'Seminar', 'Hackathon', 'Paneldiscussie', 'Netwerkevenement', 'Productlancering', 'Beurs', 'Keynote', 'Bootcamp', 'Rondetafel', 'Top', 'Symposium'],
        'pt' => ['Conferência', 'Workshop', 'Webinar', 'Meetup', 'Seminário', 'Hackathon', 'Mesa redonda', 'Evento de networking', 'Lançamento de produto', 'Feira', 'Palestra', 'Bootcamp', 'Painel', 'Cúpula', 'Simpósio'],
        'pl' => ['Konferencja', 'Warsztaty', 'Webinar', 'Meetup', 'Seminarium', 'Hackathon', 'Panel dyskusyjny', 'Wydarzenie networkingowe', 'Premiera produktu', 'Targi', 'Keynote', 'Bootcamp', 'Okrągły stół', 'Szczyt', 'Sympozjum'],
        'ru' => ['Конференция', 'Мастер-класс', 'Вебинар', 'Митап', 'Семинар', 'Хакатон', 'Панельная дискуссия', 'Нетворкинг', 'Презентация продукта', 'Выставка', 'Доклад', 'Буткемп', 'Круглый стол', 'Саммит', 'Симпозиум'],
        'ja' => ['カンファレンス', 'ワークショップ', 'ウェビナー', 'ミートアップ', 'セミナー', 'ハッカソン', 'パネルディスカッション', 'ネットワーキングイベント', '製品発表会', '展示会', '基調講演', 'ブートキャンプ', 'ラウンドテーブル', 'サミット', 'シンポジウム'],
        'zh' => ['会议', '研讨会', '网络研讨会', '交流会', '讲座', '黑客松', '圆桌讨论', '社交活动', '产品发布会', '展览会', '主题演讲', '集训营', '座谈会', '峰会', '学术研讨会'],
    ],

    // === E-commerce ===
    'product.*(type|categor|kind)|produkt.*(typ|kategori)|catégorie.*produit|categoría.*producto|categoria.*prodotto|productcategorie|kategoria.*produkt|категория.*товар|商品.*カテゴリ|产品.*分类' => [
        'en' => ['Electronics', 'Clothing', 'Home & Garden', 'Books', 'Software', 'Sports & Outdoors', 'Toys', 'Health & Beauty', 'Automotive', 'Food & Beverages', 'Jewelry', 'Office Supplies', 'Pet Supplies', 'Music', 'Art'],
        'de' => ['Elektronik', 'Bekleidung', 'Haus & Garten', 'Bücher', 'Software', 'Sport & Outdoor', 'Spielzeug', 'Gesundheit & Pflege', 'Autozubehör', 'Lebensmittel', 'Schmuck', 'Bürobedarf', 'Tierbedarf', 'Musik', 'Kunst'],
        'fr' => ['Électronique', 'Vêtements', 'Maison & Jardin', 'Livres', 'Logiciels', 'Sports & Plein air', 'Jouets', 'Santé & Beauté', 'Automobile', 'Alimentation', 'Bijoux', 'Fournitures de bureau', 'Animalerie', 'Musique', 'Art'],
        'es' => ['Electrónica', 'Ropa', 'Hogar & Jardín', 'Libros', 'Software', 'Deportes & Aire libre', 'Juguetes', 'Salud & Belleza', 'Automóvil', 'Alimentos & Bebidas', 'Joyería', 'Material de oficina', 'Mascotas', 'Música', 'Arte'],
        'it' => ['Elettronica', 'Abbigliamento', 'Casa & Giardino', 'Libri', 'Software', 'Sport & Outdoor', 'Giocattoli', 'Salute & Bellezza', 'Auto & Moto', 'Alimentari & Bevande', 'Gioielli', 'Cancelleria', 'Animali', 'Musica', 'Arte'],
        'nl' => ['Elektronica', 'Kleding', 'Huis & Tuin', 'Boeken', 'Software', 'Sport & Outdoor', 'Speelgoed', 'Gezondheid & Beauty', 'Auto', 'Eten & Drinken', 'Sieraden', 'Kantoorartikelen', 'Dierbenodigdheden', 'Muziek', 'Kunst'],
        'pt' => ['Eletrônicos', 'Roupas', 'Casa & Jardim', 'Livros', 'Software', 'Esportes & Ar livre', 'Brinquedos', 'Saúde & Beleza', 'Automotivo', 'Alimentos & Bebidas', 'Joias', 'Material de escritório', 'Pets', 'Música', 'Arte'],
        'pl' => ['Elektronika', 'Odzież', 'Dom & Ogród', 'Książki', 'Oprogramowanie', 'Sport & Outdoor', 'Zabawki', 'Zdrowie & Uroda', 'Motoryzacja', 'Żywność & Napoje', 'Biżuteria', 'Artykuły biurowe', 'Zoologia', 'Muzyka', 'Sztuka'],
        'ru' => ['Электроника', 'Одежда', 'Дом и сад', 'Книги', 'ПО', 'Спорт и отдых', 'Игрушки', 'Здоровье и красота', 'Автотовары', 'Продукты и напитки', 'Украшения', 'Канцелярия', 'Зоотовары', 'Музыка', 'Искусство'],
        'ja' => ['家電', 'ファッション', 'ホーム&ガーデン', '本', 'ソフトウェア', 'スポーツ&アウトドア', 'おもちゃ', '健康&ビューティー', 'カー用品', '食品&飲料', 'ジュエリー', 'オフィス用品', 'ペット用品', '音楽', 'アート'],
        'zh' => ['电子产品', '服装', '家居园艺', '图书', '软件', '运动户外', '玩具', '美妆个护', '汽车用品', '食品饮料', '珠宝首饰', '办公用品', '宠物用品', '音乐', '艺术'],
    ],
    '^brand|^marke' => ['Alpine', 'Coastal', 'Summit', 'Horizon', 'Nova', 'Vertex', 'Ember', 'Pulse', 'Drift', 'Forge', 'Lumen', 'Crest', 'Apex', 'Aura', 'Zenith'],
    '^colou?r|^farbe|^couleur|^color$|^colore|^kleur|^cor$|^kolor|^цвет|^色$|^颜色' => [
        'en' => ['Red', 'Blue', 'Green', 'Black', 'White', 'Navy', 'Beige', 'Gray', 'Olive', 'Burgundy', 'Teal', 'Coral', 'Sand', 'Charcoal', 'Ivory'],
        'de' => ['Rot', 'Blau', 'Grün', 'Schwarz', 'Weiß', 'Marineblau', 'Beige', 'Grau', 'Oliv', 'Bordeaux', 'Petrol', 'Koralle', 'Sand', 'Anthrazit', 'Elfenbein'],
        'fr' => ['Rouge', 'Bleu', 'Vert', 'Noir', 'Blanc', 'Marine', 'Beige', 'Gris', 'Olive', 'Bordeaux', 'Sarcelle', 'Corail', 'Sable', 'Anthracite', 'Ivoire'],
        'es' => ['Rojo', 'Azul', 'Verde', 'Negro', 'Blanco', 'Marino', 'Beige', 'Gris', 'Oliva', 'Burdeos', 'Turquesa', 'Coral', 'Arena', 'Carbón', 'Marfil'],
        'it' => ['Rosso', 'Blu', 'Verde', 'Nero', 'Bianco', 'Blu navy', 'Beige', 'Grigio', 'Oliva', 'Bordeaux', 'Teal', 'Corallo', 'Sabbia', 'Antracite', 'Avorio'],
        'nl' => ['Rood', 'Blauw', 'Groen', 'Zwart', 'Wit', 'Marineblauw', 'Beige', 'Grijs', 'Olijf', 'Bordeaux', 'Petrol', 'Koraal', 'Zand', 'Antraciet', 'Ivoor'],
        'pt' => ['Vermelho', 'Azul', 'Verde', 'Preto', 'Branco', 'Marinho', 'Bege', 'Cinza', 'Oliva', 'Bordô', 'Turquesa', 'Coral', 'Areia', 'Carvão', 'Marfim'],
        'pl' => ['Czerwony', 'Niebieski', 'Zielony', 'Czarny', 'Biały', 'Granatowy', 'Beżowy', 'Szary', 'Oliwkowy', 'Bordowy', 'Morski', 'Koralowy', 'Piaskowy', 'Grafitowy', 'Kość słoniowa'],
        'ru' => ['Красный', 'Синий', 'Зелёный', 'Чёрный', 'Белый', 'Тёмно-синий', 'Бежевый', 'Серый', 'Оливковый', 'Бордовый', 'Бирюзовый', 'Коралловый', 'Песочный', 'Угольный', 'Слоновая кость'],
        'ja' => ['レッド', 'ブルー', 'グリーン', 'ブラック', 'ホワイト', 'ネイビー', 'ベージュ', 'グレー', 'オリーブ', 'バーガンディ', 'ティール', 'コーラル', 'サンド', 'チャコール', 'アイボリー'],
        'zh' => ['红色', '蓝色', '绿色', '黑色', '白色', '藏青色', '米色', '灰色', '橄榄色', '酒红色', '青色', '珊瑚色', '沙色', '炭灰色', '象牙色'],
    ],
    '^size|^größe|^taille|^talla|^taglia|^maat|^tamanho|^rozmiar|^размер|^サイズ|^尺码' => [
        'en' => ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'One Size'],
        'de' => ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'Einheitsgröße'],
        'fr' => ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'Taille unique'],
        'es' => ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'Talla única'],
        'it' => ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'Taglia unica'],
        'nl' => ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'One size'],
        'pt' => ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'Tamanho único'],
        'pl' => ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'Uniwersalny'],
        'ru' => ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'Универсальный'],
        'ja' => ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'フリーサイズ'],
        'zh' => ['XS', 'S', 'M', 'L', 'XL', 'XXL', '均码'],
    ],
    '^material|^matériau|^materiale|^materiaal|^materiał|^материал|^素材|^材质' => [
        'en' => ['Cotton', 'Polyester', 'Leather', 'Silk', 'Wool', 'Linen', 'Denim', 'Nylon', 'Cashmere', 'Velvet', 'Canvas', 'Suede'],
        'de' => ['Baumwolle', 'Polyester', 'Leder', 'Seide', 'Wolle', 'Leinen', 'Denim', 'Nylon', 'Kaschmir', 'Samt', 'Canvas', 'Wildleder'],
        'fr' => ['Coton', 'Polyester', 'Cuir', 'Soie', 'Laine', 'Lin', 'Denim', 'Nylon', 'Cachemire', 'Velours', 'Toile', 'Daim'],
        'es' => ['Algodón', 'Poliéster', 'Cuero', 'Seda', 'Lana', 'Lino', 'Denim', 'Nailon', 'Cachemira', 'Terciopelo', 'Lona', 'Ante'],
        'it' => ['Cotone', 'Poliestere', 'Pelle', 'Seta', 'Lana', 'Lino', 'Denim', 'Nylon', 'Cashmere', 'Velluto', 'Tela', 'Camoscio'],
        'nl' => ['Katoen', 'Polyester', 'Leer', 'Zijde', 'Wol', 'Linnen', 'Denim', 'Nylon', 'Kasjmier', 'Fluweel', 'Canvas', 'Suède'],
        'pt' => ['Algodão', 'Poliéster', 'Couro', 'Seda', 'Lã', 'Linho', 'Denim', 'Nylon', 'Caxemira', 'Veludo', 'Lona', 'Camurça'],
        'pl' => ['Bawełna', 'Poliester', 'Skóra', 'Jedwab', 'Wełna', 'Len', 'Denim', 'Nylon', 'Kaszmir', 'Aksamit', 'Płótno', 'Zamsz'],
        'ru' => ['Хлопок', 'Полиэстер', 'Кожа', 'Шёлк', 'Шерсть', 'Лён', 'Деним', 'Нейлон', 'Кашемир', 'Бархат', 'Канвас', 'Замша'],
        'ja' => ['コットン', 'ポリエステル', 'レザー', 'シルク', 'ウール', 'リネン', 'デニム', 'ナイロン', 'カシミア', 'ベルベット', 'キャンバス', 'スエード'],
        'zh' => ['棉', '涤纶', '皮革', '丝绸', '羊毛', '亚麻', '牛仔布', '尼龙', '羊绒', '天鹅绒', '帆布', '麂皮'],
    ],

    // === Real Estate ===
    'property.*(type|categor)|immobilien.*(typ|art)|objekt.*(typ|art)|type.*bien|tipo.*propiedad|tipo.*immobile|woningtype|typ.*nieruchomości|тип.*недвижимост|物件.*種類|房产.*类型' => [
        'en' => ['Apartment', 'House', 'Villa', 'Condo', 'Studio', 'Penthouse', 'Townhouse', 'Duplex', 'Bungalow', 'Loft', 'Cottage', 'Farmhouse', 'Chalet', 'Mansion', 'Mobile Home'],
        'de' => ['Wohnung', 'Haus', 'Villa', 'Eigentumswohnung', 'Studio', 'Penthouse', 'Reihenhaus', 'Doppelhaushälfte', 'Bungalow', 'Loft', 'Ferienhaus', 'Bauernhaus', 'Chalet', 'Herrenhaus', 'Mobilheim'],
        'fr' => ['Appartement', 'Maison', 'Villa', 'Copropriété', 'Studio', 'Penthouse', 'Maison de ville', 'Duplex', 'Bungalow', 'Loft', 'Cottage', 'Ferme', 'Chalet', 'Manoir', 'Mobil-home'],
        'es' => ['Apartamento', 'Casa', 'Villa', 'Condominio', 'Estudio', 'Ático', 'Adosado', 'Dúplex', 'Bungalow', 'Loft', 'Cabaña', 'Cortijo', 'Chalet', 'Mansión', 'Casa móvil'],
        'it' => ['Appartamento', 'Casa', 'Villa', 'Condominio', 'Monolocale', 'Attico', 'Villetta a schiera', 'Bifamiliare', 'Bungalow', 'Loft', 'Cottage', 'Casale', 'Chalet', 'Palazzo', 'Casa mobile'],
        'nl' => ['Appartement', 'Huis', 'Villa', 'Condo', 'Studio', 'Penthouse', 'Rijwoning', 'Twee-onder-een-kap', 'Bungalow', 'Loft', 'Cottage', 'Boerderij', 'Chalet', 'Herenhuis', 'Stacaravan'],
        'pt' => ['Apartamento', 'Casa', 'Villa', 'Condomínio', 'Estúdio', 'Cobertura', 'Sobrado', 'Duplex', 'Bangalô', 'Loft', 'Chalé', 'Fazenda', 'Chalet', 'Mansão', 'Casa móvel'],
        'pl' => ['Mieszkanie', 'Dom', 'Willa', 'Apartament', 'Kawalerka', 'Penthouse', 'Szeregowiec', 'Bliźniak', 'Bungalow', 'Loft', 'Domek', 'Gospodarstwo', 'Chalet', 'Rezydencja', 'Dom mobilny'],
        'ru' => ['Квартира', 'Дом', 'Вилла', 'Кондоминиум', 'Студия', 'Пентхаус', 'Таунхаус', 'Дуплекс', 'Бунгало', 'Лофт', 'Коттедж', 'Фермерский дом', 'Шале', 'Особняк', 'Мобильный дом'],
        'ja' => ['マンション', '一戸建て', '別荘', 'コンドミニアム', 'ワンルーム', 'ペントハウス', 'タウンハウス', 'メゾネット', 'バンガロー', 'ロフト', 'コテージ', '古民家', 'シャレー', '豪邸', 'トレーラーハウス'],
        'zh' => ['公寓', '别墅', '豪华别墅', '共管公寓', '单间', '顶层公寓', '联排别墅', '复式', '平房', 'Loft', '小屋', '农舍', '木屋', '豪宅', '移动房屋'],
    ],
    'feature|amenity|amenities|ausstattung|merkmal|équipement|característica|caratteristica|voorziening|udogodnienie|удобство|設備|设施' => [
        'en' => ['Pool', 'Garage', 'Garden', 'Balcony', 'Elevator', 'Parking', 'Air Conditioning', 'Fireplace', 'Terrace', 'Storage', 'Security System', 'Gym', 'Sauna', 'Rooftop', 'Smart Home'],
        'de' => ['Pool', 'Garage', 'Garten', 'Balkon', 'Aufzug', 'Stellplatz', 'Klimaanlage', 'Kamin', 'Terrasse', 'Abstellraum', 'Alarmanlage', 'Fitnessraum', 'Sauna', 'Dachterrasse', 'Smart Home'],
        'fr' => ['Piscine', 'Garage', 'Jardin', 'Balcon', 'Ascenseur', 'Parking', 'Climatisation', 'Cheminée', 'Terrasse', 'Rangement', 'Alarme', 'Salle de sport', 'Sauna', 'Toit-terrasse', 'Domotique'],
        'es' => ['Piscina', 'Garaje', 'Jardín', 'Balcón', 'Ascensor', 'Aparcamiento', 'Aire acondicionado', 'Chimenea', 'Terraza', 'Trastero', 'Alarma', 'Gimnasio', 'Sauna', 'Azotea', 'Domótica'],
        'it' => ['Piscina', 'Garage', 'Giardino', 'Balcone', 'Ascensore', 'Parcheggio', 'Aria condizionata', 'Camino', 'Terrazza', 'Ripostiglio', 'Allarme', 'Palestra', 'Sauna', 'Terrazzo sul tetto', 'Domotica'],
        'nl' => ['Zwembad', 'Garage', 'Tuin', 'Balkon', 'Lift', 'Parkeerplaats', 'Airconditioning', 'Open haard', 'Terras', 'Berging', 'Alarmsysteem', 'Fitnessruimte', 'Sauna', 'Dakterras', 'Smart home'],
        'pt' => ['Piscina', 'Garagem', 'Jardim', 'Varanda', 'Elevador', 'Estacionamento', 'Ar condicionado', 'Lareira', 'Terraço', 'Despensa', 'Alarme', 'Academia', 'Sauna', 'Cobertura', 'Casa inteligente'],
        'pl' => ['Basen', 'Garaż', 'Ogród', 'Balkon', 'Winda', 'Parking', 'Klimatyzacja', 'Kominek', 'Taras', 'Schowek', 'Alarm', 'Siłownia', 'Sauna', 'Taras na dachu', 'Inteligentny dom'],
        'ru' => ['Бассейн', 'Гараж', 'Сад', 'Балкон', 'Лифт', 'Парковка', 'Кондиционер', 'Камин', 'Терраса', 'Кладовая', 'Сигнализация', 'Тренажёрный зал', 'Сауна', 'Крыша', 'Умный дом'],
        'ja' => ['プール', 'ガレージ', '庭', 'バルコニー', 'エレベーター', '駐車場', 'エアコン', '暖炉', 'テラス', '収納', 'セキュリティ', 'ジム', 'サウナ', '屋上', 'スマートホーム'],
        'zh' => ['游泳池', '车库', '花园', '阳台', '电梯', '停车位', '空调', '壁炉', '露台', '储物间', '安防系统', '健身房', '桑拿', '天台', '智能家居'],
    ],
    'listing.*(type|categor)|type.*annonce|tipo.*anuncio|tipo.*annuncio|advertentietype|тип.*объявлени|掲載.*種類|房源.*类型' => [
        'en' => ['For Sale', 'For Rent', 'Auction', 'Short-Term Rental', 'Lease', 'New Construction'],
        'de' => ['Zum Verkauf', 'Zur Miete', 'Auktion', 'Kurzzeitmiete', 'Pacht', 'Neubau'],
        'fr' => ['À vendre', 'À louer', 'Aux enchères', 'Location saisonnière', 'Bail', 'Neuf'],
        'es' => ['En venta', 'En alquiler', 'Subasta', 'Alquiler vacacional', 'Arrendamiento', 'Obra nueva'],
        'it' => ['In vendita', 'In affitto', 'Asta', 'Affitto breve', 'Locazione', 'Nuova costruzione'],
        'nl' => ['Te koop', 'Te huur', 'Veiling', 'Korte verhuur', 'Lease', 'Nieuwbouw'],
        'pt' => ['À venda', 'Para alugar', 'Leilão', 'Aluguel temporário', 'Arrendamento', 'Construção nova'],
        'pl' => ['Na sprzedaż', 'Do wynajęcia', 'Licytacja', 'Wynajem krótkoterminowy', 'Dzierżawa', 'Nowe budownictwo'],
        'ru' => ['Продажа', 'Аренда', 'Аукцион', 'Краткосрочная аренда', 'Лизинг', 'Новостройка'],
        'ja' => ['売買', '賃貸', 'オークション', '短期賃貸', 'リース', '新築'],
        'zh' => ['出售', '出租', '拍卖', '短租', '租赁', '新房'],
    ],

    // === Food / Restaurant ===
    'cuisine|küche|food.*(type|categor)|gastronomie|cocina|cucina|keuken|cozinha|kuchnia|кухня|料理|菜系' => [
        'en' => ['Italian', 'Mexican', 'Japanese', 'Indian', 'Thai', 'French', 'Mediterranean', 'Chinese', 'Korean', 'Vietnamese', 'Greek', 'Turkish', 'Brazilian', 'Ethiopian', 'Peruvian'],
        'de' => ['Italienisch', 'Mexikanisch', 'Japanisch', 'Indisch', 'Thailändisch', 'Französisch', 'Mediterran', 'Chinesisch', 'Koreanisch', 'Vietnamesisch', 'Griechisch', 'Türkisch', 'Brasilianisch', 'Äthiopisch', 'Peruanisch'],
        'fr' => ['Italienne', 'Mexicaine', 'Japonaise', 'Indienne', 'Thaïlandaise', 'Française', 'Méditerranéenne', 'Chinoise', 'Coréenne', 'Vietnamienne', 'Grecque', 'Turque', 'Brésilienne', 'Éthiopienne', 'Péruvienne'],
        'es' => ['Italiana', 'Mexicana', 'Japonesa', 'India', 'Tailandesa', 'Francesa', 'Mediterránea', 'China', 'Coreana', 'Vietnamita', 'Griega', 'Turca', 'Brasileña', 'Etíope', 'Peruana'],
        'it' => ['Italiana', 'Messicana', 'Giapponese', 'Indiana', 'Tailandese', 'Francese', 'Mediterranea', 'Cinese', 'Coreana', 'Vietnamita', 'Greca', 'Turca', 'Brasiliana', 'Etiope', 'Peruviana'],
        'nl' => ['Italiaans', 'Mexicaans', 'Japans', 'Indiaas', 'Thais', 'Frans', 'Mediterraans', 'Chinees', 'Koreaans', 'Vietnamees', 'Grieks', 'Turks', 'Braziliaans', 'Ethiopisch', 'Peruaans'],
        'pt' => ['Italiana', 'Mexicana', 'Japonesa', 'Indiana', 'Tailandesa', 'Francesa', 'Mediterrânea', 'Chinesa', 'Coreana', 'Vietnamita', 'Grega', 'Turca', 'Brasileira', 'Etíope', 'Peruana'],
        'pl' => ['Włoska', 'Meksykańska', 'Japońska', 'Indyjska', 'Tajska', 'Francuska', 'Śródziemnomorska', 'Chińska', 'Koreańska', 'Wietnamska', 'Grecka', 'Turecka', 'Brazylijska', 'Etiopska', 'Peruwiańska'],
        'ru' => ['Итальянская', 'Мексиканская', 'Японская', 'Индийская', 'Тайская', 'Французская', 'Средиземноморская', 'Китайская', 'Корейская', 'Вьетнамская', 'Греческая', 'Турецкая', 'Бразильская', 'Эфиопская', 'Перуанская'],
        'ja' => ['イタリアン', 'メキシカン', '和食', 'インド料理', 'タイ料理', 'フレンチ', '地中海料理', '中華', '韓国料理', 'ベトナム料理', 'ギリシャ料理', 'トルコ料理', 'ブラジル料理', 'エチオピア料理', 'ペルー料理'],
        'zh' => ['意大利菜', '墨西哥菜', '日本料理', '印度菜', '泰国菜', '法国菜', '地中海菜', '中餐', '韩国料理', '越南菜', '希腊菜', '土耳其菜', '巴西菜', '埃塞俄比亚菜', '秘鲁菜'],
    ],
    'diet|dietary|ernährung|régime|dieta|dieet|диета|食事制限|饮食' => [
        'en' => ['Vegan', 'Vegetarian', 'Gluten-Free', 'Keto', 'Halal', 'Kosher', 'Paleo', 'Low-Carb', 'Dairy-Free', 'Whole30'],
        'de' => ['Vegan', 'Vegetarisch', 'Glutenfrei', 'Keto', 'Halal', 'Koscher', 'Paleo', 'Low-Carb', 'Laktosefrei', 'Vollwertkost'],
        'fr' => ['Végan', 'Végétarien', 'Sans gluten', 'Céto', 'Halal', 'Casher', 'Paléo', 'Faible en glucides', 'Sans lactose', 'Whole30'],
        'es' => ['Vegano', 'Vegetariano', 'Sin gluten', 'Keto', 'Halal', 'Kosher', 'Paleo', 'Bajo en carbohidratos', 'Sin lácteos', 'Whole30'],
        'it' => ['Vegano', 'Vegetariano', 'Senza glutine', 'Cheto', 'Halal', 'Kosher', 'Paleo', 'Low-carb', 'Senza latticini', 'Whole30'],
        'nl' => ['Veganistisch', 'Vegetarisch', 'Glutenvrij', 'Keto', 'Halal', 'Koosjer', 'Paleo', 'Koolhydraatarm', 'Zuivelvrij', 'Whole30'],
        'pt' => ['Vegano', 'Vegetariano', 'Sem glúten', 'Keto', 'Halal', 'Kosher', 'Paleo', 'Low-carb', 'Sem lactose', 'Whole30'],
        'pl' => ['Wegański', 'Wegetariański', 'Bezglutenowy', 'Keto', 'Halal', 'Koszerny', 'Paleo', 'Niskowęglowodanowy', 'Bez nabiału', 'Whole30'],
        'ru' => ['Веганский', 'Вегетарианский', 'Безглютеновый', 'Кето', 'Халяль', 'Кошерный', 'Палео', 'Низкоуглеводный', 'Безлактозный', 'Whole30'],
        'ja' => ['ヴィーガン', 'ベジタリアン', 'グルテンフリー', 'ケトジェニック', 'ハラール', 'コーシャ', 'パレオ', '低糖質', '乳製品不使用', 'Whole30'],
        'zh' => ['纯素', '素食', '无麸质', '生酮', '清真', '犹太洁食', '原始饮食', '低碳水', '无乳制品', 'Whole30'],
    ],
    'meal.*(type)?|mahlzeit|repas|comida|pasto|maaltijd|posiłek|приём.*пищи|食事|餐' => [
        'en' => ['Breakfast', 'Lunch', 'Dinner', 'Brunch', 'Snack', 'Dessert', 'Appetizer', 'Side Dish'],
        'de' => ['Frühstück', 'Mittagessen', 'Abendessen', 'Brunch', 'Snack', 'Dessert', 'Vorspeise', 'Beilage'],
        'fr' => ['Petit-déjeuner', 'Déjeuner', 'Dîner', 'Brunch', 'En-cas', 'Dessert', 'Entrée', 'Accompagnement'],
        'es' => ['Desayuno', 'Almuerzo', 'Cena', 'Brunch', 'Merienda', 'Postre', 'Aperitivo', 'Guarnición'],
        'it' => ['Colazione', 'Pranzo', 'Cena', 'Brunch', 'Spuntino', 'Dolce', 'Antipasto', 'Contorno'],
        'nl' => ['Ontbijt', 'Lunch', 'Diner', 'Brunch', 'Snack', 'Dessert', 'Voorgerecht', 'Bijgerecht'],
        'pt' => ['Café da manhã', 'Almoço', 'Jantar', 'Brunch', 'Lanche', 'Sobremesa', 'Entrada', 'Acompanhamento'],
        'pl' => ['Śniadanie', 'Obiad', 'Kolacja', 'Brunch', 'Przekąska', 'Deser', 'Przystawka', 'Dodatek'],
        'ru' => ['Завтрак', 'Обед', 'Ужин', 'Бранч', 'Перекус', 'Десерт', 'Закуска', 'Гарнир'],
        'ja' => ['朝食', '昼食', '夕食', 'ブランチ', '軽食', 'デザート', '前菜', '副菜'],
        'zh' => ['早餐', '午餐', '晚餐', '早午餐', '小吃', '甜点', '开胃菜', '配菜'],
    ],
    'ingredient|zutat|ingrédient|ingrediente|ingrediënt|składnik|ингредиент|食材|食材原料' => [
        'en' => ['Tomato', 'Garlic', 'Onion', 'Olive Oil', 'Basil', 'Chicken', 'Rice', 'Lemon', 'Butter', 'Parmesan', 'Avocado', 'Ginger', 'Soy Sauce', 'Honey', 'Cilantro'],
        'de' => ['Tomate', 'Knoblauch', 'Zwiebel', 'Olivenöl', 'Basilikum', 'Hähnchen', 'Reis', 'Zitrone', 'Butter', 'Parmesan', 'Avocado', 'Ingwer', 'Sojasauce', 'Honig', 'Koriander'],
        'fr' => ['Tomate', 'Ail', 'Oignon', 'Huile d\'olive', 'Basilic', 'Poulet', 'Riz', 'Citron', 'Beurre', 'Parmesan', 'Avocat', 'Gingembre', 'Sauce soja', 'Miel', 'Coriandre'],
        'es' => ['Tomate', 'Ajo', 'Cebolla', 'Aceite de oliva', 'Albahaca', 'Pollo', 'Arroz', 'Limón', 'Mantequilla', 'Parmesano', 'Aguacate', 'Jengibre', 'Salsa de soja', 'Miel', 'Cilantro'],
        'it' => ['Pomodoro', 'Aglio', 'Cipolla', 'Olio d\'oliva', 'Basilico', 'Pollo', 'Riso', 'Limone', 'Burro', 'Parmigiano', 'Avocado', 'Zenzero', 'Salsa di soia', 'Miele', 'Coriandolo'],
        'nl' => ['Tomaat', 'Knoflook', 'Ui', 'Olijfolie', 'Basilicum', 'Kip', 'Rijst', 'Citroen', 'Boter', 'Parmezaan', 'Avocado', 'Gember', 'Sojasaus', 'Honing', 'Koriander'],
        'pt' => ['Tomate', 'Alho', 'Cebola', 'Azeite', 'Manjericão', 'Frango', 'Arroz', 'Limão', 'Manteiga', 'Parmesão', 'Abacate', 'Gengibre', 'Molho de soja', 'Mel', 'Coentro'],
        'pl' => ['Pomidor', 'Czosnek', 'Cebula', 'Oliwa z oliwek', 'Bazylia', 'Kurczak', 'Ryż', 'Cytryna', 'Masło', 'Parmezan', 'Awokado', 'Imbir', 'Sos sojowy', 'Miód', 'Kolendra'],
        'ru' => ['Помидор', 'Чеснок', 'Лук', 'Оливковое масло', 'Базилик', 'Курица', 'Рис', 'Лимон', 'Сливочное масло', 'Пармезан', 'Авокадо', 'Имбирь', 'Соевый соус', 'Мёд', 'Кинза'],
        'ja' => ['トマト', 'ニンニク', '玉ねぎ', 'オリーブオイル', 'バジル', '鶏肉', '米', 'レモン', 'バター', 'パルメザン', 'アボカド', '生姜', '醤油', 'はちみつ', 'パクチー'],
        'zh' => ['番茄', '大蒜', '洋葱', '橄榄油', '罗勒', '鸡肉', '米饭', '柠檬', '黄油', '帕尔马干酪', '牛油果', '生姜', '酱油', '蜂蜜', '香菜'],
    ],

    // === Content / Blog ===
    'topic|thema|themen|sujet|tema|onderwerp|temat|тема|トピック|话题' => [
        'en' => ['Technology', 'Business', 'Health', 'Travel', 'Lifestyle', 'Science', 'Education', 'Design', 'Marketing', 'Productivity', 'Finance', 'Culture', 'Environment', 'Innovation', 'Leadership'],
        'de' => ['Technologie', 'Business', 'Gesundheit', 'Reisen', 'Lifestyle', 'Wissenschaft', 'Bildung', 'Design', 'Marketing', 'Produktivität', 'Finanzen', 'Kultur', 'Umwelt', 'Innovation', 'Führung'],
        'fr' => ['Technologie', 'Business', 'Santé', 'Voyage', 'Lifestyle', 'Science', 'Éducation', 'Design', 'Marketing', 'Productivité', 'Finance', 'Culture', 'Environnement', 'Innovation', 'Leadership'],
        'es' => ['Tecnología', 'Negocios', 'Salud', 'Viajes', 'Estilo de vida', 'Ciencia', 'Educación', 'Diseño', 'Marketing', 'Productividad', 'Finanzas', 'Cultura', 'Medio ambiente', 'Innovación', 'Liderazgo'],
        'it' => ['Tecnologia', 'Business', 'Salute', 'Viaggi', 'Lifestyle', 'Scienza', 'Istruzione', 'Design', 'Marketing', 'Produttività', 'Finanza', 'Cultura', 'Ambiente', 'Innovazione', 'Leadership'],
        'nl' => ['Technologie', 'Business', 'Gezondheid', 'Reizen', 'Lifestyle', 'Wetenschap', 'Onderwijs', 'Design', 'Marketing', 'Productiviteit', 'Financiën', 'Cultuur', 'Milieu', 'Innovatie', 'Leiderschap'],
        'pt' => ['Tecnologia', 'Negócios', 'Saúde', 'Viagens', 'Estilo de vida', 'Ciência', 'Educação', 'Design', 'Marketing', 'Produtividade', 'Finanças', 'Cultura', 'Meio ambiente', 'Inovação', 'Liderança'],
        'pl' => ['Technologia', 'Biznes', 'Zdrowie', 'Podróże', 'Styl życia', 'Nauka', 'Edukacja', 'Design', 'Marketing', 'Produktywność', 'Finanse', 'Kultura', 'Środowisko', 'Innowacje', 'Przywództwo'],
        'ru' => ['Технологии', 'Бизнес', 'Здоровье', 'Путешествия', 'Образ жизни', 'Наука', 'Образование', 'Дизайн', 'Маркетинг', 'Продуктивность', 'Финансы', 'Культура', 'Экология', 'Инновации', 'Лидерство'],
        'ja' => ['テクノロジー', 'ビジネス', '健康', '旅行', 'ライフスタイル', '科学', '教育', 'デザイン', 'マーケティング', '生産性', '金融', '文化', '環境', 'イノベーション', 'リーダーシップ'],
        'zh' => ['科技', '商业', '健康', '旅行', '生活方式', '科学', '教育', '设计', '营销', '效率', '金融', '文化', '环境', '创新', '领导力'],
    ],
    'format|content.*(type|kind)' => ['Article', 'Tutorial', 'Review', 'Interview', 'Case Study', 'Opinion', 'How-To Guide', 'Listicle', 'Infographic', 'Podcast', 'Video', 'Whitepaper', 'Newsletter'],

    // === General ===
    '^genre' => ['Fiction', 'Non-Fiction', 'Thriller', 'Romance', 'Sci-Fi', 'Fantasy', 'Horror', 'Biography', 'Mystery', 'Drama', 'Comedy', 'Documentary', 'Adventure', 'Historical', 'True Crime'],
    '^status|^stati' => [
        'en' => ['Active', 'Pending', 'Completed', 'Archived', 'Draft', 'In Review', 'On Hold', 'Cancelled'],
        'de' => ['Aktiv', 'Ausstehend', 'Abgeschlossen', 'Archiviert', 'Entwurf', 'In Prüfung', 'Pausiert', 'Storniert'],
        'fr' => ['Actif', 'En attente', 'Terminé', 'Archivé', 'Brouillon', 'En révision', 'En pause', 'Annulé'],
        'es' => ['Activo', 'Pendiente', 'Completado', 'Archivado', 'Borrador', 'En revisión', 'En espera', 'Cancelado'],
        'it' => ['Attivo', 'In attesa', 'Completato', 'Archiviato', 'Bozza', 'In revisione', 'In pausa', 'Annullato'],
        'nl' => ['Actief', 'In afwachting', 'Voltooid', 'Gearchiveerd', 'Concept', 'In beoordeling', 'Onderbroken', 'Geannuleerd'],
        'pt' => ['Ativo', 'Pendente', 'Concluído', 'Arquivado', 'Rascunho', 'Em revisão', 'Em espera', 'Cancelado'],
        'pl' => ['Aktywny', 'Oczekujący', 'Zakończony', 'Zarchiwizowany', 'Szkic', 'W recenzji', 'Wstrzymany', 'Anulowany'],
        'ru' => ['Активный', 'В ожидании', 'Завершён', 'Архив', 'Черновик', 'На проверке', 'Приостановлен', 'Отменён'],
        'ja' => ['アクティブ', '保留中', '完了', 'アーカイブ', '下書き', 'レビュー中', '一時停止', 'キャンセル'],
        'zh' => ['活跃', '待处理', '已完成', '已归档', '草稿', '审核中', '暂停', '已取消'],
    ],
    'priority|priorität|dringlichkeit|priorité|prioridad|priorità|prioriteit|priorytet|приоритет|優先度|优先级' => [
        'en' => ['Low', 'Medium', 'High', 'Critical', 'Urgent'],
        'de' => ['Niedrig', 'Mittel', 'Hoch', 'Kritisch', 'Dringend'],
        'fr' => ['Faible', 'Moyen', 'Élevé', 'Critique', 'Urgent'],
        'es' => ['Baja', 'Media', 'Alta', 'Crítica', 'Urgente'],
        'it' => ['Bassa', 'Media', 'Alta', 'Critica', 'Urgente'],
        'nl' => ['Laag', 'Gemiddeld', 'Hoog', 'Kritiek', 'Urgent'],
        'pt' => ['Baixa', 'Média', 'Alta', 'Crítica', 'Urgente'],
        'pl' => ['Niski', 'Średni', 'Wysoki', 'Krytyczny', 'Pilny'],
        'ru' => ['Низкий', 'Средний', 'Высокий', 'Критический', 'Срочный'],
        'ja' => ['低', '中', '高', '重大', '緊急'],
        'zh' => ['低', '中', '高', '严重', '紧急'],
    ],
    'level|difficulty|schwierigkeit|stufe|niveau|nivel|livello|poziom|уровень|レベル|难度' => [
        'en' => ['Beginner', 'Intermediate', 'Advanced', 'Expert'],
        'de' => ['Anfänger', 'Fortgeschritten', 'Experte', 'Profi'],
        'fr' => ['Débutant', 'Intermédiaire', 'Avancé', 'Expert'],
        'es' => ['Principiante', 'Intermedio', 'Avanzado', 'Experto'],
        'it' => ['Principiante', 'Intermedio', 'Avanzato', 'Esperto'],
        'nl' => ['Beginner', 'Gemiddeld', 'Gevorderd', 'Expert'],
        'pt' => ['Iniciante', 'Intermediário', 'Avançado', 'Especialista'],
        'pl' => ['Początkujący', 'Średniozaawansowany', 'Zaawansowany', 'Ekspert'],
        'ru' => ['Начинающий', 'Средний', 'Продвинутый', 'Эксперт'],
        'ja' => ['初級', '中級', '上級', 'エキスパート'],
        'zh' => ['初级', '中级', '高级', '专家'],
    ],
    'industry|industries|branche|industrie|industria|settore|branche|branża|отрасль|業界|行业' => [
        'en' => ['Technology', 'Healthcare', 'Finance', 'Education', 'Manufacturing', 'Retail', 'Real Estate', 'Media', 'Energy', 'Transportation', 'Hospitality', 'Agriculture', 'Construction', 'Telecommunications', 'Aerospace'],
        'de' => ['Technologie', 'Gesundheitswesen', 'Finanzen', 'Bildung', 'Fertigung', 'Einzelhandel', 'Immobilien', 'Medien', 'Energie', 'Transport', 'Gastgewerbe', 'Landwirtschaft', 'Bauwesen', 'Telekommunikation', 'Luft- und Raumfahrt'],
        'fr' => ['Technologie', 'Santé', 'Finance', 'Éducation', 'Industrie', 'Commerce de détail', 'Immobilier', 'Médias', 'Énergie', 'Transport', 'Hôtellerie', 'Agriculture', 'Construction', 'Télécommunications', 'Aéronautique'],
        'es' => ['Tecnología', 'Salud', 'Finanzas', 'Educación', 'Manufactura', 'Comercio minorista', 'Inmobiliaria', 'Medios', 'Energía', 'Transporte', 'Hostelería', 'Agricultura', 'Construcción', 'Telecomunicaciones', 'Aeroespacial'],
        'it' => ['Tecnologia', 'Sanità', 'Finanza', 'Istruzione', 'Manifattura', 'Retail', 'Immobiliare', 'Media', 'Energia', 'Trasporti', 'Hospitality', 'Agricoltura', 'Edilizia', 'Telecomunicazioni', 'Aerospaziale'],
        'nl' => ['Technologie', 'Gezondheidszorg', 'Financiën', 'Onderwijs', 'Maakindustrie', 'Detailhandel', 'Vastgoed', 'Media', 'Energie', 'Transport', 'Horeca', 'Landbouw', 'Bouw', 'Telecommunicatie', 'Luchtvaart'],
        'pt' => ['Tecnologia', 'Saúde', 'Finanças', 'Educação', 'Manufatura', 'Varejo', 'Imobiliário', 'Mídia', 'Energia', 'Transporte', 'Hotelaria', 'Agricultura', 'Construção', 'Telecomunicações', 'Aeroespacial'],
        'pl' => ['Technologia', 'Ochrona zdrowia', 'Finanse', 'Edukacja', 'Produkcja', 'Handel detaliczny', 'Nieruchomości', 'Media', 'Energetyka', 'Transport', 'Hotelarstwo', 'Rolnictwo', 'Budownictwo', 'Telekomunikacja', 'Lotnictwo'],
        'ru' => ['Технологии', 'Здравоохранение', 'Финансы', 'Образование', 'Производство', 'Розничная торговля', 'Недвижимость', 'Медиа', 'Энергетика', 'Транспорт', 'Гостиничный бизнес', 'Сельское хозяйство', 'Строительство', 'Телеком', 'Аэрокосмическая отрасль'],
        'ja' => ['テクノロジー', 'ヘルスケア', '金融', '教育', '製造業', '小売', '不動産', 'メディア', 'エネルギー', '運輸', 'ホスピタリティ', '農業', '建設', '通信', '航空宇宙'],
        'zh' => ['科技', '医疗', '金融', '教育', '制造业', '零售', '房地产', '传媒', '能源', '交通', '酒店业', '农业', '建筑', '电信', '航空航天'],
    ],
    'department|abteilung|département|departamento|dipartimento|afdeling|dział|отдел|部門|部门' => [
        'en' => ['Sales', 'Marketing', 'Engineering', 'Human Resources', 'Finance', 'Customer Support', 'Operations', 'Legal', 'Product', 'Design', 'Research', 'Quality Assurance'],
        'de' => ['Vertrieb', 'Marketing', 'Technik', 'Personalwesen', 'Finanzen', 'Kundenservice', 'Betrieb', 'Recht', 'Produktmanagement', 'Design', 'Forschung', 'Qualitätssicherung'],
        'fr' => ['Ventes', 'Marketing', 'Ingénierie', 'Ressources humaines', 'Finance', 'Support client', 'Opérations', 'Juridique', 'Produit', 'Design', 'Recherche', 'Assurance qualité'],
        'es' => ['Ventas', 'Marketing', 'Ingeniería', 'Recursos humanos', 'Finanzas', 'Atención al cliente', 'Operaciones', 'Legal', 'Producto', 'Diseño', 'Investigación', 'Control de calidad'],
        'it' => ['Vendite', 'Marketing', 'Ingegneria', 'Risorse umane', 'Finanza', 'Assistenza clienti', 'Operazioni', 'Legale', 'Prodotto', 'Design', 'Ricerca', 'Garanzia qualità'],
        'nl' => ['Verkoop', 'Marketing', 'Engineering', 'Human Resources', 'Financiën', 'Klantenservice', 'Operations', 'Juridisch', 'Product', 'Design', 'Onderzoek', 'Kwaliteitsborging'],
        'pt' => ['Vendas', 'Marketing', 'Engenharia', 'Recursos humanos', 'Finanças', 'Suporte ao cliente', 'Operações', 'Jurídico', 'Produto', 'Design', 'Pesquisa', 'Garantia de qualidade'],
        'pl' => ['Sprzedaż', 'Marketing', 'Inżynieria', 'Zasoby ludzkie', 'Finanse', 'Obsługa klienta', 'Operacje', 'Dział prawny', 'Produkt', 'Design', 'Badania', 'Zapewnienie jakości'],
        'ru' => ['Продажи', 'Маркетинг', 'Разработка', 'HR', 'Финансы', 'Поддержка клиентов', 'Операции', 'Юридический', 'Продукт', 'Дизайн', 'Исследования', 'Контроль качества'],
        'ja' => ['営業', 'マーケティング', 'エンジニアリング', '人事', '経理', 'カスタマーサポート', 'オペレーション', '法務', 'プロダクト', 'デザイン', '研究', '品質保証'],
        'zh' => ['销售', '市场', '工程', '人力资源', '财务', '客户支持', '运营', '法务', '产品', '设计', '研发', '质量保证'],
    ],
    'season|saison|jahreszeit|saison|temporada|stagione|seizoen|pora.*roku|сезон|季節|季节' => [
        'en' => ['Spring', 'Summer', 'Fall', 'Winter'],
        'de' => ['Frühling', 'Sommer', 'Herbst', 'Winter'],
        'fr' => ['Printemps', 'Été', 'Automne', 'Hiver'],
        'es' => ['Primavera', 'Verano', 'Otoño', 'Invierno'],
        'it' => ['Primavera', 'Estate', 'Autunno', 'Inverno'],
        'nl' => ['Lente', 'Zomer', 'Herfst', 'Winter'],
        'pt' => ['Primavera', 'Verão', 'Outono', 'Inverno'],
        'pl' => ['Wiosna', 'Lato', 'Jesień', 'Zima'],
        'ru' => ['Весна', 'Лето', 'Осень', 'Зима'],
        'ja' => ['春', '夏', '秋', '冬'],
        'zh' => ['春', '夏', '秋', '冬'],
    ],
    'language|sprache' => ['English', 'German', 'French', 'Spanish', 'Italian', 'Portuguese', 'Dutch', 'Polish', 'Russian', 'Japanese', 'Chinese', 'Korean', 'Arabic', 'Hindi', 'Swedish'],
    'region|area|gebiet|bezirk|région|zona|regione|regio|obszar|регион|地域|地区' => [
        'en' => ['North', 'South', 'East', 'West', 'Central', 'Northeast', 'Northwest', 'Southeast', 'Southwest', 'Midwest'],
        'de' => ['Nord', 'Süd', 'Ost', 'West', 'Mitte', 'Nordost', 'Nordwest', 'Südost', 'Südwest', 'Zentral'],
        'fr' => ['Nord', 'Sud', 'Est', 'Ouest', 'Centre', 'Nord-Est', 'Nord-Ouest', 'Sud-Est', 'Sud-Ouest', 'Île-de-France'],
        'es' => ['Norte', 'Sur', 'Este', 'Oeste', 'Centro', 'Noreste', 'Noroeste', 'Sureste', 'Suroeste', 'Centro'],
        'it' => ['Nord', 'Sud', 'Est', 'Ovest', 'Centro', 'Nord-Est', 'Nord-Ovest', 'Sud-Est', 'Sud-Ovest', 'Centro Italia'],
        'nl' => ['Noord', 'Zuid', 'Oost', 'West', 'Centraal', 'Noordoost', 'Noordwest', 'Zuidoost', 'Zuidwest', 'Midden'],
        'pt' => ['Norte', 'Sul', 'Leste', 'Oeste', 'Centro', 'Nordeste', 'Noroeste', 'Sudeste', 'Sudoeste', 'Centro-Oeste'],
        'pl' => ['Północ', 'Południe', 'Wschód', 'Zachód', 'Centrum', 'Północny wschód', 'Północny zachód', 'Południowy wschód', 'Południowy zachód', 'Środkowy'],
        'ru' => ['Север', 'Юг', 'Восток', 'Запад', 'Центр', 'Северо-восток', 'Северо-запад', 'Юго-восток', 'Юго-запад', 'Центральный'],
        'ja' => ['北部', '南部', '東部', '西部', '中央', '北東', '北西', '南東', '南西', '中部'],
        'zh' => ['北部', '南部', '东部', '西部', '中部', '东北', '西北', '东南', '西南', '华中'],
    ],
    ];

    /**
     * Contextual tag/term lists when a generic taxonomy (tags, categories)
     * is attached to a recognizable CPT. Matched against CPT slug and label.
     */
    protected const CPT_TERM_MAP = [
    // Portfolio / Creative
    'portfolio|projekt|project|work|showcase|case.?stud' => [
        'en' => ['Responsive', 'Minimalist', 'Corporate', 'Redesign', 'E-Commerce', 'Landing Page', 'Mobile-First', 'Open Source', 'Award-Winning', 'Collaborative', 'Pro Bono', 'Long-Term', 'Rapid Prototype', 'Full Rebrand', 'Ongoing'],
        'de' => ['Responsiv', 'Minimalistisch', 'Corporate', 'Redesign', 'E-Commerce', 'Landing Page', 'Mobile-First', 'Open Source', 'Preisgekrönt', 'Kollaborativ', 'Pro Bono', 'Langfristig', 'Prototyp', 'Rebranding', 'Laufend'],
        'fr' => ['Responsive', 'Minimaliste', 'Corporate', 'Refonte', 'E-Commerce', 'Page d\'atterrissage', 'Mobile-First', 'Open Source', 'Primé', 'Collaboratif', 'Pro Bono', 'Long terme', 'Prototype rapide', 'Identité visuelle', 'En cours'],
        'es' => ['Responsive', 'Minimalista', 'Corporativo', 'Rediseño', 'E-Commerce', 'Landing Page', 'Mobile-First', 'Código Abierto', 'Premiado', 'Colaborativo', 'Pro Bono', 'Largo Plazo', 'Prototipo Rápido', 'Cambio de Marca', 'En Curso'],
        'it' => ['Responsive', 'Minimalista', 'Corporate', 'Restyling', 'E-Commerce', 'Landing Page', 'Mobile-First', 'Open Source', 'Premiato', 'Collaborativo', 'Pro Bono', 'Lungo Termine', 'Prototipo Rapido', 'Rebranding', 'In Corso'],
        'nl' => ['Responsive', 'Minimalistisch', 'Zakelijk', 'Herontwerp', 'E-Commerce', 'Landingspagina', 'Mobile-First', 'Open Source', 'Bekroond', 'Samenwerkend', 'Pro Bono', 'Langlopend', 'Snel Prototype', 'Rebranding', 'Lopend'],
        'pt' => ['Responsivo', 'Minimalista', 'Corporativo', 'Redesign', 'E-Commerce', 'Landing Page', 'Mobile-First', 'Código Aberto', 'Premiado', 'Colaborativo', 'Pro Bono', 'Longo Prazo', 'Protótipo Rápido', 'Nova Identidade', 'Em Andamento'],
        'pl' => ['Responsywny', 'Minimalistyczny', 'Korporacyjny', 'Redesign', 'E-Commerce', 'Landing Page', 'Mobile-First', 'Open Source', 'Nagrodzony', 'Zespołowy', 'Pro Bono', 'Długoterminowy', 'Szybki Prototyp', 'Rebranding', 'W Toku'],
        'ru' => ['Адаптивный', 'Минималистичный', 'Корпоративный', 'Редизайн', 'Электронная коммерция', 'Лендинг', 'Mobile-First', 'Открытый код', 'Отмеченный наградами', 'Совместный', 'Pro Bono', 'Долгосрочный', 'Быстрый прототип', 'Ребрендинг', 'Текущий'],
        'ja' => ['レスポンシブ', 'ミニマリスト', 'コーポレート', 'リデザイン', 'Eコマース', 'ランディングページ', 'モバイルファースト', 'オープンソース', '受賞作品', 'コラボレーション', 'プロボノ', '長期プロジェクト', 'ラピッドプロトタイプ', 'フルリブランド', '進行中'],
        'zh' => ['响应式', '极简主义', '企业项目', '重新设计', '电子商务', '着陆页', '移动优先', '开源项目', '获奖作品', '协作项目', '公益项目', '长期项目', '快速原型', '品牌重塑', '进行中'],
    ],

    // Recipes / Food
    'recipe|rezept|dish|meal|gericht' => [
        'en' => ['Quick & Easy', 'Comfort Food', 'Seasonal', 'Healthy', 'One-Pot', 'Meal Prep', 'Under 30 Minutes', 'Family Dinner', 'Date Night', 'Budget-Friendly', 'Weeknight', 'Holiday', 'Party Food', 'Beginner', 'Crowd Pleaser'],
        'de' => ['Schnell & Einfach', 'Soulfood', 'Saisonal', 'Gesund', 'Eintopf', 'Meal Prep', 'Unter 30 Minuten', 'Familienessen', 'Date Night', 'Günstig', 'Feierabendküche', 'Festtag', 'Partyessen', 'Anfänger', 'Publikumsliebling'],
        'fr' => ['Rapide & Facile', 'Cuisine Réconfortante', 'De Saison', 'Santé', 'Tout-en-un', 'Batch Cooking', 'Moins de 30 Minutes', 'Repas en Famille', 'Dîner Romantique', 'Petit Budget', 'En Semaine', 'Fête', 'Apéro Dînatoire', 'Débutant', 'Incontournable'],
        'es' => ['Rápido y Fácil', 'Comida Casera', 'De Temporada', 'Saludable', 'Olla Única', 'Meal Prep', 'Menos de 30 Minutos', 'Cena Familiar', 'Noche Romántica', 'Económico', 'Entre Semana', 'Festivo', 'Para Fiestas', 'Principiante', 'Para Todos'],
        'it' => ['Veloce e Facile', 'Comfort Food', 'Di Stagione', 'Salutare', 'Piatto Unico', 'Meal Prep', 'Sotto i 30 Minuti', 'Cena in Famiglia', 'Serata Romantica', 'Economico', 'Infrasettimanale', 'Festivo', 'Aperitivo', 'Per Principianti', 'Piace a Tutti'],
        'nl' => ['Snel & Makkelijk', 'Comfort Food', 'Seizoensgebonden', 'Gezond', 'Eenpansgerecht', 'Meal Prep', 'Onder 30 Minuten', 'Familiediner', 'Date Night', 'Budgetvriendelijk', 'Doordeweeks', 'Feestdag', 'Feesthapjes', 'Beginner', 'Publieksfavoriet'],
        'pt' => ['Rápido e Fácil', 'Comida Caseira', 'Da Estação', 'Saudável', 'Panela Única', 'Meal Prep', 'Menos de 30 Minutos', 'Jantar em Família', 'Noite Romântica', 'Econômico', 'Dia a Dia', 'Festivo', 'Para Festas', 'Iniciante', 'Sucesso Garantido'],
        'pl' => ['Szybko i Łatwo', 'Kuchnia Domowa', 'Sezonowe', 'Zdrowe', 'Jednogarnkowe', 'Meal Prep', 'Poniżej 30 Minut', 'Obiad Rodzinny', 'Kolacja we Dwoje', 'Budżetowe', 'Na Co Dzień', 'Świąteczne', 'Imprezowe', 'Dla Początkujących', 'Pewny Hit'],
        'ru' => ['Быстро и Просто', 'Домашняя Кухня', 'Сезонное', 'Полезное', 'В Одной Кастрюле', 'Заготовки', 'Менее 30 Минут', 'Семейный Ужин', 'Романтический Ужин', 'Бюджетное', 'На Каждый День', 'Праздничное', 'Для Вечеринки', 'Для Новичков', 'Всем Понравится'],
        'ja' => ['簡単・時短', '家庭料理', '旬の食材', 'ヘルシー', 'ワンポット', '作り置き', '30分以内', '家族の夕食', 'デートディナー', '節約レシピ', '平日メニュー', 'お祝い料理', 'パーティー料理', '初心者向け', '定番人気'],
        'zh' => ['快手菜', '家常菜', '应季食材', '健康饮食', '一锅搞定', '便当预备', '30分钟以内', '家庭晚餐', '约会料理', '经济实惠', '工作日菜谱', '节日美食', '聚会美食', '新手入门', '人气菜品'],
    ],

    // Events
    'event|veranstaltung|termine|appointment' => [
        'en' => ['Free Entry', 'Online', 'Sold Out', 'Featured', 'Members Only', 'Outdoor', 'Family-Friendly', 'Annual', 'Premiere', 'Limited Seats', 'Weekend', 'Evening', 'All-Day', 'Recurring', 'Hybrid'],
        'de' => ['Eintritt frei', 'Online', 'Ausverkauft', 'Empfohlen', 'Nur für Mitglieder', 'Outdoor', 'Familienfreundlich', 'Jährlich', 'Premiere', 'Begrenzte Plätze', 'Wochenende', 'Abends', 'Ganztägig', 'Wiederkehrend', 'Hybrid'],
        'fr' => ['Entrée Libre', 'En Ligne', 'Complet', 'À la Une', 'Réservé aux Membres', 'En Plein Air', 'En Famille', 'Annuel', 'Première', 'Places Limitées', 'Week-end', 'En Soirée', 'Toute la Journée', 'Récurrent', 'Hybride'],
        'es' => ['Entrada Libre', 'En Línea', 'Agotado', 'Destacado', 'Solo Miembros', 'Al Aire Libre', 'Familiar', 'Anual', 'Estreno', 'Plazas Limitadas', 'Fin de Semana', 'Nocturno', 'Todo el Día', 'Recurrente', 'Híbrido'],
        'it' => ['Ingresso Libero', 'Online', 'Esaurito', 'In Evidenza', 'Solo Soci', 'All\'Aperto', 'Per Famiglie', 'Annuale', 'Prima', 'Posti Limitati', 'Weekend', 'Serale', 'Tutto il Giorno', 'Ricorrente', 'Ibrido'],
        'nl' => ['Gratis Toegang', 'Online', 'Uitverkocht', 'Uitgelicht', 'Alleen Leden', 'Buiten', 'Gezinsvriendelijk', 'Jaarlijks', 'Première', 'Beperkte Plaatsen', 'Weekend', 'Avond', 'Hele Dag', 'Terugkerend', 'Hybride'],
        'pt' => ['Entrada Gratuita', 'Online', 'Esgotado', 'Destaque', 'Exclusivo para Membros', 'Ao Ar Livre', 'Para Famílias', 'Anual', 'Estreia', 'Vagas Limitadas', 'Fim de Semana', 'Noturno', 'Dia Inteiro', 'Recorrente', 'Híbrido'],
        'pl' => ['Wstęp Wolny', 'Online', 'Wyprzedane', 'Polecane', 'Tylko dla Członków', 'Na Zewnątrz', 'Dla Rodzin', 'Coroczne', 'Premiera', 'Ograniczona Liczba Miejsc', 'Weekend', 'Wieczorne', 'Całodniowe', 'Cykliczne', 'Hybrydowe'],
        'ru' => ['Вход Свободный', 'Онлайн', 'Распродано', 'Рекомендуемое', 'Только для Членов', 'На Открытом Воздухе', 'Для Всей Семьи', 'Ежегодное', 'Премьера', 'Ограниченные Места', 'Выходные', 'Вечернее', 'На Весь День', 'Регулярное', 'Гибридное'],
        'ja' => ['入場無料', 'オンライン', '完売', '注目イベント', '会員限定', '屋外', 'ファミリー向け', '年次', '初演', '席数限定', '週末', '夜間', '終日', '定期開催', 'ハイブリッド'],
        'zh' => ['免费入场', '线上活动', '已售罄', '精选推荐', '会员专享', '户外', '亲子活动', '年度', '首映', '限量席位', '周末', '晚间', '全天', '定期举办', '线上线下'],
    ],

    // Products / Shop
    'product|produkt|shop|artikel|item|ware' => [
        'en' => ['New Arrival', 'Best Seller', 'Sale', 'Limited Edition', 'Handmade', 'Eco-Friendly', 'Premium', 'Exclusive', 'Clearance', 'Popular', 'Staff Pick', 'Gift Idea', 'Bundle', 'Seasonal', 'Restocked'],
        'de' => ['Neuheit', 'Bestseller', 'Sale', 'Limitiert', 'Handgemacht', 'Nachhaltig', 'Premium', 'Exklusiv', 'Ausverkauf', 'Beliebt', 'Empfehlung', 'Geschenkidee', 'Bundle', 'Saisonal', 'Wieder verfügbar'],
        'fr' => ['Nouveauté', 'Best-seller', 'Soldes', 'Édition Limitée', 'Fait Main', 'Éco-responsable', 'Premium', 'Exclusif', 'Déstockage', 'Populaire', 'Coup de Cœur', 'Idée Cadeau', 'Lot', 'De Saison', 'Réapprovisionné'],
        'es' => ['Novedad', 'Más Vendido', 'Oferta', 'Edición Limitada', 'Hecho a Mano', 'Ecológico', 'Premium', 'Exclusivo', 'Liquidación', 'Popular', 'Favorito', 'Idea de Regalo', 'Pack', 'De Temporada', 'Repuesto'],
        'it' => ['Novità', 'Più Venduto', 'Saldi', 'Edizione Limitata', 'Fatto a Mano', 'Ecologico', 'Premium', 'Esclusivo', 'Svendita', 'Popolare', 'Consigliato', 'Idea Regalo', 'Bundle', 'Stagionale', 'Disponibile di Nuovo'],
        'nl' => ['Nieuw', 'Bestseller', 'Uitverkoop', 'Beperkte Oplage', 'Handgemaakt', 'Milieuvriendelijk', 'Premium', 'Exclusief', 'Opruiming', 'Populair', 'Aanrader', 'Cadeau-idee', 'Bundel', 'Seizoensgebonden', 'Weer op Voorraad'],
        'pt' => ['Novidade', 'Mais Vendido', 'Promoção', 'Edição Limitada', 'Feito à Mão', 'Sustentável', 'Premium', 'Exclusivo', 'Queima de Estoque', 'Popular', 'Escolha da Equipe', 'Ideia de Presente', 'Combo', 'Da Estação', 'Reabastecido'],
        'pl' => ['Nowość', 'Bestseller', 'Wyprzedaż', 'Edycja Limitowana', 'Ręcznie Robiony', 'Ekologiczny', 'Premium', 'Ekskluzywny', 'Przecena', 'Popularny', 'Polecany', 'Pomysł na Prezent', 'Zestaw', 'Sezonowy', 'Ponownie Dostępny'],
        'ru' => ['Новинка', 'Бестселлер', 'Распродажа', 'Ограниченная Серия', 'Ручная Работа', 'Экологичный', 'Премиум', 'Эксклюзив', 'Ликвидация', 'Популярный', 'Выбор Персонала', 'Идея для Подарка', 'Набор', 'Сезонный', 'Снова в Наличии'],
        'ja' => ['新着', 'ベストセラー', 'セール', '限定品', 'ハンドメイド', 'エコフレンドリー', 'プレミアム', '独占販売', 'クリアランス', '人気商品', 'スタッフおすすめ', 'ギフトに最適', 'セット商品', '季節限定', '再入荷'],
        'zh' => ['新品上架', '畅销商品', '促销', '限量版', '手工制作', '环保商品', '高端精品', '独家发售', '清仓特卖', '热门商品', '店长推荐', '礼物首选', '组合套装', '当季商品', '补货上架'],
    ],

    // Blog / News / Articles
    'blog|post|article|news|beitrag|nachricht' => [
        'en' => ['Featured', 'Trending', 'Opinion', 'Deep Dive', 'Beginner Guide', 'Expert Tip', 'Industry News', 'How-To', 'Update', 'Spotlight', 'Behind the Scenes', 'Guest Post', 'Recap', 'Series', 'Announcement'],
        'de' => ['Empfohlen', 'Trending', 'Meinung', 'Hintergrund', 'Einsteiger-Guide', 'Expertentipp', 'Branchennews', 'Anleitung', 'Update', 'Spotlight', 'Hinter den Kulissen', 'Gastbeitrag', 'Zusammenfassung', 'Serie', 'Ankündigung'],
        'fr' => ['À la Une', 'Tendance', 'Opinion', 'Analyse', 'Guide Débutant', 'Conseil d\'Expert', 'Actualité Secteur', 'Tutoriel', 'Mise à Jour', 'En Lumière', 'Coulisses', 'Article Invité', 'Récapitulatif', 'Série', 'Annonce'],
        'es' => ['Destacado', 'Tendencia', 'Opinión', 'Análisis', 'Guía para Principiantes', 'Consejo Experto', 'Noticias del Sector', 'Tutorial', 'Actualización', 'En Foco', 'Tras Bambalinas', 'Post Invitado', 'Resumen', 'Serie', 'Anuncio'],
        'it' => ['In Evidenza', 'Di Tendenza', 'Opinione', 'Approfondimento', 'Guida per Principianti', 'Consiglio Esperto', 'Notizie di Settore', 'Tutorial', 'Aggiornamento', 'In Primo Piano', 'Dietro le Quinte', 'Articolo Ospite', 'Riepilogo', 'Serie', 'Comunicato'],
        'nl' => ['Uitgelicht', 'Trending', 'Opinie', 'Verdieping', 'Beginnersgids', 'Expertadvies', 'Branchenieuws', 'Handleiding', 'Update', 'In de Kijker', 'Achter de Schermen', 'Gastbijdrage', 'Samenvatting', 'Reeks', 'Aankondiging'],
        'pt' => ['Destaque', 'Em Alta', 'Opinião', 'Análise', 'Guia para Iniciantes', 'Dica de Especialista', 'Notícias do Setor', 'Tutorial', 'Atualização', 'Em Foco', 'Bastidores', 'Post Convidado', 'Resumo', 'Série', 'Comunicado'],
        'pl' => ['Polecane', 'Na Topie', 'Opinia', 'Dogłębna Analiza', 'Poradnik dla Początkujących', 'Wskazówka Eksperta', 'Wiadomości Branżowe', 'Poradnik', 'Aktualizacja', 'W Centrum Uwagi', 'Za Kulisami', 'Wpis Gościnny', 'Podsumowanie', 'Seria', 'Ogłoszenie'],
        'ru' => ['Избранное', 'В Тренде', 'Мнение', 'Глубокий Анализ', 'Гид для Начинающих', 'Совет Эксперта', 'Новости Отрасли', 'Инструкция', 'Обновление', 'В Центре Внимания', 'За Кулисами', 'Гостевой Пост', 'Обзор', 'Серия', 'Объявление'],
        'ja' => ['注目記事', 'トレンド', 'オピニオン', '徹底解説', '初心者ガイド', '専門家のコツ', '業界ニュース', 'ハウツー', 'アップデート', 'スポットライト', '舞台裏', 'ゲスト投稿', 'まとめ', '連載', 'お知らせ'],
        'zh' => ['精选文章', '热门趋势', '观点评论', '深度分析', '新手指南', '专家建议', '行业新闻', '操作教程', '最新动态', '聚焦', '幕后故事', '客座文章', '回顾总结', '系列文章', '公告通知'],
    ],

    // Real Estate / Properties
    'property|immobilie|listing|objekt|wohnung|haus' => [
        'en' => ['New Listing', 'Price Reduced', 'Open House', 'Waterfront', 'Move-In Ready', 'Fixer-Upper', 'Luxury', 'Pet-Friendly', 'Downtown', 'Suburban', 'Historic', 'Newly Renovated', 'Investment', 'Furnished', 'Foreclosure'],
        'de' => ['Neues Angebot', 'Preisreduziert', 'Besichtigung', 'Wasserlage', 'Bezugsfertig', 'Renovierungsbedürftig', 'Luxus', 'Haustierfreundlich', 'Innenstadtlage', 'Vorstadt', 'Denkmalschutz', 'Frisch renoviert', 'Kapitalanlage', 'Möbliert', 'Zwangsversteigerung'],
        'fr' => ['Nouvelle Annonce', 'Prix Réduit', 'Visite Libre', 'Bord de l\'Eau', 'Prêt à Emménager', 'À Rénover', 'Luxe', 'Animaux Acceptés', 'Centre-Ville', 'Banlieue', 'Historique', 'Récemment Rénové', 'Investissement', 'Meublé', 'Saisie'],
        'es' => ['Nuevo Anuncio', 'Precio Rebajado', 'Jornada de Puertas Abiertas', 'Frente al Mar', 'Listo para Entrar', 'Para Reformar', 'Lujo', 'Se Admiten Mascotas', 'Centro Urbano', 'Zona Residencial', 'Histórico', 'Recién Reformado', 'Inversión', 'Amueblado', 'Ejecución Hipotecaria'],
        'it' => ['Nuovo Annuncio', 'Prezzo Ridotto', 'Open House', 'Fronte Mare', 'Pronto da Abitare', 'Da Ristrutturare', 'Lusso', 'Animali Ammessi', 'Centro Città', 'Periferia', 'Storico', 'Ristrutturato', 'Investimento', 'Arredato', 'Vendita Giudiziaria'],
        'nl' => ['Nieuw Aanbod', 'Prijsverlaging', 'Open Huis', 'Aan het Water', 'Direct Beschikbaar', 'Opknapper', 'Luxe', 'Huisdiervriendelijk', 'Centrum', 'Buitenwijk', 'Monumentaal', 'Nieuw Gerenoveerd', 'Belegging', 'Gemeubileerd', 'Executieverkoop'],
        'pt' => ['Novo Anúncio', 'Preço Reduzido', 'Visita Aberta', 'Beira-Mar', 'Pronto para Morar', 'Para Reformar', 'Luxo', 'Aceita Animais', 'Centro', 'Subúrbio', 'Histórico', 'Recém Reformado', 'Investimento', 'Mobiliado', 'Execução Hipotecária'],
        'pl' => ['Nowa Oferta', 'Obniżona Cena', 'Dzień Otwarty', 'Nad Wodą', 'Gotowe do Zamieszkania', 'Do Remontu', 'Luksusowe', 'Przyjazne Zwierzętom', 'Centrum Miasta', 'Przedmieścia', 'Zabytkowe', 'Świeżo Odnowione', 'Inwestycja', 'Umeblowane', 'Licytacja Komornicza'],
        'ru' => ['Новое Объявление', 'Цена Снижена', 'Открытый Показ', 'У Воды', 'Готово к Заселению', 'Под Ремонт', 'Люкс', 'Можно с Животными', 'Центр Города', 'Пригород', 'Историческое', 'Свежий Ремонт', 'Инвестиция', 'С Мебелью', 'Конфискат'],
        'ja' => ['新着物件', '値下げ', 'オープンハウス', 'ウォーターフロント', '即入居可', 'リフォーム向き', '高級物件', 'ペット可', '都心', '郊外', '歴史的建造物', 'リノベーション済み', '投資物件', '家具付き', '競売物件'],
        'zh' => ['新上架', '降价房源', '开放日', '水景房', '拎包入住', '待翻新', '豪华', '可养宠物', '市中心', '郊区', '历史建筑', '新装修', '投资房', '带家具', '法拍房'],
    ],

    // Vehicles / Cars
    'vehicle|fahrzeug|car|auto|truck|motorrad|motorcycle' => [
        'en' => ['New', 'Used', 'Certified Pre-Owned', 'Electric', 'Hybrid', 'Diesel', 'Automatic', 'Manual', 'SUV', 'Sedan', 'Convertible', 'All-Wheel Drive', 'Low Mileage', 'One Owner', 'Luxury'],
        'de' => ['Neu', 'Gebraucht', 'Zertifiziert', 'Elektro', 'Hybrid', 'Diesel', 'Automatik', 'Schaltung', 'SUV', 'Limousine', 'Cabrio', 'Allrad', 'Wenig Kilometer', 'Erstbesitz', 'Luxus'],
        'fr' => ['Neuf', 'Occasion', 'Certifié', 'Électrique', 'Hybride', 'Diesel', 'Automatique', 'Manuelle', 'SUV', 'Berline', 'Cabriolet', 'Quatre Roues Motrices', 'Faible Kilométrage', 'Première Main', 'Luxe'],
        'es' => ['Nuevo', 'Usado', 'Certificado', 'Eléctrico', 'Híbrido', 'Diésel', 'Automático', 'Manual', 'SUV', 'Sedán', 'Descapotable', 'Tracción Total', 'Bajo Kilometraje', 'Primer Dueño', 'Lujo'],
        'it' => ['Nuovo', 'Usato', 'Certificato', 'Elettrico', 'Ibrido', 'Diesel', 'Automatico', 'Manuale', 'SUV', 'Berlina', 'Cabrio', 'Trazione Integrale', 'Basso Chilometraggio', 'Unico Proprietario', 'Lusso'],
        'nl' => ['Nieuw', 'Gebruikt', 'Gecertificeerd', 'Elektrisch', 'Hybride', 'Diesel', 'Automaat', 'Handgeschakeld', 'SUV', 'Sedan', 'Cabrio', 'Vierwielaandrijving', 'Weinig Kilometers', 'Eerste Eigenaar', 'Luxe'],
        'pt' => ['Novo', 'Usado', 'Certificado', 'Elétrico', 'Híbrido', 'Diesel', 'Automático', 'Manual', 'SUV', 'Sedã', 'Conversível', 'Tração Integral', 'Baixa Quilometragem', 'Único Dono', 'Luxo'],
        'pl' => ['Nowy', 'Używany', 'Certyfikowany', 'Elektryczny', 'Hybrydowy', 'Diesel', 'Automatyczna', 'Manualna', 'SUV', 'Sedan', 'Kabriolet', 'Napęd na Cztery Koła', 'Niski Przebieg', 'Pierwszy Właściciel', 'Luksusowy'],
        'ru' => ['Новый', 'Б/У', 'Сертифицирован', 'Электрический', 'Гибрид', 'Дизель', 'Автомат', 'Механика', 'Кроссовер', 'Седан', 'Кабриолет', 'Полный Привод', 'Малый Пробег', 'Один Владелец', 'Люкс'],
        'ja' => ['新車', '中古車', '認定中古車', '電気自動車', 'ハイブリッド', 'ディーゼル', 'オートマ', 'マニュアル', 'SUV', 'セダン', 'オープンカー', '4WD', '低走行', 'ワンオーナー', '高級車'],
        'zh' => ['全新', '二手', '官方认证', '纯电动', '混合动力', '柴油', '自动挡', '手动挡', 'SUV', '轿车', '敞篷车', '四驱', '低里程', '一手车', '豪华车'],
    ],

    // Courses / Education
    'course|kurs|class|lesson|training|schulung|workshop' => [
        'en' => ['Self-Paced', 'Live', 'Certificate Included', 'Beginner', 'Advanced', 'Hands-On', 'Intensive', 'Part-Time', 'Full-Time', 'Mentored', 'Free Preview', 'Cohort-Based', 'On-Demand', 'Interactive', 'Capstone Project'],
        'de' => ['Selbstbestimmt', 'Live', 'Mit Zertifikat', 'Anfänger', 'Fortgeschritten', 'Praxisnah', 'Intensiv', 'Teilzeit', 'Vollzeit', 'Mit Mentor', 'Kostenlose Vorschau', 'Kohortenbasiert', 'On-Demand', 'Interaktiv', 'Abschlussprojekt'],
        'fr' => ['À Votre Rythme', 'En Direct', 'Certificat Inclus', 'Débutant', 'Avancé', 'Pratique', 'Intensif', 'Temps Partiel', 'Temps Plein', 'Avec Mentor', 'Aperçu Gratuit', 'En Cohorte', 'À la Demande', 'Interactif', 'Projet Final'],
        'es' => ['A Tu Ritmo', 'En Vivo', 'Con Certificado', 'Principiante', 'Avanzado', 'Práctico', 'Intensivo', 'Medio Tiempo', 'Tiempo Completo', 'Con Mentor', 'Vista Previa Gratis', 'Por Cohorte', 'Bajo Demanda', 'Interactivo', 'Proyecto Final'],
        'it' => ['Al Tuo Ritmo', 'In Diretta', 'Con Certificato', 'Principiante', 'Avanzato', 'Pratico', 'Intensivo', 'Part-Time', 'Full-Time', 'Con Tutor', 'Anteprima Gratuita', 'A Coorte', 'On-Demand', 'Interattivo', 'Progetto Finale'],
        'nl' => ['In Eigen Tempo', 'Live', 'Met Certificaat', 'Beginner', 'Gevorderd', 'Praktijkgericht', 'Intensief', 'Deeltijd', 'Voltijd', 'Met Begeleiding', 'Gratis Preview', 'Cohortgebaseerd', 'On-Demand', 'Interactief', 'Eindproject'],
        'pt' => ['No Seu Ritmo', 'Ao Vivo', 'Com Certificado', 'Iniciante', 'Avançado', 'Prático', 'Intensivo', 'Meio Período', 'Período Integral', 'Com Mentor', 'Preview Grátis', 'Por Turma', 'Sob Demanda', 'Interativo', 'Projeto Final'],
        'pl' => ['We Własnym Tempie', 'Na Żywo', 'Z Certyfikatem', 'Początkujący', 'Zaawansowany', 'Praktyczny', 'Intensywny', 'W Niepełnym Wymiarze', 'Pełnoetatowy', 'Z Mentorem', 'Bezpłatny Podgląd', 'W Grupie', 'Na Żądanie', 'Interaktywny', 'Projekt Końcowy'],
        'ru' => ['В Своём Темпе', 'Онлайн-Трансляция', 'С Сертификатом', 'Начинающий', 'Продвинутый', 'Практический', 'Интенсив', 'Неполная Занятость', 'Полная Занятость', 'С Наставником', 'Бесплатный Пробный', 'Когортный', 'По Запросу', 'Интерактивный', 'Дипломный Проект'],
        'ja' => ['自分のペースで', 'ライブ配信', '修了証付き', '初級', '上級', '実践的', '集中講座', 'パートタイム', 'フルタイム', 'メンター付き', '無料プレビュー', 'コホート型', 'オンデマンド', 'インタラクティブ', '修了プロジェクト'],
        'zh' => ['自主学习', '直播课程', '含证书', '入门级', '高级', '动手实践', '强化课程', '兼职', '全日制', '导师指导', '免费试听', '班级制', '按需学习', '互动课程', '毕业项目'],
    ],

    // Jobs / Careers
    'job|stelle|career|position|vacancy|jobangebot' => [
        'en' => ['Remote', 'Full-Time', 'Part-Time', 'Freelance', 'Contract', 'Entry Level', 'Senior', 'Hybrid', 'Urgent', 'Featured', 'Internship', 'Management', 'Executive', 'Temporary', 'Relocation'],
        'de' => ['Remote', 'Vollzeit', 'Teilzeit', 'Freelance', 'Befristet', 'Berufseinsteiger', 'Senior', 'Hybrid', 'Dringend', 'Empfohlen', 'Praktikum', 'Führungsposition', 'Geschäftsführung', 'Befristet', 'Mit Umzug'],
        'fr' => ['Télétravail', 'Temps Plein', 'Temps Partiel', 'Freelance', 'CDD', 'Débutant', 'Senior', 'Hybride', 'Urgent', 'À la Une', 'Stage', 'Management', 'Direction', 'Intérim', 'Avec Déménagement'],
        'es' => ['Remoto', 'Tiempo Completo', 'Medio Tiempo', 'Freelance', 'Contrato', 'Primer Empleo', 'Senior', 'Híbrido', 'Urgente', 'Destacado', 'Prácticas', 'Dirección', 'Ejecutivo', 'Temporal', 'Con Reubicación'],
        'it' => ['Remoto', 'Tempo Pieno', 'Part-Time', 'Freelance', 'A Contratto', 'Primo Impiego', 'Senior', 'Ibrido', 'Urgente', 'In Evidenza', 'Stage', 'Management', 'Dirigente', 'Temporaneo', 'Con Trasferimento'],
        'nl' => ['Remote', 'Fulltime', 'Parttime', 'Freelance', 'Tijdelijk', 'Starter', 'Senior', 'Hybride', 'Urgent', 'Uitgelicht', 'Stage', 'Management', 'Directie', 'Tijdelijk Contract', 'Met Verhuizing'],
        'pt' => ['Remoto', 'Tempo Integral', 'Meio Período', 'Freelancer', 'Contrato', 'Primeiro Emprego', 'Sênior', 'Híbrido', 'Urgente', 'Destaque', 'Estágio', 'Gestão', 'Executivo', 'Temporário', 'Com Mudança'],
        'pl' => ['Zdalnie', 'Pełny Etat', 'Pół Etatu', 'Freelance', 'Umowa Zlecenie', 'Pierwszy Etat', 'Senior', 'Hybrydowy', 'Pilne', 'Polecane', 'Staż', 'Kierownictwo', 'Zarząd', 'Tymczasowa', 'Z Relokacją'],
        'ru' => ['Удалённо', 'Полная Занятость', 'Частичная Занятость', 'Фриланс', 'Контракт', 'Без Опыта', 'Senior', 'Гибридный', 'Срочно', 'Рекомендуемая', 'Стажировка', 'Руководство', 'Топ-менеджмент', 'Временная', 'С Переездом'],
        'ja' => ['リモート', '正社員', 'パートタイム', 'フリーランス', '契約社員', '未経験歓迎', 'シニア', 'ハイブリッド', '急募', '注目求人', 'インターン', 'マネジメント', '役員', '期間限定', '転勤あり'],
        'zh' => ['远程办公', '全职', '兼职', '自由职业', '合同制', '应届毕业生', '资深', '混合办公', '急聘', '精选职位', '实习', '管理岗', '高管', '临时', '可调岗'],
    ],

    // Team / Staff / People
    'team|staff|member|mitarbeiter|person|employee' => [
        'en' => ['Management', 'Engineering', 'Design', 'Sales', 'Marketing', 'Support', 'Operations', 'Leadership', 'Advisory Board', 'Founding Team', 'Intern', 'Freelancer', 'Partner', 'Alumni', 'Volunteer'],
        'de' => ['Geschäftsführung', 'Technik', 'Design', 'Vertrieb', 'Marketing', 'Support', 'Betrieb', 'Führung', 'Beirat', 'Gründerteam', 'Praktikant', 'Freelancer', 'Partner', 'Alumni', 'Ehrenamtlich'],
        'fr' => ['Direction', 'Ingénierie', 'Design', 'Ventes', 'Marketing', 'Support', 'Opérations', 'Direction Générale', 'Conseil Consultatif', 'Équipe Fondatrice', 'Stagiaire', 'Freelance', 'Partenaire', 'Anciens', 'Bénévole'],
        'es' => ['Dirección', 'Ingeniería', 'Diseño', 'Ventas', 'Marketing', 'Soporte', 'Operaciones', 'Liderazgo', 'Consejo Asesor', 'Equipo Fundador', 'Becario', 'Freelance', 'Socio', 'Antiguos', 'Voluntario'],
        'it' => ['Direzione', 'Ingegneria', 'Design', 'Vendite', 'Marketing', 'Supporto', 'Operazioni', 'Leadership', 'Comitato Consultivo', 'Team Fondatore', 'Stagista', 'Freelance', 'Partner', 'Alumni', 'Volontario'],
        'nl' => ['Management', 'Engineering', 'Ontwerp', 'Verkoop', 'Marketing', 'Support', 'Operations', 'Leiderschap', 'Adviesraad', 'Oprichters', 'Stagiair', 'Freelancer', 'Partner', 'Alumni', 'Vrijwilliger'],
        'pt' => ['Direção', 'Engenharia', 'Design', 'Vendas', 'Marketing', 'Suporte', 'Operações', 'Liderança', 'Conselho Consultivo', 'Equipe Fundadora', 'Estagiário', 'Freelancer', 'Parceiro', 'Ex-Alunos', 'Voluntário'],
        'pl' => ['Zarząd', 'Inżynieria', 'Design', 'Sprzedaż', 'Marketing', 'Wsparcie', 'Operacje', 'Kierownictwo', 'Rada Doradcza', 'Zespół Założycielski', 'Stażysta', 'Freelancer', 'Partner', 'Absolwenci', 'Wolontariusz'],
        'ru' => ['Руководство', 'Инженерия', 'Дизайн', 'Продажи', 'Маркетинг', 'Поддержка', 'Операции', 'Лидерство', 'Совет Директоров', 'Основатели', 'Стажёр', 'Фрилансер', 'Партнёр', 'Выпускники', 'Волонтёр'],
        'ja' => ['経営陣', 'エンジニアリング', 'デザイン', '営業', 'マーケティング', 'サポート', 'オペレーション', 'リーダーシップ', '顧問委員会', '創業メンバー', 'インターン', 'フリーランス', 'パートナー', 'OB・OG', 'ボランティア'],
        'zh' => ['管理层', '工程部', '设计部', '销售部', '市场部', '技术支持', '运营部', '领导团队', '顾问委员会', '创始团队', '实习生', '自由职业者', '合作伙伴', '校友', '志愿者'],
    ],

    // Testimonials / Reviews
    'testimonial|review|bewertung|feedback|referenz' => [
        'en' => ['5 Stars', 'Verified', 'Featured', 'Video', 'Long-Term Client', 'Enterprise', 'Small Business', 'Individual', 'Recent', 'Top Rated', 'Detailed', 'With Photos', 'Repeat Customer', 'Staff Pick', 'Case Study'],
        'de' => ['5 Sterne', 'Verifiziert', 'Empfohlen', 'Video', 'Langzeitkunde', 'Großkunde', 'Kleinunternehmen', 'Einzelperson', 'Aktuell', 'Top-Bewertung', 'Ausführlich', 'Mit Fotos', 'Stammkunde', 'Empfehlung', 'Fallstudie'],
        'fr' => ['5 Étoiles', 'Vérifié', 'À la Une', 'Vidéo', 'Client Fidèle', 'Grande Entreprise', 'PME', 'Particulier', 'Récent', 'Mieux Noté', 'Détaillé', 'Avec Photos', 'Client Régulier', 'Coup de Cœur', 'Étude de Cas'],
        'es' => ['5 Estrellas', 'Verificado', 'Destacado', 'Vídeo', 'Cliente Fiel', 'Empresa Grande', 'Pequeña Empresa', 'Particular', 'Reciente', 'Mejor Valorado', 'Detallado', 'Con Fotos', 'Cliente Habitual', 'Favorito', 'Caso de Éxito'],
        'it' => ['5 Stelle', 'Verificato', 'In Evidenza', 'Video', 'Cliente Storico', 'Grande Azienda', 'Piccola Impresa', 'Privato', 'Recente', 'Più Votato', 'Dettagliato', 'Con Foto', 'Cliente Abituale', 'Consigliato', 'Caso Studio'],
        'nl' => ['5 Sterren', 'Geverifieerd', 'Uitgelicht', 'Video', 'Vaste Klant', 'Groot Bedrijf', 'Klein Bedrijf', 'Particulier', 'Recent', 'Hoogst Gewaardeerd', 'Gedetailleerd', 'Met Foto\'s', 'Terugkerende Klant', 'Aanrader', 'Casestudy'],
        'pt' => ['5 Estrelas', 'Verificado', 'Destaque', 'Vídeo', 'Cliente de Longa Data', 'Corporativo', 'Pequena Empresa', 'Pessoa Física', 'Recente', 'Melhor Avaliado', 'Detalhado', 'Com Fotos', 'Cliente Recorrente', 'Escolha da Equipe', 'Caso de Sucesso'],
        'pl' => ['5 Gwiazdek', 'Zweryfikowany', 'Polecany', 'Wideo', 'Stały Klient', 'Duża Firma', 'Mała Firma', 'Osoba Prywatna', 'Najnowszy', 'Najwyżej Oceniany', 'Szczegółowy', 'Ze Zdjęciami', 'Powracający Klient', 'Rekomendacja', 'Studium Przypadku'],
        'ru' => ['5 Звёзд', 'Подтверждённый', 'Избранный', 'Видео', 'Давний Клиент', 'Корпорация', 'Малый Бизнес', 'Частное Лицо', 'Свежий', 'Лучший Рейтинг', 'Подробный', 'С Фотографиями', 'Постоянный Клиент', 'Выбор Редакции', 'Кейс'],
        'ja' => ['星5つ', '認証済み', '注目レビュー', '動画付き', '長期顧客', '法人', '中小企業', '個人', '最新', '高評価', '詳細レビュー', '写真付き', 'リピーター', 'スタッフおすすめ', '導入事例'],
        'zh' => ['五星好评', '已认证', '精选评价', '视频评价', '老客户', '企业客户', '小型企业', '个人用户', '最新评价', '最高评分', '详细评价', '带图评价', '回头客', '编辑推荐', '成功案例'],
    ],

    // Dealers / Partners
    'dealer|partner|händler|standort|location|filiale' => [
        'en' => ['Authorized', 'Premium', 'Flagship', 'Regional', 'Online Only', 'Certified', 'Exclusive', 'Franchise', 'Wholesale', 'Independent', 'Service Center', 'Outlet', 'Pop-Up', 'International', 'New'],
        'de' => ['Autorisiert', 'Premium', 'Flagship', 'Regional', 'Nur Online', 'Zertifiziert', 'Exklusiv', 'Franchise', 'Großhandel', 'Unabhängig', 'Servicecenter', 'Outlet', 'Pop-Up', 'International', 'Neu'],
        'fr' => ['Agréé', 'Premium', 'Flagship', 'Régional', 'En Ligne Uniquement', 'Certifié', 'Exclusif', 'Franchise', 'Grossiste', 'Indépendant', 'Centre de Service', 'Outlet', 'Éphémère', 'International', 'Nouveau'],
        'es' => ['Autorizado', 'Premium', 'Flagship', 'Regional', 'Solo Online', 'Certificado', 'Exclusivo', 'Franquicia', 'Mayorista', 'Independiente', 'Centro de Servicio', 'Outlet', 'Pop-Up', 'Internacional', 'Nuevo'],
        'it' => ['Autorizzato', 'Premium', 'Flagship', 'Regionale', 'Solo Online', 'Certificato', 'Esclusivo', 'Franchising', 'Ingrosso', 'Indipendente', 'Centro Assistenza', 'Outlet', 'Pop-Up', 'Internazionale', 'Nuovo'],
        'nl' => ['Geautoriseerd', 'Premium', 'Flagship', 'Regionaal', 'Alleen Online', 'Gecertificeerd', 'Exclusief', 'Franchise', 'Groothandel', 'Onafhankelijk', 'Servicecentrum', 'Outlet', 'Pop-Up', 'Internationaal', 'Nieuw'],
        'pt' => ['Autorizado', 'Premium', 'Flagship', 'Regional', 'Apenas Online', 'Certificado', 'Exclusivo', 'Franquia', 'Atacado', 'Independente', 'Centro de Serviço', 'Outlet', 'Pop-Up', 'Internacional', 'Novo'],
        'pl' => ['Autoryzowany', 'Premium', 'Flagowy', 'Regionalny', 'Tylko Online', 'Certyfikowany', 'Ekskluzywny', 'Franczyza', 'Hurtowy', 'Niezależny', 'Centrum Serwisowe', 'Outlet', 'Pop-Up', 'Międzynarodowy', 'Nowy'],
        'ru' => ['Авторизованный', 'Премиум', 'Флагманский', 'Региональный', 'Только Онлайн', 'Сертифицированный', 'Эксклюзивный', 'Франшиза', 'Оптовый', 'Независимый', 'Сервисный Центр', 'Аутлет', 'Временный', 'Международный', 'Новый'],
        'ja' => ['正規代理店', 'プレミアム', 'フラッグシップ', '地域代理店', 'オンライン限定', '認定', '独占', 'フランチャイズ', '卸売', '独立系', 'サービスセンター', 'アウトレット', 'ポップアップ', '海外', '新規'],
        'zh' => ['授权经销商', '高端', '旗舰店', '区域代理', '仅限线上', '认证', '独家', '加盟店', '批发', '独立经营', '服务中心', '奥特莱斯', '快闪店', '国际', '新店'],
    ],
    ];

    /**
     * Generate a taxonomy term name
     *
     * @param int $words
     * @return string
     */
    public function termName(int $words = 2): string
    {
        return ucwords($this->faker->words($words, true));
    }

    /**
     * Extract language prefix from a locale string (e.g. 'de_DE' → 'de')
     *
     * @param string|null $locale
     * @return string
     */
    protected function extractLangPrefix(?string $locale): string
    {
        if (!$locale) {
            $locale = $this->locale;
        }
        return strtolower(substr($locale, 0, 2));
    }

    /**
     * Resolve a term list from a map entry, respecting locale.
     * Supports both flat arrays (string[]) and locale-aware arrays (array{en: string[], de: string[]}).
     *
     * @param array $terms The map entry value
     * @param string $lang Language prefix (e.g. 'de', 'en')
     * @return array The resolved term list
     */
    protected function resolveLocalizedTerms(array $terms, string $lang): array
    {
        // Check if this is a locale-aware array (has string keys like 'en', 'de')
        if (isset($terms['en']) || isset($terms['de'])) {
            return $terms[$lang] ?? $terms['en'] ?? reset($terms);
        }
        // Flat array — language-neutral
        return $terms;
    }

    /**
     * Generate a contextual term name based on taxonomy slug/label.
     * Falls back to CPT context, then random words if nothing matches.
     *
     * @param string $taxonomySlug The taxonomy slug (e.g. 'project_types')
     * @param string $taxonomyLabel The taxonomy label (e.g. 'Project Types')
     * @param string $cptSlug The associated CPT slug (e.g. 'portfolio')
     * @param string $cptLabel The associated CPT label (e.g. 'Portfolio')
     * @param string|null $locale Optional locale override (e.g. 'de_DE')
     * @return string
     */
    public function contextualTermName(string $taxonomySlug, string $taxonomyLabel = '', string $cptSlug = '', string $cptLabel = '', ?string $locale = null): string
    {
        // If a pool was initialized for this taxonomy, use it (non-repeating)
        if (array_key_exists($taxonomySlug, $this->termPools)) {
            $pool = &$this->termPools[$taxonomySlug];

            // Pool initialized and has terms left
            if (is_array($pool) && !empty($pool)) {
                return array_shift($pool);
            }

            // Pool exhausted (was an array, now empty) — signal caller to stop
            if (is_array($pool) && empty($pool)) {
                return '';
            }

            // pool === null means no pattern matched during init — fall through to random
        }

        // No pool — use random pick (backwards compatible for non-pooled callers)
        $lang = $this->extractLangPrefix($locale);

        // 1. Try matching taxonomy slug/label against TAXONOMY_TERM_MAP
        $taxSearchStrings = array_filter([
            str_replace(['-', '_'], ' ', $taxonomySlug),
            $taxonomyLabel,
        ]);

        foreach (self::TAXONOMY_TERM_MAP as $pattern => $terms) {
            foreach ($taxSearchStrings as $search) {
                if (preg_match('/' . $pattern . '/i', $search)) {
                    $resolved = $this->resolveLocalizedTerms($terms, $lang);
                    return $resolved[array_rand($resolved)];
                }
            }
        }

        // 2. Fallback: try matching CPT slug/label against CPT_TERM_MAP
        if ($cptSlug || $cptLabel) {
            $cptSearchStrings = array_filter([
                str_replace(['-', '_'], ' ', $cptSlug),
                $cptLabel,
            ]);

            foreach (self::CPT_TERM_MAP as $pattern => $terms) {
                foreach ($cptSearchStrings as $search) {
                    if (preg_match('/' . $pattern . '/i', $search)) {
                        $resolved = $this->resolveLocalizedTerms($terms, $lang);
                        return $resolved[array_rand($resolved)];
                    }
                }
            }
        }

        // 3. No match — fall back to random words
        return $this->termName();
    }

    /**
     * Per-taxonomy term pools for non-repeating term generation.
     * Each entry is either:
     *  - array of available term strings (initialized pool)
     *  - null (pattern matched but pool exhausted or no match found)
     *
     * @var array<string, array|null>
     */
    protected array $termPools = [];

    /**
     * Hive service for API query/report
     *
     * @var HiveService|null
     */
    protected ?HiveService $hive = null;

    /**
     * AI Provider for title template generation (Stufe 3)
     *
     * @var AiProviderInterface|null
     */
    protected ?AiProviderInterface $aiProvider = null;

    /**
     * CPT context from CptContextService for domain-aware generation
     *
     * @var array|null
     */
    protected ?array $cptContext = null;

    /**
     * Set the Hive service
     */
    public function setHive(HiveService $service): self
    {
        $this->hive = $service;
        return $this;
    }

    /**
     * Set the AI Provider for title generation
     */
    public function setAiProvider(AiProviderInterface $provider): self
    {
        $this->aiProvider = $provider;
        return $this;
    }

    /**
     * Set CPT context for domain-aware generation across all pipelines
     */
    public function setCptContext(?array $context): self
    {
        $this->cptContext = $context;
        return $this;
    }

    /**
     * Get the current CPT context
     */
    public function getCptContext(): ?array
    {
        return $this->cptContext;
    }

    /**
     * Reset the shuffled term pool for a taxonomy so the next batch gets fresh terms.
     *
     * @param string $taxonomy
     * @return void
     */
    public function resetTermPool(string $taxonomy): void
    {
        unset($this->termPools[$taxonomy]);
    }

    /**
     * Initialize a term pool for a taxonomy.
     * Matches the taxonomy against TAXONOMY_TERM_MAP / CPT_TERM_MAP,
     * removes already-existing terms, and shuffles the remainder.
     *
     * @param string $taxonomySlug The taxonomy slug
     * @param array $existingTermNames Term names that already exist in the DB
     * @param string $taxonomyLabel The taxonomy display label
     * @param string $cptSlug The associated CPT slug
     * @param string $cptLabel The associated CPT label
     * @param string|null $locale Optional locale override
     * @return void
     */
    public function initTermPool(
        string $taxonomySlug,
        array $existingTermNames = [],
        string $taxonomyLabel = '',
        string $cptSlug = '',
        string $cptLabel = '',
        ?string $locale = null
    ): void {
        $lang = $this->extractLangPrefix($locale);
        $matchedTerms = null;
        $matchedPattern = null;

        // Try TAXONOMY_TERM_MAP
        $taxSearchStrings = array_filter([
            str_replace(['-', '_'], ' ', $taxonomySlug),
            $taxonomyLabel,
        ]);

        foreach (self::TAXONOMY_TERM_MAP as $pattern => $terms) {
            foreach ($taxSearchStrings as $search) {
                if (preg_match('/' . $pattern . '/i', $search)) {
                    $matchedTerms = $this->resolveLocalizedTerms($terms, $lang);
                    $matchedPattern = $pattern;
                    break 2;
                }
            }
        }

        // Try CPT_TERM_MAP
        if ($matchedTerms === null && ($cptSlug || $cptLabel)) {
            $cptSearchStrings = array_filter([
                str_replace(['-', '_'], ' ', $cptSlug),
                $cptLabel,
            ]);

            foreach (self::CPT_TERM_MAP as $pattern => $terms) {
                foreach ($cptSearchStrings as $search) {
                    if (preg_match('/' . $pattern . '/i', $search)) {
                        $matchedTerms = $this->resolveLocalizedTerms($terms, $lang);
                        $matchedPattern = $pattern;
                        break 2;
                    }
                }
            }
        }

        // If local pattern matched → report terms to API (fire-and-forget)
        if ($matchedTerms !== null && $matchedPattern !== null && $this->hive) {
            $this->hive->reportTaxonomyTerms(
                $cptSlug ?: 'post',
                $cptLabel,
                [['pattern' => $matchedPattern, 'terms' => $matchedTerms, 'confidence' => 0.9]],
                $locale
            );
        }

        // If NO local pattern matched → query API as fallback
        if ($matchedTerms === null && $this->hive) {
            $searchPattern = $taxonomySlug;
            $apiTerms = $this->hive->queryTaxonomyTerms(
                $cptSlug ?: 'post',
                $searchPattern,
                $locale
            );
            if ($apiTerms) {
                $matchedTerms = $apiTerms;
            }
        }

        // If still no match → try CPT context term_seeds from AI
        if ($matchedTerms === null && $this->cptContext && !empty($this->cptContext['term_seeds'])) {
            $seeds = $this->cptContext['term_seeds'][$taxonomySlug] ?? null;
            if ($seeds && is_array($seeds) && !empty($seeds)) {
                $matchedTerms = $seeds;
                // Report to Hive so future runs benefit without AI
                if ($this->hive) {
                    $this->hive->reportTaxonomyTerms(
                        $cptSlug ?: 'post',
                        $cptLabel,
                        [['pattern' => 'cpt_context_' . $taxonomySlug, 'terms' => $seeds, 'confidence' => 0.8]],
                        $locale
                    );
                }
            }
        }

        if ($matchedTerms === null) {
            // No pattern matched — signal to contextualTermName to use random fallback
            $this->termPools[$taxonomySlug] = null;
            return;
        }

        // Remove already-existing terms (case-insensitive)
        $existingLower = array_map('strtolower', $existingTermNames);
        $available = array_values(array_filter($matchedTerms, function ($term) use ($existingLower) {
            return !in_array(strtolower($term), $existingLower, true);
        }));

        shuffle($available);
        $this->termPools[$taxonomySlug] = $available;
    }

    /**
     * Generate a term slug
     *
     * @param int $words
     * @return string
     */
    public function termSlug(int $words = 2): string
    {
        return sanitize_title($this->faker->words($words, true));
    }

    /**
     * Generate a term description
     *
     * @return string
     */
    public function termDescription(): string
    {
        return $this->faker->sentence(rand(8, 15));
    }

    /**
     * Get a random existing attachment ID
     *
     * @param string $mimeType Optional mime type filter (e.g., 'image', 'application/pdf')
     * @return int
     */
    public function attachmentId(string $mimeType = ''): int
    {
        $args = [
            'post_type'      => 'attachment',
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ];

        if ($mimeType) {
            $args['post_mime_type'] = $mimeType;
        }

        $attachments = get_posts($args);

        if (empty($attachments)) {
            return 0;
        }

        return $attachments[array_rand($attachments)];
    }

    /**
     * Get a random existing post ID
     *
     * @param string|array $postType
     * @return int
     */
    public function postId(string|array $postType = 'post'): int
    {
        $posts = get_posts([
            'post_type'      => $postType,
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ]);

        if (empty($posts)) {
            return 0;
        }

        return $posts[array_rand($posts)];
    }

    /**
     * Get a random existing term ID
     *
     * @param string $taxonomy
     * @return int
     */
    public function termId(string $taxonomy = 'category'): int
    {
        $terms = get_terms([
            'taxonomy'   => $taxonomy,
            'hide_empty' => false,
            'fields'     => 'ids',
            'number'     => 50,
        ]);

        if (is_wp_error($terms) || empty($terms)) {
            return 0;
        }

        return $terms[array_rand($terms)];
    }

    /**
     * Get a random existing user ID
     *
     * @param string|array $role
     * @return int
     */
    public function userId(string|array $role = ''): int
    {
        $args = [
            'fields' => 'ID',
            'number' => 50,
        ];

        if ($role) {
            $args['role__in'] = (array) $role;
        }

        $users = get_users($args);

        if (empty($users)) {
            return get_current_user_id();
        }

        return $users[array_rand($users)];
    }
}
