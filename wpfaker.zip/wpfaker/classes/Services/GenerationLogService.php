<?php

declare(strict_types=1);

namespace WPFaker\Services;

class GenerationLogService
{
    /** @var array<int, array{type: string, category?: string, message?: string, current?: int, total?: int}> */
    private static array $entries = [];

    /** @var callable|null */
    private static $flushCallback = null;

    public static function log(string $category, string $message): void
    {
        $entry = [
            'type'     => 'log',
            'category' => $category,
            'message'  => $message,
        ];

        self::$entries[] = $entry;

        if (self::$flushCallback) {
            (self::$flushCallback)($entry);
        }
    }

    public static function progress(int $current, int $total): void
    {
        $entry = [
            'type'    => 'progress',
            'current' => $current,
            'total'   => $total,
        ];

        self::$entries[] = $entry;

        if (self::$flushCallback) {
            (self::$flushCallback)($entry);
        }
    }

    /** @return array<int, array> */
    public static function getEntries(): array
    {
        return self::$entries;
    }

    public static function setFlushCallback(?callable $callback): void
    {
        self::$flushCallback = $callback;
    }

    public static function reset(): void
    {
        self::$entries = [];
        self::$flushCallback = null;
    }
}
