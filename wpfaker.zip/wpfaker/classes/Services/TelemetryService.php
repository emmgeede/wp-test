<?php

namespace WPFaker\Services;

use WPFaker\Plugin;

class TelemetryService
{
    public const OPTION_INSTANCE_ID = 'wpfaker_telemetry_instance_id';
    public const OPTION_BUFFER = 'wpfaker_telemetry_buffer';
    public const OPTION_LAST_SENT = 'wpfaker_telemetry_last_sent';
    public const CRON_HOOK = 'wpfaker_telemetry_send';

    private const API_BASE_URL = 'https://api.wpfaker.com/api/v1';
    private const API_BASE_URL_DEV = 'http://localhost:8080/api/v1';
    private const API_SECRET = 'wpf_8k3mX9pL2nR7vQ4wY6tB1cF5hJ0sA3dG';

    /**
     * Get or create the anonymous instance ID
     */
    public function getInstanceId(): string
    {
        $id = get_option(self::OPTION_INSTANCE_ID);

        if (!$id) {
            $id = wp_generate_uuid4();
            update_option(self::OPTION_INSTANCE_ID, $id, false);
        }

        return $id;
    }

    /**
     * Increment an event counter in the telemetry buffer
     */
    public static function incrementCounter(string $key, int $amount = 1): void
    {
        if (!self::isEnabled()) {
            return;
        }

        $buffer = get_option(self::OPTION_BUFFER, []);
        $buffer[$key] = ($buffer[$key] ?? 0) + $amount;
        update_option(self::OPTION_BUFFER, $buffer, false);
    }

    /**
     * Build the telemetry snapshot payload
     */
    public function buildSnapshot(): array
    {
        $settings = get_option('wpfaker_settings', []);
        $aiSettings = get_option('wpfaker_ai_settings', []);
        $buffer = get_option(self::OPTION_BUFFER, []);

        $historyService = new HistoryService();

        $aiProvider = null;
        if (!empty($aiSettings['enabled']) && !empty($aiSettings['provider'])) {
            $aiProvider = $aiSettings['provider'];
        }

        return [
            'instance_id'               => $this->getInstanceId(),
            'plugin_version'            => Plugin::VERSION,
            'wp_version'                => get_bloginfo('version'),
            'php_version'               => PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION,
            'locale'                    => $settings['locale'] ?? 'auto',

            // Feature flags
            'ai_enabled'                => !empty($aiSettings['enabled']),
            'ai_provider'               => $aiProvider,
            'hive_enabled' => !empty($aiSettings['hive_enabled']),

            // Cumulative counts
            'template_count'            => (new TemplateService())->getCount(),
            'generated_posts'           => $historyService->getCount('post'),
            'generated_terms'           => $historyService->getCount('term'),
            'generated_users'           => $historyService->getCount('user'),
            'generated_comments'        => $historyService->getCount('comment'),

            // Event counters (from buffer)
            'ai_detections'             => $buffer['ai_detections'] ?? 0,
            'hive_submissions'          => $buffer['hive_submissions'] ?? 0,
            'template_generations'      => $buffer['template_generations'] ?? 0,
            'history_views'             => $buffer['history_views'] ?? 0,
            'history_deletes'           => $buffer['history_deletes'] ?? 0,

            // Time/Money
            'time_saved_seconds'        => (new TimeSavingsService())->getTotalTimeSaved(),
            'hourly_rate'               => (float) ($settings['hourly_rate'] ?? 75),
            'hourly_rate_custom'        => isset($settings['hourly_rate']) && (float) $settings['hourly_rate'] !== 75.0,
        ];
    }

    /**
     * Send telemetry snapshot to the API
     */
    public function send(): bool
    {
        if (!self::isEnabled()) {
            return false;
        }

        $snapshot = $this->buildSnapshot();
        $body = wp_json_encode($snapshot);
        $timestamp = (string) time();
        $message = $timestamp . $body;
        $signature = hash_hmac('sha256', $message, self::API_SECRET);

        $apiBase = defined('WPFAKER_API_URL') ? WPFAKER_API_URL : self::API_BASE_URL;
        $response = wp_remote_post($apiBase . '/telemetry', [
            'timeout' => 15,
            'headers' => [
                'Content-Type'        => 'application/json',
                'X-WPfaker-Timestamp' => $timestamp,
                'X-WPfaker-Signature' => $signature,
            ],
            'body' => $body,
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $statusCode = wp_remote_retrieve_response_code($response);
        if ($statusCode >= 400) {
            return false;
        }

        // Clear buffer and update last sent timestamp
        update_option(self::OPTION_BUFFER, [], false);
        update_option(self::OPTION_LAST_SENT, time(), false);

        return true;
    }

    /**
     * Check if telemetry is enabled (opt-out)
     */
    public static function isEnabled(): bool
    {
        $settings = get_option('wpfaker_settings', []);

        return $settings['telemetry_enabled'] ?? true;
    }

    /**
     * Schedule the daily cron event
     */
    public function scheduleCron(): void
    {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'daily', self::CRON_HOOK);
        }
    }

    /**
     * Unschedule the cron event
     */
    public static function unscheduleCron(): void
    {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
        wp_clear_scheduled_hook(self::CRON_HOOK);
    }

    /**
     * Clean up all telemetry options
     */
    public static function cleanup(): void
    {
        delete_option(self::OPTION_INSTANCE_ID);
        delete_option(self::OPTION_BUFFER);
        delete_option(self::OPTION_LAST_SENT);
    }
}
