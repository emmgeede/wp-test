<?php

namespace WPFaker\Services;

/**
 * Fake File Service
 *
 * Generates and manages fake documents for testing (PDF, Word, Excel, etc.)
 * Downloads sample files from online sources or generates simple files.
 */
class FakeFileService
{
    /**
     * Sample file URLs for different document types
     * Using freely available sample files from various sources
     */
    protected const SAMPLE_FILES = [
        'pdf' => [
            'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
            'https://www.africau.edu/images/default/sample.pdf',
        ],
        'doc' => [
            // Word documents are harder to find freely, we'll generate simple ones
        ],
        'txt' => [
            // We'll generate text files locally
        ],
    ];

    /**
     * Supported file types and their MIME types
     */
    protected const MIME_TYPES = [
        'pdf'  => 'application/pdf',
        'doc'  => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls'  => 'application/vnd.ms-excel',
        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'ppt'  => 'application/vnd.ms-powerpoint',
        'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'txt'  => 'text/plain',
        'csv'  => 'text/csv',
        'rtf'  => 'application/rtf',
    ];

    /**
     * Faker service for generating content
     */
    protected FakerService $faker;

    /**
     * Post type this media is being created for (for reuse tracking)
     */
    protected ?string $forPostType = null;

    /**
     * Upload directory
     */
    protected string $uploadDir;

    /**
     * Constructor
     */
    /**
     * Set the post type this media is being created for (for reuse tracking)
     */
    public function setForPostType(?string $postType): self
    {
        $this->forPostType = $postType;
        return $this;
    }

    public function __construct(?FakerService $faker = null)
    {
        $this->faker = $faker ?? new FakerService();
        $uploadDirInfo = wp_upload_dir();
        $this->uploadDir = $uploadDirInfo['basedir'] . '/wpfaker-files';

        // Ensure directory exists
        if (!file_exists($this->uploadDir)) {
            wp_mkdir_p($this->uploadDir);
        }
    }

    /**
     * Get or generate a fake file attachment ID
     *
     * @param string $type File type (pdf, doc, txt, etc.)
     * @param string|null $title Optional title for the file
     * @return int Attachment ID or 0 on failure
     */
    public function getFakeFile(string $type = 'pdf', ?string $title = null): int
    {
        $type = strtolower($type);

        // First, check if we have existing fake files in the media library
        $existingFile = $this->findExistingFakeFile($type);
        if ($existingFile) {
            return $existingFile;
        }

        // Generate or download a new file
        return $this->createFakeFile($type, $title);
    }

    /**
     * Find an existing fake file in the media library
     *
     * @param string $type
     * @return int|null
     */
    protected function findExistingFakeFile(string $type): ?int
    {
        $mimeType = self::MIME_TYPES[$type] ?? null;
        if (!$mimeType) {
            return null;
        }

        $attachments = get_posts([
            'post_type'      => 'attachment',
            'post_mime_type' => $mimeType,
            'posts_per_page' => 10,
            'fields'         => 'ids',
            'meta_query'     => [
                [
                    'key'     => '_wpfaker_fake_file',
                    'value'   => '1',
                    'compare' => '=',
                ],
            ],
        ]);

        if (!empty($attachments)) {
            return $attachments[array_rand($attachments)];
        }

        // Also check for any file of this type (user might have uploaded samples)
        $anyAttachment = get_posts([
            'post_type'      => 'attachment',
            'post_mime_type' => $mimeType,
            'posts_per_page' => 5,
            'fields'         => 'ids',
        ]);

        if (!empty($anyAttachment)) {
            return $anyAttachment[array_rand($anyAttachment)];
        }

        return null;
    }

    /**
     * Create a new fake file
     *
     * @param string $type
     * @param string|null $title
     * @return int Attachment ID
     */
    protected function createFakeFile(string $type, ?string $title = null): int
    {
        $filePath = match ($type) {
            'pdf'  => $this->downloadOrGeneratePdf(),
            'txt'  => $this->generateTextFile($title),
            'csv'  => $this->generateCsvFile($title),
            'doc', 'docx' => $this->generateWordDocument($title),
            'xls', 'xlsx' => $this->generateExcelFile($title),
            default => $this->generateTextFile($title),
        };

        if (!$filePath || !file_exists($filePath)) {
            return 0;
        }

        // Add to WordPress media library
        $attachmentId = $this->addToMediaLibrary($filePath, $type, $title);

        if ($attachmentId) {
            // Mark as WPfaker generated
            update_post_meta($attachmentId, '_wpfaker_fake_file', '1');
            update_post_meta($attachmentId, '_wpfaker_generated', true);

            if ($this->forPostType) {
                update_post_meta($attachmentId, '_wpfaker_for_post_type', $this->forPostType);
            }

            // Log in history for tracking
            (new HistoryService())->log('media', $attachmentId, 'file', [
                'post_type' => $this->forPostType,
            ]);
        }

        return $attachmentId;
    }

    /**
     * Download or generate a PDF file
     *
     * @return string|null File path
     */
    protected function downloadOrGeneratePdf(): ?string
    {
        // Try to download a sample PDF
        $urls = self::SAMPLE_FILES['pdf'];
        shuffle($urls);

        foreach ($urls as $url) {
            $response = wp_remote_get($url, [
                'timeout' => 15,
                'sslverify' => false,
            ]);

            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                $content = wp_remote_retrieve_body($response);

                if (!empty($content) && strpos($content, '%PDF') === 0) {
                    $filename = 'wpfaker-sample-' . uniqid() . '.pdf';
                    $filePath = $this->uploadDir . '/' . $filename;

                    if (file_put_contents($filePath, $content)) {
                        return $filePath;
                    }
                }
            }
        }

        // If download fails, create a simple PDF using native PHP
        return $this->generateSimplePdf();
    }

    /**
     * Generate a simple PDF without external dependencies
     *
     * @return string|null File path
     */
    protected function generateSimplePdf(): ?string
    {
        $faker = $this->faker->getInstance();

        // Create a minimal valid PDF
        $title = $faker->sentence(4);
        $content = implode("\n\n", $faker->paragraphs(5));

        // Basic PDF structure
        $pdf = "%PDF-1.4\n";
        $pdf .= "1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n";
        $pdf .= "2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n";
        $pdf .= "3 0 obj<</Type/Page/MediaBox[0 0 612 792]/Parent 2 0 R/Resources<<>>>>endobj\n";
        $pdf .= "xref\n0 4\n0000000000 65535 f\n0000000009 00000 n\n0000000052 00000 n\n0000000101 00000 n\n";
        $pdf .= "trailer<</Size 4/Root 1 0 R>>\n";
        $pdf .= "startxref\n183\n%%EOF";

        $filename = 'wpfaker-document-' . uniqid() . '.pdf';
        $filePath = $this->uploadDir . '/' . $filename;

        if (file_put_contents($filePath, $pdf)) {
            return $filePath;
        }

        return null;
    }

    /**
     * Generate a text file
     *
     * @param string|null $title
     * @return string|null File path
     */
    protected function generateTextFile(?string $title = null): ?string
    {
        $faker = $this->faker->getInstance();
        $title = $title ?? $faker->sentence(4);

        $content = $title . "\n";
        $content .= str_repeat("=", strlen($title)) . "\n\n";
        $content .= "Erstellt am: " . date('d.m.Y H:i:s') . "\n\n";
        $content .= implode("\n\n", $faker->paragraphs(rand(3, 6)));

        $filename = sanitize_file_name($faker->slug(3)) . '-' . uniqid() . '.txt';
        $filePath = $this->uploadDir . '/' . $filename;

        if (file_put_contents($filePath, $content)) {
            return $filePath;
        }

        return null;
    }

    /**
     * Generate a CSV file
     *
     * @param string|null $title
     * @return string|null File path
     */
    protected function generateCsvFile(?string $title = null): ?string
    {
        $faker = $this->faker->getInstance();

        $headers = ['ID', 'Name', 'Email', 'Phone', 'City', 'Amount'];
        $rows = [$headers];

        for ($i = 1; $i <= rand(10, 20); $i++) {
            $rows[] = [
                $i,
                $faker->name(),
                $faker->safeEmail(),
                $faker->phoneNumber(),
                $faker->city(),
                number_format($faker->randomFloat(2, 100, 10000), 2, ',', '.'),
            ];
        }

        $filename = 'wpfaker-data-' . uniqid() . '.csv';
        $filePath = $this->uploadDir . '/' . $filename;

        $handle = fopen($filePath, 'w');
        if ($handle) {
            // Add BOM for Excel UTF-8 compatibility
            fwrite($handle, "\xEF\xBB\xBF");

            foreach ($rows as $row) {
                fputcsv($handle, $row, ';');
            }
            fclose($handle);

            return $filePath;
        }

        return null;
    }

    /**
     * Generate a Word document (DOCX)
     *
     * DOCX is a ZIP file containing XML files
     *
     * @param string|null $title
     * @return string|null File path
     */
    protected function generateWordDocument(?string $title = null): ?string
    {
        if (!class_exists('ZipArchive')) {
            // Fall back to text file if ZipArchive not available
            return $this->generateTextFile($title);
        }

        $faker = $this->faker->getInstance();
        $title = $title ?? $faker->sentence(4);

        $filename = 'wpfaker-document-' . uniqid() . '.docx';
        $filePath = $this->uploadDir . '/' . $filename;

        $zip = new \ZipArchive();
        if ($zip->open($filePath, \ZipArchive::CREATE) !== true) {
            return null;
        }

        // Content Types
        $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
    <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
    <Default Extension="xml" ContentType="application/xml"/>
    <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>';
        $zip->addFromString('[Content_Types].xml', $contentTypes);

        // Relationships
        $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>';
        $zip->addFromString('_rels/.rels', $rels);

        // Word Relationships
        $wordRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"></Relationships>';
        $zip->addFromString('word/_rels/document.xml.rels', $wordRels);

        // Document content
        $paragraphs = '';
        $paragraphs .= '<w:p><w:pPr><w:pStyle w:val="Title"/></w:pPr><w:r><w:t>' . htmlspecialchars($title) . '</w:t></w:r></w:p>';

        foreach ($faker->paragraphs(rand(4, 8)) as $para) {
            $paragraphs .= '<w:p><w:r><w:t>' . htmlspecialchars($para) . '</w:t></w:r></w:p>';
        }

        $document = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
    <w:body>' . $paragraphs . '</w:body>
</w:document>';
        $zip->addFromString('word/document.xml', $document);

        $zip->close();

        return file_exists($filePath) ? $filePath : null;
    }

    /**
     * Generate an Excel file (XLSX)
     *
     * XLSX is a ZIP file containing XML files
     *
     * @param string|null $title
     * @return string|null File path
     */
    protected function generateExcelFile(?string $title = null): ?string
    {
        if (!class_exists('ZipArchive')) {
            return $this->generateCsvFile($title);
        }

        $faker = $this->faker->getInstance();

        $filename = 'wpfaker-spreadsheet-' . uniqid() . '.xlsx';
        $filePath = $this->uploadDir . '/' . $filename;

        $zip = new \ZipArchive();
        if ($zip->open($filePath, \ZipArchive::CREATE) !== true) {
            return null;
        }

        // Content Types
        $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
    <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
    <Default Extension="xml" ContentType="application/xml"/>
    <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
    <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>';
        $zip->addFromString('[Content_Types].xml', $contentTypes);

        // Relationships
        $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>';
        $zip->addFromString('_rels/.rels', $rels);

        // Workbook
        $workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
    <sheets>
        <sheet name="Sheet1" sheetId="1" r:id="rId1"/>
    </sheets>
</workbook>';
        $zip->addFromString('xl/workbook.xml', $workbook);

        // Workbook relationships
        $wbRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>';
        $zip->addFromString('xl/_rels/workbook.xml.rels', $wbRels);

        // Sheet data
        $rows = '';
        // Header row
        $headers = ['ID', 'Name', 'Email', 'Phone', 'Amount'];
        $rows .= '<row r="1">';
        foreach ($headers as $col => $header) {
            $colLetter = chr(65 + $col);
            $rows .= '<c r="' . $colLetter . '1" t="inlineStr"><is><t>' . htmlspecialchars($header) . '</t></is></c>';
        }
        $rows .= '</row>';

        // Data rows
        for ($i = 2; $i <= rand(10, 20); $i++) {
            $data = [
                $i - 1,
                $faker->name(),
                $faker->safeEmail(),
                $faker->phoneNumber(),
                $faker->randomFloat(2, 100, 10000),
            ];
            $rows .= '<row r="' . $i . '">';
            foreach ($data as $col => $value) {
                $colLetter = chr(65 + $col);
                if (is_numeric($value)) {
                    $rows .= '<c r="' . $colLetter . $i . '"><v>' . $value . '</v></c>';
                } else {
                    $rows .= '<c r="' . $colLetter . $i . '" t="inlineStr"><is><t>' . htmlspecialchars($value) . '</t></is></c>';
                }
            }
            $rows .= '</row>';
        }

        $sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <sheetData>' . $rows . '</sheetData>
</worksheet>';
        $zip->addFromString('xl/worksheets/sheet1.xml', $sheet);

        $zip->close();

        return file_exists($filePath) ? $filePath : null;
    }

    /**
     * Add a file to WordPress media library
     *
     * @param string $filePath
     * @param string $type
     * @param string|null $title
     * @return int Attachment ID
     */
    protected function addToMediaLibrary(string $filePath, string $type, ?string $title = null): int
    {
        if (!file_exists($filePath)) {
            return 0;
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        // Move file to uploads directory
        $uploadDir = wp_upload_dir();
        $newFilename = basename($filePath);
        $newFilePath = $uploadDir['path'] . '/' . $newFilename;

        if (file_exists($filePath)) {
            copy($filePath, $newFilePath);
        }

        if (!file_exists($newFilePath)) {
            return 0;
        }

        // Create attachment
        $mimeType = self::MIME_TYPES[$type] ?? 'application/octet-stream';
        $title = $title ?? pathinfo($newFilename, PATHINFO_FILENAME);

        $attachment = [
            'guid'           => $uploadDir['url'] . '/' . $newFilename,
            'post_mime_type' => $mimeType,
            'post_title'     => sanitize_text_field($title),
            'post_content'   => '',
            'post_status'    => 'inherit',
        ];

        $attachmentId = wp_insert_attachment($attachment, $newFilePath);

        if (!is_wp_error($attachmentId)) {
            wp_update_attachment_metadata($attachmentId, wp_generate_attachment_metadata($attachmentId, $newFilePath));
        }

        // Clean up temp file
        if (file_exists($filePath) && $filePath !== $newFilePath) {
            @unlink($filePath);
        }

        return is_wp_error($attachmentId) ? 0 : $attachmentId;
    }

    /**
     * Get supported file types
     *
     * @return array
     */
    public function getSupportedTypes(): array
    {
        return array_keys(self::MIME_TYPES);
    }

    /**
     * Create sample files for the media library
     *
     * Creates one of each supported file type (PDF, DOCX, XLSX, CSV, TXT)
     * if they don't already exist.
     *
     * @return array List of created attachment IDs
     */
    public function createSampleFiles(): array
    {
        $createdIds = [];

        // Define sample files to create
        $sampleFiles = [
            ['type' => 'pdf', 'title' => 'WPfaker Sample PDF'],
            ['type' => 'docx', 'title' => 'WPfaker Sample Word'],
            ['type' => 'xlsx', 'title' => 'WPfaker Sample Excel'],
            ['type' => 'csv', 'title' => 'WPfaker Sample CSV'],
            ['type' => 'txt', 'title' => 'WPfaker Sample Text'],
        ];

        foreach ($sampleFiles as $file) {
            // Check if a sample file of this type already exists
            $existing = $this->findExistingFakeFile($file['type']);
            if (!$existing) {
                $attachmentId = $this->createFakeFile($file['type'], $file['title']);
                if ($attachmentId) {
                    $createdIds[] = $attachmentId;
                }
            }
        }

        return $createdIds;
    }

    /**
     * Clean up old generated files
     *
     * @param int $olderThanDays Delete files older than X days
     * @return int Number of files deleted
     */
    public function cleanup(int $olderThanDays = 30): int
    {
        $deleted = 0;
        $threshold = time() - ($olderThanDays * DAY_IN_SECONDS);

        if (is_dir($this->uploadDir)) {
            $files = glob($this->uploadDir . '/*');
            foreach ($files as $file) {
                if (filemtime($file) < $threshold) {
                    @unlink($file);
                    $deleted++;
                }
            }
        }

        return $deleted;
    }
}
