<?php

namespace WPFaker\Services;

use WPFaker\Contracts\AiProviderInterface;

/**
 * AI Provider Factory
 *
 * Creates and caches the active AI provider instance based on settings.
 */
class AiProviderFactory
{
    /**
     * Cached provider instance
     */
    private static ?AiProviderInterface $instance = null;

    /**
     * Registered custom providers
     *
     * @var array<string, array{class: string, label: string}>
     */
    private static array $providers = [];

    /**
     * Get the active provider based on settings
     *
     * Returns a cached singleton instance. Returns null if AI is disabled
     * or no API key is configured for the selected provider.
     */
    public static function getProvider(): ?AiProviderInterface
    {
        if (self::$instance !== null) {
            return self::$instance->isAvailable() ? self::$instance : null;
        }

        $settings = get_option(AbstractAiProvider::OPTION_NAME, []);
        $providerKey = $settings['provider'] ?? 'gemini';

        self::$instance = self::createProvider($providerKey);

        if (self::$instance && self::$instance->isAvailable()) {
            return self::$instance;
        }

        return null;
    }

    /**
     * Create a provider instance by key
     *
     * Used by getProvider() and for testing connections with a specific provider.
     */
    public static function createProvider(string $key): ?AiProviderInterface
    {
        // Check built-in providers first
        $provider = match ($key) {
            'gemini' => new GeminiProvider(),
            'anthropic' => new AnthropicProvider(),
            'openai' => new OpenAiProvider(),
            default => null,
        };

        // Fall back to registered providers
        if ($provider === null && isset(self::$providers[$key])) {
            $class = self::$providers[$key]['class'];
            $provider = new $class();
        }

        return $provider;
    }

    /**
     * Get available provider options for UI dropdown
     *
     * @return array Array of ['key' => string, 'label' => string]
     */
    public static function getProviderOptions(): array
    {
        $options = [
            ['key' => 'gemini', 'label' => 'Google Gemini'],
            ['key' => 'anthropic', 'label' => 'Anthropic Claude'],
            ['key' => 'openai', 'label' => 'OpenAI GPT'],
        ];

        // Append registered providers
        foreach (self::$providers as $key => $info) {
            $options[] = ['key' => $key, 'label' => $info['label']];
        }

        return $options;
    }

    /**
     * Register a custom AI provider
     *
     * @param string $key Unique provider key
     * @param string $class Fully qualified class name implementing AiProviderInterface
     * @param string $label Human-readable label for UI
     * @throws \InvalidArgumentException If the class doesn't implement AiProviderInterface
     */
    public static function register(string $key, string $class, string $label): void
    {
        if (!is_subclass_of($class, AiProviderInterface::class)) {
            throw new \InvalidArgumentException(
                sprintf('Provider class "%s" must implement AiProviderInterface', $class)
            );
        }

        self::$providers[$key] = [
            'class' => $class,
            'label' => $label,
        ];
    }

    /**
     * Clear the cached instance (e.g. after settings change)
     */
    public static function clearInstance(): void
    {
        self::$instance = null;
    }

    /**
     * Clear registered custom providers (for testing)
     */
    public static function clearProviders(): void
    {
        self::$providers = [];
    }
}
