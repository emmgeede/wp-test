<?php

declare(strict_types=1);

namespace WPFaker\Services;

/**
 * Service for calculating and tracking time savings
 *
 * Time estimates based on research:
 * - Manual blog post creation with image & custom fields: ~8 minutes
 * - Manual blog post without custom fields: ~4 minutes
 * - Manual taxonomy term creation: ~1.5 minutes
 * - Manual user creation: ~2.5 minutes
 *
 * These are conservative estimates for TEST DATA creation (filling fields,
 * uploading images, assigning taxonomies). Based on data entry benchmarks:
 * simple records with 10-20 fields take 2-5 minutes each.
 *
 * Sources:
 * - DocuClipper Data Entry Statistics: https://www.docuclipper.com/blog/data-entry-statistics/
 * - Zapier: 76% of workers spend 1-3 hrs/day on manual data entry
 * - Industry average for form-based data entry: 3 minutes per page
 */
class TimeSavingsService
{
    private const OPTION_KEY = 'wpfaker_total_time_saved';
    private const STATS_OPTION_KEY = 'wpfaker_time_saved_stats';

    /**
     * Time estimates in seconds for manual creation
     */
    private const TIME_ESTIMATES = [
        // Posts
        'post_with_fields_and_image' => 480,  // 8 minutes
        'post_with_fields' => 360,            // 6 minutes
        'post_with_image' => 300,             // 5 minutes
        'post_basic' => 180,                  // 3 minutes

        // Taxonomy terms
        'term' => 90,                         // 1.5 minutes
        'term_with_meta' => 120,              // 2 minutes

        // Users
        'user' => 150,                        // 2.5 minutes
        'user_with_meta' => 180,              // 3 minutes

        // Comments
        'comment' => 30,                      // 30 seconds (write, moderate)

        // Media
        'media_upload' => 120,                // 2 minutes (find, download, upload)

        // Custom fields per field
        'custom_field_simple' => 15,          // 15 seconds (text, number)
        'custom_field_complex' => 45,         // 45 seconds (repeater, gallery)
    ];

    /**
     * Calculate time saved for post generation
     */
    public function calculatePostTimeSaved(array $generationResult): int
    {
        $totalSeconds = 0;
        $count = $generationResult['count'] ?? 0;
        $variationStats = $generationResult['variation_stats'] ?? [];

        // Posts with featured images
        $withImage = $variationStats['with_featured_image'] ?? 0;
        $withoutImage = $count - $withImage;

        // Check if custom fields were populated
        $hasCustomFields = !empty($generationResult['custom_fields_populated'])
            || ($generationResult['options']['populate_custom_fields'] ?? false);

        if ($hasCustomFields) {
            $totalSeconds += $withImage * self::TIME_ESTIMATES['post_with_fields_and_image'];
            $totalSeconds += $withoutImage * self::TIME_ESTIMATES['post_with_fields'];
        } else {
            $totalSeconds += $withImage * self::TIME_ESTIMATES['post_with_image'];
            $totalSeconds += $withoutImage * self::TIME_ESTIMATES['post_basic'];
        }

        // Add time for auto-created taxonomies
        if (!empty($generationResult['created_terms'])) {
            $termCount = count($generationResult['created_terms']);
            $totalSeconds += $termCount * self::TIME_ESTIMATES['term'];
        }

        // Add time for auto-created authors
        if (!empty($generationResult['created_authors'])) {
            $authorCount = count($generationResult['created_authors']);
            $totalSeconds += $authorCount * self::TIME_ESTIMATES['user'];
        }

        return $totalSeconds;
    }

    /**
     * Calculate time saved for term generation
     */
    public function calculateTermTimeSaved(int $count, bool $hasMeta = false): int
    {
        $perTerm = $hasMeta
            ? self::TIME_ESTIMATES['term_with_meta']
            : self::TIME_ESTIMATES['term'];

        return $count * $perTerm;
    }

    /**
     * Calculate time saved for comment generation
     */
    public function calculateCommentTimeSaved(int $count): int
    {
        return $count * self::TIME_ESTIMATES['comment'];
    }

    /**
     * Calculate time saved for user generation
     */
    public function calculateUserTimeSaved(int $count, bool $hasMeta = false): int
    {
        $perUser = $hasMeta
            ? self::TIME_ESTIMATES['user_with_meta']
            : self::TIME_ESTIMATES['user'];

        return $count * $perUser;
    }

    /**
     * Record time saved to cumulative total
     */
    public function recordTimeSaved(int $seconds, string $type = 'posts'): void
    {
        // Update total
        $total = $this->getTotalTimeSaved();
        $total += $seconds;
        update_option(self::OPTION_KEY, $total);

        // Update stats by type
        $stats = $this->getTimeSavedStats();
        if (!isset($stats[$type])) {
            $stats[$type] = 0;
        }
        $stats[$type] += $seconds;
        $stats['last_updated'] = current_time('mysql');
        update_option(self::STATS_OPTION_KEY, $stats);
    }

    /**
     * Get total time saved in seconds
     */
    public function getTotalTimeSaved(): int
    {
        return (int) get_option(self::OPTION_KEY, 0);
    }

    /**
     * Get time saved stats by type
     */
    public function getTimeSavedStats(): array
    {
        return get_option(self::STATS_OPTION_KEY, [
            'posts'        => 0,
            'terms'        => 0,
            'users'        => 0,
            'comments'     => 0,
            'last_updated' => null,
        ]);
    }

    /**
     * Format seconds into human-readable string
     */
    public function formatTime(int $seconds): array
    {
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $secs = $seconds % 60;

        $parts = [];
        $formatted = '';

        if ($hours > 0) {
            $parts[] = sprintf('%d %s', $hours, $hours === 1 ? __('hour', 'wpfaker') : __('hours', 'wpfaker'));
        }
        if ($minutes > 0) {
            $parts[] = sprintf('%d %s', $minutes, $minutes === 1 ? __('minute', 'wpfaker') : __('minutes', 'wpfaker'));
        }
        if ($secs > 0 && $hours === 0) {
            $parts[] = sprintf('%d %s', $secs, $secs === 1 ? __('second', 'wpfaker') : __('seconds', 'wpfaker'));
        }

        if (empty($parts)) {
            $formatted = '0 ' . __('seconds', 'wpfaker');
        } else {
            $formatted = implode(' ', $parts);
        }

        return [
            'hours' => (int) $hours,
            'minutes' => (int) $minutes,
            'seconds' => (int) $secs,
            'total_seconds' => $seconds,
            'formatted' => $formatted,
            'formatted_short' => $this->formatTimeShort($seconds),
        ];
    }

    /**
     * Format seconds into short format (e.g., "2h 30m")
     */
    private function formatTimeShort(int $seconds): string
    {
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);

        if ($hours > 0 && $minutes > 0) {
            return sprintf('%dh %dm', $hours, $minutes);
        } elseif ($hours > 0) {
            return sprintf('%dh', $hours);
        } elseif ($minutes > 0) {
            return sprintf('%dm', $minutes);
        } else {
            return sprintf('%ds', $seconds);
        }
    }

    /**
     * Get comprehensive time savings report
     */
    public function getTimeSavingsReport(): array
    {
        $totalSeconds = $this->getTotalTimeSaved();
        $stats = $this->getTimeSavedStats();

        // Calculate equivalent work days (8 hours)
        $workDays = $totalSeconds / (8 * 3600);

        // Calculate money saved (configurable hourly rate)
        $settings = get_option('wpfaker_settings', []);
        $hourlyRate = (float) ($settings['hourly_rate'] ?? 75);
        $moneySaved = ($totalSeconds / 3600) * $hourlyRate;

        return [
            'total' => $this->formatTime($totalSeconds),
            'by_type' => [
                'posts'    => $this->formatTime($stats['posts'] ?? 0),
                'terms'    => $this->formatTime($stats['terms'] ?? 0),
                'users'    => $this->formatTime($stats['users'] ?? 0),
                'comments' => $this->formatTime($stats['comments'] ?? 0),
            ],
            'work_days_equivalent' => round($workDays, 1),
            'money_saved' => [
                'amount' => round($moneySaved, 2),
                'currency' => 'USD',
                'hourly_rate' => $hourlyRate,
            ],
            'last_updated' => $stats['last_updated'] ?? null,
            'estimates_based_on' => [
                'post_with_image_and_fields' => '8 min',
                'post_basic' => '3 min',
                'term' => '1.5 min',
                'user' => '2.5 min',
                'comment' => '0.5 min',
            ],
        ];
    }

    /**
     * Reset time savings (for testing)
     */
    public function resetTimeSavings(): void
    {
        delete_option(self::OPTION_KEY);
        delete_option(self::STATS_OPTION_KEY);
    }
}
