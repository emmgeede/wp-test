<?php

namespace WPFaker\Services;

/**
 * OpenAI GPT Provider
 *
 * Implements the AI provider interface for OpenAI's Chat Completions API.
 */
class OpenAiProvider extends AbstractAiProvider
{
    protected const API_ENDPOINT = 'https://api.openai.com/v1/chat/completions';

    public function getProviderKey(): string
    {
        return 'openai';
    }

    public function getProviderName(): string
    {
        return 'OpenAI GPT';
    }

    protected function callApi(string $prompt, float $temperature, int $maxTokens): ?string
    {
        $body = [
            'model' => 'gpt-4o-mini',
            'messages' => [
                [
                    'role' => 'user',
                    'content' => $prompt,
                ],
            ],
            'temperature' => $temperature,
            'max_tokens' => $maxTokens,
        ];

        $data = $this->httpPost(self::API_ENDPOINT, [
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->apiKey,
            ],
            'body' => wp_json_encode($body),
            'timeout' => 30,
        ], 'OpenAI');

        if (!$data || empty($data['choices'][0]['message']['content'])) {
            return null;
        }

        return trim($data['choices'][0]['message']['content']);
    }

    protected function callApiWithJsonMode(string $prompt, float $temperature, int $maxTokens): ?string
    {
        $body = [
            'model' => 'gpt-4o-mini',
            'messages' => [
                [
                    'role' => 'user',
                    'content' => $prompt,
                ],
            ],
            'temperature' => $temperature,
            'max_tokens' => $maxTokens,
            'response_format' => ['type' => 'json_object'],
        ];

        $data = $this->httpPost(self::API_ENDPOINT, [
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->apiKey,
            ],
            'body' => wp_json_encode($body),
            'timeout' => 30,
        ], 'OpenAI');

        if (!$data || empty($data['choices'][0]['message']['content'])) {
            return null;
        }

        return trim($data['choices'][0]['message']['content']);
    }
}
