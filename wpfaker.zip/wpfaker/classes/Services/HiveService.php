<?php

declare(strict_types=1);

namespace WPFaker\Services;

/**
 * Hive Service
 *
 * Queries and reports field detection results to the central WPFaker API.
 * This enables anonymous sharing of field detection knowledge across installations.
 */
class HiveService
{
    private const API_ENDPOINT = 'https://api.wpfaker.com/api/v1/graphql';

    /**
     * Check if Hive is enabled
     */
    public function isEnabled(): bool
    {
        $settings = get_option(AbstractAiProvider::OPTION_NAME, []);

        // One-time migration from old option key
        if (!isset($settings['hive_enabled']) && isset($settings['field_intelligence_enabled'])) {
            $settings['hive_enabled'] = $settings['field_intelligence_enabled'];
            unset($settings['field_intelligence_enabled']);
            update_option(AbstractAiProvider::OPTION_NAME, $settings);
        }

        return !empty($settings['enabled']) && !empty($settings['hive_enabled']);
    }

    /**
     * Query the API for known field configurations
     *
     * Returns configs in the same format as Gemini batch detection:
     * ['field_name' => ['method' => string, 'params' => array, 'confidence' => float]]
     *
     * @param string $postType CPT slug
     * @param array $fields Array of ['name' => string, 'label' => string, 'type' => string]
     * @param string|null $locale Locale string
     * @return array|null Associative array of field configs, or null on failure
     */
    public function queryFieldConfigs(string $postType, array $fields, ?string $locale): ?array
    {
        if (!$this->isEnabled() || empty($fields)) {
            return null;
        }

        $fieldInputs = [];
        foreach ($fields as $field) {
            $fieldInputs[] = [
                'name' => $field['name'],
                'label' => $field['label'] ?? '',
                'pluginType' => $field['type'] ?? '',
            ];
        }

        $query = 'query FieldConfigs($postType: String!, $fields: [FieldInput!]!, $locale: String) {
            fieldConfigs(postType: $postType, fields: $fields, locale: $locale) {
                fieldName
                fakerMethod
                fakerParams
                confidence
                usageCount
            }
        }';

        $variables = [
            'postType' => $postType,
            'fields' => $fieldInputs,
            'locale' => $locale ?? '',
        ];

        GenerationLogService::log('detect', sprintf('Querying Hive for %d fields...', count($fields)));

        $response = $this->graphqlRequest($query, $variables, false);

        if (!$response || empty($response['data']['fieldConfigs'])) {
            return null;
        }

        // Convert to the same format as Gemini batch detection
        $configs = [];
        foreach ($response['data']['fieldConfigs'] as $config) {
            $fieldName = $config['fieldName'] ?? '';
            if (empty($fieldName)) {
                continue;
            }

            $configs[$fieldName] = [
                'method' => $config['fakerMethod'] ?? '',
                'params' => $config['fakerParams'] ?? [],
                'confidence' => (float) ($config['confidence'] ?? 0.5),
            ];
        }

        if (!empty($configs)) {
            GenerationLogService::log('detect', sprintf('Hive matched %d/%d fields', count($configs), count($fields)));
        }

        return !empty($configs) ? $configs : null;
    }

    /**
     * Report field configurations to the API (fire-and-forget)
     *
     * @param string $postType CPT slug
     * @param string|null $postTypeLabel CPT label for context
     * @param array $configs Associative array: ['field_name' => ['method' => string, 'params' => array, 'confidence' => float]]
     * @param string|null $locale Locale string
     */
    public function reportFieldConfigs(string $postType, ?string $postTypeLabel, array $configs, ?string $locale): void
    {
        if (!$this->isEnabled() || empty($configs)) {
            return;
        }

        $fields = [];
        foreach ($configs as $fieldName => $config) {
            $confidence = (float) ($config['confidence'] ?? 0.5);
            if ($confidence < 0.7) {
                continue;
            }

            $fields[] = [
                'name' => $fieldName,
                'label' => '',
                'pluginType' => '',
                'fakerMethod' => $config['method'] ?? '',
                'fakerParams' => $config['params'] ?? [],
                'confidence' => $confidence,
            ];
        }

        if (empty($fields)) {
            return;
        }

        $mutation = 'mutation ReportFieldConfigs($input: ReportFieldConfigsInput!) {
            reportFieldConfigs(input: $input) {
                accepted
                rejected
                message
            }
        }';

        $variables = [
            'input' => [
                'postType' => $postType,
                'postTypeLabel' => $postTypeLabel ?? '',
                'locale' => $locale ?? '',
                'fields' => $fields,
            ],
        ];

        // Fire and forget — don't block on response
        $this->graphqlRequest($mutation, $variables, true);
        TelemetryService::incrementCounter('hive_submissions');
    }

    /**
     * Query the API for known taxonomy terms
     *
     * @param string $postType CPT slug
     * @param string $taxonomyPattern Regex pattern for the taxonomy
     * @param string|null $locale Locale string
     * @return array|null Array of term strings, or null on failure
     */
    public function queryTaxonomyTerms(string $postType, string $taxonomyPattern, ?string $locale): ?array
    {
        if (!$this->isEnabled()) {
            return null;
        }

        $query = 'query TaxonomyTerms($postType: String!, $taxonomyPattern: String!, $locale: String) {
            taxonomyTerms(postType: $postType, taxonomyPattern: $taxonomyPattern, locale: $locale) {
                termValue
                confidence
            }
        }';

        $variables = [
            'postType' => $postType,
            'taxonomyPattern' => $taxonomyPattern,
            'locale' => $locale ?? '',
        ];

        $response = $this->graphqlRequest($query, $variables, false);

        if (!$response || empty($response['data']['taxonomyTerms'])) {
            return null;
        }

        $terms = [];
        foreach ($response['data']['taxonomyTerms'] as $item) {
            if (!empty($item['termValue'])) {
                $terms[] = $item['termValue'];
            }
        }

        return !empty($terms) ? $terms : null;
    }

    /**
     * Report taxonomy terms to the API (fire-and-forget)
     *
     * @param string $postType CPT slug
     * @param string|null $postTypeLabel CPT label
     * @param array $taxonomyData Array of ['pattern' => string, 'terms' => string[], 'confidence' => float]
     * @param string|null $locale Locale string
     */
    public function reportTaxonomyTerms(string $postType, ?string $postTypeLabel, array $taxonomyData, ?string $locale): void
    {
        if (!$this->isEnabled() || empty($taxonomyData)) {
            return;
        }

        $taxonomies = [];
        foreach ($taxonomyData as $entry) {
            if (empty($entry['pattern']) || empty($entry['terms'])) {
                continue;
            }
            $taxonomies[] = [
                'taxonomyPattern' => $entry['pattern'],
                'terms' => $entry['terms'],
                'confidence' => (float) ($entry['confidence'] ?? 0.8),
            ];
        }

        if (empty($taxonomies)) {
            return;
        }

        $mutation = 'mutation ReportTaxonomyTerms($input: ReportTaxonomyTermsInput!) {
            reportTaxonomyTerms(input: $input) {
                accepted
                rejected
                message
            }
        }';

        $variables = [
            'input' => [
                'postType' => $postType,
                'postTypeLabel' => $postTypeLabel ?? '',
                'locale' => $locale ?? '',
                'taxonomies' => $taxonomies,
            ],
        ];

        $this->graphqlRequest($mutation, $variables, true);
        TelemetryService::incrementCounter('hive_submissions');
    }

    /**
     * Query the API for known title templates
     *
     * @param string $postType CPT slug
     * @param string|null $locale Locale string
     * @return array|null Array of ['template' => string, 'placeholderData' => array], or null on failure
     */
    public function queryTitleTemplates(string $postType, ?string $locale): ?array
    {
        if (!$this->isEnabled()) {
            return null;
        }

        $query = 'query TitleTemplates($postType: String!, $locale: String) {
            titleTemplates(postType: $postType, locale: $locale) {
                template
                placeholderData
                confidence
            }
        }';

        $variables = [
            'postType' => $postType,
            'locale' => $locale ?? '',
        ];

        $response = $this->graphqlRequest($query, $variables, false);

        if (!$response || empty($response['data']['titleTemplates'])) {
            return null;
        }

        $templates = [];
        foreach ($response['data']['titleTemplates'] as $item) {
            if (!empty($item['template'])) {
                $templates[] = [
                    'template' => $item['template'],
                    'placeholderData' => $item['placeholderData'] ?? [],
                ];
            }
        }

        return !empty($templates) ? $templates : null;
    }

    /**
     * Report title templates to the API (fire-and-forget)
     *
     * @param string $postType CPT slug
     * @param string|null $postTypeLabel CPT label
     * @param array $templates Array of ['template' => string, 'placeholderData' => array, 'confidence' => float]
     * @param string|null $locale Locale string
     */
    public function reportTitleTemplates(string $postType, ?string $postTypeLabel, array $templates, ?string $locale): void
    {
        if (!$this->isEnabled() || empty($templates)) {
            return;
        }

        $entries = [];
        foreach ($templates as $entry) {
            if (empty($entry['template'])) {
                continue;
            }
            $entries[] = [
                'template' => $entry['template'],
                'placeholderData' => $entry['placeholderData'] ?? new \stdClass(),
                'confidence' => (float) ($entry['confidence'] ?? 0.8),
            ];
        }

        if (empty($entries)) {
            return;
        }

        $mutation = 'mutation ReportTitleTemplates($input: ReportTitleTemplatesInput!) {
            reportTitleTemplates(input: $input) {
                accepted
                rejected
                message
            }
        }';

        $variables = [
            'input' => [
                'postType' => $postType,
                'postTypeLabel' => $postTypeLabel ?? '',
                'locale' => $locale ?? '',
                'templates' => $entries,
            ],
        ];

        $this->graphqlRequest($mutation, $variables, true);
        TelemetryService::incrementCounter('hive_submissions');
    }

    /**
     * Query the Hive for a number range based on prefix/suffix/label/context.
     *
     * @param string $prefix Field prefix (e.g. "$", "€")
     * @param string $suffix Field suffix (e.g. "Mio.", "kg", "%")
     * @param string $fieldName Field name/label for additional context
     * @param string $postType CPT slug for context
     * @return array|null ['min' => int, 'max' => int, 'decimals' => int] or null
     */
    public function queryNumberRange(string $prefix, string $suffix, string $fieldName, string $postType): ?array
    {
        if (!$this->isEnabled()) {
            return null;
        }

        $query = 'query NumberRange($prefix: String!, $suffix: String!, $fieldName: String!, $postType: String!) {
            numberRange(prefix: $prefix, suffix: $suffix, fieldName: $fieldName, postType: $postType) {
                min
                max
                decimals
            }
        }';

        $result = $this->graphqlRequest($query, [
            'prefix' => $prefix,
            'suffix' => $suffix,
            'fieldName' => $fieldName,
            'postType' => $postType,
        ], true);

        if (!$result || !isset($result['data']['numberRange'])) {
            return null;
        }

        $range = $result['data']['numberRange'];

        return [
            'min' => (int) $range['min'],
            'max' => (int) $range['max'],
            'decimals' => (int) ($range['decimals'] ?? 0),
        ];
    }

    /**
     * Report a learned number range back to the Hive.
     *
     * @param string $prefix Field prefix
     * @param string $suffix Field suffix
     * @param string $fieldName Field name
     * @param string $postType CPT slug
     * @param int $min Minimum value
     * @param int $max Maximum value
     * @param int $decimals Decimal places
     * @return bool Success
     */
    public function reportNumberRange(string $prefix, string $suffix, string $fieldName, string $postType, int $min, int $max, int $decimals): bool
    {
        if (!$this->isEnabled()) {
            return false;
        }

        $mutation = 'mutation ReportNumberRange($input: NumberRangeInput!) {
            reportNumberRange(input: $input) {
                success
            }
        }';

        $result = $this->graphqlRequest($mutation, [
            'input' => [
                'prefix' => $prefix,
                'suffix' => $suffix,
                'fieldName' => $fieldName,
                'postType' => $postType,
                'min' => $min,
                'max' => $max,
                'decimals' => $decimals,
            ],
        ], true);

        return !empty($result['data']['reportNumberRange']['success']);
    }

    /**
     * Send a GraphQL request to the API
     *
     * @param string $query GraphQL query or mutation
     * @param array $variables Variables for the query
     * @param bool $withHmac Whether to include HMAC authentication (for mutations)
     * @return array|null Decoded response or null on failure
     */
    private function graphqlRequest(string $query, array $variables, bool $withHmac): ?array
    {
        $body = wp_json_encode([
            'query' => $query,
            'variables' => $variables,
        ]);

        $headers = [
            'Content-Type' => 'application/json',
        ];

        if ($withHmac) {
            $apiSecret = $this->getApiSecret();
            if (!empty($apiSecret)) {
                $timestamp = (string) time();
                $message = $timestamp . $body;
                $signature = hash_hmac('sha256', $message, $apiSecret);

                $headers['X-WPfaker-Timestamp'] = $timestamp;
                $headers['X-WPfaker-Signature'] = $signature;
            }
        }

        $timeout = $withHmac ? 5 : 10;

        $response = wp_remote_post(self::API_ENDPOINT, [
            'headers' => $headers,
            'body' => $body,
            'timeout' => $timeout,
            'blocking' => !$withHmac || true, // Always blocking for now
        ]);

        if (is_wp_error($response)) {
            if (!$withHmac) {
                error_log('WPFaker Hive query error: ' . $response->get_error_message());
            }
            return null;
        }

        $statusCode = wp_remote_retrieve_response_code($response);
        if ($statusCode !== 200) {
            if (!$withHmac) {
                error_log('WPFaker Hive API returned status ' . $statusCode);
            }
            return null;
        }

        $responseBody = wp_remote_retrieve_body($response);
        $data = json_decode($responseBody, true);

        if (!$data || !empty($data['errors'])) {
            if (!$withHmac && !empty($data['errors'])) {
                error_log('WPFaker Hive API errors: ' . wp_json_encode($data['errors']));
            }
            return null;
        }

        return $data;
    }

    /**
     * Get the API secret for HMAC signing
     */
    private function getApiSecret(): string
    {
        // Use the license key as the shared secret for HMAC
        // This ensures only licensed installations can report
        return defined('WPFAKER_API_SECRET')
            ? WPFAKER_API_SECRET
            : (get_option('wpfaker_license_key', '') ?: '');
    }
}
