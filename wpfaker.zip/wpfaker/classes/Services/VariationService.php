<?php

namespace WPFaker\Services;

/**
 * Variation Service
 *
 * Handles content variation logic to ensure maximum diversity in generated content.
 * This helps developers test edge cases like empty fields, varying taxonomy counts, etc.
 */
class VariationService
{
    /**
     * Variation profiles for different testing scenarios
     */
    public const PROFILE_MINIMAL = 'minimal';      // Minimum required fields only
    public const PROFILE_PARTIAL = 'partial';      // 50% of optional fields
    public const PROFILE_COMPLETE = 'complete';    // All fields filled
    public const PROFILE_RANDOM = 'random';        // Random variation

    /**
     * Current variation seed for reproducible randomness
     */
    protected int $seed;

    /**
     * Variation statistics for the current generation run
     */
    protected array $stats = [
        'total_posts' => 0,
        'with_featured_image' => 0,
        'without_featured_image' => 0,
        'taxonomy_distribution' => [],
        'field_fill_rates' => [],
    ];

    /**
     * Constructor
     */
    public function __construct(?int $seed = null)
    {
        $this->seed = $seed ?? time();
    }

    /**
     * Get a variation profile for a specific post index
     *
     * @param int $index Current post index (0-based)
     * @param int $total Total number of posts being generated
     * @param array $options Variation options
     * @return array Variation settings for this post
     */
    public function getVariationForIndex(int $index, int $total, array $options = []): array
    {
        $this->stats['total_posts'] = $total;

        // If variation is disabled, keep posts "complete" (all fields filled, published,
        // featured image, excerpt) but still vary taxonomies, authors, dates, content
        // length so posts aren't all identical clones.
        $enableVariation = $options['enable_variation'] ?? true;
        if (!$enableVariation) {
            mt_srand($this->seed + $index);
            $maxCategories = $options['max_categories'] ?? 5;
            $maxTags = $options['max_tags'] ?? 8;
            $variation = [
                'has_featured_image' => true,
                'has_excerpt' => true,
                'taxonomy_count' => [
                    'categories' => mt_rand(1, max(1, $maxCategories)),
                    'tags' => mt_rand(1, max(1, $maxTags)),
                ],
                'field_fill_percentage' => 100,
                'content_length' => ['medium', 'long', 'very_long'][$index % 3],
                'author_index' => $this->getAuthorIndex($index, $total, $options),
                'date_spread' => $this->getDateSpread($index, $total),
                'gallery_image_count' => mt_rand(2, 5),
                'post_status' => 'publish',
                'profile' => 'none',
                'is_complete_example' => false,
            ];
            $this->stats['with_featured_image']++;
            return $variation;
        }

        // Use index-based seed for reproducibility
        mt_srand($this->seed + $index);

        // First post (index 0) is ALWAYS the complete example with all fields filled
        $isCompleteExample = ($index === 0);

        if ($isCompleteExample) {
            $variation = $this->getCompleteVariation($options);
        } else {
            $variation = [
                'has_featured_image' => $this->shouldHaveFeaturedImage($index, $total, $options),
                'has_excerpt' => $this->shouldHaveExcerpt($index, $total),
                'taxonomy_count' => $this->getTaxonomyCount($index, $total, $options),
                'field_fill_percentage' => $this->getFieldFillPercentage($index, $total, $options),
                'content_length' => $this->getContentLength($index, $total),
                'author_index' => $this->getAuthorIndex($index, $total, $options),
                'date_spread' => $this->getDateSpread($index, $total),
                'gallery_image_count' => $this->getGalleryImageCount($index, $total),
                'post_status' => $this->getPostStatus($index, $total, $options),
                'profile' => $this->getProfile($index, $total),
            ];
        }

        // Mark whether this is the complete example post
        $variation['is_complete_example'] = $isCompleteExample;

        // Track statistics
        if ($variation['has_featured_image']) {
            $this->stats['with_featured_image']++;
        } else {
            $this->stats['without_featured_image']++;
        }

        return $variation;
    }

    /**
     * Get the complete variation with all fields filled
     *
     * This is used for the first post to ensure at least one post has all data.
     *
     * @param array $options
     * @return array
     */
    protected function getCompleteVariation(array $options): array
    {
        return [
            'has_featured_image' => true,
            'has_excerpt' => true,
            'taxonomy_count' => [
                'categories' => $options['max_categories'] ?? 5,
                'tags' => $options['max_tags'] ?? 8,
            ],
            'field_fill_percentage' => 100,
            'content_length' => 'very_long',
            'author_index' => 0,
            'date_spread' => 'today',
            'gallery_image_count' => 5,
            'post_status' => 'publish', // Always publish the complete example post
            'profile' => self::PROFILE_COMPLETE,
        ];
    }

    /**
     * Determine if this post should have a featured image
     *
     * Distribution: ~70% with image, ~30% without
     */
    protected function shouldHaveFeaturedImage(int $index, int $total, array $options): bool
    {
        // If explicitly disabled, return false
        if (isset($options['set_featured_image']) && !$options['set_featured_image']) {
            return false;
        }

        // Ensure at least some posts have images and some don't
        if ($total >= 5) {
            // First 70% have images, last 30% may or may not
            if ($index < (int)($total * 0.7)) {
                return true;
            }
            // Mix for the remaining
            return mt_rand(0, 100) < 50;
        }

        // For small batches, use probability
        return mt_rand(0, 100) < 70;
    }

    /**
     * Determine if this post should have an excerpt
     */
    protected function shouldHaveExcerpt(int $index, int $total): bool
    {
        // ~60% of posts have excerpts
        return mt_rand(0, 100) < 60;
    }

    /**
     * Get the number of taxonomies to assign
     *
     * Distribution varies to test different scenarios
     */
    protected function getTaxonomyCount(int $index, int $total, array $options): array
    {
        $maxCategories = $options['max_categories'] ?? 5;
        $maxTags = $options['max_tags'] ?? 8;

        // Create varied distribution
        $distributions = [
            ['categories' => 0, 'tags' => 0],           // No taxonomies
            ['categories' => 1, 'tags' => 0],           // Single category, no tags
            ['categories' => 1, 'tags' => mt_rand(1, 3)], // Single category with tags
            ['categories' => 2, 'tags' => mt_rand(0, 3)], // Two categories
            ['categories' => mt_rand(1, 3), 'tags' => mt_rand(2, 5)], // Medium mix
            ['categories' => mt_rand(3, $maxCategories), 'tags' => mt_rand(3, $maxTags)], // Heavy
        ];

        // Ensure distribution covers all cases across the batch
        if ($total >= 6) {
            $distributionIndex = $index % count($distributions);
        } else {
            $distributionIndex = mt_rand(0, count($distributions) - 1);
        }

        return $distributions[$distributionIndex];
    }

    /**
     * Get the percentage of optional fields to fill
     */
    protected function getFieldFillPercentage(int $index, int $total, array $options): int
    {
        $profile = $options['variation_profile'] ?? self::PROFILE_RANDOM;

        return match ($profile) {
            self::PROFILE_MINIMAL => 0,
            self::PROFILE_PARTIAL => 50,
            self::PROFILE_COMPLETE => 100,
            self::PROFILE_RANDOM => $this->getRandomFieldPercentage($index, $total),
            default => $this->getRandomFieldPercentage($index, $total),
        };
    }

    /**
     * Get random field fill percentage with good distribution
     */
    protected function getRandomFieldPercentage(int $index, int $total): int
    {
        // Ensure we have posts with different fill rates
        $percentages = [0, 25, 50, 75, 100];

        if ($total >= 5) {
            return $percentages[$index % count($percentages)];
        }

        return $percentages[mt_rand(0, count($percentages) - 1)];
    }

    /**
     * Get content length variation
     */
    protected function getContentLength(int $index, int $total): string
    {
        $lengths = ['short', 'medium', 'long', 'very_long'];

        if ($total >= 4) {
            return $lengths[$index % count($lengths)];
        }

        return $lengths[mt_rand(0, count($lengths) - 1)];
    }

    /**
     * Get author index for varied author distribution
     */
    protected function getAuthorIndex(int $index, int $total, array $options): int
    {
        $authorCount = $options['author_count'] ?? 3;

        // Some posts from same author, some from different
        if ($total >= $authorCount * 2) {
            // First half: distribute evenly
            if ($index < $total / 2) {
                return $index % $authorCount;
            }
            // Second half: random with preference for first author
            return mt_rand(0, 100) < 40 ? 0 : mt_rand(0, $authorCount - 1);
        }

        return $index % max(1, $authorCount);
    }

    /**
     * Get date spread for posts
     */
    protected function getDateSpread(int $index, int $total): string
    {
        $spreads = [
            'today',
            'this_week',
            'this_month',
            'last_month',
            'this_year',
            'older',
        ];

        if ($total >= count($spreads)) {
            return $spreads[$index % count($spreads)];
        }

        return $spreads[mt_rand(0, count($spreads) - 1)];
    }

    /**
     * Get gallery image count for posts with galleries
     */
    protected function getGalleryImageCount(int $index, int $total): int
    {
        $counts = [0, 0, 1, 2, 3, 4, 5, 8, 10];
        return $counts[mt_rand(0, count($counts) - 1)];
    }

    /**
     * Get post status for variation
     *
     * If post_status is 'random', returns a random status.
     * Otherwise returns the configured status.
     */
    protected function getPostStatus(int $index, int $total, array $options): string
    {
        $postStatus = $options['post_status'] ?? 'publish';

        if ($postStatus === 'random') {
            // Distribution: mostly published, some drafts, few pending/private
            $statuses = ['publish', 'publish', 'publish', 'draft', 'draft', 'pending', 'private'];
            return $statuses[mt_rand(0, count($statuses) - 1)];
        }

        return $postStatus;
    }

    /**
     * Get the variation profile for this post
     */
    protected function getProfile(int $index, int $total): string
    {
        $profiles = [
            self::PROFILE_MINIMAL,
            self::PROFILE_PARTIAL,
            self::PROFILE_PARTIAL,
            self::PROFILE_COMPLETE,
        ];

        if ($total >= 4) {
            return $profiles[$index % count($profiles)];
        }

        return $profiles[mt_rand(0, count($profiles) - 1)];
    }

    /**
     * Determine if a specific optional field should be filled
     *
     * @param string $fieldName The field name
     * @param int $fillPercentage The fill percentage for this post
     * @param bool $isRequired Whether the field is required
     * @return bool
     */
    public function shouldFillField(string $fieldName, int $fillPercentage, bool $isRequired = false): bool
    {
        if ($isRequired) {
            return true;
        }

        return mt_rand(0, 100) < $fillPercentage;
    }

    /**
     * Get taxonomy terms to create/reuse for maximum variation
     *
     * @param string $taxonomy The taxonomy name
     * @param int $needed Number of terms needed
     * @param int $totalPosts Total posts being generated
     * @return array Array of term data
     */
    public function getTermsForVariation(string $taxonomy, int $needed, int $totalPosts): array
    {
        if ($needed <= 0) {
            return [];
        }

        // Get existing terms
        $existingTerms = get_terms([
            'taxonomy' => $taxonomy,
            'hide_empty' => false,
            'fields' => 'ids',
        ]);

        if (is_wp_error($existingTerms)) {
            $existingTerms = [];
        }

        $existingCount = count($existingTerms);

        // Calculate optimal term count for good overlap
        // We want some posts to share terms (for "related posts" testing)
        $optimalTermCount = max(3, (int)ceil($totalPosts / 3));

        // If we have enough terms, reuse them
        if ($existingCount >= $optimalTermCount) {
            shuffle($existingTerms);
            return array_slice($existingTerms, 0, min($needed, $existingCount));
        }

        // Return existing terms, caller should create more if needed
        return [
            'existing' => $existingTerms,
            'needed' => max(0, $optimalTermCount - $existingCount),
            'use_count' => min($needed, max($existingCount, $optimalTermCount)),
        ];
    }

    /**
     * Generate a descriptive title based on post characteristics
     *
     * @param array $characteristics Post characteristics
     * @param string $locale Language locale
     * @return string
     */
    public function generateDescriptiveTitle(array $characteristics, string $locale = 'en_US'): string
    {
        $parts = [];

        // Language-specific labels
        $labels = $this->getTitleLabels($locale);

        // Add special marker for complete example (first post with all fields)
        if (!empty($characteristics['is_complete_example'])) {
            $parts[] = $labels['complete_example'];
        }

        // Categories count
        $catCount = $characteristics['category_count'] ?? 0;
        if ($catCount > 0) {
            $parts[] = sprintf($labels['categories'], $catCount);
        } else {
            $parts[] = $labels['no_categories'];
        }

        // Tags count
        $tagCount = $characteristics['tag_count'] ?? 0;
        if ($tagCount > 0) {
            $parts[] = sprintf($labels['tags'], $tagCount);
        }

        // Featured image
        if ($characteristics['has_featured_image'] ?? false) {
            $parts[] = $labels['has_image'];
        } else {
            $parts[] = $labels['no_image'];
        }

        // Author
        if (!empty($characteristics['author_name'])) {
            $parts[] = sprintf($labels['author'], $characteristics['author_name']);
        }

        // Custom fields
        $fieldCount = $characteristics['custom_field_count'] ?? 0;
        if ($fieldCount > 0) {
            $parts[] = sprintf($labels['fields'], $fieldCount);
        }

        // Excerpt
        if ($characteristics['has_excerpt'] ?? false) {
            $parts[] = $labels['has_excerpt'];
        }

        // Gallery
        $galleryCount = $characteristics['gallery_count'] ?? 0;
        if ($galleryCount > 0) {
            $parts[] = sprintf($labels['gallery'], $galleryCount);
        }

        // Profile (only show when variation is enabled, not 'none')
        $profile = $characteristics['profile'] ?? '';
        if (!empty($profile) && $profile !== 'none') {
            $profileLabel = $labels['profiles'][$profile] ?? ucfirst($profile);
            $parts[] = sprintf($labels['profile'], $profileLabel);
        }

        return implode(' | ', $parts);
    }

    /**
     * Get localized title labels
     */
    protected function getTitleLabels(string $locale): array
    {
        $labels = [
            'en_US' => [
                'complete_example' => '★ ALL FIELDS',
                'categories' => '%d Cat',
                'no_categories' => 'No Cat',
                'tags' => '%d Tags',
                'has_image' => 'Img',
                'no_image' => 'No Img',
                'author' => 'By: %s',
                'fields' => '%d Fields',
                'has_excerpt' => 'Excerpt',
                'gallery' => 'Gallery: %d',
                'profile' => '[%s]',
                'profiles' => [
                    'random' => 'Random',
                    'minimal' => 'Minimal',
                    'partial' => 'Partial',
                    'complete' => 'Complete',
                ],
            ],
            'de_DE' => [
                'complete_example' => '★ ALLE FELDER',
                'categories' => '%d Kat',
                'no_categories' => 'Keine Kat',
                'tags' => '%d Tags',
                'has_image' => 'Bild',
                'no_image' => 'Kein Bild',
                'author' => 'Von: %s',
                'fields' => '%d Felder',
                'has_excerpt' => 'Auszug',
                'gallery' => 'Galerie: %d',
                'profile' => '[%s]',
                'profiles' => [
                    'random' => 'Zufällig',
                    'minimal' => 'Minimal',
                    'partial' => 'Teilweise',
                    'complete' => 'Vollständig',
                ],
            ],
        ];

        return $labels[$locale] ?? $labels['en_US'];
    }

    /**
     * Get content length in paragraphs
     */
    public function getContentParagraphCount(string $length): int
    {
        return match ($length) {
            'short' => mt_rand(1, 2),
            'medium' => mt_rand(3, 5),
            'long' => mt_rand(6, 10),
            'very_long' => mt_rand(11, 20),
            default => mt_rand(3, 5),
        };
    }

    /**
     * Get date based on spread setting
     */
    public function getDateForSpread(string $spread): string
    {
        $now = time();

        return match ($spread) {
            'today' => date('Y-m-d H:i:s', $now - mt_rand(0, 86400)),
            'this_week' => date('Y-m-d H:i:s', $now - mt_rand(0, 604800)),
            'this_month' => date('Y-m-d H:i:s', $now - mt_rand(0, 2592000)),
            'last_month' => date('Y-m-d H:i:s', $now - mt_rand(2592000, 5184000)),
            'this_year' => date('Y-m-d H:i:s', $now - mt_rand(0, 31536000)),
            'older' => date('Y-m-d H:i:s', $now - mt_rand(31536000, 94608000)),
            default => date('Y-m-d H:i:s', $now - mt_rand(0, 31536000)),
        };
    }

    /**
     * Get generation statistics
     */
    public function getStats(): array
    {
        return $this->stats;
    }

    /**
     * Reset statistics
     */
    public function resetStats(): void
    {
        $this->stats = [
            'total_posts' => 0,
            'with_featured_image' => 0,
            'without_featured_image' => 0,
            'taxonomy_distribution' => [],
            'field_fill_rates' => [],
        ];
    }
}
