<?php

namespace WPFaker\Services;

use WPFaker\Contracts\AiProviderInterface;

/**
 * Field Name Detector Service
 *
 * Analyzes field names to determine appropriate fake data types.
 * Uses pattern matching to detect common field types like IBAN, BIC, phone, etc.
 * Optionally uses AI as a fallback when pattern matching fails.
 */
class FieldNameDetector
{
    /**
     * AI provider for AI-powered detection (optional)
     */
    protected ?AiProviderInterface $aiProvider = null;

    /**
     * CPT context for disambiguation
     */
    protected ?string $cptSlug = null;
    protected ?string $cptLabel = null;

    /**
     * AI-generated CPT context for enhanced domain detection
     */
    protected ?array $cptContextData = null;

    /**
     * Context rules for sub-field disambiguation.
     * Each rule: context tokens (matched against parent field path),
     * field tokens (matched against the field name), resulting type.
     * Rules scored by matching context token count. Highest wins.
     *
     * Note: Rule order matters for tie-breaking — when two rules score
     * equally, the first rule in this array wins.
     */
    protected const CONTEXT_RULES = [
        // Awards context
        ['context' => ['award', 'prize', 'nomination'], 'field' => ['category', 'kategorie', 'catégorie', 'categoría'], 'type' => 'award_category'],
        ['context' => ['award', 'prize', 'nomination'], 'field' => ['name', 'title', 'titel', 'nom', 'nombre'], 'type' => 'award_name'],
        ['context' => ['award', 'prize', 'nomination'], 'field' => ['year', 'jahr', 'année', 'año'], 'type' => 'year'],

        // Cast/Actor/Awards context — role/character fields
        ['context' => ['cast', 'actor', 'actress', 'performer', 'darsteller', 'schauspieler', 'acteur', 'actriz', 'award', 'prize', 'nomination'], 'field' => ['role', 'rolle', 'rôle', 'papel', 'character', 'charakter', 'personnage', 'personaje'], 'type' => 'character_name'],
        ['context' => ['cast', 'actor', 'actress', 'performer', 'darsteller', 'schauspieler'], 'field' => ['name', 'nom', 'nombre', 'nome'], 'type' => 'full_name'],

        // Team/Staff context
        ['context' => ['team', 'staff', 'employee', 'member', 'mitarbeiter', 'équipe', 'equipo', 'colleague'], 'field' => ['role', 'rolle', 'rôle', 'papel', 'title', 'titel', 'position', 'stelle'], 'type' => 'job_title'],
        ['context' => ['team', 'staff', 'employee', 'member', 'mitarbeiter'], 'field' => ['name', 'nom', 'nombre', 'nome'], 'type' => 'full_name'],
        ['context' => ['team', 'staff', 'employee', 'member', 'mitarbeiter'], 'field' => ['department', 'abteilung', 'département', 'departamento'], 'type' => 'department'],

        // Product/Shop context
        ['context' => ['product', 'produkt', 'shop', 'item', 'artikel', 'variant', 'variante'], 'field' => ['category', 'kategorie', 'catégorie', 'categoría'], 'type' => 'product_category'],
        ['context' => ['product', 'produkt', 'shop', 'item', 'artikel'], 'field' => ['name', 'nom', 'nombre'], 'type' => 'product_name'],
        ['context' => ['product', 'produkt', 'shop', 'item', 'artikel'], 'field' => ['price', 'preis', 'prix', 'precio'], 'type' => 'price'],

        // Event context
        ['context' => ['event', 'veranstaltung', 'événement', 'evento', 'conference', 'konferenz'], 'field' => ['name', 'title', 'titel'], 'type' => 'event_name'],
        ['context' => ['event', 'veranstaltung', 'événement', 'conference'], 'field' => ['location', 'ort', 'lieu', 'ubicación', 'venue'], 'type' => 'city'],

        // Education context
        ['context' => ['course', 'kurs', 'class', 'lesson', 'lektion', 'curriculum'], 'field' => ['name', 'title', 'titel'], 'type' => 'title'],
        ['context' => ['course', 'kurs', 'class', 'lesson', 'curriculum'], 'field' => ['instructor', 'lehrer', 'teacher', 'dozent', 'professeur'], 'type' => 'full_name'],

        // Recipe/Food context
        ['context' => ['recipe', 'rezept', 'recette', 'receta', 'ingredient', 'zutat'], 'field' => ['name', 'nom', 'nombre'], 'type' => 'ingredient'],
        ['context' => ['recipe', 'rezept', 'recette', 'ingredient', 'zutat'], 'field' => ['amount', 'menge', 'quantity', 'quantité', 'cantidad'], 'type' => 'ingredient_amount'],
    ];

    /**
     * Set CPT context for disambiguation of ambiguous field names
     */
    public function setCptContext(string $slug, ?string $label = null): void
    {
        $this->cptSlug = $slug;
        $this->cptLabel = $label;
    }

    /**
     * Set AI-generated CPT context data for enhanced domain detection
     */
    public function setCptContextData(?array $cptContext): void
    {
        $this->cptContextData = $cptContext;
    }

    /**
     * Get the current CPT slug (if set)
     */
    public function getCptSlug(): ?string
    {
        return $this->cptSlug;
    }

    /**
     * CPT context map: keywords in CPT slug/label → domain context
     */
    protected const CPT_CONTEXT_MAP = [
        'product' => [
            // en + de (original)
            'produkt', 'product', 'shop', 'artikel', 'ware', 'article', 'item',
            // fr
            'produit', 'boutique', 'marchandise',
            // es
            'producto', 'tienda', 'artículo', 'mercancía',
            // it
            'prodotto', 'negozio', 'articolo',
            // nl
            'winkel', 'waren',
            // pt
            'loja',
            // pl
            'sklep', 'towar',
            // ru
            'продукт', 'товар', 'магазин',
            // ja
            '製品', '商品', 'ショップ',
            // zh
            '产品', '商店',
        ],
        'realestate' => [
            // en + de (original)
            'immobilie', 'property', 'wohnung', 'apartment', 'haus', 'house', 'real_estate',
            // fr
            'immobilier', 'propriété', 'appartement', 'maison', 'bien',
            // es
            'inmueble', 'propiedad', 'vivienda', 'piso', 'casa',
            // it
            'immobile', 'proprietà', 'appartamento', 'abitazione',
            // nl
            'vastgoed', 'woning', 'huis',
            // pt
            'imóvel', 'propriedade',
            // pl
            'nieruchomość', 'mieszkanie', 'dom',
            // ru
            'недвижимость', 'квартира', 'дом', 'жильё',
            // ja
            '不動産', '物件', 'マンション',
            // zh
            '房产', '房地产', '公寓', '住宅',
        ],
        'person' => [
            // en + de (original)
            'team', 'staff', 'mitarbeiter', 'person', 'member', 'employee', 'kunde', 'customer', 'agent', 'makler', 'berater',
            // fr
            'équipe', 'personnel', 'employé', 'membre', 'collaborateur', 'client',
            // es
            'equipo', 'empleado', 'miembro', 'personal', 'cliente',
            // it
            'squadra', 'dipendente', 'membro', 'personale',
            // nl
            'medewerker', 'personeel', 'lid', 'klant',
            // pt
            'equipe', 'funcionário', 'pessoal',
            // pl
            'pracownik', 'zespół', 'członek', 'personel', 'klient',
            // ru
            'команда', 'сотрудник', 'персонал', 'участник', 'клиент',
            // ja
            'チーム', 'スタッフ', '社員', 'メンバー',
            // zh
            '团队', '员工', '成员', '人员',
        ],
        'event' => [
            // en + de (original)
            'event', 'veranstaltung', 'termin', 'appointment', 'booking',
            // fr
            'événement', 'rendez-vous', 'réservation',
            // es
            'evento', 'cita', 'reserva',
            // it
            'appuntamento', 'prenotazione',
            // nl
            'evenement', 'afspraak', 'boeking',
            // pt
            'compromisso',
            // pl
            'wydarzenie', 'spotkanie', 'rezerwacja',
            // ru
            'событие', 'мероприятие', 'встреча', 'бронирование',
            // ja
            'イベント', '予約', '行事',
            // zh
            '活动', '事件', '预约',
        ],
        'food' => [
            // en + de (original)
            'recipe', 'rezept', 'food', 'essen', 'gericht', 'dish', 'menu',
            // fr
            'recette', 'nourriture', 'plat', 'cuisine',
            // es
            'receta', 'comida', 'plato', 'menú',
            // it
            'ricetta', 'cibo', 'piatto',
            // nl
            'recept', 'eten', 'gerecht',
            // pt
            'receita', 'prato', 'cardápio',
            // pl
            'przepis', 'jedzenie', 'danie', 'potrawa',
            // ru
            'рецепт', 'еда', 'блюдо', 'меню',
            // ja
            'レシピ', '料理', '食事', 'メニュー',
            // zh
            '食谱', '菜谱', '美食', '菜品',
        ],
        'vehicle' => [
            // en + de (original)
            'vehicle', 'fahrzeug', 'auto', 'car', 'kfz', 'pkw', 'automotive',
            // fr
            'véhicule', 'voiture', 'automobile',
            // es
            'vehículo', 'coche', 'automóvil',
            // it
            'veicolo', 'macchina',
            // nl
            'voertuig', 'wagen', 'automobiel',
            // pt
            'veículo', 'carro', 'automóvel',
            // pl
            'pojazd', 'samochód',
            // ru
            'автомобиль', 'транспорт', 'машина',
            // ja
            '車両', '車', '自動車',
            // zh
            '车辆', '汽车', '机动车',
        ],
        'service' => [
            // en + de
            'service', 'dienstleistung', 'leistung',
            // fr
            'prestation',
            // es
            'servicio',
            // it
            'servizio',
            // nl
            'dienst',
            // pt
            'serviço',
            // pl
            'usługa',
            // ru
            'услуга',
            // ja
            'サービス',
            // zh
            '服务',
        ],
        'media' => [
            // en + de
            'video', 'podcast', 'gallery', 'galerie', 'album', 'media', 'clip', 'episode', 'movie', 'film', 'kino',
            // fr
            'vidéo',
            // es
            'vídeo',
            // it
            'galleria',
            // nl
            'galerij',
            // pt
            'galeria',
            // ja
            'ビデオ', 'ギャラリー',
            // zh
            '视频', '画廊',
        ],
        'directory' => [
            // en + de
            'directory', 'verzeichnis', 'eintrag',
            // fr
            'annuaire',
            // es
            'directorio',
            // it
            'guida',
            // nl
            'gids',
            // pt
            'diretório',
            // pl
            'katalog',
            // ru
            'каталог',
            // ja
            'ディレクトリ',
            // zh
            '目录',
        ],
        'faq' => [
            // en + de
            'faq', 'hilfe', 'help',
            // fr
            'support',
            // es
            'pregunta',
            // it
            'domanda',
            // nl
            'vraag',
            // pt
            'pergunta',
            // pl
            'pytanie',
            // ru
            'вопрос',
            // ja
            '質問',
            // zh
            '问题',
        ],
        'coupon' => [
            // en + de
            'coupon', 'gutschein', 'deal', 'voucher', 'promo', 'rabatt', 'angebot',
            // fr
            'bon',
            // es
            'cupón',
            // it
            'buono',
            // nl
            'kortingscode',
            // pt
            'cupom',
            // pl
            'kupon',
            // ru
            'купон',
            // ja
            'クーポン',
            // zh
            '优惠券',
        ],
        'case_study' => [
            // en + de
            'case_study', 'fallstudie', 'referenz', 'success_story',
            // fr
            'étude_de_cas',
            // es
            'caso_de_estudio',
            // it
            'caso_studio',
            // nl
            'casestudy',
            // pt
            'estudo_de_caso',
            // pl
            'studium_przypadku',
            // ru
            'кейс',
        ],
        'partner' => [
            // en + de
            'partner', 'sponsor',
            // fr
            'partenaire',
            // es
            'socio',
            // pt
            'parceiro',
            // ru
            'партнёр',
            // ja
            'パートナー',
            // zh
            '合作伙伴',
        ],
        'slide' => [
            // en + de
            'slide', 'slider', 'banner', 'hero', 'carousel', 'karussell',
            // fr
            'diapositive',
            // es
            'diapositiva',
            // ja
            'スライド',
            // zh
            '幻灯片',
        ],
        'press' => [
            // en + de
            'press', 'presse', 'pressemitteilung', 'press_release',
            // fr
            'communiqué',
            // es
            'comunicado',
            // it
            'comunicato',
            // nl
            'persbericht',
            // pt
            'notícia',
            // pl
            'informacja_prasowa',
            // ru
            'пресс-релиз',
            // ja
            'プレスリリース',
            // zh
            '新闻',
        ],
        'portfolio' => [
            // en + de
            'portfolio', 'projekt', 'project', 'showcase', 'work',
            // fr
            'projet', 'réalisation',
            // es
            'proyecto', 'portafolio',
            // it
            'progetto', 'portafoglio',
            // nl
            'projecten',
            // pt
            'projeto', 'portfólio',
            // pl
            'realizacja',
            // ru
            'проект', 'портфолио',
            // ja
            'ポートフォリオ', 'プロジェクト', '実績',
            // zh
            '作品集', '项目', '案例',
        ],
        'education' => [
            // en + de
            'course', 'kurs', 'lesson', 'training', 'schulung', 'workshop', 'class', 'seminar',
            // fr
            'cours', 'formation', 'leçon', 'atelier',
            // es
            'curso', 'formación', 'lección', 'taller',
            // it
            'corso', 'formazione', 'lezione', 'laboratorio',
            // nl
            'cursus', 'opleiding', 'les',
            // pt
            'treinamento', 'aula', 'oficina',
            // pl
            'szkolenie', 'lekcja', 'warsztat',
            // ru
            'курс', 'обучение', 'урок', 'тренинг', 'семинар',
            // ja
            'コース', '講座', 'レッスン', '研修',
            // zh
            '课程', '培训', '讲座', '研讨会',
        ],
        'job' => [
            // en + de
            'job', 'stelle', 'career', 'vacancy', 'jobangebot', 'position', 'stellenangebot',
            // fr
            'emploi', 'carrière', 'poste', 'offre_emploi',
            // es
            'empleo', 'carrera', 'vacante', 'oferta_empleo',
            // it
            'lavoro', 'carriera', 'posizione', 'offerta_lavoro',
            // nl
            'baan', 'vacature', 'carrière', 'functie',
            // pt
            'emprego', 'vaga',
            // pl
            'praca', 'kariera', 'stanowisko', 'oferta_pracy',
            // ru
            'работа', 'вакансия', 'карьера', 'должность',
            // ja
            '求人', 'キャリア', '募集', '職種',
            // zh
            '工作', '职位', '招聘', '职业',
        ],
        'testimonial' => [
            // en + de
            'testimonial', 'review', 'bewertung', 'feedback', 'referenz', 'erfahrungsbericht',
            // fr
            'témoignage', 'avis', 'critique',
            // es
            'testimonio', 'reseña', 'opinión',
            // it
            'testimonianza', 'recensione', 'opinione',
            // nl
            'getuigenis', 'recensie', 'beoordeling',
            // pt
            'depoimento', 'avaliação', 'opinião',
            // pl
            'opinia', 'recenzja', 'referencja',
            // ru
            'отзыв', 'рецензия', 'рекомендация',
            // ja
            'お客様の声', 'レビュー', '感想',
            // zh
            '评价', '评论', '客户反馈', '推荐',
        ],
    ];

    /**
     * Patterns for detecting field types from field names
     * Key: detection type, Value: array of regex patterns
     * Order matters: first match wins (specific patterns before generic ones)
     */
    protected const PATTERNS = [
        // Logo / Branding
        'logo' => ['/(?<![a-z])logo(?![a-z])/i', '/firmenlogo/i', '/brand[_\s.-]?logo/i', '/company[_\s.-]?logo/i', '/site[_\s.-]?logo/i', '/logotype/i'],

        // Banking & Financial
        'iban' => ['/iban/i', '/kontonummer/i', '/account.*number/i'],
        'bic' => ['/bic/i', '/swift/i'],
        'bank_name' => ['/bank(?!.*verbindung)/i', '/kreditinstitut/i'],
        'credit_card' => ['/credit.*card/i', '/kreditkarte/i', '/card.*number/i'],

        // Product / E-Commerce (BEFORE personal info to win first-match)
        'product_name' => ['/produkt.*name/i', '/product.*name/i', '/item.*name/i', '/artikel.*name/i', '/article.*name/i', '/warenname/i'],
        'sku' => ['/sku/i', '/artikelnummer/i', '/article.*number/i', '/item.*number/i', '/part.*number/i', '/bestellnummer/i', '/product.*code/i', '/produkt.*code/i', '/produktnummer/i'],
        'brand' => ['/brand$/i', '/marke$/i', '/hersteller/i', '/manufacturer/i'],
        'model' => ['/^model/i', '/modell/i'],
        'ean' => ['/ean$/i', '/barcode/i', '/gtin/i', '/upc/i'],
        'isbn' => ['/isbn/i'],
        'rating' => ['/rating/i', '/bewertung/i', '/stars$/i', '/sterne/i', '/évaluation/i', '/valoración/i', '/valutazione/i', '/beoordeling/i', '/avaliação/i', '/ocena/i', '/рейтинг/i'],
        'stock' => ['/stock/i', '/lagerbestand/i', '/bestand/i', '/vorrat/i', '/inventory/i', '/inventaire/i', '/inventario/i', '/voorraad/i', '/estoque/i', '/zapas/i', '/запас/i'],
        // Coupon / Commerce (BEFORE discount — rabattcode must win over /rabatt/i)
        'coupon_code' => ['/coupon.*code/i', '/promo.*code/i', '/gutscheincode/i', '/aktionscode/i', '/rabattcode/i', '/code.*promo/i', '/código.*cupón/i'],
        'expiration_date' => ['/expir/i', '/ablauf/i', '/gültig.*bis/i', '/valid.*until/i', '/verfallsdatum/i', '/date.*expiration/i'],
        'minimum_spend' => ['/min.*spend/i', '/min.*order/i', '/mindestbestell/i', '/montant.*minimum/i'],
        'usage_limit' => ['/usage.*limit/i', '/nutzungslimit/i', '/max.*einlösung/i', '/limite.*utilisation/i'],

        'discount' => ['/discount/i', '/rabatt/i', '/nachlass/i', '/remise/i', '/descuento/i', '/sconto/i', '/korting/i', '/desconto/i', '/zniżka/i', '/скидка/i'],

        // Titles/Names (specific, before generic personal names)
        'event_name' => ['/event.*name/i', '/veranstaltung.*name/i'],
        'project_name' => ['/project.*name/i', '/projekt.*name/i'],

        // Media / Content
        'episode_number' => ['/episode/i', '/folge/i', '/épisode/i', '/episodio/i', '/aflevering/i', '/odcinek/i'],
        'season_number' => ['/season/i', '/staffel/i', '/saison/i', '/temporada/i', '/stagione/i', '/seizoen/i'],
        'audio_url' => ['/audio.*url/i', '/podcast.*url/i', '/audio.*file/i', '/audiodatei/i', '/mp3/i'],
        'video_url' => ['/video.*url/i', '/video.*link/i', '/embed.*url/i', '/youtube/i', '/vimeo/i'],
        'genre' => ['/genre/i', '/filmgenre/i', '/musikgenre/i', '/buchgenre/i'],
        'plot' => ['/plot/i', '/handlung/i', '/synopsis/i', '/storyline/i', '/inhaltsangabe/i'],
        'director' => ['/(?<![a-z])director(?![a-z])/i', '/regisseur/i', '/réalisateur/i', '/régisseur/i'],
        'award_category' => ['/award.*categor/i', '/categor.*award/i', '/nomination.*categor/i', '/categor.*nomination/i', '/kategorie.*auszeichnung/i', '/auszeichnung.*kategorie/i'],
        'award_name' => ['/award(?!.*(?:year|jahr|categor|kategorie))/i', '/auszeichnung(?!.*kategorie)/i', '/trophy/i', '/preis_name/i', '/prix_nom/i', '/premio/i'],
        'play_count' => ['/play.*count/i', '/views$/i', '/aufrufe/i', '/wiedergaben/i', '/plays$/i'],
        'transcript' => ['/transcript/i', '/transkript/i', '/transcription/i', '/transcripción/i', '/trascrizione/i'],

        // Presentation / Slides (BEFORE title, content, website — first-match wins)
        'button_text' => ['/button.*text/i', '/cta.*text/i', '/link.*text/i', '/button.*label/i', '/beschriftung/i'],
        'button_url' => ['/button.*url/i', '/cta.*url/i', '/button.*link/i', '/cta.*link/i'],
        'subtitle' => ['/subtitle/i', '/untertitel/i', '/sous.*titre/i', '/subtítulo/i', '/sottotitolo/i', '/ondertitel/i'],
        'badge_text' => ['/badge/i', '/abzeichen/i', '/auszeichnung/i', '/étiquette/i'],

        // Service / Business (booking_url BEFORE website — first-match wins for *_url)
        'service_area' => ['/service.*area/i', '/einzugsgebiet/i', '/zone.*intervention/i', '/área.*servicio/i'],
        'availability' => ['/availability/i', '/verfügbarkeit/i', '/disponibilité/i', '/disponibilidad/i', '/beschikbaarheid/i'],
        'booking_url' => ['/booking.*url/i', '/buchung.*link/i', '/reservierung.*link/i', '/réservation.*lien/i'],

        // Personal Information
        'first_name' => ['/first.*name/i', '/vorname/i', '/given.*name/i', '/prénom/i', '/nombre/i', '/nome/i', '/voornaam/i', '/imię/i', '/имя/i'],
        'last_name' => ['/last.*name/i', '/nachname/i', '/surname/i', '/family.*name/i', '/nom.*famille/i', '/apellido/i', '/cognome/i', '/achternaam/i', '/nazwisko/i', '/фамилия/i'],
        'full_name' => ['/full.*name/i', '/^name$/i', '/contact.*name/i', '/makler.*name/i', '/person.*name/i', '/ansprechpartner/i', '/inhaber/i', '/stage.*name/i', '/artist.*name/i', '/nick.*name/i', '/pen.*name/i', '/screen.*name/i', '/display.*name/i', '/künstlername/i', '/pseudonym/i'],
        'salutation' => ['/salutation/i', '/anrede/i', '/^title$/i'],
        'gender' => ['/gender/i', '/geschlecht/i', '/sex/i', '/sexe/i', '/género/i', '/genere/i', '/geslacht/i', '/gênero/i', '/płeć/i', '/пол$/i'],
        'birthday' => ['/birthday/i', '/birth.*date/i', '/date.*birth/i', '/geburtstag/i', '/dob/i', '/anniversaire/i', '/cumpleaños/i', '/compleanno/i', '/verjaardag/i', '/aniversário/i', '/urodziny/i', '/день.*рождения/i'],
        'age' => ['/^age$/i', '/alter$/i'],

        // Contact Information
        'email' => ['/email/i', '/e-mail/i', '/mail/i', '/courriel/i', '/correo/i', '/posta.*elettronica/i'],
        'phone' => ['/phone/i', '/telefon/i', '/tel$/i', '/mobile/i', '/handy/i', '/fax/i', '/téléphone/i', '/teléfono/i', '/telefono/i', '/telefoon/i', '/telefone/i', '/numer.*telefon/i', '/телефон/i'],
        'website' => ['/website/i', '/webseite/i', '/homepage/i', '/url$/i', '/site.*web/i', '/sitio.*web/i', '/sito.*web/i'],

        // Address
        'street' => ['/street/i', '/strasse/i', '/straße/i', '/address.*line.*1/i', '/rue/i', '/calle/i', '/via$/i', '/straat/i', '/rua/i', '/ulica/i', '/улица/i'],
        'house_number' => ['/house.*number/i', '/hausnummer/i', '/hnr/i'],
        'postal_code' => ['/postal.*code/i', '/zip.*code/i', '/postleitzahl/i', '/plz/i', '/zip/i', '/code.*postal/i', '/código.*postal/i', '/codice.*postale/i', '/postcode/i', '/kod.*pocztowy/i', '/почтовый.*индекс/i'],
        'city' => ['/city/i', '/stadt/i', '/(?<!w)ort$/i', '/town/i', '/ville/i', '/ciudad/i', '/città/i', '/cidade/i', '/город/i', '/miasto/i'],
        'state' => ['/state/i', '/bundesland/i', '/region/i', '/province/i', '/provincia/i', '/воеводство/i', '/область/i'],
        'country' => ['/country/i', '/land$/i', '/nation/i', '/pays/i', '/país/i', '/paese/i', '/kraj/i', '/страна/i'],
        'address' => ['/^address$/i', '/adresse$/i', '/anschrift/i', '/dirección/i', '/indirizzo/i', '/adres$/i', '/endereço/i', '/адрес/i'],
        'latitude' => ['/latitude/i', '/lat$/i', '/breitengrad/i'],
        'longitude' => ['/longitude/i', '/lng$/i', '/lon$/i', '/längengrad/i'],

        // Food / Nutrition
        'calories' => ['/calorie/i', '/kalorien/i', '/kcal/i'],
        'ingredients' => ['/ingredient/i', '/zutat/i', '/ingrédient/i', '/ingrediente/i', '/ingrediënt/i'],
        'allergens' => ['/allergen/i', '/allergie/i', '/allergène/i', '/alérgeno/i'],
        'prep_time' => ['/prep.*time/i', '/vorbereit.*zeit/i', '/temps.*préparation/i', '/tiempo.*preparación/i'],
        'cook_time' => ['/cook.*time/i', '/koch.*zeit/i', '/garzeit/i', '/temps.*cuisson/i', '/tiempo.*cocción/i'],
        'servings' => ['/serving/i', '/portion/i', '/ration/i', '/porción/i', '/porzione/i'],
        'nutrition_info' => ['/nutrition/i', '/nährwert/i', '/valeur.*nutritive/i', '/valor.*nutricional/i'],
        'cuisine_type' => ['/cuisine/i', '/küche/i', '/cocina/i', '/cucina/i', '/keuken/i'],

        // Location / Directory
        'opening_hours' => ['/opening.*hour/i', '/business.*hour/i', '/öffnungszeit/i', '/geschäftszeit/i', '/horaire/i', '/horario/i', '/orari/i'],
        'coordinates' => ['/coordinate/i', '/koordinate/i', '/geo.*location/i', '/standort.*karte/i'],
        'wheelchair_accessible' => ['/wheelchair/i', '/barrierefrei/i', '/rollstuhl/i', '/accessible.*handicap/i', '/accesib/i'],
        'parking' => ['/parking/i', '/parkplatz/i', '/parkmöglichkeit/i', '/stationnement/i', '/aparcamiento/i', '/parcheggio/i'],

        // Company
        'company' => ['/company/i', '/firma/i', '/unternehmen/i', '/business/i', '/entreprise/i', '/empresa/i', '/azienda/i', '/bedrijf/i', '/companhia/i', '/компания/i', '/przedsiębiorstwo/i'],
        'company_suffix' => ['/company.*suffix/i', '/rechtsform/i'],
        'job_title' => ['/job.*title/i', '/job.*position/i', '/beruf/i', '/jobtitel/i', '/poste$/i', '/puesto/i', '/ruolo/i', '/functie/i', '/cargo/i', '/stanowisko/i', '/должность/i'],
        'department' => ['/department/i', '/abteilung/i', '/département/i', '/departamento/i', '/reparto/i', '/afdeling/i', '/wydział/i', '/отдел/i'],
        'vat_number' => ['/vat/i', '/ust.*id/i', '/steuer.*nummer/i', '/tax.*id/i'],

        // Internet & Tech
        'username' => ['/username/i', '/user.*name/i', '/benutzername/i', '/login/i', '/nom.*utilisateur/i', '/nombre.*usuario/i', '/nome.*utente/i', '/gebruikersnaam/i', '/nazwa.*użytkownika/i', '/имя.*пользователя/i'],
        'password' => ['/password/i', '/passwort/i', '/kennwort/i', '/mot.*passe/i', '/contraseña/i', '/parola.*chiave/i', '/wachtwoord/i', '/senha/i', '/hasło/i', '/пароль/i'],
        'ip_address' => ['/ip.*address/i', '/ip$/i'],
        'mac_address' => ['/mac.*address/i', '/mac$/i'],
        'uuid' => ['/uuid/i', '/guid/i'],
        'slug' => ['/slug/i', '/permalink/i'],

        // Dates & Times
        'date' => ['/date/i', '/datum/i', '/tag$/i', '/fecha/i', '/data$/i', '/дата/i'],
        'time' => ['/time$/i', '/zeit$/i', '/uhrzeit/i'],
        'year' => ['/year$/i', '/jahr$/i', '/baujahr/i', '/année/i', '/año/i', '/anno/i', '/jaar$/i', '/rok$/i', '/год$/i'],

        // Measurements & Numbers
        'price' => ['/price/i', '/preis/i', '/kosten/i', '/betrag/i', '/amount/i', '/prix/i', '/precio/i', '/prezzo/i', '/prijs/i', '/preço/i', '/cena/i', '/цена/i'],
        'percentage' => ['/percent/i', '/prozent/i', '/^rate$/i', '/interest.*rate/i', '/pourcentage/i', '/porcentaje/i', '/percentuale/i', '/percentage/i', '/percentual/i', '/процент/i'],
        'area' => ['/area/i', '/fläche/i', '/größe/i', '/qm$/i', '/m2$/i', '/superficie/i', '/oppervlakte/i', '/área/i', '/площадь/i', '/powierzchnia/i'],
        'weight' => ['/weight/i', '/gewicht/i', '/poids/i', '/peso/i', '/вес$/i', '/waga/i'],
        'height' => ['/height/i', '/höhe/i', '/hauteur/i', '/taille/i', '/altezza/i', '/hoogte/i', '/altura/i', '/wysokość/i', '/рост/i', '/высота/i'],
        'width' => ['/width/i', '/breite/i'],
        'length' => ['/length/i', '/länge/i'],
        'count' => ['/count/i', '/anzahl/i', '/number/i', '/menge/i'],
        'floor' => ['/floor/i', '/etage/i', '/stockwerk/i'],
        'rooms' => ['/rooms/i', '/zimmer/i', '/räume/i'],

        // Vehicle / Automotive
        'vehicle_model' => ['/vehicle.*model/i', '/fahrzeugmodell/i', '/car_model/i', '/automodell/i'],
        'vehicle_make' => ['/^make$/i', '/^marke$/i', '/manufacturer|hersteller/i'],
        'license_plate' => ['/license.*plate/i', '/kennzeichen/i', '/nummernschild/i', '/plate.*number/i'],
        'vin' => ['/^vin$/i', '/fahrgestell/i', '/vehicle.*ident/i', '/chassis/i'],
        'color_name' => ['/^colou?r$/i', '/^farbe$/i', '/exterior.*colou?r|lack.*farbe/i', '/paint/i'],
        'listing_title' => ['/listing.*title|inserat.*titel|anzeigen.*titel/i'],

        // Real Estate Specific
        'object_number' => ['/object.*number/i', '/objektnummer/i', '/reference/i', '/referenz/i'],
        'commission' => ['/commission/i', '/provision/i', '/courtage/i'],
        'energy_class' => ['/energy.*class/i', '/energieeffizienz/i', '/energieklasse/i'],
        'heating_type' => ['/heating/i', '/heizung/i', '/heizungsart/i'],

        // Event-specific
        'event_date' => ['/event.*date/i', '/veranstaltung.*datum/i', '/event.*datum/i', '/date.*event/i', '/date.*événement/i', '/fecha.*evento/i', '/data.*evento/i'],
        'venue' => ['/venue/i', '/veranstaltungsort/i', '/location.*name/i', '/lieu/i', '/lugar/i', '/sede/i', '/locatie/i', '/local/i', '/miejsce/i', '/площадка/i'],
        'organizer' => ['/organizer/i', '/veranstalter/i', '/organisateur/i', '/organizador/i', '/organizzatore/i', '/organisator/i', '/organizator/i', '/организатор/i'],
        'duration' => ['/duration/i', '/dauer/i', '/durée/i', '/duración/i', '/durata/i', '/duur/i', '/duração/i', '/czas.*trwania/i', '/длительность/i', '/продолжительность/i'],
        'capacity' => ['/capacity/i', '/kapazität/i', '/capacité/i', '/capacidad/i', '/capacità/i', '/capaciteit/i', '/capacidade/i', '/pojemność/i', '/вместимость/i'],

        // Education-specific
        'instructor' => ['/instructor/i', '/dozent/i', '/lehrer/i', '/teacher/i', '/professeur/i', '/profesor/i', '/insegnante/i', '/docent/i', '/instrutor/i', '/instruktor/i', '/преподаватель/i'],
        'curriculum' => ['/curriculum/i', '/lehrplan/i', '/syllabus/i', '/programme/i', '/programa/i', '/programma/i', '/leerplan/i', '/currículo/i', '/program.*nauczania/i', '/учебный.*план/i'],

        // Job-specific
        'salary' => ['/salary/i', '/gehalt/i', '/salaire/i', '/salario/i', '/stipendio/i', '/lohn/i', '/vergütung/i', '/salaris/i', '/wynagrodzenie/i', '/зарплата/i', '/оклад/i'],
        'experience' => ['/experience/i', '/erfahrung/i', '/expérience/i', '/experiencia/i', '/esperienza/i', '/ervaring/i', '/experiência/i', '/doświadczenie/i', '/опыт/i'],
        'qualification' => ['/qualification/i', '/qualifikation/i', '/anforderung/i', '/requirement/i', '/compétence.*requise/i', '/requisito/i', '/requisiti/i', '/kwalificatie/i', '/qualificação/i', '/kwalifikacja/i', '/квалификация/i'],

        // Text Content
        'title' => ['/^title$/i', '/titel$/i', '/überschrift/i', '/heading/i', '/titre/i', '/título/i', '/titolo/i'],
        'description' => ['/description/i', '/beschreibung/i', '/desc$/i', '/beschrijving/i', '/descrição/i', '/descrizione/i', '/descripción/i', '/opis/i', '/описание/i'],
        'summary' => ['/summary/i', '/zusammenfassung/i', '/excerpt/i', '/auszug/i', '/résumé/i', '/resumen/i', '/riepilogo/i', '/samenvatting/i', '/resumo/i', '/streszczenie/i', '/краткое.*описание/i'],
        'notes' => ['/notes/i', '/notizen/i', '/bemerkung/i', '/anmerkung/i', '/remarques/i', '/notas/i', '/appunti/i', '/opmerkingen/i', '/observações/i', '/uwagi/i', '/заметки/i'],
        'content' => ['/content/i', '/inhalt/i', '/text$/i'],

        // IDs & Codes
        'reference_code' => ['/^code$/i', '/ref.*code/i', '/referenz/i', '/kennung/i'],
    ];

    /**
     * Word-level translations for bridging English field names to locale-specific patterns.
     *
     * Maps common English field-name tokens to their locale equivalent.
     * Only tokens that appear in existing PATTERNS need translating — the goal
     * is to bridge English field names to existing locale patterns.
     */
    protected const WORD_TRANSLATIONS = [
        'de' => [
            // Personal
            'name' => 'name', 'first' => 'vor', 'last' => 'nach', 'surname' => 'nachname',
            'birth' => 'geburt', 'birthday' => 'geburtstag', 'age' => 'alter',
            'gender' => 'geschlecht', 'salutation' => 'anrede',
            // Contact
            'email' => 'email', 'phone' => 'telefon', 'mobile' => 'handy',
            'website' => 'webseite', 'fax' => 'fax',
            // Address
            'street' => 'strasse', 'city' => 'stadt', 'country' => 'land',
            'state' => 'bundesland', 'address' => 'adresse', 'zip' => 'plz',
            'postal' => 'postleit', 'house' => 'haus', 'number' => 'nummer',
            // Dates & Times
            'date' => 'datum', 'time' => 'zeit', 'year' => 'jahr', 'day' => 'tag',
            // Company
            'company' => 'firma', 'job' => 'beruf', 'department' => 'abteilung',
            'title' => 'titel', 'position' => 'stelle',
            // Content
            'description' => 'beschreibung', 'summary' => 'zusammenfassung',
            'content' => 'inhalt', 'notes' => 'notizen', 'heading' => 'überschrift',
            // Product/Commerce
            'product' => 'produkt', 'price' => 'preis', 'discount' => 'rabatt',
            'stock' => 'lagerbestand', 'brand' => 'marke', 'model' => 'modell',
            'rating' => 'bewertung', 'weight' => 'gewicht', 'color' => 'farbe',
            // Measurements
            'height' => 'höhe', 'width' => 'breite', 'length' => 'länge',
            'area' => 'fläche', 'floor' => 'etage', 'rooms' => 'zimmer',
            'count' => 'anzahl', 'amount' => 'betrag', 'percentage' => 'prozent',
            // Food
            'calories' => 'kalorien', 'ingredients' => 'zutaten', 'servings' => 'portionen',
            'cuisine' => 'küche', 'preparation' => 'vorbereitung', 'cooking' => 'koch',
            // Events
            'venue' => 'veranstaltungsort', 'organizer' => 'veranstalter',
            'duration' => 'dauer', 'capacity' => 'kapazität',
            // Media
            'director' => 'regisseur', 'genre' => 'genre', 'plot' => 'handlung',
            'season' => 'staffel', 'episode' => 'folge', 'subtitle' => 'untertitel',
            // Vehicle
            'license' => 'kennzeichen', 'plate' => 'nummernschild',
            // Finance
            'bank' => 'bank', 'account' => 'konto', 'tax' => 'steuer',
            'salary' => 'gehalt', 'commission' => 'provision',
            // Real Estate
            'heating' => 'heizung', 'energy' => 'energie', 'parking' => 'parkplatz',
            // Education
            'instructor' => 'dozent', 'teacher' => 'lehrer',
            'curriculum' => 'lehrplan', 'experience' => 'erfahrung',
            // Tech
            'username' => 'benutzername', 'password' => 'passwort',
        ],
        'fr' => [
            'name' => 'nom', 'first' => 'pré', 'last' => 'nom',
            'birth' => 'naissance', 'birthday' => 'anniversaire',
            'gender' => 'sexe', 'salutation' => 'civilité',
            'email' => 'courriel', 'phone' => 'téléphone',
            'website' => 'site', 'street' => 'rue', 'city' => 'ville',
            'country' => 'pays', 'address' => 'adresse', 'postal' => 'postal',
            'date' => 'date', 'time' => 'heure', 'year' => 'année',
            'company' => 'entreprise', 'job' => 'poste',
            'department' => 'département', 'title' => 'titre',
            'description' => 'description', 'summary' => 'résumé',
            'content' => 'contenu', 'notes' => 'remarques',
            'product' => 'produit', 'price' => 'prix', 'discount' => 'remise',
            'brand' => 'marque', 'weight' => 'poids', 'height' => 'hauteur',
            'duration' => 'durée', 'venue' => 'lieu',
            'organizer' => 'organisateur', 'director' => 'réalisateur',
            'subtitle' => 'sous-titre', 'salary' => 'salaire',
            'ingredients' => 'ingrédients', 'cuisine' => 'cuisine',
            'parking' => 'stationnement', 'instructor' => 'professeur',
            'experience' => 'expérience', 'password' => 'mot_passe',
        ],
        'es' => [
            'name' => 'nombre', 'birth' => 'nacimiento', 'birthday' => 'cumpleaños',
            'gender' => 'género', 'phone' => 'teléfono',
            'street' => 'calle', 'city' => 'ciudad', 'country' => 'país',
            'address' => 'dirección', 'postal' => 'postal',
            'date' => 'fecha', 'year' => 'año',
            'company' => 'empresa', 'title' => 'título',
            'description' => 'descripción', 'summary' => 'resumen',
            'product' => 'producto', 'price' => 'precio', 'discount' => 'descuento',
            'weight' => 'peso', 'height' => 'altura',
            'duration' => 'duración', 'venue' => 'lugar',
            'director' => 'director', 'subtitle' => 'subtítulo',
            'salary' => 'salario', 'ingredients' => 'ingredientes',
            'parking' => 'aparcamiento', 'experience' => 'experiencia',
            'password' => 'contraseña',
        ],
        'it' => [
            'name' => 'nome', 'birth' => 'nascita', 'birthday' => 'compleanno',
            'gender' => 'genere', 'phone' => 'telefono',
            'street' => 'via', 'city' => 'città', 'country' => 'paese',
            'address' => 'indirizzo', 'postal' => 'postale',
            'date' => 'data', 'year' => 'anno',
            'company' => 'azienda', 'title' => 'titolo',
            'description' => 'descrizione', 'summary' => 'riepilogo',
            'product' => 'prodotto', 'price' => 'prezzo', 'discount' => 'sconto',
            'weight' => 'peso', 'height' => 'altezza',
            'duration' => 'durata', 'venue' => 'sede',
            'director' => 'regista', 'subtitle' => 'sottotitolo',
            'salary' => 'stipendio', 'ingredients' => 'ingredienti',
            'parking' => 'parcheggio', 'experience' => 'esperienza',
            'password' => 'parola_chiave',
        ],
        'nl' => [
            'name' => 'naam', 'first' => 'voor', 'last' => 'achter',
            'birth' => 'geboorte', 'birthday' => 'verjaardag',
            'gender' => 'geslacht', 'phone' => 'telefoon',
            'street' => 'straat', 'city' => 'stad', 'country' => 'land',
            'address' => 'adres', 'postal' => 'postcode',
            'date' => 'datum', 'year' => 'jaar',
            'company' => 'bedrijf', 'title' => 'titel',
            'description' => 'beschrijving', 'summary' => 'samenvatting',
            'product' => 'product', 'price' => 'prijs', 'discount' => 'korting',
            'weight' => 'gewicht', 'height' => 'hoogte',
            'duration' => 'duur', 'venue' => 'locatie',
            'subtitle' => 'ondertitel', 'salary' => 'salaris',
            'ingredients' => 'ingrediënten',
            'parking' => 'parkeren', 'experience' => 'ervaring',
            'password' => 'wachtwoord',
        ],
        'pt' => [
            'name' => 'nome', 'birth' => 'nascimento', 'birthday' => 'aniversário',
            'gender' => 'gênero', 'phone' => 'telefone',
            'street' => 'rua', 'city' => 'cidade', 'country' => 'país',
            'address' => 'endereço', 'postal' => 'postal',
            'date' => 'data', 'year' => 'ano',
            'company' => 'companhia', 'title' => 'título',
            'description' => 'descrição', 'summary' => 'resumo',
            'product' => 'produto', 'price' => 'preço', 'discount' => 'desconto',
            'weight' => 'peso', 'height' => 'altura',
            'duration' => 'duração', 'venue' => 'local',
            'subtitle' => 'subtítulo', 'salary' => 'salário',
            'ingredients' => 'ingredientes',
            'parking' => 'estacionamento', 'experience' => 'experiência',
            'password' => 'senha',
        ],
        'pl' => [
            'name' => 'imię', 'birth' => 'urodziny', 'gender' => 'płeć',
            'phone' => 'telefon', 'street' => 'ulica', 'city' => 'miasto',
            'country' => 'kraj', 'address' => 'adres', 'postal' => 'pocztowy',
            'date' => 'data', 'year' => 'rok',
            'company' => 'przedsiębiorstwo', 'title' => 'tytuł',
            'description' => 'opis', 'summary' => 'streszczenie',
            'product' => 'produkt', 'price' => 'cena', 'discount' => 'zniżka',
            'weight' => 'waga', 'height' => 'wysokość',
            'duration' => 'czas', 'experience' => 'doświadczenie',
            'password' => 'hasło',
        ],
        'ru' => [
            'name' => 'имя', 'birth' => 'рождения', 'gender' => 'пол',
            'phone' => 'телефон', 'street' => 'улица', 'city' => 'город',
            'country' => 'страна', 'address' => 'адрес',
            'date' => 'дата', 'year' => 'год',
            'company' => 'компания', 'title' => 'название',
            'description' => 'описание',
            'product' => 'продукт', 'price' => 'цена', 'discount' => 'скидка',
            'weight' => 'вес', 'height' => 'рост',
            'salary' => 'зарплата', 'experience' => 'опыт',
            'password' => 'пароль',
        ],
    ];

    /**
     * Check if a field name indicates a logo-type image field.
     *
     * Used by AbstractFieldPluginAdapter to decide between
     * regular image generation and LogoService.
     */
    public static function isLogoField(string $fieldName): bool
    {
        $patterns = self::PATTERNS['logo'] ?? [];
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $fieldName)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Translate English field name tokens to the target locale.
     *
     * Tokenizes the field name (splits on _, -, ., spaces) and translates
     * each token individually using the WORD_TRANSLATIONS dictionary.
     * Returns translated tokens that can be matched against locale-specific patterns.
     *
     * @param string $fieldName The English field name (e.g. "date_of_birth")
     * @param string $locale The target locale (e.g. "de_DE")
     * @return string[] Translated tokens (e.g. ["datum", "geburt"])
     */
    protected function translateTokens(string $fieldName, string $locale): array
    {
        // Extract language prefix (de_DE → de, fr_FR → fr)
        $lang = strtolower(substr($locale, 0, 2));

        if (!isset(self::WORD_TRANSLATIONS[$lang])) {
            return [];
        }

        $dictionary = self::WORD_TRANSLATIONS[$lang];

        // Tokenize: split on _, -, ., spaces
        $tokens = preg_split('/[_\-.\s]+/', strtolower($fieldName), -1, PREG_SPLIT_NO_EMPTY);

        $translated = [];
        foreach ($tokens as $token) {
            if (isset($dictionary[$token])) {
                $translated[] = $dictionary[$token];
            }
        }

        return $translated;
    }

    /**
     * Faker service instance
     */
    protected FakerService $faker;

    /**
     * Constructor
     *
     * @param FakerService|null $faker
     * @param AiProviderInterface|null $aiProvider Optional AI provider for fallback detection
     */
    public function __construct(?FakerService $faker = null, ?AiProviderInterface $aiProvider = null)
    {
        $this->faker = $faker ?? new FakerService();
        $this->aiProvider = $aiProvider ?? AiProviderFactory::getProvider();
    }

    /**
     * Detect the field type from field name and generate appropriate value
     *
     * @param string $fieldName The field name to analyze
     * @param array $fieldConfig Optional field configuration for additional context
     * @param string|null $locale Optional locale for localized data
     * @return mixed|null The generated value, or null if no pattern matched
     */
    public function detectAndGenerate(string $fieldName, array $fieldConfig = [], ?string $locale = null): mixed
    {
        // First try pattern-based detection (with locale-aware translation)
        $detectedType = $this->detectType($fieldName, $fieldConfig, $locale);

        // If pattern matching fails, try AI detection as fallback
        if (!$detectedType && $this->aiProvider && $this->aiProvider->isAvailable()) {
            $detectedType = $this->detectTypeWithAi($fieldName, $fieldConfig, $locale);
        }

        if (!$detectedType) {
            return null;
        }

        return $this->generateForType($detectedType, $fieldConfig, $locale);
    }

    /**
     * Detect field type and generate value using pattern matching only (no AI)
     *
     * Same as detectAndGenerate() but skips the Gemini single-field fallback.
     * Used when batch AI detection handles all AI calls separately.
     *
     * @param string $fieldName The field name to analyze
     * @param array $fieldConfig Optional field configuration for additional context
     * @param string|null $locale Optional locale for localized data
     * @return mixed|null The generated value, or null if no pattern matched
     */
    public function detectAndGenerateWithoutAi(string $fieldName, array $fieldConfig = [], ?string $locale = null): mixed
    {
        $detectedType = $this->detectType($fieldName, $fieldConfig, $locale);

        if (!$detectedType) {
            return null;
        }

        return $this->generateForType($detectedType, $fieldConfig, $locale);
    }

    /**
     * Detect field type using AI (Gemini)
     *
     * @param string $fieldName
     * @param array $fieldConfig
     * @param string|null $locale
     * @return string|null
     */
    protected function detectTypeWithAi(string $fieldName, array $fieldConfig, ?string $locale): ?string
    {
        $fieldLabel = $fieldConfig['label'] ?? '';
        $fieldType = $fieldConfig['type'] ?? 'text';

        $result = $this->aiProvider->detectFieldType($fieldName, $fieldLabel, $fieldType, $locale);

        if ($result && !empty($result['type'])) {
            // Only use AI result if confidence is high enough
            $confidence = $result['confidence'] ?? 0;
            if ($confidence >= 0.7) {
                return $result['type'];
            }
        }

        return null;
    }

    /**
     * Detect the type from field name
     *
     * @param string $fieldName
     * @param array $fieldConfig
     * @param string|null $locale Optional locale for translation-enhanced matching
     * @return string|null
     */
    public function detectType(string $fieldName, array $fieldConfig = [], ?string $locale = null): ?string
    {
        // Check field label first if available (often more descriptive)
        $label = $fieldConfig['label'] ?? '';
        $searchStrings = [$fieldName, $label];

        // Context rules first — disambiguate generic names (category, role, name)
        // using parent field hierarchy. Uses exact field name matching so compound
        // names like first_name fall through to PATTERNS.
        $fieldPath = $fieldConfig['field_path'] ?? [];
        if (!empty($fieldPath) && count($fieldPath) > 1) {
            $contextResult = $this->detectWithFieldPath($fieldName, $fieldPath);
            if ($contextResult) {
                return $contextResult;
            }
        }

        // Translate English field name tokens to locale language
        if ($locale) {
            $translatedTokens = $this->translateTokens($fieldName, $locale);
            foreach ($translatedTokens as $token) {
                $searchStrings[] = $token;
            }
        }

        foreach (self::PATTERNS as $type => $patterns) {
            foreach ($patterns as $pattern) {
                foreach ($searchStrings as $search) {
                    if (preg_match($pattern, $search)) {
                        return $type;
                    }
                }
            }
        }

        // If no pattern matched, try CPT context disambiguation
        $contextType = $this->detectWithCptContext($fieldName, $label);
        if ($contextType) {
            return $contextType;
        }

        return null;
    }

    /**
     * Try to detect field type using parent field path context.
     * Scores each CONTEXT_RULES entry against the field path.
     * The rule with the highest score wins (most matching context tokens).
     */
    protected function detectWithFieldPath(string $fieldName, array $fieldPath): ?string
    {
        $contextTokens = array_map('strtolower', array_slice($fieldPath, 0, -1));
        $fieldLower = strtolower($fieldName);

        // Split compound field names without separators (e.g. "rolecharacter" → ["role", "character"])
        // Only used as fallback when exact matching fails
        $fieldParts = $this->splitCompoundName($fieldLower);

        $bestMatch = null;
        $bestScore = 0;

        foreach (self::CONTEXT_RULES as $rule) {
            // Field token must match exactly first
            $fieldMatches = false;
            foreach ($rule['field'] as $token) {
                if ($fieldLower === $token) {
                    $fieldMatches = true;
                    break;
                }
            }

            // Fallback: check if any part of a compound name matches
            if (!$fieldMatches && count($fieldParts) > 1) {
                foreach ($rule['field'] as $token) {
                    if (in_array($token, $fieldParts, true)) {
                        $fieldMatches = true;
                        break;
                    }
                }
            }

            if (!$fieldMatches) {
                continue;
            }

            // Score by counting matching context tokens (check each path segment individually
            // to avoid substring false positives, e.g. "item" matching "limited")
            $score = 0;
            foreach ($rule['context'] as $token) {
                foreach ($contextTokens as $segment) {
                    if (str_contains($segment, $token)) {
                        $score++;
                        break; // count each context token at most once
                    }
                }
            }

            if ($score > $bestScore) {
                $bestScore = $score;
                $bestMatch = $rule['type'];
            }
        }

        return $bestMatch;
    }

    /**
     * Split a compound field name into parts using camelCase boundaries
     * and known word boundaries. E.g. "rolecharacter" → ["role", "character"],
     * "firstName" → ["first", "name"]
     */
    protected function splitCompoundName(string $name): array
    {
        // Already has separators — split on them
        if (preg_match('/[_\-\s]/', $name)) {
            return preg_split('/[_\-\s]+/', $name);
        }

        // Split camelCase
        $parts = preg_split('/(?<=[a-z])(?=[A-Z])/', $name);
        if (count($parts) > 1) {
            return array_map('strtolower', $parts);
        }

        // Try known word boundaries for concatenated lowercase names
        $knownWords = ['role', 'character', 'name', 'title', 'category', 'year', 'date', 'type', 'status', 'price', 'count', 'email', 'phone', 'address', 'city', 'country', 'first', 'last', 'full', 'birth', 'start', 'end'];
        // Sort by length descending to match longer words first
        usort($knownWords, fn($a, $b) => strlen($b) - strlen($a));

        $remaining = $name;
        $result = [];
        while ($remaining !== '') {
            $matched = false;
            foreach ($knownWords as $word) {
                if (str_starts_with($remaining, $word)) {
                    $result[] = $word;
                    $remaining = substr($remaining, strlen($word));
                    $matched = true;
                    break;
                }
            }
            if (!$matched) {
                // Can't split further — return original as single element
                return [$name];
            }
        }

        return count($result) > 1 ? $result : [$name];
    }

    /**
     * Try to detect field type using CPT context when pattern matching is ambiguous
     *
     * For example: a field "name" in a product CPT → product_name,
     * but "name" in a team CPT → full_name
     */
    protected function detectWithCptContext(string $fieldName, string $label): ?string
    {
        if (!$this->cptSlug) {
            return null;
        }

        $cptContext = $this->getCptDomain();
        if (!$cptContext) {
            return null;
        }

        $search = strtolower($fieldName);

        // Disambiguation rules based on CPT domain
        return match (true) {
            // "name" in product context → product_name
            $cptContext === 'product' && preg_match('/name/i', $search) => 'product_name',
            // "name" in person context → full_name
            $cptContext === 'person' && preg_match('/name/i', $search) => 'full_name',
            // "name" in event context → event_name
            $cptContext === 'event' && preg_match('/name/i', $search) => 'event_name',
            // "nummer/number" in product context → sku
            $cptContext === 'product' && preg_match('/nummer|number/i', $search) => 'sku',
            // Vehicle context: "model/modell" → vehicle_model
            $cptContext === 'vehicle' && preg_match('/model|modell/i', $search) => 'vehicle_model',
            // Vehicle context: "marke/make/brand" → vehicle_make
            $cptContext === 'vehicle' && preg_match('/make|marke|brand|hersteller/i', $search) => 'vehicle_make',
            // Vehicle context: "farbe/color" → color_name
            $cptContext === 'vehicle' && preg_match('/colou?r|farbe/i', $search) => 'color_name',
            // Vehicle context: "title/titel" → listing_title
            $cptContext === 'vehicle' && preg_match('/title|titel/i', $search) => 'listing_title',

            // Service context
            $cptContext === 'service' && preg_match('/name/i', $search) => 'title',
            $cptContext === 'service' && preg_match('/rate|preis|price/i', $search) => 'price',

            // Media context
            $cptContext === 'media' && preg_match('/name|title|titel/i', $search) => 'title',
            $cptContext === 'media' && preg_match('/number|nummer|no$/i', $search) => 'episode_number',
            $cptContext === 'media' && preg_match('/length|länge|dauer/i', $search) => 'duration',

            // Directory context
            $cptContext === 'directory' && preg_match('/name/i', $search) => 'company',
            $cptContext === 'directory' && preg_match('/typ|type|art/i', $search) => 'reference_code',

            // FAQ context
            $cptContext === 'faq' && preg_match('/answer|antwort|réponse|respuesta/i', $search) => 'content',

            // Coupon context
            $cptContext === 'coupon' && preg_match('/code/i', $search) => 'coupon_code',
            $cptContext === 'coupon' && preg_match('/value|wert|betrag/i', $search) => 'discount',
            $cptContext === 'coupon' && preg_match('/type|typ|art/i', $search) => 'reference_code',

            // Case study context
            $cptContext === 'case_study' && preg_match('/name|client|kunde/i', $search) => 'company',
            $cptContext === 'case_study' && preg_match('/result|ergebnis/i', $search) => 'description',

            // Partner context
            $cptContext === 'partner' && preg_match('/name/i', $search) => 'company',
            $cptContext === 'partner' && preg_match('/level|stufe|tier/i', $search) => 'reference_code',

            // Slide context
            $cptContext === 'slide' && preg_match('/name|title|titel/i', $search) => 'title',

            // Press context
            $cptContext === 'press' && preg_match('/name|source|quelle/i', $search) => 'company',
            $cptContext === 'press' && preg_match('/date|datum/i', $search) => 'date',

            default => null,
        };
    }

    /**
     * Determine the CPT domain from slug and label
     */
    protected function getCptDomain(): ?string
    {
        $searchIn = strtolower(($this->cptSlug ?? '') . ' ' . ($this->cptLabel ?? ''));

        foreach (self::CPT_CONTEXT_MAP as $domain => $keywords) {
            foreach ($keywords as $keyword) {
                // Use word-boundary regex to prevent partial matches
                // e.g. 'network' must not match keyword 'work'
                // /iu flags: case-insensitive + Unicode support (Cyrillic, CJK)
                if (preg_match('/\b' . preg_quote($keyword, '/') . '\b/iu', $searchIn)) {
                    return $domain;
                }
            }
        }

        // Fallback: use AI-generated CPT context domain
        if ($this->cptContextData && !empty($this->cptContextData['domain'])) {
            return $this->cptContextData['domain'];
        }

        return null;
    }

    /**
     * Generate a value for the detected type
     *
     * @param string $type The detected type
     * @param array $fieldConfig Field configuration
     * @param string|null $locale Locale for localized data
     * @return mixed
     */
    public function generateForType(string $type, array $fieldConfig = [], ?string $locale = null): mixed
    {
        $faker = $locale ? $this->faker->forLocale($locale) : $this->faker->getInstance();

        return match ($type) {
            // Banking & Financial
            'iban' => $faker->iban('DE'),
            'bic' => $faker->swiftBicNumber(),
            'bank_name' => $this->generateBankName($locale),
            'credit_card' => $faker->creditCardNumber(),

            // Product / E-Commerce
            'product_name' => $this->generateProductName($locale),
            'sku' => strtoupper($faker->bothify('??-####-???')),
            'brand' => $faker->company(),
            'model' => $faker->bothify('Model ??-####'),
            'ean' => $faker->ean13(),
            'isbn' => $faker->isbn13(),
            'rating' => $faker->randomFloat(1, 1, 5),
            'stock' => $faker->numberBetween(0, 500),
            'discount' => $faker->randomFloat(0, 5, 50),

            // Coupon / Commerce
            'coupon_code' => $this->generateCouponCode(),
            'expiration_date' => date('Y-m-d', strtotime('+' . rand(30, 365) . ' days')),
            'minimum_spend' => $faker->randomFloat(2, 10, 200),
            'usage_limit' => $faker->numberBetween(1, 1000),

            // Specific Titles/Names
            'event_name' => $this->generateEventName($locale),
            'project_name' => $this->generateProjectName($locale),

            // Media / Content
            'genre' => $this->generateGenre($locale),
            'plot' => $this->localeParagraphs($faker, rand(1, 3)),
            'director' => $faker->name(),
            'episode_number' => $faker->numberBetween(1, 300),
            'season_number' => $faker->numberBetween(1, 20),
            'audio_url' => 'https://example.com/audio/' . $faker->slug(3) . '.mp3',
            'video_url' => 'https://www.youtube.com/watch?v=' . $faker->bothify('???????????'),
            'award_name' => $faker->randomElement([
                'Academy Award', 'Golden Globe', 'BAFTA Award', 'Emmy Award', 'Screen Actors Guild Award',
                'Cannes Film Festival Award', 'Sundance Film Festival Award', 'Venice Film Festival Award',
                'Berlin International Film Festival Award', 'Critics\' Choice Award',
                'Tony Award', 'Grammy Award', 'Pulitzer Prize', 'National Book Award',
            ]),
            'award_category' => $faker->randomElement([
                'Best Picture', 'Best Director', 'Best Actor', 'Best Actress',
                'Best Supporting Actor', 'Best Supporting Actress', 'Best Original Screenplay',
                'Best Adapted Screenplay', 'Best Cinematography', 'Best Film Editing',
                'Best Original Score', 'Best Visual Effects', 'Best Costume Design',
                'Best Production Design', 'Best Sound', 'Best Animated Feature',
            ]),
            'character_name' => $faker->randomElement([
                'Jack Dawson', 'Ellen Ripley', 'Forrest Gump', 'Clarice Starling',
                'Tony Montana', 'Vito Corleone', 'Sarah Connor', 'Indiana Jones',
                'Holly Golightly', 'Tyler Durden', 'Mia Wallace', 'Han Solo',
                'Hermione Granger', 'Gandalf', 'Katniss Everdeen', 'Darth Vader',
                'James Bond', 'Lara Croft', 'Neo', 'Morpheus',
            ]),
            'product_category' => $faker->randomElement([
                'Electronics', 'Clothing', 'Home & Garden', 'Sports', 'Books',
                'Toys', 'Health & Beauty', 'Automotive', 'Food & Beverages',
                'Office Supplies', 'Pet Supplies', 'Jewelry', 'Outdoor',
            ]),
            'ingredient' => $faker->randomElement([
                'flour', 'sugar', 'butter', 'eggs', 'milk', 'salt', 'pepper',
                'olive oil', 'garlic', 'onion', 'tomatoes', 'cheese', 'cream',
                'chicken', 'rice', 'pasta', 'basil', 'oregano', 'lemon juice',
            ]),
            'ingredient_amount' => $faker->randomElement([
                '1 cup', '2 tbsp', '1/2 tsp', '3 cloves', '200g', '1 lb',
                '250ml', '1 pinch', '2 pieces', '100g', '1/4 cup', '3 oz',
            ]),
            'play_count' => $faker->numberBetween(100, 1000000),
            'transcript' => $this->localeParagraphs($faker, rand(2, 4)),

            // Presentation / Slides
            'button_text' => $faker->randomElement(['Learn More', 'Get Started', 'Read More', 'Sign Up', 'Buy Now', 'Contact Us', 'Download', 'Subscribe']),
            'button_url' => 'https://' . $faker->domainName() . '/' . $faker->slug(2),
            'subtitle' => $this->localeSentence($faker, rand(40, 80)),
            'badge_text' => $faker->randomElement(['New', 'Hot', 'Sale', 'Featured', 'Popular', 'Best', 'Top', 'Premium']),

            // Service / Business
            'service_area' => $faker->city() . ' + ' . $faker->numberBetween(10, 100) . ' km',
            'availability' => $faker->randomElement(['Available', 'Unavailable', 'Limited', 'On Request', 'Coming Soon']),
            'booking_url' => 'https://' . $faker->domainName() . '/book',

            // Personal Information
            'first_name' => $faker->firstName(),
            'last_name' => $faker->lastName(),
            'full_name' => $faker->name(),
            'salutation' => $this->generateSalutation($locale),
            'gender' => $faker->randomElement(['male', 'female', 'other']),
            'birthday' => $faker->date('Y-m-d', '-18 years'),
            'age' => $faker->numberBetween(18, 80),

            // Contact Information
            'email' => $faker->safeEmail(),
            'phone' => $faker->phoneNumber(),
            'website' => $faker->url(),

            // Address
            'street' => $faker->streetName(),
            'house_number' => (string) $faker->buildingNumber(),
            'postal_code' => $faker->postcode(),
            'city' => $faker->city(),
            'state' => $this->generateState($locale),
            'country' => $faker->country(),
            'address' => $faker->address(),
            'latitude' => (string) $faker->latitude(),
            'longitude' => (string) $faker->longitude(),

            // Food / Nutrition
            'calories' => $faker->numberBetween(50, 1200),
            'ingredients' => implode(', ', $faker->words(rand(5, 12))),
            'allergens' => $faker->randomElement(['Gluten', 'Dairy', 'Nuts', 'Eggs', 'Soy', 'Fish', 'Shellfish', 'Wheat', 'None']),
            'prep_time' => $faker->numberBetween(5, 60) . ' min',
            'cook_time' => $faker->numberBetween(10, 120) . ' min',
            'servings' => $faker->numberBetween(1, 12),
            'nutrition_info' => $this->generateNutritionInfo($faker),
            'cuisine_type' => $faker->randomElement(['Italian', 'French', 'Chinese', 'Japanese', 'Indian', 'Mexican', 'Thai', 'Mediterranean', 'American', 'German']),

            // Location / Directory
            'opening_hours' => $this->generateOpeningHours(),
            'coordinates' => $faker->latitude() . ', ' . $faker->longitude(),
            'wheelchair_accessible' => $faker->randomElement(['yes', 'no']),
            'parking' => $faker->randomElement(['Free parking', 'Paid parking', 'Street parking', 'Garage', 'No parking', 'Valet']),

            // Company
            'company' => $faker->company(),
            'company_suffix' => $faker->companySuffix(),
            'job_title' => $faker->jobTitle(),
            'department' => $this->generateDepartment($locale),
            'vat_number' => $this->generateVatNumber($locale),

            // Internet & Tech
            'username' => $faker->userName(),
            'password' => $faker->password(12, 20),
            'ip_address' => $faker->ipv4(),
            'mac_address' => $faker->macAddress(),
            'uuid' => $faker->uuid(),
            'slug' => $faker->slug(3),

            // Dates & Times
            'date' => date('Y-m-d', rand(strtotime('-1 year'), time())),
            'time' => $faker->time('H:i'),
            'year' => (string) $faker->year(),

            // Measurements & Numbers
            'price' => $faker->randomFloat(2, 100, 10000),
            'percentage' => $faker->randomFloat(1, 0, 100),
            'area' => $faker->randomFloat(1, 20, 500),
            'weight' => $faker->randomFloat(1, 1, 1000),
            'height' => $faker->randomFloat(2, 0.5, 10),
            'width' => $faker->randomFloat(2, 0.5, 20),
            'length' => $faker->randomFloat(2, 0.5, 50),
            'count' => $faker->numberBetween(1, 100),
            'floor' => $faker->numberBetween(-2, 30),
            'rooms' => $faker->numberBetween(1, 10),

            // Vehicle / Automotive
            'vehicle_model' => $this->generateVehicleModel(),
            'vehicle_make' => $this->generateVehicleMake(),
            'license_plate' => $this->generateLicensePlate($locale),
            'vin' => $this->generateVinNumber(),
            'color_name' => $this->generateColorName($locale),
            'listing_title' => $this->generateListingTitle($locale),

            // Real Estate Specific
            'object_number' => $this->generateObjectNumber(),
            'commission' => $this->generateCommission($locale),
            'energy_class' => $faker->randomElement(['A+', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']),
            'heating_type' => $this->generateHeatingType($locale),

            // Event-specific
            'event_date' => date('Y-m-d', strtotime('+' . rand(1, 365) . ' days')),
            'venue' => $faker->company() . ' ' . $faker->randomElement(['Arena', 'Center', 'Hall', 'Stadium', 'Theater', 'Convention Center', 'Auditorium']),
            'organizer' => $faker->company(),
            'duration' => rand(1, 8) . 'h ' . $faker->randomElement(['00', '15', '30', '45']) . 'min',
            'capacity' => (string) $faker->numberBetween(10, 5000),

            // Education-specific
            'instructor' => $faker->name(),
            'curriculum' => implode(', ', $faker->words(rand(3, 8))),

            // Job-specific
            'salary' => $this->generateSalaryRange($faker),
            'experience' => rand(1, 15) . '+ years',
            'qualification' => $faker->randomElement(['Bachelor', 'Master', 'PhD', 'MBA', 'Certificate', 'Diploma', 'Associate']),

            // Text Content (locale-aware via realText with Lorem fallback)
            'title' => $this->localeSentence($faker, rand(30, 60)),
            'description' => $this->localeParagraphs($faker, rand(2, 4)),
            'summary' => $this->localeText($faker, rand(100, 200)),
            'notes' => $this->localeText($faker, rand(60, 150)),
            'content' => $this->localeParagraphs($faker, rand(3, 6)),

            // IDs & Codes
            'reference_code' => strtoupper($faker->bothify('???-#####')),

            default => null,
        };
    }

    /**
     * Generate locale-aware text (paragraph-length) with fallback to Lorem
     *
     * Tries realText() first for natural-sounding text in the current locale.
     * Falls back to Lorem-based paragraph() if realText is not available.
     *
     * @param \Faker\Generator $faker The Faker generator instance
     * @param int $maxChars Maximum number of characters
     * @return string
     */
    protected function localeText(\Faker\Generator $faker, int $maxChars = 200): string
    {
        if (FakerService::getTextSource() === 'lorem') {
            $wordCount = max(3, (int) ($maxChars / 6));
            $sentenceCount = max(1, (int) ($wordCount / 8));
            return $faker->paragraph($sentenceCount);
        }

        try {
            return $faker->realText(max($maxChars, 10));
        } catch (\InvalidArgumentException $e) {
            // Approximate word count from char count (avg ~6 chars per word)
            $wordCount = max(3, (int) ($maxChars / 6));
            $sentenceCount = max(1, (int) ($wordCount / 8));
            return $faker->paragraph($sentenceCount);
        }
    }

    /**
     * Generate locale-aware sentence (title-length) with fallback to Lorem
     *
     * Tries realText() first and strips trailing punctuation for cleaner titles.
     * Falls back to Lorem-based sentence() if realText is not available.
     *
     * @param \Faker\Generator $faker The Faker generator instance
     * @param int $maxChars Maximum number of characters
     * @return string
     */
    protected function localeSentence(\Faker\Generator $faker, int $maxChars = 50): string
    {
        if (FakerService::getTextSource() === 'lorem') {
            $wordCount = max(3, (int) ($maxChars / 7));
            return $faker->sentence($wordCount);
        }

        try {
            $text = $faker->realText(max($maxChars, 10));
            return rtrim($text, '.!?…');
        } catch (\InvalidArgumentException $e) {
            $wordCount = max(3, (int) ($maxChars / 7));
            return $faker->sentence($wordCount);
        }
    }

    /**
     * Generate locale-aware multi-paragraph text with fallback to Lorem
     *
     * Generates multiple realText() paragraphs joined with double newlines.
     * Falls back to Lorem-based paragraphs() if realText is not available.
     *
     * @param \Faker\Generator $faker The Faker generator instance
     * @param int $count Number of paragraphs
     * @return string
     */
    protected function localeParagraphs(\Faker\Generator $faker, int $count = 3): string
    {
        if (FakerService::getTextSource() === 'lorem') {
            return implode("\n\n", $faker->paragraphs($count));
        }

        try {
            $paragraphs = [];
            for ($i = 0; $i < $count; $i++) {
                $paragraphs[] = $faker->realText(rand(100, 300));
            }
            return implode("\n\n", $paragraphs);
        } catch (\InvalidArgumentException $e) {
            return implode("\n\n", $faker->paragraphs($count));
        }
    }

    /**
     * Generate locale-aware words (for project names etc.) with fallback to Lorem
     *
     * Tries realText() and extracts individual words from it.
     * Falls back to Lorem-based words() if realText is not available.
     *
     * @param \Faker\Generator $faker The Faker generator instance
     * @param int $count Number of words to generate
     * @return array
     */
    protected function localeWords(\Faker\Generator $faker, int $count = 3): array
    {
        try {
            $text = $faker->realText(max($count * 10, 20));
            // Strip punctuation and split into words
            $text = preg_replace('/[^\p{L}\p{N}\s]/u', '', $text);
            $words = array_values(array_filter(preg_split('/\s+/', $text)));
            // Return the requested number of words, or fewer if not enough
            return array_slice($words, 0, $count) ?: $faker->words($count);
        } catch (\InvalidArgumentException $e) {
            return $faker->words($count);
        }
    }

    /**
     * Generate a German bank name
     */
    protected function generateBankName(?string $locale): string
    {
        $germanBanks = [
            'Deutsche Bank', 'Commerzbank', 'Sparkasse', 'Volksbank',
            'Raiffeisenbank', 'ING-DiBa', 'DKB', 'Postbank',
            'HypoVereinsbank', 'Santander', 'Targobank', 'Sparda-Bank',
            'PSD Bank', 'Comdirect', 'N26', 'Consorsbank',
        ];

        return $germanBanks[array_rand($germanBanks)];
    }

    /**
     * Generate salutation based on locale
     */
    protected function generateSalutation(?string $locale): string
    {
        if ($locale && str_starts_with($locale, 'de')) {
            return $this->faker->getInstance()->randomElement(['Herr', 'Frau']);
        }

        return $this->faker->getInstance()->randomElement(['Mr.', 'Mrs.', 'Ms.', 'Dr.']);
    }

    /**
     * Generate state/region based on locale
     */
    protected function generateState(?string $locale): string
    {
        if ($locale && str_starts_with($locale, 'de')) {
            $states = [
                'Baden-Württemberg', 'Bayern', 'Berlin', 'Brandenburg',
                'Bremen', 'Hamburg', 'Hessen', 'Mecklenburg-Vorpommern',
                'Niedersachsen', 'Nordrhein-Westfalen', 'Rheinland-Pfalz',
                'Saarland', 'Sachsen', 'Sachsen-Anhalt', 'Schleswig-Holstein', 'Thüringen',
            ];
            return $states[array_rand($states)];
        }

        return $this->faker->getInstance()->state ?? $this->faker->getInstance()->city();
    }

    /**
     * Generate department name
     */
    protected function generateDepartment(?string $locale): string
    {
        if ($locale && str_starts_with($locale, 'de')) {
            $departments = [
                'Vertrieb', 'Marketing', 'Buchhaltung', 'Personalabteilung',
                'IT', 'Kundenservice', 'Einkauf', 'Produktion',
                'Forschung & Entwicklung', 'Qualitätsmanagement',
            ];
            return $departments[array_rand($departments)];
        }

        $departments = [
            'Sales', 'Marketing', 'Accounting', 'Human Resources',
            'IT', 'Customer Service', 'Procurement', 'Production',
            'Research & Development', 'Quality Management',
        ];
        return $departments[array_rand($departments)];
    }

    /**
     * Generate VAT number
     */
    protected function generateVatNumber(?string $locale): string
    {
        if ($locale && str_starts_with($locale, 'de')) {
            return 'DE' . $this->faker->getInstance()->numerify('#########');
        }

        return $this->faker->getInstance()->bothify('??#########');
    }

    /**
     * Generate object/reference number
     */
    protected function generateObjectNumber(): string
    {
        $prefixes = ['OBJ', 'IMM', 'REF', 'ID'];
        $prefix = $prefixes[array_rand($prefixes)];
        return $prefix . '-' . $this->faker->getInstance()->numerify('######');
    }

    /**
     * Generate commission text
     */
    protected function generateCommission(?string $locale): string
    {
        $percentage = $this->faker->getInstance()->randomFloat(2, 2.5, 7.14);

        if ($locale && str_starts_with($locale, 'de')) {
            return number_format($percentage, 2, ',', '.') . '% inkl. MwSt.';
        }

        return number_format($percentage, 2) . '% incl. VAT';
    }

    /**
     * Generate heating type
     */
    protected function generateHeatingType(?string $locale): string
    {
        if ($locale && str_starts_with($locale, 'de')) {
            $types = [
                'Zentralheizung', 'Gasheizung', 'Ölheizung', 'Fernwärme',
                'Wärmepumpe', 'Fußbodenheizung', 'Elektroheizung', 'Pelletheizung',
            ];
            return $types[array_rand($types)];
        }

        $types = [
            'Central heating', 'Gas heating', 'Oil heating', 'District heating',
            'Heat pump', 'Underfloor heating', 'Electric heating', 'Pellet heating',
        ];
        return $types[array_rand($types)];
    }

    /**
     * Generate a product name using Faker (locale-aware)
     *
     * Combines a Faker-generated company name fragment with a short word
     * to produce something that looks like a product name in any locale.
     */
    protected function generateProductName(?string $locale): string
    {
        $faker = $locale ? $this->faker->forLocale($locale) : $this->faker->getInstance();

        // Use company() as base — Faker localizes this per locale
        // Then trim to just the first word(s) as a "brand prefix"
        $brand = explode(' ', $faker->company())[0];

        // Append a model-like suffix for product feel
        $suffix = $faker->bothify('??-####');

        return $brand . ' ' . strtoupper($suffix);
    }

    /**
     * Generate a locale-aware genre name (film/music/book genres)
     */
    protected function generateGenre(?string $locale): string
    {
        $lang = $locale ? substr($locale, 0, 2) : 'en';

        $genres = match ($lang) {
            'de' => ['Action', 'Abenteuer', 'Animation', 'Komödie', 'Krimi', 'Dokumentarfilm', 'Drama', 'Fantasy', 'Horror', 'Musical', 'Mystery', 'Romanze', 'Science-Fiction', 'Thriller', 'Western', 'Kriegsfilm', 'Familienfilm', 'Historienfilm'],
            'fr' => ['Action', 'Aventure', 'Animation', 'Comédie', 'Crime', 'Documentaire', 'Drame', 'Fantaisie', 'Horreur', 'Musical', 'Mystère', 'Romance', 'Science-fiction', 'Thriller', 'Western', 'Guerre', 'Familial', 'Historique'],
            'es' => ['Acción', 'Aventura', 'Animación', 'Comedia', 'Crimen', 'Documental', 'Drama', 'Fantasía', 'Horror', 'Musical', 'Misterio', 'Romance', 'Ciencia ficción', 'Suspense', 'Western', 'Bélico', 'Familiar', 'Histórico'],
            default => ['Action', 'Adventure', 'Animation', 'Comedy', 'Crime', 'Documentary', 'Drama', 'Fantasy', 'Horror', 'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Thriller', 'Western', 'War', 'Family', 'Historical'],
        };

        $faker = $locale ? $this->faker->forLocale($locale) : $this->faker->getInstance();
        return $faker->randomElement($genres);
    }

    /**
     * Generate an event name using Faker (locale-aware)
     *
     * Uses realText() for locale-aware event titles with Lorem fallback.
     */
    protected function generateEventName(?string $locale): string
    {
        $faker = $locale ? $this->faker->forLocale($locale) : $this->faker->getInstance();

        // Generate a short title-like phrase using locale-aware text
        $title = $this->localeSentence($faker, rand(25, 45));

        // Append a year to give it an event feel
        $year = $faker->year();

        return $title . ' ' . $year;
    }

    /**
     * Generate a project name using Faker (locale-aware)
     *
     * Uses realText()-derived words for locale-aware project titles with Lorem fallback.
     */
    protected function generateProjectName(?string $locale): string
    {
        $faker = $locale ? $this->faker->forLocale($locale) : $this->faker->getInstance();

        // Combine locale-aware words into a project-like title
        $words = $this->localeWords($faker, rand(2, 3));
        $title = implode(' ', array_map('ucfirst', $words));

        // Add a version-like suffix for project feel
        $version = $faker->randomFloat(1, 1, 5);

        return $title . ' ' . $version;
    }

    /**
     * Generate a VIN (Vehicle Identification Number)
     * 17 alphanumeric characters, excluding I, O, Q per ISO 3779
     */
    protected function generateVinNumber(): string
    {
        $chars = 'ABCDEFGHJKLMNPRSTUVWXYZ0123456789';
        $vin = '';
        for ($i = 0; $i < 17; $i++) {
            $vin .= $chars[rand(0, strlen($chars) - 1)];
        }
        return $vin;
    }

    /**
     * Generate a license plate number
     */
    protected function generateLicensePlate(?string $locale): string
    {
        $faker = $this->faker->getInstance();

        if ($locale && str_starts_with($locale, 'de')) {
            $cities = ['B', 'M', 'HH', 'K', 'F', 'S', 'D', 'DO', 'E', 'N', 'DD', 'L', 'HB', 'H', 'KA', 'MA', 'FR'];
            return $cities[array_rand($cities)] . ' ' . strtoupper($faker->bothify('?? ####'));
        }

        return strtoupper($faker->bothify('??? ####'));
    }

    /**
     * Generate a vehicle model name
     */
    protected function generateVehicleModel(): string
    {
        $models = [
            '320d', '520i', 'X3', 'X5', 'M3', 'M5',
            'A3', 'A4', 'A6', 'Q5', 'Q7', 'RS6',
            'C 200', 'E 300', 'GLC 250', 'S 500', 'GLE 350',
            'Golf', 'Passat', 'Tiguan', 'Polo', 'T-Roc', 'ID.4',
            'Corsa', 'Astra', 'Mokka', 'Insignia',
            '911', 'Cayenne', 'Macan', 'Taycan',
            'Yaris', 'Corolla', 'RAV4', 'Camry', 'Supra',
            'Civic', 'CR-V', 'Jazz', 'HR-V',
            'i30', 'Tucson', 'Kona', 'Ioniq 5',
            'Ceed', 'Sportage', 'Niro', 'EV6',
            '3', 'CX-5', 'MX-5', 'CX-30',
            'Model 3', 'Model Y', 'Model S', 'Model X',
            'Octavia', 'Superb', 'Kodiaq', 'Enyaq',
        ];

        return $models[array_rand($models)];
    }

    /**
     * Generate a vehicle make/manufacturer name
     */
    protected function generateVehicleMake(): string
    {
        $makes = [
            'BMW', 'Mercedes-Benz', 'Audi', 'Volkswagen', 'Porsche', 'Opel',
            'Ford', 'Toyota', 'Honda', 'Hyundai', 'Kia', 'Mazda',
            'Volvo', 'Skoda', 'Renault', 'Peugeot', 'Tesla', 'Fiat',
            'Nissan', 'Jeep',
        ];

        return $makes[array_rand($makes)];
    }

    /**
     * Generate a color name (vehicle/product context)
     */
    protected function generateColorName(?string $locale): string
    {
        if ($locale && str_starts_with($locale, 'de')) {
            $colors = [
                'Schwarz', 'Weiß', 'Silber', 'Grau', 'Blau', 'Rot',
                'Grün', 'Braun', 'Beige', 'Anthrazit', 'Midnight Blue',
                'Glacier White', 'Mineralgrau', 'Tiefschwarz',
            ];
            return $colors[array_rand($colors)];
        }

        $colors = [
            'Black', 'White', 'Silver', 'Grey', 'Blue', 'Red',
            'Green', 'Brown', 'Beige', 'Anthracite', 'Midnight Blue',
            'Glacier White', 'Mineral Grey', 'Deep Black',
        ];
        return $colors[array_rand($colors)];
    }

    /**
     * Generate a listing title (vehicle/classified ad context)
     */
    protected function generateListingTitle(?string $locale = null): string
    {
        $lang = $locale ? strtolower(substr($locale, 0, 2)) : 'en';

        $makes = ['BMW', 'Mercedes', 'Audi', 'VW', 'Porsche', 'Opel', 'Toyota', 'Tesla', 'Volvo', 'Hyundai'];
        $models = ['320d', 'A4', 'C 200', 'Golf', '911', 'Corsa', 'Yaris', 'Model 3', 'XC60', 'Tucson'];
        $extras = match ($lang) {
            'de' => ['Automatik', 'Navi', 'LED', 'Allrad', 'Schiebedach', 'Panorama', 'Sport', 'Leder', ''],
            'fr' => ['Automatique', 'GPS', 'LED', 'AWD', 'Toit Ouvrant', 'Panoramique', 'Sport', 'Cuir', ''],
            'es' => ['Automático', 'GPS', 'LED', 'AWD', 'Techo Solar', 'Panorámico', 'Sport', 'Cuero', ''],
            'it' => ['Automatico', 'Navigatore', 'LED', 'AWD', 'Tetto Apribile', 'Panoramico', 'Sport', 'Pelle', ''],
            default => ['Automatic', 'GPS', 'LED', 'AWD', 'Sunroof', 'Panoramic', 'Sport', 'Leather', ''],
        };

        $idx = array_rand($makes);
        $extra = $extras[array_rand($extras)];
        $year = rand(2018, (int) date('Y'));

        return $makes[$idx] . ' ' . $models[$idx] . ' ' . $year . ($extra ? ' ' . $extra : '');
    }

    /**
     * Generate a salary range string
     */
    protected function generateSalaryRange(\Faker\Generator $faker): string
    {
        $base = $faker->numberBetween(30, 120) * 1000;
        return number_format($base) . ' - ' . number_format($base + 20000);
    }

    /**
     * Generate a coupon code (alphanumeric, no hyphens)
     */
    protected function generateCouponCode(): string
    {
        $faker = $this->faker->getInstance();
        $formats = ['SAVE##', '???##OFF', 'DEAL####', '???PROMO##', 'GET##??'];
        $format = $formats[array_rand($formats)];
        return strtoupper($faker->bothify($format));
    }

    /**
     * Generate opening hours string
     */
    protected function generateOpeningHours(): string
    {
        $open = rand(6, 10);
        $close = rand(17, 22);
        return sprintf('Mon-Fri %d:00-%d:00', $open, $close);
    }

    /**
     * Generate nutrition info string
     */
    protected function generateNutritionInfo(\Faker\Generator $faker): string
    {
        return sprintf(
            'Calories: %d, Fat: %dg, Carbs: %dg, Protein: %dg, Fiber: %dg',
            $faker->numberBetween(100, 800),
            $faker->numberBetween(2, 40),
            $faker->numberBetween(10, 80),
            $faker->numberBetween(5, 50),
            $faker->numberBetween(1, 15)
        );
    }

    /**
     * Check if field name detection is enabled
     * Can be filtered by plugins/themes
     */
    public function isEnabled(): bool
    {
        return apply_filters('wpfaker_field_name_detection_enabled', true);
    }
}
