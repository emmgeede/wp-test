<?php

namespace WPFaker\Services;

use WPFaker\Generators\TaxonomyGenerator;

/**
 * Taxonomy Assignment Service
 *
 * Handles assigning taxonomies to posts based on template configuration.
 */
class TaxonomyAssignmentService
{
    /**
     * The Faker service
     *
     * @var FakerService
     */
    protected FakerService $faker;

    /**
     * The Taxonomy generator
     *
     * @var TaxonomyGenerator
     */
    protected TaxonomyGenerator $taxonomyGenerator;

    /**
     * Cache for created terms within a generation session
     *
     * @var array
     */
    protected array $createdTermsCache = [];

    /**
     * Constructor
     *
     * @param FakerService|null $faker
     * @param TaxonomyGenerator|null $taxonomyGenerator
     */
    public function __construct(?FakerService $faker = null, ?TaxonomyGenerator $taxonomyGenerator = null)
    {
        $this->faker = $faker ?? new FakerService();
        $this->taxonomyGenerator = $taxonomyGenerator ?? new TaxonomyGenerator($this->faker);
    }

    /**
     * Clear the created terms cache (call before starting a new generation batch)
     *
     * @return void
     */
    public function clearCache(): void
    {
        $this->createdTermsCache = [];
    }

    /**
     * Assign taxonomies to a post based on taxonomy configuration
     *
     * @param int $postId The post ID
     * @param array $taxonomyConfig The taxonomy configuration from template
     * @param int $postIndex Current post index (0-based)
     * @param int $totalPosts Total posts being generated
     * @return array Results with assigned terms per taxonomy
     */
    public function assignTaxonomies(int $postId, array $taxonomyConfig, int $postIndex, int $totalPosts): array
    {
        $results = [];

        foreach ($taxonomyConfig as $taxonomy => $config) {
            // Validate taxonomy exists
            if (!taxonomy_exists($taxonomy)) {
                continue;
            }

            $mode = $config['mode'] ?? 'none';

            $assignedTerms = match ($mode) {
                'choose' => $this->handleChooseMode($postId, $taxonomy, $config, $postIndex, $totalPosts),
                'create' => $this->handleCreateMode($postId, $taxonomy, $config, $postIndex),
                default  => [],
            };

            if (!empty($assignedTerms)) {
                wp_set_object_terms($postId, $assignedTerms, $taxonomy);
            }

            $results[$taxonomy] = [
                'mode'  => $mode,
                'terms' => $assignedTerms,
                'count' => count($assignedTerms),
            ];
        }

        return $results;
    }

    /**
     * Handle "choose" mode - select from existing terms
     *
     * @param int $postId
     * @param string $taxonomy
     * @param array $config
     * @param int $postIndex
     * @param int $totalPosts
     * @return array Term IDs to assign
     */
    protected function handleChooseMode(int $postId, string $taxonomy, array $config, int $postIndex, int $totalPosts): array
    {
        $selectedTerms = $config['terms'] ?? [];
        $includeNone = $config['include_none'] ?? false;
        $randomly = $config['randomly'] ?? false;
        $multiple = $config['multiple'] ?? false;
        $minTerms = (int) ($config['min_terms'] ?? 1);
        $maxTerms = (int) ($config['max_terms'] ?? 3);

        // Validate selected terms still exist
        $validTerms = $this->filterValidTerms($selectedTerms, $taxonomy);

        if (empty($validTerms)) {
            return [];
        }

        // Handle include_none - some posts get no terms
        if ($includeNone) {
            // ~20% chance of no terms, or can be configured
            $noneChance = $config['none_probability'] ?? 20;
            if (mt_rand(1, 100) <= $noneChance) {
                return [];
            }
        }

        // Determine how many terms to assign
        if ($multiple) {
            // Assign multiple terms
            $count = mt_rand($minTerms, min($maxTerms, count($validTerms)));
        } else {
            // Assign exactly one term
            $count = 1;
        }

        // Select terms based on mode
        if ($randomly) {
            // Random selection
            return $this->selectRandomTerms($validTerms, $count);
        } else {
            // Rotation mode - cycle through terms
            if ($multiple) {
                // Multiple + no random = all selected terms for each post
                return $validTerms;
            } else {
                // Single term rotation
                return $this->selectRotatingTerm($validTerms, $postIndex);
            }
        }
    }

    /**
     * Handle "create" mode - generate new terms
     *
     * @param int $postId
     * @param string $taxonomy
     * @param array $config
     * @param int $postIndex
     * @return array Term IDs to assign
     */
    protected function handleCreateMode(int $postId, string $taxonomy, array $config, int $postIndex): array
    {
        $createMode = $config['create_mode'] ?? 'random';
        $customNames = $config['custom_names'] ?? [];
        $count = (int) ($config['count'] ?? 5);
        $includeSubcategories = $config['include_subcategories'] ?? false;

        // Check if we've already created terms for this taxonomy in this session
        $cacheKey = $taxonomy . '_' . md5(json_encode($config));

        if (isset($this->createdTermsCache[$cacheKey])) {
            // Use existing created terms and rotate/randomly assign
            $createdTerms = $this->createdTermsCache[$cacheKey];
            $assignCount = $config['assign_count'] ?? 1;
            return $this->selectRandomTerms($createdTerms, min($assignCount, count($createdTerms)));
        }

        // Create new terms
        $createdTermIds = [];

        if ($createMode === 'custom' && !empty($customNames)) {
            // Create terms with custom names
            $createdTermIds = $this->createCustomTerms($taxonomy, $customNames, $includeSubcategories);
        } else {
            // Create terms with random names
            $createdTermIds = $this->createRandomTerms($taxonomy, $count, $includeSubcategories, $config);
        }

        // If creation returned no terms, fall back to existing terms in this taxonomy
        // (e.g. terms already created by ensureTaxonomies or a previous generation)
        if (empty($createdTermIds)) {
            $existingTerms = get_terms([
                'taxonomy' => $taxonomy,
                'hide_empty' => false,
                'fields' => 'ids',
            ]);
            if (!is_wp_error($existingTerms) && !empty($existingTerms)) {
                $createdTermIds = $existingTerms;
            }
        }

        // Cache the created terms
        $this->createdTermsCache[$cacheKey] = $createdTermIds;

        // Return some or all created terms for this post
        $assignCount = $config['assign_count'] ?? 1;
        return $this->selectRandomTerms($createdTermIds, min($assignCount, count($createdTermIds)));
    }

    /**
     * Filter terms to only include valid (existing) term IDs
     *
     * @param array $termIds
     * @param string $taxonomy
     * @return array
     */
    protected function filterValidTerms(array $termIds, string $taxonomy): array
    {
        $validTerms = [];

        foreach ($termIds as $termId) {
            $term = get_term((int) $termId, $taxonomy);
            if ($term && !is_wp_error($term)) {
                $validTerms[] = (int) $termId;
            }
        }

        return $validTerms;
    }

    /**
     * Select random terms from available terms
     *
     * @param array $terms
     * @param int $count
     * @return array
     */
    protected function selectRandomTerms(array $terms, int $count): array
    {
        if ($count >= count($terms)) {
            return $terms;
        }

        shuffle($terms);
        return array_slice($terms, 0, $count);
    }

    /**
     * Select a term using rotation (cycling through)
     *
     * @param array $terms
     * @param int $index
     * @return array Single term ID in array
     */
    protected function selectRotatingTerm(array $terms, int $index): array
    {
        if (empty($terms)) {
            return [];
        }

        $selectedIndex = $index % count($terms);
        return [$terms[$selectedIndex]];
    }

    /**
     * Create terms with custom names
     *
     * @param string $taxonomy
     * @param array $names
     * @param bool $includeSubcategories
     * @return array Created term IDs
     */
    protected function createCustomTerms(string $taxonomy, array $names, bool $includeSubcategories): array
    {
        $createdIds = [];
        $parentId = 0;

        foreach ($names as $name) {
            $name = sanitize_text_field($name);
            if (empty($name)) {
                continue;
            }

            $args = [];
            if ($includeSubcategories && $this->isTaxonomyHierarchical($taxonomy) && !empty($createdIds)) {
                // Randomly assign as child of a previously created term
                if (mt_rand(0, 100) > 50) {
                    $args['parent'] = $createdIds[array_rand($createdIds)];
                }
            }

            $result = wp_insert_term($name, $taxonomy, $args);

            if (!is_wp_error($result)) {
                $createdIds[] = $result['term_id'];
            } elseif ($result->get_error_code() === 'term_exists') {
                // Term already exists, use existing
                $existingTerm = get_term_by('name', $name, $taxonomy);
                if ($existingTerm) {
                    $createdIds[] = $existingTerm->term_id;
                }
            }
        }

        return $createdIds;
    }

    /**
     * Create terms with random names
     *
     * @param string $taxonomy
     * @param int $count
     * @param bool $includeSubcategories
     * @param array $config Additional config
     * @return array Created term IDs
     */
    protected function createRandomTerms(string $taxonomy, int $count, bool $includeSubcategories, array $config = []): array
    {
        $createdIds = [];
        $depth = (int) ($config['depth'] ?? 2);
        $breadth = (int) ($config['breadth'] ?? 3);

        if ($includeSubcategories && $this->isTaxonomyHierarchical($taxonomy)) {
            // Create hierarchical structure
            return $this->createHierarchicalTerms($taxonomy, $depth, $breadth);
        }

        // Create flat terms — reset pool for a fresh shuffled batch
        $this->taxonomyGenerator->setTaxonomy($taxonomy);
        $this->faker->resetTermPool($taxonomy);

        for ($i = 0; $i < $count; $i++) {
            $termId = $this->taxonomyGenerator->generateOne([
                'taxonomy' => $taxonomy,
            ]);

            if ($termId) {
                $createdIds[] = $termId;
            }
        }

        return $createdIds;
    }

    /**
     * Create hierarchical term structure
     *
     * @param string $taxonomy
     * @param int $depth
     * @param int $breadth
     * @return array Created term IDs
     */
    protected function createHierarchicalTerms(string $taxonomy, int $depth, int $breadth): array
    {
        $createdIds = [];
        $this->taxonomyGenerator->setTaxonomy($taxonomy);
        $this->faker->resetTermPool($taxonomy);

        // Create root level terms
        $parentIds = [];
        for ($i = 0; $i < $breadth; $i++) {
            $termId = $this->taxonomyGenerator->generateOne([
                'taxonomy' => $taxonomy,
                'parent'   => null,
            ]);

            if ($termId) {
                $createdIds[] = $termId;
                $parentIds[] = $termId;
            }
        }

        // Create child levels
        for ($level = 1; $level < $depth; $level++) {
            $newParentIds = [];

            foreach ($parentIds as $parentId) {
                $childCount = mt_rand(1, max(1, $breadth - $level));

                for ($i = 0; $i < $childCount; $i++) {
                    $termId = $this->taxonomyGenerator->generateOne([
                        'taxonomy' => $taxonomy,
                        'parent'   => $parentId,
                    ]);

                    if ($termId) {
                        $createdIds[] = $termId;
                        $newParentIds[] = $termId;
                    }
                }
            }

            $parentIds = $newParentIds;

            if (empty($parentIds)) {
                break;
            }
        }

        return $createdIds;
    }

    /**
     * Check if a taxonomy is hierarchical
     *
     * @param string $taxonomy
     * @return bool
     */
    protected function isTaxonomyHierarchical(string $taxonomy): bool
    {
        $taxObject = get_taxonomy($taxonomy);
        return $taxObject && $taxObject->hierarchical;
    }

    /**
     * Validate taxonomy configuration
     *
     * @param string $taxonomy
     * @param array $config
     * @return array Array of error messages (empty if valid)
     */
    public function validateConfig(string $taxonomy, array $config): array
    {
        $errors = [];
        $mode = $config['mode'] ?? 'none';

        if (!in_array($mode, ['none', 'choose', 'create'], true)) {
            $errors[] = __('Invalid taxonomy assignment mode', 'wpfaker');
        }

        if ($mode === 'choose') {
            $terms = $config['terms'] ?? [];
            $includeNone = $config['include_none'] ?? false;

            if (empty($terms) && !$includeNone) {
                $errors[] = __('Please select at least one term or enable "Include None"', 'wpfaker');
            }

            $multiple = $config['multiple'] ?? false;
            if ($multiple) {
                $minTerms = (int) ($config['min_terms'] ?? 1);
                $maxTerms = (int) ($config['max_terms'] ?? 3);

                if ($minTerms > $maxTerms) {
                    $errors[] = __('Minimum terms cannot exceed maximum terms', 'wpfaker');
                }

                if ($minTerms < 1) {
                    $errors[] = __('Minimum terms must be at least 1', 'wpfaker');
                }
            }
        }

        if ($mode === 'create') {
            $createMode = $config['create_mode'] ?? 'random';
            $customNames = $config['custom_names'] ?? [];

            if ($createMode === 'custom' && empty($customNames)) {
                $errors[] = __('Custom names are required when using custom create mode', 'wpfaker');
            }

            if ($createMode === 'random') {
                $count = (int) ($config['count'] ?? 5);
                if ($count < 1 || $count > 100) {
                    $errors[] = __('Term count must be between 1 and 100', 'wpfaker');
                }
            }
        }

        return $errors;
    }

    /**
     * Get all terms for a taxonomy (for multiselect UI)
     *
     * @param string $taxonomy
     * @param array $args Additional get_terms args
     * @return array
     */
    public function getTermsForSelect(string $taxonomy, array $args = []): array
    {
        $defaultArgs = [
            'taxonomy'   => $taxonomy,
            'hide_empty' => false,
            'orderby'    => 'name',
            'order'      => 'ASC',
        ];

        $terms = get_terms(array_merge($defaultArgs, $args));

        if (is_wp_error($terms)) {
            return [];
        }

        return array_map(function ($term) {
            return [
                'value'  => $term->term_id,
                'label'  => $term->name,
                'parent' => $term->parent,
                'count'  => $term->count,
            ];
        }, $terms);
    }
}
