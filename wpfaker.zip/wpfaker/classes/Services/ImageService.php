<?php

namespace WPFaker\Services;

/**
 * Image Service
 *
 * Downloads placeholder images and adds them to the WordPress Media Library.
 */
class ImageService
{
    /**
     * Available image providers
     */
    public const PROVIDER_PICSUM = 'picsum';
    public const PROVIDER_UNSPLASH = 'unsplash';
    public const PROVIDER_PLACEHOLDER = 'placeholder';
    public const PROVIDER_LOREMFLICKR = 'loremflickr';
    public const PROVIDER_PEXELS = 'pexels';
    public const PROVIDER_PIXABAY = 'pixabay';

    /**
     * Option name for image provider settings (API keys)
     */
    public const OPTION_NAME = 'wpfaker_image_provider_settings';

    /**
     * WPFaker API base URL and shared secret for proxy requests
     */
    private const API_BASE_URL = 'https://api.wpfaker.com/api/v1';
    private const API_SECRET = 'wpf_8k3mX9pL2nR7vQ4wY6tB1cF5hJ0sA3dG';

    /**
     * Category mapping: internal category => provider-specific query/category
     */
    protected const PEXELS_CATEGORY_MAP = [
        'nature'       => 'nature landscape',
        'architecture' => 'architecture building',
        'people'       => 'people portrait',
        'food'         => 'food cooking',
        'business'     => 'business office',
        'technology'   => 'technology computer',
        'animals'      => 'animals wildlife',
        'sports'       => 'sports fitness',
        'travel'       => 'travel destination',
        'abstract'     => 'abstract texture',
        'real-estate'  => 'real estate house',
        'interior'     => 'interior design room',
        'exterior'     => 'exterior building facade',
        'product'      => 'product commercial',
        'events'       => 'event celebration',
        'vehicles'     => 'car automotive',
        'portrait'     => 'portrait headshot face',
        'cinema'       => 'cinema movie film',
    ];

    protected const PIXABAY_CATEGORY_MAP = [
        'nature'       => 'nature',
        'architecture' => 'buildings',
        'people'       => 'people',
        'food'         => 'food',
        'business'     => 'business',
        'technology'   => 'computer',
        'animals'      => 'animals',
        'sports'       => 'sports',
        'travel'       => 'travel',
        'abstract'     => 'backgrounds',
        'real-estate'  => 'buildings',
        'interior'     => 'buildings',
        'exterior'     => 'buildings',
        'product'      => 'industry',
        'events'       => 'people',
        'vehicles'     => 'transportation',
        'portrait'     => 'people',
        'cinema'       => 'music',
    ];

    protected const UNSPLASH_CATEGORY_MAP = [
        'nature'       => 'nature landscape',
        'architecture' => 'architecture building',
        'people'       => 'people portrait',
        'food'         => 'food cooking',
        'business'     => 'business office',
        'technology'   => 'technology computer',
        'animals'      => 'animals wildlife',
        'sports'       => 'sports fitness',
        'travel'       => 'travel destination',
        'abstract'     => 'abstract texture',
        'real-estate'  => 'real estate house',
        'interior'     => 'interior design room',
        'exterior'     => 'exterior building facade',
        'product'      => 'product commercial',
        'events'       => 'event celebration',
        'vehicles'     => 'car automobile vehicle',
        'portrait'     => 'portrait face headshot person',
        'cinema'       => 'cinema movie film',
    ];

    /**
     * Guess the best image category for a given post type.
     * Used by PostGenerator and FieldAssignmentService for context-aware images.
     */
    public static function guessCategoryForPostType(string $postType, ?array $cptContext = null): ?string
    {
        // Exact match map
        $categoryMap = [
            'product'      => 'product',
            'food'         => 'food',
            'recipe'       => 'food',
            'travel'       => 'travel',
            'destination'  => 'travel',
            'team'         => 'portrait',
            'staff'        => 'portrait',
            'person'       => 'portrait',
            'agent'        => 'portrait',
            'actor'        => 'portrait',
            'director'     => 'portrait',
            'author'       => 'portrait',
            'movie'        => 'cinema',
            'film'         => 'cinema',
            'portfolio'    => 'architecture',
            'project'      => 'business',
            'property'     => 'real-estate',
            'real_estate'  => 'real-estate',
            'vehicle'      => 'vehicles',
            'car'          => 'vehicles',
        ];

        if (isset($categoryMap[$postType])) {
            return $categoryMap[$postType];
        }

        // Keyword-based detection in CPT slug
        $keywordMap = [
            'vehicles'     => ['vehicle', 'car', 'auto', 'fahrzeug', 'kfz', 'motor'],
            'food'         => ['rezept', 'recipe', 'food', 'essen', 'gericht', 'dish', 'menu', 'koch', 'meal'],
            'real-estate'  => ['immobili', 'property', 'realestate', 'wohnung', 'apartment', 'haus', 'house', 'listing'],
            'product'      => ['produkt', 'product', 'shop', 'artikel', 'ware', 'item'],
            'people'       => ['team', 'staff', 'mitarbeiter', 'person', 'member', 'employee', 'agent', 'makler', 'berater', 'actor', 'actress', 'director', 'author', 'schauspieler', 'regisseur', 'autor'],
            'travel'       => ['travel', 'reise', 'destination', 'location', 'standort', 'tour'],
            'business'     => ['project', 'projekt', 'portfolio', 'service', 'firma', 'company'],
            'events'       => ['event', 'veranstaltung', 'termin', 'booking'],
            'cinema'       => ['movie', 'film', 'kino', 'cinema'],
        ];

        foreach ($keywordMap as $category => $keywords) {
            foreach ($keywords as $keyword) {
                if (stripos($postType, $keyword) !== false) {
                    return $category;
                }
            }
        }

        // Fallback: check CPT label
        $cptObject = get_post_type_object($postType);
        if ($cptObject) {
            $label = strtolower($cptObject->labels->singular_name ?? '');
            foreach ($keywordMap as $category => $keywords) {
                foreach ($keywords as $keyword) {
                    if (stripos($label, $keyword) !== false) {
                        return $category;
                    }
                }
            }
        }

        // Fallback: use CPT context image keywords as search query
        if ($cptContext && !empty($cptContext['image_keywords'])) {
            return $cptContext['image_keywords'][0];
        }

        return null;
    }

    /**
     * Common aspect ratios
     */
    public const ASPECT_RATIOS = [
        '1:1' => 1.0,
        '4:3' => 4/3,
        '3:2' => 3/2,
        '16:9' => 16/9,
        '21:9' => 21/9,
        '2:3' => 2/3,
        '3:4' => 3/4,
        '9:16' => 9/16,
    ];

    /**
     * Default image dimensions
     */
    protected int $width = 1200;
    protected int $height = 800;

    /**
     * Random size range
     */
    protected bool $randomSize = false;
    protected int $widthMin = 800;
    protected int $widthMax = 1600;

    /**
     * Aspect ratio
     */
    protected string $aspectRatio = '3:2';

    /**
     * Image provider to use (Picsum is most reliable)
     */
    protected string $provider = self::PROVIDER_PICSUM;

    /**
     * Unsplash attribution data for the last fetched image
     */
    protected ?array $unsplashAttribution = null;

    /**
     * Categories for LoremFlickr
     */
    protected array $categories = ['nature', 'architecture', 'people', 'food', 'business', 'technology'];

    /**
     * Post type this media is being created for (for reuse tracking)
     */
    protected ?string $forPostType = null;

    /**
     * Set image dimensions (fixed size)
     *
     * @param int $width
     * @param int $height
     * @return self
     */
    public function setDimensions(int $width, int $height): self
    {
        $this->width = $width;
        $this->height = $height;
        $this->randomSize = false;
        return $this;
    }

    /**
     * Set aspect ratio
     *
     * @param string $ratio e.g. "3:2", "16:9"
     * @return self
     */
    public function setAspectRatio(string $ratio): self
    {
        if (isset(self::ASPECT_RATIOS[$ratio])) {
            $this->aspectRatio = $ratio;
        }
        return $this;
    }

    /**
     * Set random size mode with width range
     *
     * @param int $widthMin
     * @param int $widthMax
     * @return self
     */
    public function setRandomSize(int $widthMin, int $widthMax): self
    {
        $this->randomSize = true;
        $this->widthMin = min($widthMin, $widthMax);
        $this->widthMax = max($widthMin, $widthMax);
        return $this;
    }

    /**
     * Set the post type this media is being created for (for reuse tracking)
     */
    public function setForPostType(?string $postType): self
    {
        $this->forPostType = $postType;
        return $this;
    }

    /**
     * Calculate height from width using current aspect ratio
     *
     * @param int $width
     * @return int
     */
    protected function calculateHeight(int $width): int
    {
        $ratio = self::ASPECT_RATIOS[$this->aspectRatio] ?? 1.5; // Default 3:2
        return (int) round($width / $ratio);
    }

    /**
     * Get current dimensions (respects random size mode)
     *
     * @return array{width: int, height: int}
     */
    protected function getCurrentDimensions(): array
    {
        if ($this->randomSize) {
            $width = random_int($this->widthMin, $this->widthMax);
        } else {
            $width = $this->width;
        }

        $height = $this->calculateHeight($width);

        return ['width' => $width, 'height' => $height];
    }

    /**
     * Set the image provider
     *
     * @param string $provider
     * @return self
     */
    public function setProvider(string $provider): self
    {
        $this->provider = $provider;
        return $this;
    }

    /**
     * Download a placeholder image and add it to the media library
     *
     * @param string|null $title Optional image title
     * @param string|null $category Optional category for LoremFlickr
     * @param int|null $postId Optional post ID to attach the image to
     * @return int|false Attachment ID or false on failure
     */
    public function downloadImage(?string $title = null, ?string $category = null, ?int $postId = null): int|false
    {
        // Get current dimensions (may be randomized)
        $dimensions = $this->getCurrentDimensions();
        $currentWidth = $dimensions['width'];
        $currentHeight = $dimensions['height'];

        // Temporarily set dimensions for URL generation
        $originalWidth = $this->width;
        $originalHeight = $this->height;
        $this->width = $currentWidth;
        $this->height = $currentHeight;

        // Get image URL from provider
        $imageUrl = $this->getImageUrl($category);

        // Restore original dimensions
        $this->width = $originalWidth;
        $this->height = $originalHeight;

        if (!$imageUrl) {
            return false;
        }

        // Generate filename with size and ratio info
        $filename = $this->generateFilename($title, $currentWidth, $currentHeight);

        // Download the image with retry on failure
        $tempFile = $this->downloadToTemp($imageUrl);

        // If first attempt fails, try Picsum as fallback
        if (!$tempFile && $this->provider !== self::PROVIDER_PICSUM) {
            error_log('WPfaker: First download attempt failed, trying Picsum fallback');
            $this->width = $currentWidth;
            $this->height = $currentHeight;
            $fallbackUrl = $this->getPicsumUrl();
            $this->width = $originalWidth;
            $this->height = $originalHeight;
            $tempFile = $this->downloadToTemp($fallbackUrl);
        }

        if (!$tempFile) {
            return false;
        }

        // Generate title with dimensions if not provided
        $imageTitle = $title ?: $this->generateImageTitle($currentWidth, $currentHeight);

        // Add to media library
        $attachmentId = $this->addToMediaLibrary($tempFile, $filename, $imageTitle, $postId);

        // Clean up temp file
        @unlink($tempFile);

        // Store dimension metadata
        if ($attachmentId) {
            update_post_meta($attachmentId, '_wpfaker_dimensions', "{$currentWidth}x{$currentHeight}");
            update_post_meta($attachmentId, '_wpfaker_aspect_ratio', $this->aspectRatio);

            // Store Unsplash attribution if available
            if ($this->unsplashAttribution) {
                update_post_meta($attachmentId, '_wpfaker_unsplash_attribution', $this->unsplashAttribution);

                // Set caption (post_excerpt) with proper Unsplash attribution
                $photographer = $this->unsplashAttribution['photographer'] ?? '';
                $photographerUrl = $this->unsplashAttribution['photographer_url'] ?? '';
                $photoUrl = $this->unsplashAttribution['photo_url'] ?? '';

                if ($photographer) {
                    $photographerLink = $photographerUrl
                        ? '<a href="' . esc_url($photographerUrl . '?utm_source=wpfaker&utm_medium=referral') . '">' . esc_html($photographer) . '</a>'
                        : esc_html($photographer);
                    $unsplashLink = $photoUrl
                        ? '<a href="' . esc_url($photoUrl . '?utm_source=wpfaker&utm_medium=referral') . '">Unsplash</a>'
                        : '<a href="https://unsplash.com/?utm_source=wpfaker&utm_medium=referral">Unsplash</a>';

                    wp_update_post([
                        'ID'           => $attachmentId,
                        'post_excerpt' => 'Photo by ' . $photographerLink . ' on ' . $unsplashLink,
                    ]);
                }

                $this->unsplashAttribution = null;
            }
        }

        return $attachmentId;
    }

    /**
     * Download multiple images
     *
     * @param int $count Number of images to download
     * @param string|null $category Optional category
     * @param int|null $postId Optional post ID
     * @return array Array of attachment IDs
     */
    public function downloadImages(int $count, ?string $category = null, ?int $postId = null): array
    {
        $attachmentIds = [];

        for ($i = 0; $i < $count; $i++) {
            $id = $this->downloadImage(null, $category, $postId);
            if ($id) {
                $attachmentIds[] = $id;
            }

            // Small delay to avoid rate limiting
            if ($i < $count - 1) {
                usleep(200000); // 200ms
            }
        }

        return $attachmentIds;
    }

    /**
     * Get image URL from the selected provider
     *
     * @param string|null $category
     * @return string|null
     */
    protected function getImageUrl(?string $category = null): ?string
    {
        return match ($this->provider) {
            self::PROVIDER_PEXELS => $this->getPexelsUrl($category),
            self::PROVIDER_PIXABAY => $this->getPixabayUrl($category),
            self::PROVIDER_PICSUM => $this->getPicsumUrl(),
            self::PROVIDER_UNSPLASH => $this->getUnsplashUrl($category),
            self::PROVIDER_PLACEHOLDER => $this->getPlaceholderUrl(),
            self::PROVIDER_LOREMFLICKR => $this->getLoremFlickrUrl($category),
            default => $this->getPicsumUrl(),
        };
    }

    /**
     * Get URL from Lorem Picsum (https://picsum.photos)
     *
     * @return string
     */
    protected function getPicsumUrl(): string
    {
        // Add random seed to get different images each time
        $seed = uniqid();
        return "https://picsum.photos/seed/{$seed}/{$this->width}/{$this->height}";
    }

    /**
     * Get URL from Unsplash via WPFaker API proxy
     *
     * @param string|null $category
     * @return string|null
     */
    protected function getUnsplashUrl(?string $category = null): ?string
    {
        $query = 'photo';
        if ($category && isset(self::UNSPLASH_CATEGORY_MAP[$category])) {
            $query = self::UNSPLASH_CATEGORY_MAP[$category];
        } elseif ($category) {
            $query = $category;
        }

        $orientation = 'landscape';
        if ($this->width < $this->height) {
            $orientation = 'portrait';
        } elseif ($this->width === $this->height) {
            $orientation = 'squarish';
        }

        $body = wp_json_encode([
            'query'       => $query,
            'orientation' => $orientation,
            'width'       => $this->width,
            'height'      => $this->height,
        ]);

        $timestamp = (string) time();
        $message = $timestamp . $body;
        $signature = hash_hmac('sha256', $message, self::API_SECRET);

        $response = wp_remote_post(self::API_BASE_URL . '/images/unsplash', [
            'timeout' => 15,
            'headers' => [
                'Content-Type'        => 'application/json',
                'X-WPfaker-Timestamp' => $timestamp,
                'X-WPfaker-Signature' => $signature,
            ],
            'body' => $body,
        ]);

        if (is_wp_error($response)) {
            error_log('WPfaker: Unsplash proxy error: ' . $response->get_error_message());
            return $this->getPicsumUrl();
        }

        $statusCode = wp_remote_retrieve_response_code($response);
        if ($statusCode !== 200) {
            error_log('WPfaker: Unsplash proxy returned status ' . $statusCode);
            return $this->getPicsumUrl();
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);

        if (empty($data['success']) || empty($data['url'])) {
            error_log('WPfaker: Unsplash proxy returned no image URL');
            return $this->getPicsumUrl();
        }

        // Store attribution data for later use
        if (!empty($data['attribution']['photographer'])) {
            $this->unsplashAttribution = [
                'photographer'     => $data['attribution']['photographer'],
                'photographer_url' => $data['attribution']['photographer_url'] ?? '',
                'photo_url'        => $data['attribution']['photo_url'] ?? '',
            ];
        }

        return $data['url'];
    }

    /**
     * Get URL from Placeholder.com
     *
     * @return string
     */
    protected function getPlaceholderUrl(): string
    {
        // placehold.co is more reliable than via.placeholder.com
        $colors = ['cccccc', 'e0e0e0', 'f5f5f5', 'd4edda', 'cce5ff', 'f8d7da', 'fff3cd'];
        $bgColor = $colors[array_rand($colors)];
        return "https://placehold.co/{$this->width}x{$this->height}/{$bgColor}/333333.jpg";
    }

    /**
     * Get URL from LoremFlickr (real photos by category)
     * Falls back to Picsum if category-based fetch fails
     *
     * @param string|null $category
     * @return string
     */
    protected function getLoremFlickrUrl(?string $category = null): string
    {
        // Use Picsum instead - LoremFlickr is unreliable
        // Picsum doesn't support categories but is much more reliable
        return $this->getPicsumUrl();
    }

    /**
     * Get image URL from Pexels API
     *
     * @param string|null $category
     * @return string|null
     */
    protected function getPexelsUrl(?string $category = null): ?string
    {
        $apiKey = self::getApiKey('pexels');
        if (empty($apiKey)) {
            error_log('WPfaker: Pexels API key not configured, falling back to Picsum');
            return $this->getPicsumUrl();
        }

        $query = 'photo';
        if ($category && isset(self::PEXELS_CATEGORY_MAP[$category])) {
            $query = self::PEXELS_CATEGORY_MAP[$category];
        }

        $page = random_int(1, 50);
        $url = 'https://api.pexels.com/v1/search?' . http_build_query([
            'query'    => $query,
            'per_page' => 1,
            'page'     => $page,
            'orientation' => $this->width >= $this->height ? 'landscape' : 'portrait',
        ]);

        $response = wp_remote_get($url, [
            'timeout' => 15,
            'headers' => [
                'Authorization' => $apiKey,
            ],
        ]);

        if (is_wp_error($response)) {
            error_log('WPfaker: Pexels API error: ' . $response->get_error_message());
            return $this->getPicsumUrl();
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (empty($body['photos'][0]['src'])) {
            error_log('WPfaker: Pexels returned no photos for query "' . $query . '"');
            return $this->getPicsumUrl();
        }

        $src = $body['photos'][0]['src'];

        // Use resize parameters for exact dimensions
        return $src['original'] . '?auto=compress&w=' . $this->width . '&h=' . $this->height . '&fit=crop';
    }

    /**
     * Get image URL from Pixabay API
     *
     * @param string|null $category
     * @return string|null
     */
    protected function getPixabayUrl(?string $category = null): ?string
    {
        $apiKey = self::getApiKey('pixabay');
        if (empty($apiKey)) {
            error_log('WPfaker: Pixabay API key not configured, falling back to Picsum');
            return $this->getPicsumUrl();
        }

        $params = [
            'key'        => $apiKey,
            'per_page'   => 3,
            'page'       => random_int(1, 30),
            'image_type' => 'photo',
            'min_width'  => $this->width,
            'min_height' => $this->height,
            'orientation' => $this->width >= $this->height ? 'horizontal' : 'vertical',
        ];

        if ($category && isset(self::PIXABAY_CATEGORY_MAP[$category])) {
            $params['category'] = self::PIXABAY_CATEGORY_MAP[$category];
        }

        $url = 'https://pixabay.com/api/?' . http_build_query($params);

        $response = wp_remote_get($url, ['timeout' => 15]);

        if (is_wp_error($response)) {
            error_log('WPfaker: Pixabay API error: ' . $response->get_error_message());
            return $this->getPicsumUrl();
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (empty($body['hits'])) {
            error_log('WPfaker: Pixabay returned no results');
            return $this->getPicsumUrl();
        }

        // Pick a random hit from results
        $hit = $body['hits'][array_rand($body['hits'])];

        return $hit['largeImageURL'] ?? $hit['webformatURL'] ?? $this->getPicsumUrl();
    }

    /**
     * Get API key for a provider
     *
     * @param string $provider 'pexels' or 'pixabay'
     * @return string|null
     */
    public static function getApiKey(string $provider): ?string
    {
        $settings = get_option(self::OPTION_NAME, []);
        return $settings[$provider . '_api_key'] ?? null;
    }

    /**
     * Save API key for a provider
     *
     * @param string $provider 'pexels' or 'pixabay'
     * @param string $apiKey
     */
    public static function saveApiKey(string $provider, string $apiKey): void
    {
        $settings = get_option(self::OPTION_NAME, []);
        $settings[$provider . '_api_key'] = sanitize_text_field($apiKey);
        update_option(self::OPTION_NAME, $settings);
    }

    /**
     * Get masked API key for display
     *
     * @param string $provider 'pexels' or 'pixabay'
     * @return string
     */
    public static function getMaskedApiKey(string $provider): string
    {
        $key = self::getApiKey($provider);
        if (empty($key)) {
            return '';
        }

        $length = strlen($key);
        if ($length <= 8) {
            return str_repeat('*', $length);
        }

        return substr($key, 0, 4) . str_repeat('*', $length - 8) . substr($key, -4);
    }

    /**
     * Get all image provider settings for the frontend
     *
     * @return array
     */
    public static function getProviderSettings(): array
    {
        return [
            'pexels' => [
                'has_api_key'    => !empty(self::getApiKey('pexels')),
                'masked_api_key' => self::getMaskedApiKey('pexels'),
            ],
            'pixabay' => [
                'has_api_key'    => !empty(self::getApiKey('pixabay')),
                'masked_api_key' => self::getMaskedApiKey('pixabay'),
            ],
        ];
    }

    /**
     * Generate a unique filename with size and ratio info
     *
     * @param string|null $title
     * @param int|null $width
     * @param int|null $height
     * @return string
     */
    protected function generateFilename(?string $title = null, ?int $width = null, ?int $height = null): string
    {
        $base = $title ? sanitize_title($title) : 'wpfaker';
        $unique = substr(uniqid(), -4);

        // Format ratio for filename (3:2 -> 3-2)
        $ratioForFilename = str_replace(':', '-', $this->aspectRatio);

        // Include dimensions and ratio in filename
        $sizeInfo = '';
        if ($width && $height) {
            $sizeInfo = "-{$width}x{$height}-{$ratioForFilename}";
        }

        return "{$base}{$sizeInfo}-{$unique}.jpg";
    }

    /**
     * Download image to a temporary file
     *
     * @param string $url
     * @return string|false Temp file path or false on failure
     */
    protected function downloadToTemp(string $url): string|false
    {
        // Use WordPress HTTP API
        $response = wp_remote_get($url, [
            'timeout'     => 30,
            'redirection' => 5,
            'sslverify'   => false,
        ]);

        if (is_wp_error($response)) {
            error_log('WPfaker: Failed to download image: ' . $response->get_error_message());
            return false;
        }

        $responseCode = wp_remote_retrieve_response_code($response);
        if ($responseCode !== 200) {
            error_log('WPfaker: Image download returned status ' . $responseCode);
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            error_log('WPfaker: Empty response body');
            return false;
        }

        // Include WordPress file functions if not already loaded
        if (!function_exists('wp_tempnam')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        // Create temp file
        $tempFile = \wp_tempnam('wpfaker_');

        if (!$tempFile) {
            error_log('WPfaker: Failed to create temp file');
            return false;
        }

        // Write content to temp file
        $result = file_put_contents($tempFile, $body);

        if ($result === false) {
            error_log('WPfaker: Failed to write temp file');
            @unlink($tempFile);
            return false;
        }

        return $tempFile;
    }

    /**
     * Add downloaded image to WordPress Media Library
     *
     * @param string $tempFile Path to temp file
     * @param string $filename Desired filename
     * @param string|null $title Image title
     * @param int|null $postId Post to attach to
     * @return int|false Attachment ID or false on failure
     */
    protected function addToMediaLibrary(string $tempFile, string $filename, ?string $title = null, ?int $postId = null): int|false
    {
        // Include required WordPress files
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        // Get upload directory
        $uploadDir = wp_upload_dir();

        if ($uploadDir['error']) {
            error_log('WPfaker: Upload directory error: ' . $uploadDir['error']);
            return false;
        }

        // Generate unique filename in upload directory
        $targetPath = $uploadDir['path'] . '/' . wp_unique_filename($uploadDir['path'], $filename);

        // Move temp file to uploads
        if (!copy($tempFile, $targetPath)) {
            error_log('WPfaker: Failed to copy file to uploads');
            return false;
        }

        // Set correct file permissions
        chmod($targetPath, 0644);

        // Get file type
        $fileType = wp_check_filetype($targetPath, null);

        // Prepare attachment data
        $attachment = [
            'post_mime_type' => $fileType['type'] ?: 'image/jpeg',
            'post_title'     => $title ?: $this->generateImageTitle(),
            'post_content'   => '',
            'post_status'    => 'inherit',
        ];

        // Insert attachment
        $attachmentId = wp_insert_attachment($attachment, $targetPath, $postId ?: 0);

        if (is_wp_error($attachmentId)) {
            error_log('WPfaker: Failed to insert attachment: ' . $attachmentId->get_error_message());
            @unlink($targetPath);
            return false;
        }

        // Generate attachment metadata (thumbnails, etc.)
        $metadata = wp_generate_attachment_metadata($attachmentId, $targetPath);

        if (is_wp_error($metadata)) {
            error_log('WPfaker: Failed to generate metadata');
        } else {
            wp_update_attachment_metadata($attachmentId, $metadata);
        }

        // Add custom meta to identify as generated by WPfaker
        update_post_meta($attachmentId, '_wpfaker_generated', true);
        update_post_meta($attachmentId, '_wpfaker_provider', $this->provider);

        if ($this->forPostType) {
            update_post_meta($attachmentId, '_wpfaker_for_post_type', $this->forPostType);
        }

        // Log in history for tracking
        (new HistoryService())->log('media', $attachmentId, 'image', [
            'post_type' => $this->forPostType,
        ]);

        return $attachmentId;
    }

    /**
     * Generate a random image title with optional dimensions
     *
     * @param int|null $width
     * @param int|null $height
     * @return string
     */
    protected function generateImageTitle(?int $width = null, ?int $height = null): string
    {
        $adjectives = ['Beautiful', 'Stunning', 'Amazing', 'Gorgeous', 'Lovely', 'Scenic', 'Vibrant', 'Elegant', 'Modern', 'Classic'];
        $nouns = ['Landscape', 'Scene', 'View', 'Photo', 'Image', 'Picture', 'Moment', 'Capture', 'Shot', 'Portrait'];

        $adjective = $adjectives[array_rand($adjectives)];
        $noun = $nouns[array_rand($nouns)];

        $title = "{$adjective} {$noun}";

        // Add dimension info to title
        if ($width && $height) {
            $title .= " ({$width}×{$height}, {$this->aspectRatio})";
        }

        return $title;
    }

    /**
     * Get or create a featured image for a post
     *
     * @param int $postId
     * @param string|null $category
     * @return int|false Attachment ID or false
     */
    public function getOrCreateFeaturedImage(int $postId, ?string $category = null): int|false
    {
        // Check if post already has a featured image
        $existingId = get_post_thumbnail_id($postId);

        if ($existingId) {
            return $existingId;
        }

        // Download new image
        $attachmentId = $this->downloadImage(
            get_the_title($postId) . ' Featured Image',
            $category,
            $postId
        );

        if ($attachmentId) {
            set_post_thumbnail($postId, $attachmentId);
        }

        return $attachmentId;
    }

    /**
     * Get available image providers
     *
     * @return array
     */
    public static function getProviders(): array
    {
        $pexelsConfigured = !empty(self::getApiKey('pexels'));
        $pixabayConfigured = !empty(self::getApiKey('pixabay'));

        return [
            self::PROVIDER_PICSUM => [
                'name'              => 'Lorem Picsum',
                'description'       => __('Random photos. Does not support categories.', 'wpfaker'),
                'url'               => 'https://picsum.photos',
                'supports_category' => false,
                'requires_api_key'  => false,
                'configured'        => true,
            ],
            self::PROVIDER_UNSPLASH => [
                'name'              => 'Unsplash',
                'description'       => __('High-quality curated photos with category support.', 'wpfaker'),
                'url'               => 'https://unsplash.com',
                'supports_category' => true,
                'requires_api_key'  => false,
                'configured'        => true,
            ],
            self::PROVIDER_PEXELS => [
                'name'              => 'Pexels',
                'description'       => $pexelsConfigured
                    ? __('High-quality photos with category support.', 'wpfaker')
                    : __('Requires API key. Configure in Settings > Image Providers.', 'wpfaker'),
                'url'               => 'https://www.pexels.com',
                'supports_category' => true,
                'requires_api_key'  => true,
                'configured'        => $pexelsConfigured,
            ],
            self::PROVIDER_PIXABAY => [
                'name'              => 'Pixabay',
                'description'       => $pixabayConfigured
                    ? __('Free photos with built-in category support.', 'wpfaker')
                    : __('Requires API key. Configure in Settings > Image Providers.', 'wpfaker'),
                'url'               => 'https://pixabay.com',
                'supports_category' => true,
                'requires_api_key'  => true,
                'configured'        => $pixabayConfigured,
            ],
            self::PROVIDER_PLACEHOLDER => [
                'name'              => 'Placeholder.com',
                'description'       => __('Simple colored placeholders. No real photos.', 'wpfaker'),
                'url'               => 'https://placeholder.com',
                'supports_category' => false,
                'requires_api_key'  => false,
                'configured'        => true,
            ],
        ];
    }

    /**
     * Get available categories for LoremFlickr
     *
     * @return array
     */
    public static function getCategories(): array
    {
        return [
            'nature'       => 'Nature',
            'architecture' => 'Architecture',
            'people'       => 'People',
            'food'         => 'Food',
            'business'     => 'Business',
            'technology'   => 'Technology',
            'animals'      => 'Animals',
            'sports'       => 'Sports',
            'travel'       => 'Travel',
            'abstract'     => 'Abstract',
            'real-estate'  => 'Real Estate',
            'interior'     => 'Interior',
            'exterior'     => 'Exterior',
            'portrait'     => 'Portrait / Headshot',
        ];
    }

    /**
     * Find reusable WPFaker-generated images for a post type.
     * Returns attachment IDs that are orphaned (post_parent = 0 or parent deleted).
     *
     * @param string $postType The post type to find reusable images for
     * @return array<int> Attachment IDs
     */
    public static function getReusablePool(string $postType): array
    {
        $attachments = get_posts([
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'post_mime_type' => 'image',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => [
                ['key' => '_wpfaker_generated', 'value' => '1'],
                ['key' => '_wpfaker_for_post_type', 'value' => $postType],
            ],
        ]);

        if (empty($attachments)) {
            return [];
        }

        // Only return orphaned images (post_parent points to deleted/no post)
        return array_values(array_filter($attachments, function ($id) {
            $parent = wp_get_post_parent_id($id);
            return !$parent || !get_post($parent);
        }));
    }

    /**
     * Delete all images generated by WPfaker
     *
     * @param bool $forceDelete Skip trash
     * @return int Number of images deleted
     */
    public static function deleteGeneratedImages(bool $forceDelete = false): int
    {
        $history = new HistoryService();
        $attachmentIds = $history->getIdsByType('media');

        $deleted = 0;
        foreach ($attachmentIds as $attachmentId) {
            if (wp_delete_attachment($attachmentId, $forceDelete)) {
                $deleted++;
            }
        }

        return $deleted;
    }

    /**
     * Count images generated by WPfaker
     *
     * @return int
     */
    public static function countGeneratedImages(): int
    {
        global $wpdb;

        return (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_wpfaker_generated' AND meta_value = '1'"
        );
    }
}
