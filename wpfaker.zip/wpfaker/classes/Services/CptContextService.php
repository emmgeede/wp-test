<?php

namespace WPFaker\Services;

use WPFaker\Contracts\AiProviderInterface;

/**
 * CPT Context Service
 *
 * Generates a comprehensive context object for unknown/niche CPTs via a single AI call.
 * The context feeds ALL pipelines (titles, taxonomy terms, images, content, comments, field detection)
 * so they produce domain-relevant data instead of generic/nonsensical fallbacks.
 *
 * Results are cached as WordPress transients for 24 hours.
 */
class CptContextService
{
    /**
     * Cache duration: 24 hours
     */
    protected const CACHE_DURATION = 86400;

    /**
     * AI Provider for context generation
     */
    protected AiProviderInterface $aiProvider;

    /**
     * Last warning message (set when AI is unavailable or generation fails)
     */
    protected ?string $lastWarning = null;

    public function __construct(AiProviderInterface $aiProvider)
    {
        $this->aiProvider = $aiProvider;
    }

    /**
     * Get the last warning message
     */
    public function getLastWarning(): ?string
    {
        return $this->lastWarning;
    }

    /**
     * Get comprehensive context for a CPT.
     *
     * Returns a cached context array or generates one via AI.
     * Structure:
     * [
     *   'domain'         => 'geology',
     *   'description'    => 'Volcanoes and volcanic activity',
     *   'topics'         => ['eruptions', 'magma', ...],
     *   'image_keywords' => ['volcano eruption lava', ...],
     *   'comment_tones'  => ['scientific', 'observational', ...],
     *   'content_themes' => ['geological formation', ...],
     *   'term_seeds'     => ['eruption_types' => ['Effusive', 'Explosive', ...]]
     * ]
     *
     * @param string $cptSlug The CPT slug
     * @param string|null $cptLabel The CPT display label
     * @param string|null $locale The locale for generation
     * @param array|null $taxonomies Array of taxonomy slugs registered for this CPT
     * @return array|null Context array or null if AI unavailable/failed
     */
    public function getContext(string $cptSlug, ?string $cptLabel, ?string $locale, ?array $taxonomies = null, ?array $parentCptInfo = null): ?array
    {
        $this->lastWarning = null;

        if (!$this->aiProvider->isAvailable()) {
            $this->lastWarning = 'AI provider is not configured';
            return null;
        }

        // Check cache first — separate cache for standalone vs. relational context
        $parentSlug = $parentCptInfo['slug'] ?? '';
        $cacheKey = 'wpfaker_cpt_context_' . md5($cptSlug . '_' . ($locale ?? '') . '_' . $parentSlug);

        // When generating with parent context, clear any stale standalone transient
        // to prevent it from being used in other code paths
        if ($parentSlug) {
            $standaloneKey = 'wpfaker_cpt_context_' . md5($cptSlug . '_' . ($locale ?? '') . '_');
            delete_transient($standaloneKey);
        }

        $cached = get_transient($cacheKey);
        if ($cached !== false) {
            return $cached;
        }

        // Generate via AI
        $context = $this->aiProvider->generateCptContext($cptSlug, $cptLabel, $locale, $taxonomies, $parentCptInfo);

        if ($context) {
            set_transient($cacheKey, $context, self::CACHE_DURATION);
        } else {
            $this->lastWarning = $this->aiProvider->getLastError() ?? 'AI context generation failed';
        }

        return $context;
    }
}
