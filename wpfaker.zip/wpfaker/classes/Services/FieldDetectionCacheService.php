<?php

declare(strict_types=1);

namespace WPFaker\Services;

/**
 * Field Detection Cache Service
 *
 * Caches field content type detections in a database table to avoid
 * repeated pattern matching and AI calls for the same CPT fields.
 */
class FieldDetectionCacheService
{
    /**
     * Get the table name
     */
    public static function getTableName(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'wpfaker_field_detections';
    }

    /**
     * Check if detections exist for a post type
     */
    public function hasDetectionsFor(string $postType): bool
    {
        global $wpdb;
        $table = self::getTableName();

        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE post_type = %s",
            $postType
        ));

        return (int) $count > 0;
    }

    /**
     * Get all cached detections for a post type
     *
     * @return array<string, array{detected_content_type: string, detection_source: string, confidence: float}>
     *         Keyed by field_name
     */
    public function getDetectionsForPostType(string $postType): array
    {
        global $wpdb;
        $table = self::getTableName();

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT field_name, detected_content_type, detection_source, confidence, faker_config
             FROM {$table}
             WHERE post_type = %s",
            $postType
        ), ARRAY_A);

        $detections = [];
        foreach ($rows as $row) {
            $detections[$row['field_name']] = [
                'detected_content_type' => $row['detected_content_type'],
                'detection_source' => $row['detection_source'],
                'confidence' => (float) $row['confidence'],
                'faker_config' => $row['faker_config'] ? json_decode($row['faker_config'], true) : null,
            ];
        }

        if (!empty($detections)) {
            GenerationLogService::log('detect', sprintf('Using cached field detections for %s', $postType));
        }

        return $detections;
    }

    /**
     * Get a single detection for a specific field
     *
     * @return array{detected_content_type: string, detection_source: string, confidence: float}|null
     */
    public function getDetection(string $postType, string $fieldName): ?array
    {
        global $wpdb;
        $table = self::getTableName();

        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT detected_content_type, detection_source, confidence, faker_config
             FROM {$table}
             WHERE post_type = %s AND field_name = %s",
            $postType,
            $fieldName
        ), ARRAY_A);

        if (!$row) {
            return null;
        }

        return [
            'detected_content_type' => $row['detected_content_type'],
            'detection_source' => $row['detection_source'],
            'confidence' => (float) $row['confidence'],
            'faker_config' => $row['faker_config'] ? json_decode($row['faker_config'], true) : null,
        ];
    }

    /**
     * Save a single detection
     */
    public function saveDetection(
        string $postType,
        string $fieldName,
        string $contentType,
        string $source = 'pattern',
        float $confidence = 1.0,
        ?string $fieldLabel = null,
        ?string $fieldPluginType = null,
        ?array $fakerConfig = null
    ): void {
        global $wpdb;
        $table = self::getTableName();

        $wpdb->replace($table, [
            'post_type' => $postType,
            'field_name' => $fieldName,
            'field_label' => $fieldLabel ?? '',
            'field_plugin_type' => $fieldPluginType ?? '',
            'detected_content_type' => $contentType,
            'detection_source' => $source,
            'confidence' => $confidence,
            'faker_config' => $fakerConfig ? wp_json_encode($fakerConfig) : null,
            'created_at' => current_time('mysql'),
        ], ['%s', '%s', '%s', '%s', '%s', '%s', '%f', '%s', '%s']);
    }

    /**
     * Save multiple detections in batch
     *
     * @param array $detections Array of ['field_name' => string, 'content_type' => string, 'source' => string, 'confidence' => float]
     */
    public function saveBatchDetections(string $postType, array $detections): void
    {
        foreach ($detections as $detection) {
            $this->saveDetection(
                $postType,
                $detection['field_name'],
                $detection['content_type'],
                $detection['source'] ?? 'pattern',
                $detection['confidence'] ?? 1.0,
                $detection['field_label'] ?? null,
                $detection['field_plugin_type'] ?? null
            );
        }
    }

    /**
     * Clear all cached detections for a post type
     */
    public function clearForPostType(string $postType): int
    {
        global $wpdb;
        $table = self::getTableName();

        return (int) $wpdb->delete($table, ['post_type' => $postType], ['%s']);
    }

    /**
     * Clear all cached detections
     */
    public function clearAll(): int
    {
        global $wpdb;
        $table = self::getTableName();

        return (int) $wpdb->query("DELETE FROM {$table}");
    }

    /**
     * Check if AI batch detections exist for a post type
     */
    public function hasAiDetectionsFor(string $postType): bool
    {
        global $wpdb;
        $table = self::getTableName();

        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE post_type = %s AND detection_source IN (%s, %s, %s)",
            $postType,
            'ai_batch',
            'gemini_batch',
            'hive'
        ));

        return (int) $count > 0;
    }

    /**
     * Create the database table
     */
    public static function createTable(): void
    {
        global $wpdb;
        $table = self::getTableName();
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            post_type varchar(100) NOT NULL,
            field_name varchar(200) NOT NULL,
            field_label varchar(200) NOT NULL DEFAULT '',
            field_plugin_type varchar(50) NOT NULL DEFAULT '',
            detected_content_type varchar(50) NOT NULL,
            detection_source varchar(20) NOT NULL DEFAULT 'pattern',
            confidence decimal(3,2) NOT NULL DEFAULT 1.00,
            faker_config text DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY post_type_field (post_type, field_name),
            KEY post_type_idx (post_type)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Drop the database table
     */
    public static function dropTable(): void
    {
        global $wpdb;
        $table = self::getTableName();
        $wpdb->query("DROP TABLE IF EXISTS {$table}");
    }
}
