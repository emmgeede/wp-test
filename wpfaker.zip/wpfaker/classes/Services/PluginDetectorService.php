<?php

namespace WPFaker\Services;

/**
 * Plugin Detector Service
 *
 * Detects installed custom field and CPT plugins,
 * regardless of whether WPfaker has an adapter for them.
 */
class PluginDetectorService
{
    /**
     * List of supported custom field plugins with detection info
     */
    protected const PLUGINS = [
        'acf_pro' => [
            'name' => 'Advanced Custom Fields PRO',
            'slug' => 'advanced-custom-fields-pro',
            'detect_class' => 'acf_pro',
            'detect_function' => null,
            'detect_constant' => 'ACF_PRO',
            'version_constant' => 'ACF_VERSION',
            'category' => 'custom_fields',
            'has_adapter' => true,
            'website' => 'https://www.advancedcustomfields.com/pro/',
            'icon' => 'acf',
        ],
        'acf' => [
            'name' => 'Advanced Custom Fields',
            'slug' => 'advanced-custom-fields',
            'detect_class' => 'ACF',
            'detect_function' => 'acf_get_field_groups',
            'detect_constant' => null,
            'version_constant' => 'ACF_VERSION',
            'category' => 'custom_fields',
            'has_adapter' => true,
            'website' => 'https://www.advancedcustomfields.com/',
            'icon' => 'acf',
        ],
        'jet_engine' => [
            'name' => 'JetEngine',
            'slug' => 'jet-engine',
            'detect_class' => 'Jet_Engine',
            'detect_function' => null,
            'detect_constant' => 'JET_ENGINE_VERSION',
            'version_constant' => 'JET_ENGINE_VERSION',
            'category' => 'custom_fields',
            'has_adapter' => true,
            'website' => 'https://crocoblock.com/plugins/jetengine/',
            'icon' => 'jetengine',
        ],
        'meta_box' => [
            'name' => 'Meta Box',
            'slug' => 'meta-box',
            'detect_class' => 'RWMB_Loader',
            'detect_function' => 'rwmb_meta',
            'detect_constant' => 'RWMB_VER',
            'version_constant' => 'RWMB_VER',
            'category' => 'custom_fields',
            'has_adapter' => true,
            'website' => 'https://metabox.io/',
            'icon' => 'metabox',
        ],
        'acpt' => [
            'name' => 'ACPT - Advanced Custom Post Type',
            'slug' => 'advanced-custom-post-type',
            'detect_class' => 'ACPT_Plugin',
            'detect_function' => null,
            'detect_constant' => 'ACPT_PLUGIN_VERSION',
            'version_constant' => 'ACPT_PLUGIN_VERSION',
            'category' => 'custom_fields',
            'has_adapter' => true,
            'website' => 'https://acpt.io/',
            'icon' => 'acpt',
        ],
        'cptui' => [
            'name' => 'Custom Post Type UI',
            'slug' => 'custom-post-type-ui',
            'detect_class' => null,
            'detect_function' => 'cptui_get_post_type_data',
            'detect_constant' => 'CPT_VERSION',
            'version_constant' => 'CPT_VERSION',
            'category' => 'cpt',
            'has_adapter' => true,
            'website' => 'https://wordpress.org/plugins/custom-post-type-ui/',
            'icon' => 'cptui',
        ],
        'toolset' => [
            'name' => 'Toolset Types',
            'slug' => 'types',
            'detect_class' => 'Types_Main',
            'detect_function' => null,
            'detect_constant' => 'TYPES_VERSION',
            'version_constant' => 'TYPES_VERSION',
            'category' => 'custom_fields',
            'has_adapter' => false,
            'website' => 'https://toolset.com/',
            'icon' => 'toolset',
        ],
        'carbon_fields' => [
            'name' => 'Carbon Fields',
            'slug' => 'carbon-fields',
            'detect_class' => 'Carbon_Fields\\Carbon_Fields',
            'detect_function' => null,
            'detect_constant' => null,
            'version_constant' => null,
            'category' => 'custom_fields',
            'has_adapter' => false,
            'website' => 'https://carbonfields.net/',
            'icon' => 'carbon',
        ],
        'cmb2' => [
            'name' => 'CMB2',
            'slug' => 'cmb2',
            'detect_class' => 'CMB2',
            'detect_function' => 'cmb2_init',
            'detect_constant' => 'CMB2_VERSION',
            'version_constant' => 'CMB2_VERSION',
            'category' => 'custom_fields',
            'has_adapter' => false,
            'website' => 'https://cmb2.io/',
            'icon' => 'cmb2',
        ],
        'acf_extended' => [
            'name' => 'ACF Extended',
            'slug' => 'acf-extended',
            'detect_class' => 'ACFE',
            'detect_function' => null,
            'detect_constant' => 'ACFE_VERSION',
            'version_constant' => 'ACFE_VERSION',
            'category' => 'acf_addon',
            'has_adapter' => true,
            'website' => 'https://www.acf-extended.com/',
            'icon' => 'acfe',
        ],
    ];

    /**
     * Get status of all known plugins
     *
     * @return array
     */
    public static function getAllPluginStatus(): array
    {
        $plugins = [];

        foreach (self::PLUGINS as $key => $plugin) {
            $isInstalled = self::isPluginInstalled($plugin);
            $isActive = self::isPluginActive($plugin);
            $version = $isActive ? self::getPluginVersion($plugin) : null;

            $plugins[$key] = [
                'key' => $key,
                'name' => $plugin['name'],
                'slug' => $plugin['slug'],
                'category' => $plugin['category'],
                'installed' => $isInstalled,
                'active' => $isActive,
                'version' => $version,
                'has_wpfaker_adapter' => $plugin['has_adapter'],
                'website' => $plugin['website'],
                'icon' => $plugin['icon'],
            ];
        }

        return $plugins;
    }

    /**
     * Get only active plugins
     *
     * @return array
     */
    public static function getActivePlugins(): array
    {
        return array_filter(self::getAllPluginStatus(), fn($p) => $p['active']);
    }

    /**
     * Get plugins by category
     *
     * @param string $category
     * @return array
     */
    public static function getPluginsByCategory(string $category): array
    {
        return array_filter(self::getAllPluginStatus(), fn($p) => $p['category'] === $category);
    }

    /**
     * Check if a plugin is installed (files exist)
     *
     * @param array $plugin
     * @return bool
     */
    protected static function isPluginInstalled(array $plugin): bool
    {
        // Check if plugin directory exists
        $pluginDir = WP_PLUGIN_DIR . '/' . $plugin['slug'];
        if (is_dir($pluginDir)) {
            return true;
        }

        // For Pro plugins that might be in different directories
        if (strpos($plugin['slug'], '-pro') !== false) {
            $baseDir = WP_PLUGIN_DIR . '/' . str_replace('-pro', '', $plugin['slug']);
            if (is_dir($baseDir)) {
                return true;
            }
        }

        // Check if it's loaded (might be in mu-plugins or merged)
        return self::isPluginActive($plugin);
    }

    /**
     * Check if a plugin is active
     *
     * @param array $plugin
     * @return bool
     */
    protected static function isPluginActive(array $plugin): bool
    {
        // Check by class
        if (!empty($plugin['detect_class'])) {
            if (class_exists($plugin['detect_class'])) {
                return true;
            }
        }

        // Check by function
        if (!empty($plugin['detect_function'])) {
            if (function_exists($plugin['detect_function'])) {
                return true;
            }
        }

        // Check by constant
        if (!empty($plugin['detect_constant'])) {
            if (defined($plugin['detect_constant'])) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get plugin version
     *
     * @param array $plugin
     * @return string|null
     */
    protected static function getPluginVersion(array $plugin): ?string
    {
        if (!empty($plugin['version_constant']) && defined($plugin['version_constant'])) {
            return constant($plugin['version_constant']);
        }

        // Try to get version from plugin file
        if (!function_exists('get_plugin_data')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $pluginFile = self::findPluginFile($plugin['slug']);
        if ($pluginFile && file_exists($pluginFile)) {
            $pluginData = get_plugin_data($pluginFile);
            if (!empty($pluginData['Version'])) {
                return $pluginData['Version'];
            }
        }

        return null;
    }

    /**
     * Find plugin main file
     *
     * @param string $slug
     * @return string|null
     */
    protected static function findPluginFile(string $slug): ?string
    {
        $possibleFiles = [
            WP_PLUGIN_DIR . '/' . $slug . '/' . $slug . '.php',
            WP_PLUGIN_DIR . '/' . $slug . '/plugin.php',
            WP_PLUGIN_DIR . '/' . $slug . '/index.php',
        ];

        // Special cases
        if ($slug === 'advanced-custom-fields-pro') {
            $possibleFiles[] = WP_PLUGIN_DIR . '/advanced-custom-fields-pro/acf.php';
        }
        if ($slug === 'advanced-custom-fields') {
            $possibleFiles[] = WP_PLUGIN_DIR . '/advanced-custom-fields/acf.php';
        }

        foreach ($possibleFiles as $file) {
            if (file_exists($file)) {
                return $file;
            }
        }

        return null;
    }

    /**
     * Get summary statistics
     *
     * @return array
     */
    public static function getSummary(): array
    {
        $all = self::getAllPluginStatus();
        $active = array_filter($all, fn($p) => $p['active']);
        $withAdapter = array_filter($active, fn($p) => $p['has_wpfaker_adapter']);

        return [
            'total_known' => count($all),
            'installed' => count(array_filter($all, fn($p) => $p['installed'])),
            'active' => count($active),
            'with_adapter' => count($withAdapter),
            'without_adapter' => count($active) - count($withAdapter),
            'primary_plugin' => !empty($active) ? array_values($active)[0]['name'] : null,
        ];
    }
}
