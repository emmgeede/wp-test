<?php

namespace WPFaker\Services;

use WPFaker\Generators\PostGenerator;
use WPFaker\Services\AdapterFactory;
use WPFaker\Services\HistoryService;
use WPFaker\Services\TemplateService;

/**
 * Dependency Resolver Service
 *
 * Analyzes and resolves cross-CPT dependencies for relational fields.
 * When generating posts for a CPT that has relational fields pointing to other CPTs,
 * this service ensures enough target-CPT posts exist before generation begins.
 */
class DependencyResolverService
{
    /**
     * Relational field types that reference other posts
     */
    protected const RELATIONAL_FIELD_TYPES = [
        'post_object',
        'relationship',
        'page_link',
        'posts',
        'post',
        'post_object_multi',
    ];

    /**
     * Maximum recursion depth for dependency chains
     */
    protected const MAX_DEPTH = 3;

    /**
     * Stack of post types currently being resolved (circular dependency guard)
     *
     * @var array
     */
    protected array $resolving = [];

    /**
     * Count of posts auto-created during this resolution
     *
     * @var int
     */
    protected int $autoCreatedCount = 0;

    /**
     * Per-CPT auto-created counts
     *
     * @var array<string, int>
     */
    protected array $autoCreatedPerCpt = [];

    /**
     * Per-CPT auto-created post IDs
     *
     * @var array<string, int[]>
     */
    protected array $autoCreatedIdsPerCpt = [];

    /**
     * Analyze cross-CPT dependencies for a post type
     *
     * Scans all relational fields and JetEngine relations to find fields
     * that reference other post types (not the same CPT).
     *
     * @param string $postType The post type to analyze
     * @return array Array of dependency definitions
     */
    public function analyzeDependencies(string $postType): array
    {
        $dependencies = [];

        // 1. Scan field plugin relational fields
        $adapter = AdapterFactory::getAdapterForPostType($postType);
        if ($adapter && $adapter->isActive()) {
            $fields = $adapter->getFieldsForPostType($postType);

            foreach ($fields as $field) {
                $fieldName = $field['name'] ?? '';
                $fieldType = $field['type'] ?? 'text';
                $parentField = $field['parent_field'] ?? null;

                // Skip empty names, sub-fields, and non-relational types
                if (empty($fieldName) || $parentField) {
                    continue;
                }
                if (!in_array($fieldType, self::RELATIONAL_FIELD_TYPES, true)) {
                    continue;
                }

                // Get target post types from field config
                $targetPostTypes = $this->getTargetPostTypes($field, $postType);
                if (empty($targetPostTypes)) {
                    continue;
                }

                // Filter to only cross-CPT (exclude self-references)
                $crossCptTargets = array_values(array_filter($targetPostTypes, function ($t) use ($postType) {
                    return $t !== $postType;
                }));

                if (empty($crossCptTargets)) {
                    continue;
                }

                $isMultiple = !empty($field['multiple']) || !empty($field['is_multiple'])
                    || in_array($fieldType, ['relationship', 'post_object_multi'], true);

                $dependencies[] = [
                    'field_name'        => $fieldName,
                    'field_type'        => $fieldType,
                    'target_post_types' => $crossCptTargets,
                    'is_multiple'       => $isMultiple,
                    'source'            => 'field',
                    'cardinality'       => $isMultiple ? 'many_to_many' : 'many_to_one',
                    'required'          => !empty($field['required']),
                ];
            }
        }

        // 2. Scan JetEngine Relations
        if ($adapter && method_exists($adapter, 'getRelationsForPostType')) {
            $relations = $adapter->getRelationsForPostType($postType);

            foreach ($relations as $relId => $relation) {
                $relatedObject = $relation['related_object'] ?? '';
                $relationType = $relation['type'] ?? 'one_to_many';

                // Only handle post-to-post relations
                if (!str_starts_with($relatedObject, 'posts::')) {
                    continue;
                }

                $relatedPostType = str_replace('posts::', '', $relatedObject);

                // Skip self-references
                if ($relatedPostType === $postType) {
                    continue;
                }

                // Verify the post type exists
                if (!post_type_exists($relatedPostType)) {
                    continue;
                }

                $dependencies[] = [
                    'field_name'        => $relation['name'] ?? $relId,
                    'field_type'        => 'jet_relation',
                    'target_post_types' => [$relatedPostType],
                    'is_multiple'       => $relationType !== 'one_to_one',
                    'source'            => 'jet_relation',
                    'cardinality'       => $relationType,
                    'required'          => false,
                ];
            }
        }

        // 3. Scan MB Relationships
        if ($adapter && method_exists($adapter, 'getMBRelationshipsForPostType')) {
            $mbRelationships = $adapter->getMBRelationshipsForPostType($postType);

            foreach ($mbRelationships as $relId => $relationship) {
                $relatedPostType = $relationship['related_post_type'] ?? '';
                $cardinality = $relationship['cardinality'] ?? 'many_to_many';

                // Skip self-references
                if ($relatedPostType === $postType) {
                    continue;
                }

                // Verify the post type exists
                if (!post_type_exists($relatedPostType)) {
                    continue;
                }

                $dependencies[] = [
                    'field_name'        => $relId,
                    'field_type'        => 'mb_relationship',
                    'target_post_types' => [$relatedPostType],
                    'is_multiple'       => $cardinality !== 'one_to_one',
                    'source'            => 'mb_relationship',
                    'cardinality'       => $cardinality,
                    'required'          => false,
                ];
            }
        }

        return $dependencies;
    }

    /**
     * Analyze bidirectional dependencies for a post type
     *
     * Scans all registered CPTs to find both incoming (provides) and
     * outgoing (requires) relationships for bidirectional awareness.
     *
     * @param string $postType The post type to analyze
     * @return array{requires: array, provides: array}
     */
    public function analyzeBidirectionalDependencies(string $postType): array
    {
        $requires = [];
        $provides = [];

        // Get this CPT's own dependencies (outgoing = "requires")
        $ownDeps = $this->analyzeDependencies($postType);
        foreach ($ownDeps as $dep) {
            foreach ($dep['target_post_types'] as $target) {
                $requires[] = [
                    'target'    => $target,
                    'field'     => $dep['field_name'],
                    'direction' => $dep['is_multiple'] ? 'has_many' : 'belongs_to',
                    'required'  => $dep['required'],
                    'source'    => $dep['source'],
                ];
            }
        }

        // Scan all other CPTs for fields pointing TO this post type (incoming = "provides")
        $allPostTypes = get_post_types(['public' => true], 'names');
        $allPostTypes = array_merge($allPostTypes, get_post_types(['public' => false, '_builtin' => false], 'names'));
        $allPostTypes = array_unique($allPostTypes);

        foreach ($allPostTypes as $otherCpt) {
            if ($otherCpt === $postType) {
                continue;
            }

            $otherDeps = $this->analyzeDependencies($otherCpt);
            foreach ($otherDeps as $dep) {
                if (in_array($postType, $dep['target_post_types'], true)) {
                    $provides[] = [
                        'target'    => $otherCpt,
                        'field'     => $dep['field_name'],
                        'direction' => $dep['is_multiple'] ? 'has_many' : 'has_one',
                        'required'  => $dep['required'],
                        'source'    => $dep['source'],
                    ];
                }
            }
        }

        return [
            'requires' => $requires,
            'provides' => $provides,
        ];
    }

    /**
     * Check what the selected CPT needs but doesn't have.
     *
     * Returns only the missing dependencies (required parents with 0 existing posts).
     * Read-only — does not create anything.
     *
     * @param string     $postType      The post type to check
     * @param array|null $bidirectional Pre-computed result from analyzeBidirectionalDependencies(), or null to compute
     * @return array Missing dependency definitions with existing_count and is_missing
     */
    public function getMissingDependencies(string $postType, ?array $bidirectional = null): array
    {
        if ($bidirectional === null) {
            $bidirectional = $this->analyzeBidirectionalDependencies($postType);
        }
        $missing = [];

        foreach ($bidirectional['requires'] as $dep) {
            $target = $dep['target'];
            $counts = wp_count_posts($target);
            $count = (int) ($counts->publish ?? 0);

            if ($count === 0) {
                $missing[] = array_merge($dep, [
                    'existing_count' => $count,
                    'is_missing'     => true,
                ]);
            }
        }

        return $missing;
    }

    /**
     * Maximum total posts that can be auto-created across all related CPTs.
     * Set via $options['post_budget'] in ensureRelatedPosts().
     * null = unlimited (legacy behavior).
     */
    protected ?int $remainingBudget = null;

    /**
     * Ensure enough related posts exist for all cross-CPT dependencies
     *
     * @param string $postType The source post type being generated
     * @param array $options Generation options. Supports 'post_budget' key to limit
     *                       total auto-created posts across all related CPTs.
     * @return array Map of post_type => post_ids[] for the related post pool
     */
    public function ensureRelatedPosts(string $postType, array $options = []): array
    {
        $this->autoCreatedCount = 0;
        $this->autoCreatedPerCpt = [];
        $this->autoCreatedIdsPerCpt = [];
        $this->remainingBudget = isset($options['post_budget']) ? (int) $options['post_budget'] : null;
        return $this->resolveForPostType($postType, $options, 0);
    }

    /**
     * Get the number of posts auto-created during the last ensureRelatedPosts() call
     *
     * @return int
     */
    public function getAutoCreatedCount(): int
    {
        return $this->autoCreatedCount;
    }

    /**
     * Get per-CPT auto-created counts
     *
     * @return array<string, int>
     */
    public function getAutoCreatedPerCpt(): array
    {
        return $this->autoCreatedPerCpt;
    }

    /**
     * Get per-CPT auto-created post IDs
     *
     * @return array<string, int[]>
     */
    public function getAutoCreatedIdsPerCpt(): array
    {
        return $this->autoCreatedIdsPerCpt;
    }

    /**
     * Internal recursive resolver with depth tracking
     *
     * @param string $postType The post type to resolve dependencies for
     * @param array $options Generation options
     * @param int $depth Current recursion depth
     * @return array Map of post_type => post_ids[]
     */
    protected function resolveForPostType(string $postType, array $options, int $depth): array
    {
        // Guard: max depth
        if ($depth >= self::MAX_DEPTH) {
            return [];
        }

        // Guard: circular dependency
        if (in_array($postType, $this->resolving, true)) {
            // Use existing posts for circular references
            return $this->getExistingPostsByType($postType);
        }

        $this->resolving[] = $postType;
        $pool = [];

        $dependencies = $this->analyzeDependencies($postType);

        // Collect unique target CPTs that need creation to calculate fair budget shares
        $relatedCptOptions = $options['related_cpt_options'] ?? null;
        $parentSlug = $options['parent_cpt_info']['slug'] ?? null;
        $defaultCount = $options['count'] ?? 5;
        $cptNeeds = []; // targetCpt => toCreate count

        foreach ($dependencies as $dep) {
            foreach ($dep['target_post_types'] as $targetCpt) {
                if (isset($cptNeeds[$targetCpt]) || !post_type_exists($targetCpt)) {
                    continue;
                }

                $perCptConfig = is_array($relatedCptOptions) ? ($relatedCptOptions[$targetCpt] ?? null) : null;
                if (is_array($perCptConfig) && ($perCptConfig['enabled'] ?? true) === false) {
                    continue;
                }

                $existingIds = $this->getExistingPostIds($targetCpt);
                $neededCount = is_array($perCptConfig) && isset($perCptConfig['count'])
                    ? (int) $perCptConfig['count']
                    : $defaultCount;

                $countableIds = $existingIds;
                if ($parentSlug) {
                    $countableIds = $this->getExistingPostIdsWithParent($targetCpt, $parentSlug);
                }

                $toCreate = max(0, $neededCount - count($countableIds));
                $cptNeeds[$targetCpt] = $toCreate;
            }
        }

        // Calculate per-CPT budget: distribute remaining budget fairly across CPTs that need posts
        $totalNeeded = array_sum($cptNeeds);
        $perCptBudgets = [];
        if ($this->remainingBudget !== null && $totalNeeded > 0) {
            foreach ($cptNeeds as $cpt => $needed) {
                if ($needed <= 0) {
                    $perCptBudgets[$cpt] = 0;
                    continue;
                }
                // Proportional share: at least 1 per CPT that needs posts
                $share = (int) floor($this->remainingBudget * ($needed / $totalNeeded));
                $perCptBudgets[$cpt] = max(1, $share);
            }
        }

        foreach ($dependencies as $dep) {
            foreach ($dep['target_post_types'] as $targetCpt) {
                // Skip if already resolved in this pool
                if (isset($pool[$targetCpt])) {
                    continue;
                }

                // Check if the target CPT is registered
                if (!post_type_exists($targetCpt)) {
                    continue;
                }

                // Per-CPT config from related_cpt_options
                $perCptConfig = is_array($relatedCptOptions) ? ($relatedCptOptions[$targetCpt] ?? null) : null;

                // Skip disabled target CPTs
                if (is_array($perCptConfig) && ($perCptConfig['enabled'] ?? true) === false) {
                    continue;
                }

                // Get all existing posts for relationship pool
                $existingIds = $this->getExistingPostIds($targetCpt);

                // Use per-CPT count from related_cpt_options, or match main post count
                $neededCount = is_array($perCptConfig) && isset($perCptConfig['count'])
                    ? (int) $perCptConfig['count']
                    : $defaultCount;

                // When parent context is available, only count posts that were created
                // with matching parent context — ensures context-aware posts get created
                // even when generic posts already exist
                $countableIds = $existingIds;
                if ($parentSlug) {
                    $countableIds = $this->getExistingPostIdsWithParent($targetCpt, $parentSlug);
                }

                if (count($countableIds) >= $neededCount) {
                    // Enough (context-matching) posts exist already
                    $pool[$targetCpt] = $existingIds;
                } else {
                    // Need to create more context-aware posts
                    $toCreate = $neededCount - count($countableIds);

                    // Enforce budget: use pre-calculated fair share per CPT
                    if ($this->remainingBudget !== null) {
                        if ($this->remainingBudget <= 0) {
                            // Budget exhausted — use whatever exists
                            $pool[$targetCpt] = $existingIds;
                            continue;
                        }
                        $fairShare = $perCptBudgets[$targetCpt] ?? $toCreate;
                        $toCreate = min($toCreate, $fairShare, $this->remainingBudget);
                    }

                    $newIds = $this->autoCreatePosts($targetCpt, $toCreate, $options);
                    $actuallyCreated = count($newIds);
                    $this->autoCreatedCount += $actuallyCreated;
                    $this->autoCreatedPerCpt[$targetCpt] = ($this->autoCreatedPerCpt[$targetCpt] ?? 0) + $actuallyCreated;
                    $this->autoCreatedIdsPerCpt[$targetCpt] = array_merge($this->autoCreatedIdsPerCpt[$targetCpt] ?? [], $newIds);

                    // Deduct from budget
                    if ($this->remainingBudget !== null) {
                        $this->remainingBudget -= $actuallyCreated;
                    }
                    $pool[$targetCpt] = array_merge($existingIds, $newIds);
                }
            }
        }

        // Remove self from resolving stack
        $this->resolving = array_values(array_diff($this->resolving, [$postType]));

        return $pool;
    }

    /**
     * Auto-create posts for a target CPT
     *
     * Uses the default template if one exists for full generation,
     * otherwise creates minimal posts with title + content.
     *
     * @param string $targetCpt The target post type to create posts for
     * @param int $count Number of posts to create
     * @param array $options Parent generation options (for locale, etc.)
     * @return array Array of created post IDs
     */
    public function autoCreatePosts(string $targetCpt, int $count, array $options = []): array
    {
        $locale = $options['locale'] ?? null;

        // Get per-CPT overrides from related_cpt_options
        $relatedCptOptions = $options['related_cpt_options'] ?? null;
        $perCptConfig = is_array($relatedCptOptions) ? ($relatedCptOptions[$targetCpt] ?? null) : null;

        // Use linked template from parent config, fall back to default
        $templateService = new TemplateService();
        $linkedTemplateId = is_array($perCptConfig) ? ($perCptConfig['template_id'] ?? null) : null;
        $template = $linkedTemplateId
            ? $templateService->get($linkedTemplateId)
            : $templateService->getDefault($targetCpt);

        // Build generator options — full quality for both paths
        $generator = new PostGenerator();
        $generatorOptions = [
            'post_type'              => $targetCpt,
            'post_status'            => is_array($perCptConfig) ? ($perCptConfig['post_status'] ?? 'publish') : 'publish',
            'locale'                 => $locale,
            'populate_custom_fields' => true,
            'auto_create_taxonomies' => true,
            'auto_taxonomies'        => true,
            'enable_variation'       => is_array($perCptConfig) ? !empty($perCptConfig['enable_variation']) : false,
            'set_featured_image'     => is_array($perCptConfig) ? ($perCptConfig['set_featured_image'] ?? post_type_supports($targetCpt, 'thumbnail')) : post_type_supports($targetCpt, 'thumbnail'),
            'download_images'        => is_array($perCptConfig) ? ($perCptConfig['download_images'] ?? post_type_supports($targetCpt, 'thumbnail')) : post_type_supports($targetCpt, 'thumbnail'),
            // Prevent recursive auto-creation of related posts
            'auto_create_related'    => false,
        ];

        // Pass parent CPT context so child CPTs get domain-aware context
        if (!empty($options['parent_cpt_info'])) {
            $generatorOptions['parent_cpt_info'] = $options['parent_cpt_info'];
        }

        if ($template) {
            // Use template config as base, but per-CPT overrides win
            $generatorOptions['template_id']            = $template['id'];
            $generatorOptions['taxonomy_config']        = $template['taxonomy_config'] ?? null;
            $generatorOptions['field_config']           = $template['field_config'] ?? null;
            $generatorOptions['image_provider']         = $template['config']['image_provider'] ?? 'unsplash';
            $generatorOptions['auto_create_authors']    = $template['config']['auto_create_authors'] ?? false;

            // Only override from template if no per-CPT config
            if (!is_array($perCptConfig)) {
                $generatorOptions['set_featured_image'] = $template['config']['set_featured_image'] ?? post_type_supports($targetCpt, 'thumbnail');
                $generatorOptions['download_images']    = $template['config']['download_images'] ?? post_type_supports($targetCpt, 'thumbnail');
                $generatorOptions['enable_variation']   = $template['config']['enable_variation'] ?? false;
            }
        }
        // When no template exists, PostGenerator's buildAutoFieldConfig() will auto-fill all custom fields

        $newIds = $generator->generate($count, $generatorOptions);

        // Tag auto-created posts with parent context slug for future lookups
        if (!empty($options['parent_cpt_info']['slug'])) {
            $parentSlug = $options['parent_cpt_info']['slug'];
            foreach ($newIds as $id) {
                update_post_meta($id, '_wpfaker_parent_cpt', $parentSlug);
            }
        }

        return $newIds;
    }

    /**
     * Get existing post IDs for a post type
     *
     * @param string $postType
     * @return array
     */
    protected function getExistingPostIds(string $postType): array
    {
        $posts = get_posts([
            'post_type'      => $postType,
            'posts_per_page' => 100,
            'post_status'    => 'any',
            'fields'         => 'ids',
            'orderby'        => 'rand',
        ]);

        return is_array($posts) ? $posts : [];
    }

    /**
     * Get existing post IDs that were auto-created with a specific parent context
     *
     * @param string $postType
     * @param string $parentCpt Parent CPT slug
     * @return array
     */
    protected function getExistingPostIdsWithParent(string $postType, string $parentCpt): array
    {
        $posts = get_posts([
            'post_type'      => $postType,
            'posts_per_page' => 100,
            'post_status'    => 'any',
            'fields'         => 'ids',
            'orderby'        => 'rand',
            'meta_key'       => '_wpfaker_parent_cpt',
            'meta_value'     => $parentCpt,
        ]);

        return is_array($posts) ? $posts : [];
    }

    /**
     * Get existing posts mapped by type (for circular dependency fallback)
     *
     * @param string $postType
     * @return array Map of post_type => post_ids[]
     */
    protected function getExistingPostsByType(string $postType): array
    {
        $ids = $this->getExistingPostIds($postType);
        return !empty($ids) ? [$postType => $ids] : [];
    }

    /**
     * Extract target post types from a field definition
     *
     * @param array $field The field definition
     * @param string $currentPostType The current post type (to detect self-refs)
     * @return string[] Array of post type slugs
     */
    protected function getTargetPostTypes(array $field, string $currentPostType): array
    {
        // ACF: 'post_type' key
        $fieldPostTypes = $field['post_type'] ?? null;

        // JetEngine: 'search_post_type' key
        if (empty($fieldPostTypes)) {
            $fieldPostTypes = $field['search_post_type'] ?? null;
        }

        // Meta Box: 'post_type' in query_args
        if (empty($fieldPostTypes) && !empty($field['query_args']['post_type'])) {
            $fieldPostTypes = $field['query_args']['post_type'];
        }

        // Empty or 'all' means it can reference any post type — skip (same-batch behavior)
        if (empty($fieldPostTypes) || $fieldPostTypes === 'all') {
            return [];
        }

        // Normalize to array
        if (is_string($fieldPostTypes)) {
            $fieldPostTypes = [$fieldPostTypes];
        }

        // Filter to registered post types only
        return array_values(array_filter($fieldPostTypes, function ($pt) {
            return is_string($pt) && post_type_exists($pt);
        }));
    }
}
