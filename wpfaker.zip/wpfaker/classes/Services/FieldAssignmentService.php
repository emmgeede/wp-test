<?php

declare(strict_types=1);

namespace WPFaker\Services;

use WPFaker\Schema\FieldConfigSchema;
use WPFaker\Contracts\FieldPluginAdapterInterface;

/**
 * Service for assigning field values based on template configuration.
 * Implements None/Choose/Create pattern for all field types.
 */
class FieldAssignmentService
{
    /**
     * Whitelisted FakerPHP methods that AI can request
     */
    private const ALLOWED_FAKER_METHODS = [
        'numberBetween', 'randomFloat', 'randomDigit', 'randomNumber',
        'regexify', 'bothify', 'numerify', 'lexify',
        'sentence', 'word', 'words', 'paragraph', 'paragraphs', 'text',
        'name', 'firstName', 'lastName', 'email', 'safeEmail',
        'phoneNumber', 'url', 'address', 'streetName', 'city',
        'postcode', 'country', 'company', 'jobTitle',
        'iban', 'swiftBicNumber', 'creditCardNumber',
        'uuid', 'ean13', 'isbn13', 'ipv4', 'macAddress', 'slug',
        'date', 'time', 'year', 'dateTimeBetween',
        'randomElement', 'randomElements', 'boolean', 'hexColor',
        'latitude', 'longitude',
    ];

    private FakerService $faker;
    private ImageService $imageService;
    private FieldNameDetector $fieldDetector;
    private ?FieldPluginAdapterInterface $adapter = null;
    private ?string $locale = null;
    private ?FieldDetectionCacheService $detectionCache = null;
    private ?string $currentPostType = null;
    private ?array $cptContextData = null;
    private ?\Closure $imagePoolCallback = null;

    /**
     * Current template's custom_fields config, used to look up
     * flat sub-field configs during repeater/group generation.
     */
    private array $currentCustomConfig = [];

    /**
     * Rotation indices for 'rotation' selection mode
     * @var array<string, int>
     */
    private array $rotationIndices = [];

    public function __construct(
        FakerService $faker,
        ImageService $imageService
    ) {
        $this->faker = $faker;
        $this->imageService = $imageService;
        $this->fieldDetector = new FieldNameDetector($faker);
        $this->detectionCache = new FieldDetectionCacheService();
    }

    /**
     * Set the current post type for context-aware detection
     */
    public function setPostType(string $postType): void
    {
        $this->currentPostType = $postType;
    }

    /**
     * Set CPT context on the field name detector for disambiguation
     */
    public function setCptContext(string $slug, ?string $label = null): void
    {
        $this->fieldDetector->setCptContext($slug, $label);
    }

    /**
     * Set AI-generated CPT context data for enhanced detection (images, fields)
     */
    public function setCptContextData(?array $cptContext): void
    {
        $this->cptContextData = $cptContext;
        $this->fieldDetector->setCptContextData($cptContext);
    }

    /**
     * Set the field plugin adapter
     */
    public function setAdapter(?FieldPluginAdapterInterface $adapter): void
    {
        $this->adapter = $adapter;
    }

    /**
     * Set the locale for content generation
     */
    /**
     * Set callback for consuming images from the reuse pool
     */
    public function setImagePoolCallback(?\Closure $callback): void
    {
        $this->imagePoolCallback = $callback;
    }

    public function setLocale(?string $locale): void
    {
        $this->locale = $locale;
        if ($locale) {
            $this->faker->setLocale($locale);
        }
    }

    /**
     * Generate locale-aware sentence text (uses realText instead of Lorem when available)
     */
    protected function localeText(int $maxChars = 100): string
    {
        $faker = $this->locale ? $this->faker->forLocale($this->locale) : $this->faker->getInstance();

        // When user has selected "Lorem Ipsum" text source, use Lorem regardless of locale.
        if (FakerService::getTextSource() === 'lorem') {
            $wordCount = max(3, (int) ($maxChars / 6));
            return $faker->sentence($wordCount);
        }

        try {
            $text = $faker->realText(max($maxChars, 10));
            return $text;
        } catch (\InvalidArgumentException $e) {
            $wordCount = max(3, (int) ($maxChars / 6));
            return $faker->sentence($wordCount);
        }
    }

    /**
     * Main method: Assign all fields from field_config
     *
     * @param int $postId The post ID (0 if pre-insert for core fields)
     * @param array $fieldConfig The complete field configuration
     * @param int $postIndex Current post index in batch
     * @param int $totalPosts Total posts being generated
     * @return array Results with assigned values
     */
    public function assignFields(
        int $postId,
        array $fieldConfig,
        int $postIndex,
        int $totalPosts
    ): array {
        $result = [
            'core_fields' => [],
            'custom_fields' => [],
        ];

        // Assign core fields
        if (!empty($fieldConfig['core_fields'])) {
            $result['core_fields'] = $this->assignCoreFields(
                $fieldConfig['core_fields'],
                $postIndex
            );
        }

        // Assign custom fields (requires post ID)
        if ($postId > 0 && !empty($fieldConfig['custom_fields'])) {
            $result['custom_fields'] = $this->assignCustomFields(
                $postId,
                $fieldConfig['custom_fields'],
                $postIndex
            );
        }

        return $result;
    }

    /**
     * Assign core fields (before wp_insert_post)
     *
     * @param array $coreConfig Core field configuration
     * @param int $index Current post index
     * @return array Values for wp_insert_post
     */
    public function assignCoreFields(array $coreConfig, int $index): array
    {
        $values = [];

        foreach ($coreConfig as $field => $config) {
            if (!isset($config['mode']) || $config['mode'] === 'none') {
                continue;
            }

            $value = $this->resolveFieldValue($field, $config, $index);

            if ($value !== null) {
                $values[$field] = $value;
            }
        }

        return $values;
    }

    /**
     * Assign custom fields (after wp_insert_post)
     *
     * @param int $postId The post ID
     * @param array $customConfig Custom field configuration
     * @param int $index Current post index
     * @return array Assigned field names and values
     */
    public function assignCustomFields(int $postId, array $customConfig, int $index): array
    {
        $this->currentCustomConfig = $customConfig;
        $assigned = [];

        foreach ($customConfig as $fieldName => $config) {
            $mode = $config['mode'] ?? 'none';

            // Get field_type from config, or look it up from ACF if not set
            $fieldType = $config['field_type'] ?? null;
            $fieldKey = $config['field_key'] ?? $fieldName;
            $isRequired = $config['required'] ?? false;

            if ($this->adapter) {
                // Look up field info from ACF
                $acfField = $this->adapter->getFieldConfig($fieldKey);
                if ($acfField) {
                    $fieldType = $fieldType ?? $acfField['type'] ?? 'text';
                    $isRequired = $isRequired || !empty($acfField['required']);
                    // Also update config with field_key for later use
                    $config['field_type'] = $fieldType;
                    $config['field_key'] = $acfField['key'] ?? $fieldKey;

                    // Propagate prefix/suffix from field config for unit range detection
                    $prefix = $acfField['prepend'] ?? $acfField['prefix'] ?? '';
                    $suffix = $acfField['append'] ?? $acfField['suffix'] ?? '';
                    if ($prefix !== '') {
                        $config['create']['prefix'] = $prefix;
                    }
                    if ($suffix !== '') {
                        $config['create']['suffix'] = $suffix;
                    }

                    // Propagate date return_format from ACF field config
                    $returnFormat = $acfField['return_format'] ?? '';
                    if ($returnFormat !== '' && !isset($config['create']['format'])) {
                        $config['create']['format'] = $returnFormat;
                    }
                }
            }

            $fieldType = $fieldType ?? 'text';

            // Skip non-required fields with mode 'none'
            // But always generate required fields
            if ($mode === 'none' && !$isRequired) {
                continue;
            }

            // For required fields with mode 'none', force 'create' mode with defaults
            if ($mode === 'none' && $isRequired) {
                $config['mode'] = 'create';
            }

            $value = $this->resolveFieldValue($fieldName, $config, $index, $postId);

            if ($value !== null) {
                $this->saveCustomFieldValue($postId, $fieldName, $value, $config);
                $assigned[$fieldName] = $value;
            }
        }

        return $assigned;
    }

    /**
     * Resolve a field value based on mode
     *
     * @param string $field Field name
     * @param array $config Field configuration
     * @param int $index Current post index
     * @param int|null $excludePostId Post ID to exclude from relationship results (prevents self-reference)
     */
    protected function resolveFieldValue(string $field, array $config, int $index, ?int $excludePostId = null): mixed
    {
        $mode = $config['mode'] ?? 'none';

        return match ($mode) {
            'none' => null,
            'choose' => $this->handleChooseMode($field, $config, $index),
            'custom' => $this->handleCustomMode($config, $index),
            'create' => $this->handleCreateMode($field, $config, $excludePostId),
            default => null,
        };
    }

    /**
     * Handle 'choose' mode - select from predefined values
     */
    protected function handleChooseMode(string $field, array $config, int $index): mixed
    {
        $choose = $config['choose'] ?? [];
        $fieldType = $config['field_type'] ?? 'text';

        // Check for include_none probability
        if (!empty($choose['include_none']) && isset($choose['none_probability'])) {
            if (rand(1, 100) <= $choose['none_probability']) {
                return null;
            }
        }

        // Get values based on field type
        $values = $this->getChooseValues($choose, $fieldType);

        // When use_all_options is true and no values are populated,
        // fetch choices from ACF field definition
        if (empty($values) && !empty($choose['use_all_options']) && $this->adapter) {
            $fieldKey = $config['field_key'] ?? $field;
            $acfField = $this->adapter->getFieldConfig($fieldKey);
            $choices = $acfField['choices'] ?? [];
            if (!empty($choices)) {
                $values = array_keys($choices);
            }
        }

        if (empty($values)) {
            return null;
        }

        // Select value(s)
        $selectionMode = $choose['selection_mode'] ?? 'random';
        $isMultiple = $this->isMultipleSelection($fieldType, $choose);

        if ($isMultiple) {
            return $this->selectMultipleValues($field, $values, $choose, $index, $selectionMode);
        }

        return $this->selectValue($field, $values, $selectionMode, $index);
    }

    /**
     * Handle 'custom' mode - use user-defined values
     */
    protected function handleCustomMode(array $config, int $index): mixed
    {
        $custom = $config['custom'] ?? [];
        $values = $custom['values'] ?? [];

        if (empty($values)) {
            return null;
        }

        // Filter out empty lines
        $values = array_values(array_filter($values, fn($v) => trim($v) !== ''));

        if (empty($values)) {
            return null;
        }

        $selectionMode = $custom['selection_mode'] ?? 'random';

        return match ($selectionMode) {
            'sequential' => $values[$index % count($values)],
            default => $values[array_rand($values)],
        };
    }

    /**
     * Handle 'create' mode - generate new values
     *
     * @param string $field Field name
     * @param array $config Field configuration
     * @param int|null $excludePostId Post ID to exclude from relationship results
     */
    protected function handleCreateMode(string $field, array $config, ?int $excludePostId = null): mixed
    {
        $fieldType = $config['field_type'] ?? 'text';
        $create = $config['create'] ?? [];
        $category = FieldConfigSchema::getFieldCategory($fieldType);
        $fieldKey = $config['field_key'] ?? $field;

        // Thread parent path from config into create for context-aware generation
        // (set by generateSubFieldValues for repeater/group sub-fields)
        if (!empty($config['_parent_path'])) {
            $create['parent_path'] = $config['_parent_path'];
            $create['_parent_path'] = $config['_parent_path'];
        } elseif ($this->currentPostType) {
            // Seed with post type for top-level fields so context rules
            // can use the full hierarchy (e.g. movie → awards → category)
            $create['parent_path'] = [$this->currentPostType];
            $create['_parent_path'] = [$this->currentPostType];
        }
        // For plugin-specific field types (ACFE, JetEngine), delegate to the adapter
        // which has specialized handlers for these field types
        $pluginSpecificTypes = [
            // ACFE types
            'acfe_',
            // JetEngine types that need adapter handling
            'colorpicker', 'iconpicker', 'switcher', 'datetime-local', 'posts',
            'media', 'gallery', 'date', 'time', 'datetime',
            // Meta Box types that need adapter handling
            'slider', 'select_advanced', 'checkbox_list', 'button_group',
            'autocomplete', 'image_select', 'switch', 'color',
            'file_input', 'file_advanced', 'file_upload',
            'image_upload', 'image_advanced', 'single_image', 'video',
            'post', 'taxonomy_advanced', 'map', 'osm',
            'key_value', 'fieldset_text', 'text_list', 'background', 'sidebar',
        ];

        // Types that must match exactly (not as prefix) to avoid false positives
        // e.g. 'post' must NOT match 'post_title', 'date' must NOT match 'date_range'
        $exactMatchOnly = ['post', 'date', 'time', 'color', 'switch', 'video', 'map'];

        $needsAdapterHandling = false;
        foreach ($pluginSpecificTypes as $type) {
            if (in_array($type, $exactMatchOnly, true)) {
                if ($fieldType === $type) {
                    $needsAdapterHandling = true;
                    break;
                }
            } elseif (str_starts_with($fieldType, $type) || $fieldType === $type) {
                $needsAdapterHandling = true;
                break;
            }
        }

        // ACPT fields: always delegate to adapter (identified by acpt_type in config)
        if (!$needsAdapterHandling && !empty($config['acpt_type'])) {
            $needsAdapterHandling = true;
        }

        if ($this->adapter && $needsAdapterHandling) {
            // Build a field definition array for the adapter
            $fieldDef = array_merge($config, $create, [
                'type' => $fieldType,
                'name' => $field,
                'key' => $fieldKey,
            ]);

            // Map acf_sub_fields to sub_fields for JetEngine compatibility
            if (!empty($config['acf_sub_fields']) && empty($fieldDef['sub_fields'])) {
                $fieldDef['sub_fields'] = $config['acf_sub_fields'];
            }

            // Map mb_fields to fields for Meta Box group/cloneable compatibility
            if (!empty($config['mb_fields']) && empty($fieldDef['fields'])) {
                $fieldDef['fields'] = $config['mb_fields'];
            }

            // Pass exclude post ID for relationship fields
            if ($excludePostId) {
                $fieldDef['exclude_post_id'] = $excludePostId;
            }

            $value = $this->adapter->generateFakeValue($fieldDef);
            if ($value !== null) {
                return $value;
            }
            // If adapter returns null, fall through to generic handling
        }

        // AI faker config check (from batch detection)
        // Skip for certain categories where built-in generation is better:
        // - text + locale: AI configs contain locale-insensitive values (English strings)
        // - numeric + prefix/suffix: unit range detection gives more realistic values
        // - datetime: user-configured or default date ranges are more appropriate
        if ($this->currentPostType && $this->detectionCache) {
            $cached = $this->detectionCache->getDetection($this->currentPostType, $field);
            if ($cached && !empty($cached['faker_config'])) {
                $hasUnitIndicators = ($create['prefix'] ?? '') !== '' || ($create['suffix'] ?? '') !== '';
                $skipAiCache = ($this->locale && $category === 'text')
                    || ($category === 'numeric' && $hasUnitIndicators)
                    || $category === 'datetime';
                if (!$skipAiCache) {
                    $aiValue = $this->executeAiFakerConfig($cached['faker_config']);
                    if ($aiValue !== null) {
                        return $aiValue;
                    }
                }
            }
        }

        // For complex fields, merge cached ACF data into the create config
        // This ensures sub_fields and layouts are available in generateComplexField
        if ($category === 'complex') {
            if (!empty($config['acf_sub_fields'])) {
                $create['acf_sub_fields'] = $config['acf_sub_fields'];
            }
            if (!empty($config['acf_layouts'])) {
                $create['acf_layouts'] = $config['acf_layouts'];
            }
            // Build hierarchical parent path: CPT → repeater → sub-field
            // For top-level fields, seed the path with the post type slug
            // so sub-fields get full context (e.g. ['movie', 'awards', 'category'])
            $parentPath = $config['_parent_path'] ?? [];
            if (empty($parentPath) && $this->currentPostType) {
                $parentPath = [$this->currentPostType];
            }
            if (!empty($parentPath)) {
                $create['_parent_path'] = $parentPath;
                $create['parent_path'] = $parentPath;
            }
        }

        // For datetime fields, detect birthday-type names and use appropriate date range
        if ($category === 'datetime' && !isset($create['range_start'])) {
            $birthdayPatterns = ['/birthday/i', '/birth.*date/i', '/date.*birth/i', '/geburtstag/i', '/dob\b/i', '/anniversaire/i', '/cumpleaños/i', '/compleanno/i', '/verjaardag/i', '/aniversário/i', '/urodziny/i', '/день.*рождения/i'];
            foreach ($birthdayPatterns as $pattern) {
                if (preg_match($pattern, $field)) {
                    $create['range_start'] = '-80 years';
                    $create['range_end'] = '-18 years';
                    break;
                }
            }
        }

        // For numeric fields, detect year-type names and generate realistic years
        $hasUserRange = is_numeric($create['min'] ?? null) && is_numeric($create['max'] ?? null)
            && !((int) ($create['min'] ?? 0) === 0 && (int) ($create['max'] ?? 0) >= 1000);
        if ($category === 'numeric' && !$hasUserRange) {
            $yearPatterns = ['/\byear\b/i', '/\bjahr\b/i', '/\bannée\b/i', '/\baño\b/i', '/\banno\b/i', '/\bjaar\b/i', '/\bgod\b/i'];
            $isYear = false;
            foreach ($yearPatterns as $pattern) {
                if (preg_match($pattern, $field)) {
                    $isYear = true;
                    break;
                }
            }
            // Also check parent path context for year detection
            if (!$isYear && !empty($create['parent_path'])) {
                $fieldPath = array_merge($create['parent_path'], [$field]);
                $detectedType = $this->fieldDetector->detectType($field, ['field_path' => $fieldPath]);
                if ($detectedType === 'year') {
                    $isYear = true;
                }
            }
            if ($isYear) {
                return (int) rand(1950, (int) date('Y'));
            }
        }

        $result = match ($category) {
            'text' => $this->generateTextField($field, $fieldType, $create),
            'numeric' => $this->generateNumberField($create),
            'datetime' => $this->generateDateField($fieldType, $create),
            'selection' => $this->generateSelectionField($fieldType, $create),
            'media' => $this->generateImageField($create, $field),
            'gallery' => $this->generateGalleryField($create),
            'relational' => $this->generateRelationshipField($fieldType, $create, $excludePostId),
            'taxonomy' => $this->generateTaxonomyField($create),
            'user' => $this->generateUserField($create),
            'complex' => $this->generateComplexField($fieldType, $create, $fieldKey, $field),
            'special' => $this->generateSpecialField($fieldType, $create),
            default => $this->generateTextField($field, $fieldType, $create),
        };

        return $result;
    }

    /**
     * Execute an AI-provided faker config safely
     *
     * @param array $fakerConfig ['method' => string, 'params' => array, 'confidence' => float]
     * @return mixed Generated value or null on failure
     */
    protected function executeAiFakerConfig(array $fakerConfig): mixed
    {
        $method = $fakerConfig['method'] ?? null;
        $params = $fakerConfig['params'] ?? [];

        if (!$method || !in_array($method, self::ALLOWED_FAKER_METHODS, true)) {
            return null;
        }

        // Validate params array
        if (!is_array($params) || count($params) > 10) {
            return null;
        }

        // Sanitize params: only allow scalar values and simple arrays
        foreach ($params as $param) {
            if (is_array($param)) {
                // Allow simple arrays (for randomElement/randomElements)
                foreach ($param as $item) {
                    if (!is_scalar($item)) {
                        return null;
                    }
                }
            } elseif (!is_scalar($param) && $param !== null) {
                return null;
            }
            // String params: limit length to prevent abuse
            if (is_string($param) && strlen($param) > 500) {
                return null;
            }
        }

        try {
            $faker = $this->locale
                ? $this->faker->forLocale($this->locale)
                : $this->faker->getInstance();

            // Intercept Lorem-generating methods and use realText() instead,
            // but only when the user hasn't explicitly chosen "Lorem Ipsum" text source.
            $loremMethods = ['sentence', 'words', 'paragraph', 'paragraphs', 'text', 'word'];
            if (in_array($method, $loremMethods, true) && FakerService::getTextSource() !== 'lorem') {
                try {
                    $result = $faker->realText(match ($method) {
                        'word', 'words' => rand(10, 30),
                        'sentence' => rand(40, 100),
                        'paragraph' => rand(100, 300),
                        'paragraphs' => rand(300, 800),
                        'text' => rand(100, 500),
                        default => 100,
                    });
                    // For 'words' method, the original returns an array or string
                    // realText returns a string which is fine for most uses
                    return $result;
                } catch (\InvalidArgumentException $e) {
                    // Fall through to normal execution if realText unavailable for this locale
                }
            }

            $value = $faker->$method(...$params);

            // Convert DateTime objects to string
            if ($value instanceof \DateTime || $value instanceof \DateTimeInterface) {
                $value = $value->format('Y-m-d H:i:s');
            }

            return $value;
        } catch (\Throwable $e) {
            error_log('WPfaker AI faker config execution failed: ' . $e->getMessage());
            return null;
        }
    }

    // ========================================
    // Text Field Generator
    // ========================================

    protected function generateTextField(string $fieldName, string $fieldType, array $config): string
    {
        // Handle oEmbed fields - generate video URLs
        if ($fieldType === 'oembed') {
            return $this->generateOembedUrl($config);
        }

        // If field has a detected_type from smart defaults, use its faker method directly.
        // This bypasses word_count checks that would otherwise cause lorem ipsum output.
        if (!empty($config['detected_type'])) {
            $value = $this->fieldDetector->generateForType($config['detected_type'], [], $this->locale);
            if ($value !== null) {
                return is_string($value) ? $value : (string) $value;
            }
        }

        // For wysiwyg and post_content fields, skip smart detection — they need HTML paragraphs.
        // Textarea fields DO get smart detection so field names like "Address" generate proper content.
        $isLongTextField = in_array($fieldType, ['wysiwyg', 'post_content'], true);

        // Use smart field name detection if enabled (default: true for text fields)
        // But skip for long text fields to ensure proper content
        // For sub-fields (has parent_path), always try smart detection first — context-aware
        // detection (e.g. "category" inside "awards" → award_category) is more valuable than
        // default word counts set by the frontend config defaults.
        $hasParentContext = !empty($config['parent_path']);
        $hasExplicitWordCount = isset($config['word_count_min']) || isset($config['word_count_max']);
        $useSmartDetection = ($config['use_smart_detection'] ?? true) && !$isLongTextField && ($hasParentContext || !$hasExplicitWordCount);

        if ($useSmartDetection) {
            // Build field_path from parent_path for context-aware detection
            $parentPath = $config['parent_path'] ?? [];
            $fieldConfig = [];
            if (!empty($parentPath)) {
                $fieldConfig['field_path'] = array_merge($parentPath, [$fieldName]);
            }

            // Check detection cache first
            if ($this->currentPostType && $this->detectionCache) {
                $cached = $this->detectionCache->getDetection($this->currentPostType, $fieldName);
                if ($cached) {
                    $cachedValue = $this->fieldDetector->generateForType($cached['detected_content_type'], [], $this->locale);
                    if ($cachedValue !== null) {
                        $stringValue = is_string($cachedValue) ? $cachedValue : (string) $cachedValue;
                        return $stringValue;
                    }
                }
            }

            $smartValue = $this->fieldDetector->detectAndGenerateWithoutAi($fieldName, $fieldConfig, $this->locale);
            if ($smartValue !== null) {
                // Only use smart value if it's a string with reasonable length
                // Skip numeric-looking values for text fields
                $stringValue = is_string($smartValue) ? $smartValue : (string) $smartValue;
                if (!is_numeric($smartValue) && strlen($stringValue) > 3) {
                    // Cache the detection result for future use
                    if ($this->currentPostType && $this->detectionCache) {
                        $detectedType = $this->fieldDetector->detectType($fieldName, $fieldConfig, $this->locale);
                        if ($detectedType) {
                            $this->detectionCache->saveDetection(
                                $this->currentPostType,
                                $fieldName,
                                $detectedType,
                                'pattern',
                                1.0
                            );
                        }
                    }
                    return $stringValue;
                }
            }
        }

        // Default to 'words' when word count is explicitly configured (frontend sets word_count but not faker_method for single-line fields)
        $defaultMethod = $hasExplicitWordCount ? 'words' : 'sentence';
        $method = $config['faker_method'] ?? $defaultMethod;

        // Handle special text field types
        if ($fieldType === 'email') {
            return $this->faker->email();
        }

        if ($fieldType === 'url') {
            return $this->faker->url();
        }

        // Handle wysiwyg fields - generate HTML paragraphs by default
        if ($fieldType === 'wysiwyg' || $fieldType === 'post_content') {
            $paragraphMin = $config['paragraph_count_min'] ?? 3;
            $paragraphMax = $config['paragraph_count_max'] ?? 7;
            $includeHtml = $config['include_html'] ?? true;
            $count = rand($paragraphMin, $paragraphMax);

            if ($includeHtml) {
                return $this->generateHtmlContent($count, $config['html_options'] ?? [
                    'headings' => true,
                    'lists' => true,
                    'blockquotes' => false,
                ]);
            }

            $paragraphs = [];
            for ($i = 0; $i < $count; $i++) {
                $paragraphs[] = $this->localeText(rand(200, 400));
            }
            return implode("\n\n", $paragraphs);
        }

        // Handle textarea fields - check for list-like or domain-specific content
        if ($fieldType === 'textarea') {
            $fieldNameLower = strtolower($fieldName);

            // Check for plot/synopsis patterns - generate locale-aware paragraphs
            if (strpos($fieldNameLower, 'plot') !== false || strpos($fieldNameLower, 'handlung') !== false ||
                strpos($fieldNameLower, 'synopsis') !== false || strpos($fieldNameLower, 'storyline') !== false ||
                strpos($fieldNameLower, 'inhaltsangabe') !== false || strpos($fieldNameLower, 'beschreibung') !== false) {
                $count = rand(1, 3);
                $paragraphs = [];
                for ($i = 0; $i < $count; $i++) {
                    $paragraphs[] = $this->localeText(rand(100, 300));
                }
                return implode("\n\n", $paragraphs);
            }

            // Check for ingredient list patterns
            if (strpos($fieldNameLower, 'zutaten') !== false || strpos($fieldNameLower, 'ingredient') !== false) {
                return $this->generateIngredientList();
            }

            // Check for instruction/step patterns
            if (strpos($fieldNameLower, 'anleitung') !== false || strpos($fieldNameLower, 'instruction') !== false ||
                strpos($fieldNameLower, 'schritte') !== false || strpos($fieldNameLower, 'steps') !== false) {
                return $this->generateInstructionList();
            }

            // Check for general list patterns
            if (strpos($fieldNameLower, 'liste') !== false || strpos($fieldNameLower, 'list') !== false) {
                return $this->generateSimpleList();
            }

            // Check for tips patterns
            if (strpos($fieldNameLower, 'tipps') !== false || strpos($fieldNameLower, 'tips') !== false ||
                strpos($fieldNameLower, 'hinweis') !== false) {
                return $this->generateTipsList();
            }

            // Default textarea: multiple paragraphs
            return $this->generateParagraphs($config);
        }

        return match ($method) {
            'sentence' => $this->generateSentence($config),
            'paragraphs' => $this->generateParagraphs($config),
            'words' => $this->generateWords($config),
            'text' => $this->generateText($config),
            default => $this->generateSentence($config),
        };
    }

    /**
     * Generate a list of ingredients (one per line)
     */
    protected function generateIngredientList(): string
    {
        $ingredients = [
            // German ingredients
            '200g Mehl', '3 Eier', '250ml Milch', '100g Butter', '1 TL Salz',
            '2 EL Olivenöl', '1 Zwiebel, gewürfelt', '2 Knoblauchzehen, gehackt',
            '400g Tomaten (Dose)', '150g Parmesan, gerieben', '500g Hackfleisch',
            '1 Bund Petersilie', '200g Sahne', '300g Nudeln', '2 Paprika, in Streifen',
            '100g Champignons', '1 Zitrone (Saft und Abrieb)', '50g Pinienkerne',
            '1 TL Paprikapulver', '½ TL Kreuzkümmel', '200g Mozzarella',
            '1 Dose Kichererbsen', '150g Feta', '2 EL Honig', '1 EL Senf',
        ];

        shuffle($ingredients);
        $count = rand(6, 12);
        $selected = array_slice($ingredients, 0, $count);

        return implode("\n", $selected);
    }

    /**
     * Generate cooking instructions (numbered steps)
     */
    protected function generateInstructionList(): string
    {
        $steps = [
            'Die Zutaten vorbereiten und abwiegen.',
            'Den Ofen auf 180°C vorheizen.',
            'Die Zwiebeln in einer Pfanne mit Öl glasig dünsten.',
            'Das Fleisch hinzufügen und scharf anbraten.',
            'Die Tomaten und Gewürze unterrühren.',
            'Alles 20 Minuten bei mittlerer Hitze köcheln lassen.',
            'Die Nudeln nach Packungsanleitung kochen.',
            'Den Käse über das Gericht streuen.',
            'Mit frischen Kräutern garnieren.',
            'Sofort servieren und genießen.',
            'Die Sauce abschmecken und nachwürzen.',
            'Das Gemüse bissfest garen.',
            'Den Teig gut durchkneten.',
            'Alles gut vermischen.',
            'Im vorgeheizten Ofen backen bis goldbraun.',
        ];

        shuffle($steps);
        $count = rand(5, 8);
        $selected = array_slice($steps, 0, $count);

        $numbered = [];
        foreach ($selected as $i => $step) {
            $numbered[] = ($i + 1) . '. ' . $step;
        }

        return implode("\n", $numbered);
    }

    /**
     * Generate a simple list (one item per line)
     */
    protected function generateSimpleList(): string
    {
        $items = [];
        $count = rand(4, 8);

        for ($i = 0; $i < $count; $i++) {
            $text = $this->localeText(rand(15, 30));
            // Strip trailing punctuation for list items
            $items[] = rtrim($text, '.!?…');
        }

        return implode("\n", $items);
    }

    /**
     * Generate tips/hints list
     */
    protected function generateTipsList(): string
    {
        $tips = [
            'Am besten frische Zutaten verwenden.',
            'Das Gericht schmeckt auch am nächsten Tag noch gut.',
            'Kann gut eingefroren werden.',
            'Für Vegetarier: Fleisch durch Tofu ersetzen.',
            'Passt gut zu einem frischen Salat.',
            'Mit einem Glas Wein servieren.',
            'Die Gewürze nach Geschmack anpassen.',
            'Reste können als Meal Prep verwendet werden.',
            'Für mehr Schärfe etwas Chili hinzufügen.',
            'Frische Kräuter erst zum Schluss zugeben.',
        ];

        shuffle($tips);
        $count = rand(2, 4);
        $selected = array_slice($tips, 0, $count);

        return implode("\n\n", $selected);
    }

    protected function generateSentence(array $config): string
    {
        $minWords = $config['word_count_min'] ?? 3;
        $maxWords = $config['word_count_max'] ?? 10;
        $charEstimate = rand($minWords, $maxWords) * 7;

        return $this->localeText($charEstimate);
    }

    protected function generateParagraphs(array $config): string
    {
        $minParagraphs = $config['paragraph_count_min'] ?? 2;
        $maxParagraphs = $config['paragraph_count_max'] ?? 5;
        $count = rand($minParagraphs, $maxParagraphs);
        $includeHtml = $config['include_html'] ?? false;

        if ($includeHtml) {
            return $this->generateHtmlContent($count, $config['html_options'] ?? []);
        }

        $paragraphs = [];
        for ($i = 0; $i < $count; $i++) {
            $paragraphs[] = $this->localeText(rand(200, 400));
        }

        return implode("\n\n", $paragraphs);
    }

    protected function generateHtmlContent(int $paragraphCount, array $options): string
    {
        $content = [];
        $addHeadings = $options['headings'] ?? true;
        $addLists = $options['lists'] ?? true;
        $addBlockquotes = $options['blockquotes'] ?? false;

        for ($i = 0; $i < $paragraphCount; $i++) {
            // Add heading before some paragraphs
            if ($addHeadings && $i > 0 && rand(1, 3) === 1) {
                $level = rand(2, 4);
                $heading = rtrim($this->localeText(rand(20, 50)), '.!?…');
                $content[] = sprintf('<h%d>%s</h%d>', $level, $heading, $level);
            }

            // Regular paragraph
            $content[] = '<p>' . $this->localeText(rand(200, 400)) . '</p>';

            // Occasionally add list
            if ($addLists && rand(1, 4) === 1) {
                $content[] = $this->generateHtmlList();
            }

            // Occasionally add blockquote
            if ($addBlockquotes && rand(1, 5) === 1) {
                $content[] = '<blockquote><p>' . $this->localeText(rand(60, 150)) . '</p></blockquote>';
            }
        }

        return implode("\n\n", $content);
    }

    protected function generateHtmlList(): string
    {
        $isOrdered = rand(0, 1) === 1;
        $tag = $isOrdered ? 'ol' : 'ul';
        $itemCount = rand(3, 6);

        $items = [];
        for ($i = 0; $i < $itemCount; $i++) {
            $items[] = '<li>' . $this->localeText(rand(30, 80)) . '</li>';
        }

        return sprintf('<%s>%s</%s>', $tag, implode('', $items), $tag);
    }

    protected function generateWords(array $config): string
    {
        $minWords = $config['word_count_min'] ?? 3;
        $maxWords = $config['word_count_max'] ?? 10;
        $wordCount = rand($minWords, $maxWords);
        $charEstimate = $wordCount * 6;

        $text = $this->localeText($charEstimate);
        // Trim to approximate word count
        $words = explode(' ', $text);
        return implode(' ', array_slice($words, 0, $wordCount));
    }

    protected function generateText(array $config): string
    {
        $maxChars = $config['max_chars'] ?? 200;
        return $this->localeText($maxChars);
    }

    // ========================================
    // oEmbed Field Generator
    // ========================================

    /**
     * Generate a video URL for oEmbed fields
     *
     * @param array $config Configuration options
     * @return string A YouTube or Vimeo URL
     */
    protected function generateOembedUrl(array $config): string
    {
        $provider = $config['provider'] ?? 'random';

        // Handle custom URLs
        if ($provider === 'custom' && !empty($config['custom_urls'])) {
            $customUrls = array_filter(
                array_map('trim', explode("\n", $config['custom_urls'])),
                fn($url) => !empty($url) && filter_var($url, FILTER_VALIDATE_URL)
            );

            if (!empty($customUrls)) {
                return $customUrls[array_rand($customUrls)];
            }
            // Fall through to random if no valid custom URLs
        }

        // Curated list of embeddable sample videos
        $youtubeVideos = [
            'https://www.youtube.com/watch?v=dQw4w9WgXcQ', // Rick Astley - Never Gonna Give You Up
            'https://www.youtube.com/watch?v=9bZkp7q19f0', // PSY - Gangnam Style
            'https://www.youtube.com/watch?v=JGwWNGJdvx8', // Ed Sheeran - Shape of You
            'https://www.youtube.com/watch?v=kJQP7kiw5Fk', // Luis Fonsi - Despacito
            'https://www.youtube.com/watch?v=RgKAFK5djSk', // Wiz Khalifa - See You Again
            'https://www.youtube.com/watch?v=OPf0YbXqDm0', // Mark Ronson - Uptown Funk
            'https://www.youtube.com/watch?v=fRh_vgS2dFE', // Justin Bieber - Sorry
            'https://www.youtube.com/watch?v=CevxZvSJLk8', // Katy Perry - Roar
            'https://www.youtube.com/watch?v=09R8_2nJtjg', // Maroon 5 - Sugar
            'https://www.youtube.com/watch?v=hT_nvWreIhg', // OneRepublic - Counting Stars
        ];

        $vimeoVideos = [
            'https://vimeo.com/148751763', // Nature
            'https://vimeo.com/236254412', // Drone footage
            'https://vimeo.com/253989945', // Travel
            'https://vimeo.com/315163963', // Architecture
            'https://vimeo.com/259411563', // Short film
            'https://vimeo.com/286898202', // Nature documentary
            'https://vimeo.com/169599296', // Timelapse
            'https://vimeo.com/217499569', // Ocean
        ];

        // Select provider
        if ($provider === 'youtube') {
            return $youtubeVideos[array_rand($youtubeVideos)];
        }

        if ($provider === 'vimeo') {
            return $vimeoVideos[array_rand($vimeoVideos)];
        }

        // Random: 70% YouTube, 30% Vimeo
        if (rand(1, 100) <= 70) {
            return $youtubeVideos[array_rand($youtubeVideos)];
        }

        return $vimeoVideos[array_rand($vimeoVideos)];
    }

    // ========================================
    // Number Field Generator
    // ========================================

    protected function generateNumberField(array $config): int|float|string
    {
        $prefix = $config['prefix'] ?? '';
        $suffix = $config['suffix'] ?? '';

        // If no explicit min/max set, try prefix/suffix unit detection.
        // Exclude default values (min=0, max>=1000) — these come from
        // FieldConfigSchema defaults and don't represent user intent.
        $hasExplicitRange = is_numeric($config['min'] ?? null) && is_numeric($config['max'] ?? null)
            && !((int) ($config['min'] ?? 0) === 0 && (int) ($config['max'] ?? 0) >= 1000);
        if (!$hasExplicitRange && ($prefix !== '' || $suffix !== '')) {
            $unitRange = \WPFaker\Adapters\AbstractFieldPluginAdapter::detectUnitRangeStatic(
                (string) $prefix,
                (string) $suffix
            );
            if ($unitRange !== null) {
                $decimals = (int) ($config['decimal_places'] ?? $unitRange['decimals'] ?? 0);
                if ($decimals > 0) {
                    $value = $unitRange['min'] + (mt_rand() / mt_getrandmax()) * ($unitRange['max'] - $unitRange['min']);
                    $value = round($value, $decimals);
                    return $this->formatNumberForLocale($value, $decimals);
                }
                return rand($unitRange['min'], $unitRange['max']);
            }
        }

        // Ensure numeric values (ACF may pass strings)
        $min = is_numeric($config['min'] ?? null) ? (float) $config['min'] : 0;
        $max = is_numeric($config['max'] ?? null) ? (float) $config['max'] : 1000;
        $step = is_numeric($config['step'] ?? null) ? (float) $config['step'] : 1;
        $decimals = (int) ($config['decimal_places'] ?? 0);

        // Ensure min <= max
        if ($min > $max) {
            [$min, $max] = [$max, $min];
        }

        // Ensure step is positive
        if ($step <= 0) {
            $step = 1;
        }

        if ($decimals > 0) {
            $value = $min + (mt_rand() / mt_getrandmax()) * ($max - $min);
            $value = round($value, $decimals);

            // Format according to locale (German uses comma as decimal separator)
            return $this->formatNumberForLocale($value, $decimals);
        }

        // For integers with step
        $range = ($max - $min) / $step;
        $steps = rand(0, max(0, (int) $range));

        return (int) ($min + ($steps * $step));
    }

    /**
     * Format a number according to the current locale
     *
     * @param float $value The numeric value
     * @param int $decimals Number of decimal places
     * @return string|float Formatted number (string for locales using comma)
     */
    protected function formatNumberForLocale(float $value, int $decimals): string|float
    {
        // German-speaking locales use comma as decimal separator
        $germanLocales = ['de_DE', 'de_AT', 'de_CH'];

        if ($this->locale && in_array($this->locale, $germanLocales)) {
            return number_format($value, $decimals, ',', '');
        }

        // For other locales, return the raw float value
        return $value;
    }

    // ========================================
    // Date Field Generator
    // ========================================

    protected function generateDateField(string $fieldType, array $config): string
    {
        $start = $config['range_start'] ?? '-1 year';
        $end = $config['range_end'] ?? 'now';

        // ACF date_picker stores dates internally as Ymd (e.g. "20260304").
        // We save via update_post_meta(), so we must use ACF's storage format,
        // not the return_format (which is only for get_field() output).
        $format = $this->getStorageFormat($fieldType, $config['format'] ?? null);

        $startTimestamp = strtotime($start);
        $endTimestamp = strtotime($end);

        if ($startTimestamp === false) {
            $startTimestamp = strtotime('-1 year');
        }
        if ($endTimestamp === false) {
            $endTimestamp = time();
        }

        $randomTimestamp = rand($startTimestamp, $endTimestamp);

        return date($format, $randomTimestamp);
    }

    /**
     * Get the storage format for a date field type.
     *
     * ACF date_picker requires Ymd format in the database. Other field types
     * use their own storage formats. The $configFormat (from ACF return_format)
     * is only used for non-ACF field types as a fallback.
     */
    protected function getStorageFormat(string $fieldType, ?string $configFormat): string
    {
        return match ($fieldType) {
            'date_picker' => 'Ymd',
            'time_picker' => 'H:i:s',
            'date_time_picker' => 'Y-m-d H:i:s',
            'post_date' => 'Y-m-d H:i:s',
            default => $configFormat ?? 'Y-m-d',
        };
    }

    // ========================================
    // Selection Field Generator
    // ========================================

    /**
     * Generate a value for selection fields (select, checkbox, radio, true_false, button_group)
     *
     * @param string $fieldType The field type
     * @param array $config The create configuration
     * @return mixed Selected value(s)
     */
    protected function generateSelectionField(string $fieldType, array $config): mixed
    {
        // Handle true_false (boolean) fields — ACF stores as '0' or '1', not booleans
        if ($fieldType === 'true_false') {
            return rand(0, 1);
        }

        // Get choices from config
        $choices = $config['choices'] ?? [];

        if (empty($choices)) {
            // Fallback: return null or default value
            return match ($fieldType) {
                'checkbox' => [],
                default => '',
            };
        }

        // Get choice keys
        $keys = array_keys($choices);

        // Handle multi-select fields (checkbox)
        if ($fieldType === 'checkbox') {
            $minSelections = $config['min_selections'] ?? 1;
            $maxSelections = $config['max_selections'] ?? min(3, count($keys));
            $count = rand($minSelections, $maxSelections);

            shuffle($keys);
            return array_slice($keys, 0, $count);
        }

        // Handle select fields with multiple option (JetEngine/ACF)
        $isMultiple = !empty($config['multiple']) || !empty($config['is_multiple']);
        if ($isMultiple) {
            $minSelections = $config['min_selections'] ?? 1;
            $maxSelections = $config['max_selections'] ?? min(3, count($keys));
            $count = rand($minSelections, $maxSelections);

            shuffle($keys);
            return array_slice($keys, 0, $count);
        }

        // Handle single-select fields (select, radio, button_group)
        return $keys[array_rand($keys)];
    }

    // ========================================
    // Image Field Generator
    // ========================================

    protected function generateImageField(array $config, string $fieldName = ''): ?int
    {
        // Check if this is a logo field — generate a logo instead of a random photo
        if ($fieldName !== '' && FieldNameDetector::isLogoField($fieldName)) {
            $seed = $this->faker->getInstance()->company();
            $logoId = LogoService::generateLogo($seed);
            if ($logoId > 0) {
                return $logoId;
            }
        }

        // Try reusing from pool first
        if ($this->imagePoolCallback) {
            $poolId = ($this->imagePoolCallback)();
            if ($poolId !== null) {
                return $poolId;
            }
        }

        $provider = $config['provider'] ?? 'unsplash';
        $category = $config['category'] ?? null;
        $width = $config['width'] ?? 1200;
        $height = $config['height'] ?? 800;

        // Auto-detect category from post type context if not explicitly set
        if (!$category && $this->currentPostType) {
            $category = ImageService::guessCategoryForPostType($this->currentPostType, $this->cptContextData);
        }

        // Use ImageService to download and create attachment
        $this->imageService
            ->setProvider($provider)
            ->setDimensions($width, $height);

        $attachmentId = $this->imageService->downloadImage(
            'Generated Image',
            $category
        );

        return $attachmentId ?: null;
    }

    // ========================================
    // Gallery Field Generator
    // ========================================

    protected function generateGalleryField(array $config): array
    {
        $minCount = $config['count_min'] ?? 3;
        $maxCount = $config['count_max'] ?? 8;
        $count = rand($minCount, $maxCount);

        $attachmentIds = [];
        for ($i = 0; $i < $count; $i++) {
            $id = $this->generateImageField($config);
            if ($id) {
                $attachmentIds[] = $id;
            }
        }

        return $attachmentIds;
    }

    // ========================================
    // Relationship Field Generator
    // ========================================

    /**
     * Generate value for relational fields (post_object, relationship, page_link)
     *
     * @param string $fieldType The specific field type
     * @param array $config Configuration options
     * @param int|null $excludePostId Post ID to exclude (prevents self-reference)
     * @return array|int|null Post ID(s)
     */
    protected function generateRelationshipField(string $fieldType, array $config, ?int $excludePostId = null): array|int|null
    {
        $batchPostIds = $config['batch_post_ids'] ?? [];
        $useVariation = $config['use_variation'] ?? false;

        // If we have batch post IDs, use batch-aware generation
        if (!empty($batchPostIds)) {
            return $this->generateRelationshipFieldFromBatch($fieldType, $config, $batchPostIds, $useVariation);
        }

        // Fallback: existing behavior for non-batch cases (backward compatible)
        $postTypes = $config['filter_by_post_type'] ?? ['post', 'page'];
        $minCount = (int) ($config['count_min'] ?? 1);
        $maxCount = (int) ($config['count_max'] ?? 5);

        // Base query args
        $baseArgs = [
            'post_type' => $postTypes,
            'orderby' => 'rand',
            'fields' => 'ids',
            'post_status' => ['publish', 'draft'], // Include drafts for variation
        ];

        // Exclude current post to prevent self-reference
        if ($excludePostId) {
            $baseArgs['post__not_in'] = [$excludePostId];
        }

        // Fetch a pool of candidates and shuffle locally (MySQL rand() with small
        // pools tends to return the same result across sequential calls)
        $poolSize = max(20, $maxCount * 3);
        $args = array_merge($baseArgs, ['posts_per_page' => $poolSize]);
        $posts = get_posts($args);

        if (empty($posts)) {
            return $fieldType === 'post_object' ? null : [];
        }

        shuffle($posts);

        // For post_object (single), return just one ID
        if ($fieldType === 'post_object') {
            return (int) $posts[0];
        }

        // For relationship and page_link, return multiple IDs
        $count = rand($minCount, min($maxCount, count($posts)));

        return array_slice($posts, 0, $count);
    }

    /**
     * Generate relationship field value from batch post IDs
     *
     * Without variation: use ALL batch posts (full interconnection)
     * With variation: random subset of batch posts
     *
     * @param string $fieldType The specific field type
     * @param array $config Configuration options
     * @param array $batchPostIds Other post IDs from the current batch
     * @param bool $useVariation Whether to randomize relations
     * @return array|int|null Post ID(s)
     */
    protected function generateRelationshipFieldFromBatch(
        string $fieldType,
        array $config,
        array $batchPostIds,
        bool $useVariation
    ): array|int|null {
        if (empty($batchPostIds)) {
            return $fieldType === 'post_object' ? null : [];
        }

        // For single-value fields (post_object), always pick a random post
        // to distribute across available targets (e.g. agents → different agencies)
        if ($fieldType === 'post_object') {
            return (int) $batchPostIds[array_rand($batchPostIds)];
        }

        // Always select a random subset using count_min/count_max from field config
        $minCount = (int) ($config['count_min'] ?: 1);
        $maxCount = (int) ($config['count_max'] ?: 3);
        $available = count($batchPostIds);
        $maxCount = min($maxCount, $available);
        $minCount = min($minCount, $maxCount);
        $count = rand($minCount, $maxCount);
        shuffle($batchPostIds);
        $selected = array_slice($batchPostIds, 0, $count);
        return array_map('intval', $selected);
    }

    // ========================================
    // User Field Generator
    // ========================================

    /**
     * Generate value for user fields
     *
     * @param array $config Configuration options
     * @return int|null User ID
     */
    protected function generateUserField(array $config): ?int
    {
        $roles = $config['filter_by_role'] ?? ['author', 'editor', 'administrator'];

        $args = [
            'role__in' => $roles,
            'number' => 1,
            'orderby' => 'rand',
            'fields' => 'ID',
        ];

        $users = get_users($args);

        return !empty($users) ? (int) $users[0] : null;
    }

    // ========================================
    // Taxonomy Field Generator
    // ========================================

    /**
     * Generate value for taxonomy fields
     *
     * @param array $config Configuration options
     * @return array|int|null Term ID(s)
     */
    protected function generateTaxonomyField(array $config): array|int|null
    {
        $taxonomy = $config['taxonomy'] ?? 'category';
        $multiple = $config['multiple'] ?? true;
        $minCount = $config['count_min'] ?? 1;
        $maxCount = $config['count_max'] ?? 3;

        // Get existing terms from this taxonomy
        $terms = get_terms([
            'taxonomy' => $taxonomy,
            'hide_empty' => false,
            'number' => $multiple ? rand($minCount, $maxCount) : 1,
            'orderby' => 'rand',
            'fields' => 'ids',
        ]);

        if (is_wp_error($terms) || empty($terms)) {
            return $multiple ? [] : null;
        }

        // Return single ID or array based on field settings
        if (!$multiple) {
            return (int) $terms[0];
        }

        return array_map('intval', $terms);
    }

    // ========================================
    // Complex Field Generator (Repeater, Flexible Content)
    // ========================================

    protected function generateComplexField(string $fieldType, array $config, string $fieldKey, string $fieldName = ''): array
    {
        if ($fieldType === 'flexible_content') {
            return $this->generateFlexibleContent($config, $fieldKey);
        }

        if ($fieldType === 'group') {
            return $this->generateGroup($config, $fieldKey, $fieldName);
        }

        return $this->generateRepeater($config, $fieldKey, $fieldName);
    }

    protected function generateRepeater(array $config, string $fieldKey, string $fieldName = ''): array
    {
        $minRows = $config['row_count_min'] ?? 1;
        $maxRows = $config['row_count_max'] ?? 5;
        $rowCount = rand($minRows, $maxRows);

        // Build parent path using field NAME (not key) for context-aware detection
        // CONTEXT_RULES match on names like "awards", not ACF keys like "field_69aaad2b0651f"
        $parentPath = $config['_parent_path'] ?? [];
        $pathSegment = $fieldName ?: $config['_field_name'] ?? $fieldKey;
        $currentPath = array_merge($parentPath, [$pathSegment]);

        // Priority: 1) explicit sub_fields config, 2) cached acf_sub_fields, 3) fetch from ACF
        $subFields = $config['sub_fields'] ?? [];

        // Check for cached ACF sub_fields (set by buildAutoFieldConfig for nested fields)
        if (empty($subFields) && !empty($config['acf_sub_fields'])) {
            $subFields = $config['acf_sub_fields'];
        }

        // If still empty, try to fetch from ACF
        if (empty($subFields) && $this->adapter) {
            $subFields = $this->getSubFieldsFromAcf($fieldKey);
        }

        // When sub_fields is partially configured (only some sub-fields have explicit config),
        // merge with ACF definitions for the missing ones so all sub-fields get generated.
        if (!empty($subFields) && $this->adapter) {
            $hasConfiguredSubFields = false;
            foreach ($subFields as $sf) {
                if (isset($sf['mode'])) {
                    $hasConfiguredSubFields = true;
                    break;
                }
            }

            if ($hasConfiguredSubFields) {
                $acfSubFields = $this->getSubFieldsFromAcf($fieldKey);
                foreach ($acfSubFields as $acfSf) {
                    $sfName = $acfSf['name'] ?? '';
                    if ($sfName && !isset($subFields[$sfName])) {
                        $subFields[$sfName] = $acfSf;
                    }
                }
            }
        }

        $rows = [];
        for ($i = 0; $i < $rowCount; $i++) {
            $row = $this->generateSubFieldValues($subFields, $i, $currentPath);
            if (!empty($row)) {
                $rows[] = $row;
            }
        }

        return $rows;
    }

    protected function generateGroup(array $config, string $fieldKey, string $fieldName = ''): array
    {
        // Build parent path using field NAME for context-aware detection
        $parentPath = $config['_parent_path'] ?? [];
        $pathSegment = $fieldName ?: $config['_field_name'] ?? $fieldKey;
        $currentPath = array_merge($parentPath, [$pathSegment]);

        // Priority: 1) explicit sub_fields config, 2) cached acf_sub_fields, 3) fetch from ACF
        $subFields = $config['sub_fields'] ?? [];

        if (empty($subFields) && !empty($config['acf_sub_fields'])) {
            $subFields = $config['acf_sub_fields'];
        }

        if (empty($subFields) && $this->adapter) {
            $subFields = $this->getSubFieldsFromAcf($fieldKey);
        }

        // Merge missing ACF sub-fields when only some are explicitly configured
        if (!empty($subFields) && $this->adapter) {
            $hasConfiguredSubFields = false;
            foreach ($subFields as $sf) {
                if (isset($sf['mode'])) {
                    $hasConfiguredSubFields = true;
                    break;
                }
            }

            if ($hasConfiguredSubFields) {
                $acfSubFields = $this->getSubFieldsFromAcf($fieldKey);
                foreach ($acfSubFields as $acfSf) {
                    $sfName = $acfSf['name'] ?? '';
                    if ($sfName && !isset($subFields[$sfName])) {
                        $subFields[$sfName] = $acfSf;
                    }
                }
            }
        }

        return $this->generateSubFieldValues($subFields, 0, $currentPath);
    }

    protected function generateFlexibleContent(array $config, string $fieldKey): array
    {
        $minRows = $config['row_count_min'] ?? 2;
        $maxRows = $config['row_count_max'] ?? 6;
        $rowCount = rand($minRows, $maxRows);
        $layouts = $config['layouts'] ?? [];
        $weights = $config['layout_weights'] ?? [];

        // Build parent path: combine existing parent_field chain with this field's key
        $parentPath = $config['_parent_path'] ?? [];
        $currentPath = array_merge($parentPath, [$fieldKey]);

        // Check for cached ACF layouts (set by buildAutoFieldConfig for nested fields)
        if (empty($layouts) && !empty($config['acf_layouts'])) {
            foreach ($config['acf_layouts'] as $layout) {
                $layoutName = $layout['name'] ?? '';
                if ($layoutName) {
                    $layouts[$layoutName] = [
                        'sub_fields' => $layout['sub_fields'] ?? [],
                    ];
                }
            }
        }

        // If still empty, try to fetch from ACF
        if (empty($layouts) && $this->adapter) {
            $acfField = $this->adapter->getFieldConfig($fieldKey);
            if ($acfField && !empty($acfField['layouts'])) {
                foreach ($acfField['layouts'] as $layout) {
                    $layoutName = $layout['name'] ?? '';
                    if ($layoutName) {
                        $layouts[$layoutName] = [
                            'sub_fields' => $layout['sub_fields'] ?? [],
                        ];
                    }
                }
            }
        }

        if (empty($layouts)) {
            return [];
        }

        $layoutNames = array_keys($layouts);
        $rows = [];

        for ($i = 0; $i < $rowCount; $i++) {
            // Select layout based on weights or random
            $layoutName = $this->selectLayoutByWeight($layoutNames, $weights);
            $layout = $layouts[$layoutName] ?? [];
            $subFieldsConfig = $layout['sub_fields'] ?? [];

            $row = ['acf_fc_layout' => $layoutName];

            // Generate sub-field values
            $subFieldValues = $this->generateSubFieldValues($subFieldsConfig, $i, $currentPath);
            $row = array_merge($row, $subFieldValues);

            $rows[] = $row;
        }

        return $rows;
    }

    /**
     * Get sub-fields from ACF field definition
     *
     * @param string $fieldKey The field key or name
     * @return array Sub-fields from ACF (as ACF field definitions, not configs)
     */
    protected function getSubFieldsFromAcf(string $fieldKey): array
    {
        if (!$this->adapter) {
            return [];
        }

        $acfField = $this->adapter->getFieldConfig($fieldKey);

        if (!$acfField) {
            return [];
        }

        if (empty($acfField['sub_fields'])) {
            return [];
        }

        return $acfField['sub_fields'];
    }

    /**
     * Generate values for sub-fields
     *
     * Handles both configured sub-fields (with mode/create settings) and
     * raw ACF sub-field definitions (auto-generates based on type).
     *
     * @param array $subFields Sub-field configurations or ACF definitions
     * @param int $rowIndex Current row index
     * @return array Generated values keyed by field name
     */
    protected function generateSubFieldValues(array $subFields, int $rowIndex, array $parentPath = []): array
    {
        $row = [];

        foreach ($subFields as $key => $subField) {
            // Check if this is a configured sub-field (has 'mode') or raw ACF definition
            if (isset($subField['mode'])) {
                // Configured sub-field - inject parent path for nested repeaters/groups
                $subField['_parent_path'] = $parentPath;
                // Configured sub-field - use resolveFieldValue
                $value = $this->resolveFieldValue($key, $subField, $rowIndex);
                if ($value !== null) {
                    $row[$key] = $value;
                }
            } else {
                // Raw ACF field definition — check if the template has a flat config for this sub-field
                $fieldName = $subField['name'] ?? $key;
                $templateConfig = $this->currentCustomConfig[$fieldName] ?? null;

                if ($templateConfig && isset($templateConfig['mode']) && $templateConfig['mode'] !== 'none') {
                    // Template has a config for this sub-field name — use it
                    $templateConfig['_parent_path'] = $parentPath;
                    $value = $this->resolveFieldValue($fieldName, $templateConfig, $rowIndex);
                } else {
                    // No template config — auto-generate based on ACF type
                    $fieldType = $subField['type'] ?? 'text';
                    $value = $this->autoGenerateFieldValue($fieldName, $fieldType, $subField, $parentPath);
                }

                if ($value !== null) {
                    $row[$fieldName] = $value;
                }
            }
        }

        return $row;
    }

    /**
     * Auto-generate a field value based on ACF/JetEngine field definition
     *
     * @param string $fieldName The field name
     * @param string $fieldType The field type (ACF, JetEngine, etc.)
     * @param array $fieldDef The complete field definition
     * @return mixed Generated value
     */
    protected function autoGenerateFieldValue(string $fieldName, string $fieldType, array $fieldDef, array $parentPath = []): mixed
    {
        // For plugin-specific field types (ACFE, JetEngine, Meta Box), delegate to the adapter
        $pluginSpecificTypes = [
            'acfe_', 'colorpicker', 'iconpicker', 'switcher', 'datetime-local',
            'posts', 'media', 'gallery', 'date', 'time', 'datetime',
            // Meta Box types
            'slider', 'select_advanced', 'checkbox_list', 'button_group',
            'autocomplete', 'image_select', 'switch', 'color',
            'file_input', 'file_advanced', 'file_upload',
            'image_upload', 'image_advanced', 'single_image', 'video',
            'post', 'taxonomy_advanced', 'map', 'osm',
            'key_value', 'fieldset_text', 'text_list', 'background', 'sidebar',
        ];

        $exactMatchOnly = ['post', 'date', 'time', 'color', 'switch', 'video', 'map'];

        $needsAdapterHandling = false;
        foreach ($pluginSpecificTypes as $type) {
            if (in_array($type, $exactMatchOnly, true)) {
                if ($fieldType === $type) {
                    $needsAdapterHandling = true;
                    break;
                }
            } elseif (str_starts_with($fieldType, $type) || $fieldType === $type) {
                $needsAdapterHandling = true;
                break;
            }
        }

        if ($this->adapter && $needsAdapterHandling) {
            $value = $this->adapter->generateFakeValue($fieldDef);
            if ($value !== null) {
                return $value;
            }
            // If adapter returns null, fall through to generic handling
        }

        $category = FieldConfigSchema::getFieldCategory($fieldType);

        return match ($category) {
            'text' => $this->generateTextField($fieldName, $fieldType, [
                'use_smart_detection' => true,
                'parent_path' => $parentPath,
            ]),
            'numeric' => $this->autoGenerateNumericField($fieldName, $fieldDef, $parentPath),
            'datetime' => $this->generateDateField($fieldType, []),
            'selection' => $this->autoGenerateSelectionValue($fieldDef),
            'media' => $this->generateImageField([], $fieldName),
            'gallery' => $this->generateGalleryField([]),
            'relational' => $this->generateRelationshipField($fieldType, [
                'filter_by_post_type' => $fieldDef['post_type'] ?? ['post', 'page'],
            ]),
            'taxonomy' => $this->generateTaxonomyField([
                'taxonomy' => $fieldDef['taxonomy'] ?? 'category',
                'multiple' => !empty($fieldDef['multiple']) || ($fieldDef['field_type'] ?? '') === 'multi_select',
            ]),
            'user' => $this->generateUserField([]),
            'complex' => $this->generateComplexField(
                $fieldType,
                [
                    // Pass sub_fields for repeater/group
                    'acf_sub_fields' => $fieldDef['sub_fields'] ?? [],
                    // Pass layouts for flexible_content
                    'acf_layouts' => $fieldDef['layouts'] ?? [],
                    // Pass parent path for context-aware detection
                    // Seed with post type for top-level fields so sub-fields get full hierarchy
                    '_parent_path' => !empty($parentPath) ? $parentPath : ($this->currentPostType ? [$this->currentPostType] : []),
                ],
                $fieldDef['key'] ?? $fieldName,
                $fieldName
            ),
            'special' => $this->generateSpecialField($fieldType, []),
            default => $this->generateTextField($fieldName, 'text', []),
        };
    }

    /**
     * Auto-generate a numeric field value with context-aware year detection
     */
    protected function autoGenerateNumericField(string $fieldName, array $fieldDef, array $parentPath = []): int|float|string
    {
        // Check if this is a year field by name or context
        $yearPatterns = ['/\byear\b/i', '/\bjahr\b/i', '/\bannée\b/i', '/\baño\b/i'];
        foreach ($yearPatterns as $pattern) {
            if (preg_match($pattern, $fieldName)) {
                return rand(1950, (int) date('Y'));
            }
        }

        // Also check via context rules if parent path is available
        if (!empty($parentPath)) {
            $fieldPath = array_merge($parentPath, [$fieldName]);
            $detectedType = $this->fieldDetector->detectType($fieldName, ['field_path' => $fieldPath]);
            if ($detectedType === 'year') {
                return rand(1950, (int) date('Y'));
            }
        }

        return $this->generateNumberField([
            'min' => $fieldDef['min'] ?? 0,
            'max' => $fieldDef['max'] ?? 1000,
            'step' => $fieldDef['step'] ?? 1,
        ]);
    }

    /**
     * Auto-generate a value for selection fields (select, radio, checkbox, etc.)
     *
     * @param array $fieldDef The ACF field definition
     * @return mixed Selected value(s)
     */
    protected function autoGenerateSelectionValue(array $fieldDef): mixed
    {
        $fieldType = $fieldDef['type'] ?? 'select';
        $choices = $fieldDef['choices'] ?? [];

        // true_false field — ACF stores as '0' or '1', not booleans
        if ($fieldType === 'true_false') {
            return rand(0, 1);
        }

        if (empty($choices)) {
            return null;
        }

        $choiceKeys = array_keys($choices);

        // Checkbox can have multiple values
        if ($fieldType === 'checkbox') {
            $count = rand(1, min(3, count($choiceKeys)));
            shuffle($choiceKeys);
            return array_slice($choiceKeys, 0, $count);
        }

        // Select with multiple option (JetEngine/ACF)
        $isMultiple = !empty($fieldDef['multiple']) || !empty($fieldDef['is_multiple']);
        if ($isMultiple) {
            $count = rand(1, min(3, count($choiceKeys)));
            shuffle($choiceKeys);
            return array_slice($choiceKeys, 0, $count);
        }

        // Single selection
        return $choiceKeys[array_rand($choiceKeys)];
    }

    protected function selectLayoutByWeight(array $layouts, array $weights): string
    {
        if (empty($weights)) {
            return $layouts[array_rand($layouts)];
        }

        $totalWeight = array_sum($weights);
        $random = rand(1, $totalWeight);
        $cumulative = 0;

        foreach ($weights as $layout => $weight) {
            $cumulative += $weight;
            if ($random <= $cumulative) {
                return $layout;
            }
        }

        return $layouts[array_rand($layouts)];
    }

    // ========================================
    // Special Field Generators
    // ========================================

    protected function generateSpecialField(string $fieldType, array $config): mixed
    {
        return match ($fieldType) {
            'color_picker' => $this->generateColorField($config),
            'google_map' => $this->generateMapField($config),
            'link' => $this->generateLinkField($config),
            default => null,
        };
    }

    protected function generateColorField(array $config): string
    {
        $palette = $config['palette'] ?? 'random';

        return match ($palette) {
            'pastel' => $this->generatePastelColor(),
            'vibrant' => $this->generateVibrantColor(),
            'monochrome' => $this->generateMonochromeColor(),
            default => sprintf('#%06X', rand(0, 0xFFFFFF)),
        };
    }

    protected function generatePastelColor(): string
    {
        $r = rand(180, 255);
        $g = rand(180, 255);
        $b = rand(180, 255);
        return sprintf('#%02X%02X%02X', $r, $g, $b);
    }

    protected function generateVibrantColor(): string
    {
        $hue = rand(0, 360);
        return $this->hslToHex($hue, 100, 50);
    }

    protected function generateMonochromeColor(): string
    {
        $gray = rand(0, 255);
        return sprintf('#%02X%02X%02X', $gray, $gray, $gray);
    }

    protected function hslToHex(int $h, int $s, int $l): string
    {
        $s /= 100;
        $l /= 100;

        $c = (1 - abs(2 * $l - 1)) * $s;
        $x = $c * (1 - abs(fmod($h / 60, 2) - 1));
        $m = $l - $c / 2;

        [$r, $g, $b] = match (true) {
            $h < 60 => [$c, $x, 0],
            $h < 120 => [$x, $c, 0],
            $h < 180 => [0, $c, $x],
            $h < 240 => [0, $x, $c],
            $h < 300 => [$x, 0, $c],
            default => [$c, 0, $x],
        };

        $r = (int) (($r + $m) * 255);
        $g = (int) (($g + $m) * 255);
        $b = (int) (($b + $m) * 255);

        return sprintf('#%02X%02X%02X', $r, $g, $b);
    }

    protected function generateMapField(array $config): array
    {
        $centerLat = $config['center_lat'] ?? 48.8566;
        $centerLng = $config['center_lng'] ?? 2.3522;
        $radiusKm = $config['radius_km'] ?? 50;

        // Generate random point within radius
        $radiusDeg = $radiusKm / 111; // Approximate km to degrees
        $lat = $centerLat + (rand(-100, 100) / 100 * $radiusDeg);
        $lng = $centerLng + (rand(-100, 100) / 100 * $radiusDeg);

        return [
            'address' => $this->faker->address(),
            'lat' => round($lat, 6),
            'lng' => round($lng, 6),
            'zoom' => 14,
        ];
    }

    protected function generateLinkField(array $config): array
    {
        $includeTitle = $config['include_title'] ?? true;
        $targetBlank = $config['target_blank'] ?? false;

        return [
            'url' => $this->faker->url(),
            'title' => $includeTitle ? rtrim($this->localeText(rand(20, 40)), '.!?…') : '',
            'target' => $targetBlank ? '_blank' : '',
        ];
    }

    // ========================================
    // Selection Helpers
    // ========================================

    protected function getChooseValues(array $choose, string $fieldType): array
    {
        // Different value keys for different field types
        $valueKeys = [
            'values', 'dates', 'attachment_ids', 'post_ids',
            'user_ids', 'colors', 'locations', 'links', 'subset',
        ];

        foreach ($valueKeys as $key) {
            if (!empty($choose[$key])) {
                return $choose[$key];
            }
        }

        return [];
    }

    protected function isMultipleSelection(string $fieldType, array $choose): bool
    {
        // Field types that support multiple selection
        $multipleTypes = ['checkbox', 'gallery', 'relationship', 'post_object'];

        if (in_array($fieldType, $multipleTypes, true)) {
            return true;
        }

        // Check if multiple is explicitly enabled
        return !empty($choose['multiple']);
    }

    protected function selectValue(string $field, array $values, string $mode, int $index): mixed
    {
        if (empty($values)) {
            return null;
        }

        return match ($mode) {
            'rotation' => $this->selectRotation($field, $values),
            'weighted' => $this->selectWeighted($values),
            default => $values[array_rand($values)], // random
        };
    }

    protected function selectMultipleValues(
        string $field,
        array $values,
        array $choose,
        int $index,
        string $mode
    ): array {
        // If use_all is set or no min/max specified with specific IDs, use all values
        $useAll = $choose['use_all'] ?? false;
        $hasExplicitCounts = isset($choose['min_selections']) || isset($choose['max_selections'])
                          || isset($choose['count_min']) || isset($choose['count_max']);

        if ($useAll || (!$hasExplicitCounts && !empty($choose['attachment_ids']))) {
            return $values;
        }

        $minCount = $choose['min_selections'] ?? $choose['count_min'] ?? 1;
        $maxCount = $choose['max_selections'] ?? $choose['count_max'] ?? count($values);
        $count = rand($minCount, min($maxCount, count($values)));

        if ($mode === 'rotation') {
            return $this->selectRotationMultiple($field, $values, $count);
        }

        // Random selection
        $keys = array_rand($values, min($count, count($values)));
        if (!is_array($keys)) {
            $keys = [$keys];
        }

        return array_values(array_intersect_key($values, array_flip($keys)));
    }

    protected function selectRotation(string $field, array $values): mixed
    {
        $key = 'rotation_' . $field;

        if (!isset($this->rotationIndices[$key])) {
            $this->rotationIndices[$key] = 0;
        }

        $index = $this->rotationIndices[$key] % count($values);
        $this->rotationIndices[$key]++;

        return $values[$index];
    }

    protected function selectRotationMultiple(string $field, array $values, int $count): array
    {
        $key = 'rotation_multi_' . $field;

        if (!isset($this->rotationIndices[$key])) {
            $this->rotationIndices[$key] = 0;
        }

        $startIndex = $this->rotationIndices[$key] % count($values);
        $this->rotationIndices[$key] += $count;

        $result = [];
        for ($i = 0; $i < $count; $i++) {
            $idx = ($startIndex + $i) % count($values);
            $result[] = $values[$idx];
        }

        return $result;
    }

    protected function selectWeighted(array $valuesWithWeights): mixed
    {
        // Expects format: ['value' => weight, ...]
        $total = array_sum($valuesWithWeights);
        $random = rand(1, $total);
        $cumulative = 0;

        foreach ($valuesWithWeights as $value => $weight) {
            $cumulative += $weight;
            if ($random <= $cumulative) {
                return $value;
            }
        }

        return array_key_first($valuesWithWeights);
    }

    // ========================================
    // Save Helpers
    // ========================================

    protected function saveCustomFieldValue(int $postId, string $fieldName, mixed $value, array $config): void
    {
        // Use adapter if available
        if ($this->adapter && $this->adapter->isActive()) {
            $fieldKey = $config['field_key'] ?? $fieldName;
            $fieldType = $config['field_type'] ?? 'text';

            // For complex fields (repeater, flexible_content, group), use field NAME not KEY
            // ACF's update_field works better with the field name for these types
            $selector = $fieldName;

            /**
             * Filter a generated field value before saving.
             *
             * @param mixed  $value        The generated value.
             * @param array  $config       The field configuration array.
             * @param string $postType     The post type slug.
             * @param int    $postId       The post ID.
             */
            $value = apply_filters('wpfaker_field_value', $value, $config, $this->currentPostType ?? '', $postId);

            $this->adapter->saveFieldValue($postId, $selector, $value);
            return;
        }

        /**
         * Filter a generated field value before saving.
         *
         * @param mixed  $value        The generated value.
         * @param array  $config       The field configuration array.
         * @param string $postType     The post type slug.
         * @param int    $postId       The post ID.
         */
        $value = apply_filters('wpfaker_field_value', $value, $config, $this->currentPostType ?? '', $postId);

        // Fallback to standard meta
        update_post_meta($postId, $fieldName, $value);
    }

    /**
     * Reset rotation indices (call between batches if needed)
     */
    public function resetRotation(): void
    {
        $this->rotationIndices = [];
    }
}
