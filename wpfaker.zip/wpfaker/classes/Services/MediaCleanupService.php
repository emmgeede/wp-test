<?php

namespace WPFaker\Services;

/**
 * Media Cleanup Service
 *
 * Handles automatic deletion of WPfaker-generated media when posts are deleted.
 */
class MediaCleanupService
{
    /**
     * Setting key for auto-delete media
     */
    public const SETTING_KEY = 'delete_media_with_posts';

    /**
     * Initialize the service
     *
     * @return void
     */
    public static function init(): void
    {
        add_action('before_delete_post', [self::class, 'onPostDelete'], 10, 2);
    }

    /**
     * Check if auto-delete is enabled
     *
     * @return bool
     */
    public static function isAutoDeleteEnabled(): bool
    {
        $settings = get_option('wpfaker_settings', []);
        return !empty($settings[self::SETTING_KEY]);
    }

    /**
     * Hook callback: Delete media when a WPfaker post is deleted
     *
     * @param int $postId
     * @param \WP_Post $post
     * @return void
     */
    public static function onPostDelete(int $postId, \WP_Post $post): void
    {
        // Skip if auto-delete is disabled
        if (!self::isAutoDeleteEnabled()) {
            return;
        }

        // Skip attachments (we don't want to recursively delete)
        if ($post->post_type === 'attachment') {
            return;
        }

        // Only process WPfaker-generated posts
        if (!get_post_meta($postId, '_wpfaker_generated', true)) {
            return;
        }

        self::deletePostMedia($postId);
    }

    /**
     * Delete all WPfaker-generated media attached to a post
     *
     * @param int $postId
     * @return int Number of media items deleted
     */
    public static function deletePostMedia(int $postId): int
    {
        $deleted = 0;
        $deletedIds = []; // Track deleted IDs to avoid double-deletion

        // 1. Delete Featured Image if WPfaker-generated
        $thumbnailId = get_post_thumbnail_id($postId);
        if ($thumbnailId && get_post_meta($thumbnailId, '_wpfaker_generated', true)) {
            if (wp_delete_attachment($thumbnailId, true)) {
                $deleted++;
                $deletedIds[] = $thumbnailId;
            }
        }

        // 2. Delete all attachments with post_parent that are WPfaker-generated
        $attachments = get_posts([
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => -1,
            'post_parent'    => $postId,
            'meta_key'       => '_wpfaker_generated',
            'meta_value'     => '1',
            'fields'         => 'ids',
        ]);

        foreach ($attachments as $attachmentId) {
            // Skip if already deleted (e.g., if featured image was also a child)
            if (in_array($attachmentId, $deletedIds, true)) {
                continue;
            }

            if (wp_delete_attachment($attachmentId, true)) {
                $deleted++;
                $deletedIds[] = $attachmentId;
            }
        }

        return $deleted;
    }

    /**
     * Delete orphaned WPFaker media for a specific post type.
     * Orphaned = post_parent is 0 or points to a deleted post.
     *
     * @param string $postType
     * @return int Number of media items deleted
     */
    public static function deleteOrphanedMedia(string $postType): int
    {
        $orphaned = ImageService::getReusablePool($postType);
        $deleted = 0;

        foreach ($orphaned as $attachmentId) {
            if (wp_delete_attachment($attachmentId, true)) {
                $deleted++;
            }
        }

        return $deleted;
    }

    /**
     * Delete all WPfaker-generated content (posts, terms, users, media)
     *
     * @return array Statistics of deleted items
     */
    public static function deleteAllGeneratedData(): array
    {
        $stats = [
            'posts'  => 0,
            'terms'  => 0,
            'users'  => 0,
            'media'  => 0,
        ];

        // 1. Delete all WPfaker-generated media first
        // This prevents the before_delete_post hook from interfering
        $stats['media'] = ImageService::deleteGeneratedImages(true);

        // 2. Delete all WPfaker-generated posts via history
        $historyService = new HistoryService();
        $postIds = $historyService->getIdsByType('post');

        foreach ($postIds as $postId) {
            if (wp_delete_post($postId, true)) {
                $stats['posts']++;
            }
        }

        // 3. Delete all WPfaker-generated terms
        $termIds = $historyService->getIdsByType('term');

        foreach ($termIds as $termId) {
            $term = get_term($termId);
            if ($term && !is_wp_error($term)) {
                $result = wp_delete_term($termId, $term->taxonomy);
                if (!is_wp_error($result) && $result !== false) {
                    $stats['terms']++;
                }
            }
        }

        // 4. Delete all WPfaker-generated users (except administrators)
        $userIds = $historyService->getIdsByType('user');

        // wp_delete_user() is in wp-admin/includes/user.php, not loaded during REST requests
        if (!function_exists('wp_delete_user')) {
            require_once ABSPATH . 'wp-admin/includes/user.php';
        }

        foreach ($userIds as $userId) {
            $user = get_user_by('ID', $userId);
            if ($user && !in_array('administrator', $user->roles, true)) {
                if (wp_delete_user($userId)) {
                    $stats['users']++;
                }
            }
        }

        // 5. Clear the history table
        $historyService->clearAll();

        return $stats;
    }
}
