<?php

namespace WPFaker;

/**
 * License management for WPfaker
 */
class License
{
    private const LICENSE_OPTION = 'wpfaker_license';
    private const LICENSE_STATUS_OPTION = 'wpfaker_license_status';
    private const LICENSE_CACHE_DURATION = DAY_IN_SECONDS;
    private const API_URL = 'https://wpfaker.com/api/wpfaker-license/v1';
    private const API_SECRET = 'wpf_8k3mX9pL2nR7vQ4wY6tB1cF5hJ0sA3dG';

    /**
     * Generate a unique site fingerprint
     *
     * This fingerprint is used to identify a specific WordPress installation
     * and prevent license key sharing across multiple sites.
     *
     * Components:
     * - Database prefix (unique per installation)
     * - AUTH_KEY (from wp-config.php, unique per installation)
     * - Site URL (domain binding)
     * - ABSPATH hash (installation path)
     *
     * @return string SHA256 hash fingerprint
     */
    public static function generateFingerprint(): string
    {
        global $wpdb;

        $components = [
            // Database prefix - unique per WP installation
            $wpdb->prefix ?? 'wp_',

            // WordPress security keys (set during installation)
            defined('AUTH_KEY') ? AUTH_KEY : '',
            defined('SECURE_AUTH_KEY') ? SECURE_AUTH_KEY : '',

            // Site URL for domain binding
            home_url(),

            // Installation path hash
            defined('ABSPATH') ? ABSPATH : '',

            // Database name (if accessible)
            defined('DB_NAME') ? DB_NAME : '',
        ];

        // Create a deterministic hash from all components
        $fingerprintData = implode('|', $components);

        return hash('sha256', $fingerprintData);
    }

    /**
     * Get a shortened version of the fingerprint for display
     *
     * @return string First 8 + last 8 characters of fingerprint
     */
    public static function getShortFingerprint(): string
    {
        $fingerprint = self::generateFingerprint();
        return substr($fingerprint, 0, 8) . '...' . substr($fingerprint, -8);
    }

    /**
     * Get fingerprint components for debugging (without sensitive data)
     *
     * @return array
     */
    public static function getFingerprintInfo(): array
    {
        global $wpdb;

        return [
            'fingerprint' => self::getShortFingerprint(),
            'full_fingerprint' => self::generateFingerprint(),
            'components' => [
                'db_prefix' => $wpdb->prefix ?? 'wp_',
                'has_auth_key' => defined('AUTH_KEY') && !empty(AUTH_KEY),
                'has_secure_auth_key' => defined('SECURE_AUTH_KEY') && !empty(SECURE_AUTH_KEY),
                'site_url' => home_url(),
                'abspath_hash' => defined('ABSPATH') ? substr(md5(ABSPATH), 0, 8) : 'n/a',
                'db_name_hash' => defined('DB_NAME') ? substr(md5(DB_NAME), 0, 8) : 'n/a',
            ],
        ];
    }

    /**
     * Get the stored license key
     */
    public static function getKey(): string
    {
        return get_option(self::LICENSE_OPTION, '');
    }

    /**
     * Save the license key
     */
    public static function saveKey(string $key): bool
    {
        $key = sanitize_text_field(trim($key));

        // Clear cached status when key changes
        delete_transient(self::LICENSE_STATUS_OPTION);

        if (empty($key)) {
            delete_option(self::LICENSE_OPTION);
            delete_option(self::LICENSE_STATUS_OPTION . '_data');
            return true;
        }

        return update_option(self::LICENSE_OPTION, $key);
    }

    /**
     * Activate the license on the current site
     */
    public static function activate(string $key): array
    {
        $response = self::apiRequest('activate', [
            'license_key' => $key,
            'site_url' => home_url(),
            'site_fingerprint' => self::generateFingerprint(),
        ]);

        if ($response['success']) {
            self::saveKey($key);
            // Activation response has 'success' but Check response has 'valid'.
            // Normalize so cached status always has 'valid' for isValid() check.
            $statusData = $response['data']['data'] ?? $response['data'];
            if (!isset($statusData['valid']) && !empty($statusData['success'])) {
                $statusData['valid'] = true;
            }
            self::cacheStatus($statusData);
        }

        return $response;
    }

    /**
     * Deactivate the license from the current site
     */
    public static function deactivate(): array
    {
        $key = self::getKey();

        if (empty($key)) {
            return [
                'success' => false,
                'message' => __('No license key found.', 'wpfaker'),
            ];
        }

        $response = self::apiRequest('deactivate', [
            'license_key' => $key,
            'site_url' => home_url(),
            'site_fingerprint' => self::generateFingerprint(),
        ]);

        if ($response['success']) {
            self::saveKey('');
        }

        return $response;
    }

    /**
     * Check if the license is valid
     */
    public static function isValid(): bool
    {
        $status = self::getStatus();
        return $status['valid'] ?? false;
    }

    /**
     * Get the license status (cached)
     */
    public static function getStatus(): array
    {
        $key = self::getKey();

        if (empty($key)) {
            return [
                'valid' => false,
                'status' => 'inactive',
                'message' => __('No license key entered.', 'wpfaker'),
            ];
        }

        // Check cache first
        $cached = get_transient(self::LICENSE_STATUS_OPTION);
        if ($cached !== false) {
            return $cached;
        }

        // Check persistent cache if transient expired
        $persistentCache = get_option(self::LICENSE_STATUS_OPTION . '_data');
        if ($persistentCache && !empty($persistentCache['valid'])) {
            // Restore transient from persistent cache while we verify
            set_transient(self::LICENSE_STATUS_OPTION, $persistentCache, self::LICENSE_CACHE_DURATION);
        }

        // Fetch fresh status
        $response = self::apiRequest('check', [
            'license_key' => $key,
            'site_url' => home_url(),
            'site_fingerprint' => self::generateFingerprint(),
        ]);

        if ($response['success']) {
            // Extract the inner data object which contains valid, status, etc.
            $statusData = $response['data']['data'] ?? $response['data'];
            self::cacheStatus($statusData);
            return $statusData;
        }

        // API failed - if we have a valid persistent cache, trust it
        if ($persistentCache && !empty($persistentCache['valid'])) {
            // Keep the license valid if it was valid before
            set_transient(self::LICENSE_STATUS_OPTION, $persistentCache, HOUR_IN_SECONDS);
            return $persistentCache;
        }

        // Return error status but don't cache failures for long
        $errorStatus = [
            'valid' => false,
            'status' => 'error',
            'message' => $response['message'] ?? __('Could not verify license.', 'wpfaker'),
        ];

        set_transient(self::LICENSE_STATUS_OPTION, $errorStatus, HOUR_IN_SECONDS);

        return $errorStatus;
    }

    /**
     * Force refresh the license status
     */
    public static function refreshStatus(): array
    {
        delete_transient(self::LICENSE_STATUS_OPTION);
        return self::getStatus();
    }

    /**
     * Get license data for update requests
     */
    public static function getUpdateData(): array
    {
        return [
            'license_key' => self::getKey(),
            'site_url' => home_url(),
            'site_fingerprint' => self::generateFingerprint(),
            'wp_version' => get_bloginfo('version'),
            'php_version' => PHP_VERSION,
            'plugin_version' => defined('WPF_VERSION') ? WPF_VERSION : '0.0.0',
        ];
    }

    /**
     * Cache the license status
     */
    private static function cacheStatus(array $data): void
    {
        set_transient(self::LICENSE_STATUS_OPTION, $data, self::LICENSE_CACHE_DURATION);
        update_option(self::LICENSE_STATUS_OPTION . '_data', $data);
    }

    /**
     * Make an API request to the license server
     */
    private static function apiRequest(string $endpoint, array $data): array
    {
        $baseUrl = defined('WPFAKER_API_URL')
            ? WPFAKER_API_URL . '/license'
            : self::API_URL;
        $url = $baseUrl . '/' . $endpoint;
        $body = wp_json_encode($data);
        $timestamp = time();
        $signature = self::generateSignature($body, $timestamp);

        $response = wp_remote_post($url, [
            'timeout' => 15,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-WPfaker-Timestamp' => $timestamp,
                'X-WPfaker-Signature' => $signature,
            ],
            'body' => $body,
        ]);

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message(),
            ];
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if ($code !== 200) {
            return [
                'success' => false,
                'message' => $data['message'] ?? __('License server error.', 'wpfaker'),
            ];
        }

        return [
            'success' => true,
            'data' => $data,
            'message' => $data['message'] ?? '',
        ];
    }

    /**
     * Generate HMAC signature for API request
     */
    private static function generateSignature(string $body, int $timestamp): string
    {
        // Go API expects: timestamp + body (no separator)
        // Old Astro API used: timestamp . '.' . body
        $payload = defined('WPFAKER_API_URL')
            ? $timestamp . $body
            : $timestamp . '.' . $body;
        return hash_hmac('sha256', $payload, self::API_SECRET);
    }
}
