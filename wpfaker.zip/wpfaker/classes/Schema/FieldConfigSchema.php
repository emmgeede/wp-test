<?php

declare(strict_types=1);

namespace WPFaker\Schema;

use WPFaker\Services\FieldNameDetector;

/**
 * Schema definitions and validation for field configurations.
 * Supports Core Fields, Custom Fields with None/Choose/Create pattern.
 */
class FieldConfigSchema
{
    /**
     * Mapping from FieldNameDetector detected types to Faker method names
     */
    private const DETECTED_TYPE_TO_FAKER_METHOD = [
        'first_name'    => 'firstName',
        'last_name'     => 'lastName',
        'full_name'     => 'name',
        'email'         => 'email',
        'phone'         => 'phoneNumber',
        'website'       => 'url',
        'street'        => 'streetName',
        'house_number'  => 'buildingNumber',
        'postal_code'   => 'postcode',
        'city'          => 'city',
        'state'         => 'state',
        'country'       => 'country',
        'company'       => 'company',
        'job_title'     => 'jobTitle',
        'iban'          => 'iban',
        // Additional detected types can be mapped here as needed.
        // Types not listed fall through to generic 'sentence' defaults.
    ];

    /**
     * Field type to category mapping
     */
    private const FIELD_CATEGORIES = [
        // Text fields
        'text' => 'text',
        'textarea' => 'text',
        'wysiwyg' => 'text',
        'post_title' => 'text',
        'post_content' => 'text',
        'post_excerpt' => 'text',
        'email' => 'text',
        'url' => 'text',
        'password' => 'text',
        'oembed' => 'text',

        // Numeric fields
        'number' => 'numeric',
        'range' => 'numeric',

        // Date/Time fields
        'date_picker' => 'datetime',
        'date_time_picker' => 'datetime',
        'time_picker' => 'datetime',
        'post_date' => 'datetime',

        // Selection fields
        'select' => 'selection',
        'radio' => 'selection',
        'checkbox' => 'selection',
        'button_group' => 'selection',
        'true_false' => 'selection',
        'post_status' => 'selection',

        // Media fields
        'image' => 'media',
        'file' => 'media',
        'gallery' => 'gallery',

        // Relational fields
        'post_object' => 'relational',
        'relationship' => 'relational',
        'page_link' => 'relational',
        'taxonomy' => 'taxonomy',
        'user' => 'user',
        'post_author' => 'user',

        // Complex fields
        'repeater' => 'complex',
        'flexible_content' => 'complex',
        'group' => 'complex',

        // Special fields
        'google_map' => 'special',
        'color_picker' => 'special',
        'link' => 'special',

        // ACFE Fields - Basic
        'acfe_advanced_link' => 'special',
        'acfe_code_editor' => 'text',
        'acfe_slug' => 'text',
        'acfe_hidden' => 'text',

        // ACFE Fields - Date
        'acfe_date_range_picker' => 'datetime',

        // ACFE Fields - Selectors (selection category)
        'acfe_countries' => 'selection',
        'acfe_currencies' => 'selection',
        'acfe_languages' => 'selection',
        'acfe_menus' => 'selection',
        'acfe_menu_locations' => 'selection',
        'acfe_post_formats' => 'selection',
        'acfe_post_statuses' => 'selection',
        'acfe_post_types' => 'selection',
        'acfe_taxonomies' => 'selection',
        'acfe_user_roles' => 'selection',
        'acfe_options_pages' => 'selection',
        'acfe_templates' => 'selection',
        'acfe_field_groups' => 'selection',
        'acfe_fields' => 'selection',
        'acfe_taxonomy_terms' => 'selection',
        'acfe_block_types' => 'selection',
        'acfe_image_selector' => 'selection',

        // ACFE Fields - Pro
        'acfe_phone_number' => 'text',
        'acfe_block_editor' => 'text',
        'acfe_address' => 'special',
        'acfe_field_types' => 'selection',
        'acfe_image_sizes' => 'selection',
        'acfe_post_field' => 'selection',

        // Meta Box Fields
        'slider' => 'numeric',
        'range' => 'numeric',
        'switch' => 'selection',
        'button_group' => 'selection',
        'image_select' => 'selection',
        'select_advanced' => 'selection',
        'checkbox_list' => 'selection',
        'autocomplete' => 'selection',
        'file_input' => 'text',
        'file_advanced' => 'media',
        'file_upload' => 'media',
        'image_upload' => 'media',
        'image_advanced' => 'media',
        'single_image' => 'media',
        'video' => 'media',
        'osm' => 'special',
        'map' => 'special',
        'color' => 'special',
        'key_value' => 'special',
        'fieldset_text' => 'special',
        'text_list' => 'special',
        'background' => 'special',
        'sidebar' => 'selection',
        'custom_html' => 'text',
        'post' => 'relational',
        'taxonomy_advanced' => 'taxonomy',

        // JetEngine Fields
        'colorpicker' => 'special',
        'iconpicker' => 'special',
        'switcher' => 'selection',
        'datetime-local' => 'datetime',
        'date' => 'datetime',
        'time' => 'datetime',
        'datetime' => 'datetime',
        'media' => 'media',
        'posts' => 'relational',
        'hidden' => 'text',

        // ACPT Fields - Text
        'editor' => 'text',
        'phone' => 'text',

        // ACPT Fields - Numeric
        'rating' => 'numeric',
        'currency' => 'numeric',
        'length' => 'numeric',
        'weight' => 'numeric',

        // ACPT Fields - DateTime
        'date_time' => 'datetime',
        'date_range' => 'datetime',

        // ACPT Fields - Selection
        'select_multi' => 'selection',
        'toggle' => 'selection',

        // ACPT Fields - Media
        'audio' => 'media',

        // ACPT Fields - Gallery
        'image_slider' => 'gallery',
        'audio_multi' => 'gallery',

        // ACPT Fields - Relational
        'post_object_multi' => 'relational',

        // ACPT Fields - Taxonomy
        'term_object' => 'taxonomy',
        'term_object_multi' => 'taxonomy',

        // ACPT Fields - User
        'user_multi' => 'user',

        // ACPT Fields - Complex
        'list' => 'complex',
        'table' => 'complex',
        'clone' => 'complex',

        // ACPT Fields - Special
        'html' => 'special',
        'icon' => 'special',
        'country' => 'special',
        'address' => 'special',
        'address_multi' => 'special',
        'embed' => 'special',
        'barcode' => 'special',
        'qr_code' => 'special',
        'id' => 'special',
    ];

    /**
     * Available modes per category (default)
     * Text and numeric fields only support none/create (no choose - doesn't make sense for these)
     */
    private const CATEGORY_MODES = [
        'text' => ['none', 'custom', 'create'],
        'numeric' => ['none', 'custom', 'create'],
        'datetime' => ['none', 'custom', 'create'],
        'selection' => ['none', 'choose'],
        'media' => ['none', 'choose', 'create'],
        'gallery' => ['none', 'choose', 'create'],
        'relational' => ['none', 'choose', 'create'],
        'user' => ['none', 'choose', 'create'],
        'complex' => ['none', 'create'],
        'special' => ['none', 'create'], // Default for special, overridden per type
    ];

    /**
     * Field type specific mode overrides
     * Use this when a field type needs different modes than its category default
     */
    private const FIELD_TYPE_MODES = [
        // Special fields - most only have none/create
        'google_map' => ['none', 'create'],
        'oembed' => ['none', 'create'],
        // Color picker can have predefined colors to choose from
        'color_picker' => ['none', 'choose', 'create'],
        // Link can have predefined links
        'link' => ['none', 'choose', 'create'],
    ];

    /**
     * Core fields list
     */
    public const CORE_FIELDS = [
        'post_title',
        'post_content',
        'post_excerpt',
        'post_date',
        'post_status',
        'post_author',
    ];

    /**
     * Get the category for a field type
     */
    public static function getFieldCategory(string $fieldType): string
    {
        return self::FIELD_CATEGORIES[$fieldType] ?? 'text';
    }

    /**
     * Get available modes for a field type
     */
    public static function getAvailableModes(string $fieldType): array
    {
        // Check for field-type specific overrides first
        if (isset(self::FIELD_TYPE_MODES[$fieldType])) {
            return self::FIELD_TYPE_MODES[$fieldType];
        }

        $category = self::getFieldCategory($fieldType);
        return self::CATEGORY_MODES[$category] ?? ['none', 'choose', 'create'];
    }

    /**
     * Check if a field type is a core field
     */
    public static function isCoreField(string $fieldType): bool
    {
        return in_array($fieldType, self::CORE_FIELDS, true);
    }

    /**
     * Get schema definition for a field type
     */
    public static function getSchemaForType(string $fieldType): array
    {
        $category = self::getFieldCategory($fieldType);

        $schemas = [
            'text' => self::getTextSchema($fieldType),
            'numeric' => self::getNumericSchema(),
            'datetime' => self::getDateTimeSchema($fieldType),
            'selection' => self::getSelectionSchema(),
            'media' => self::getMediaSchema(),
            'gallery' => self::getGallerySchema(),
            'relational' => self::getRelationalSchema(),
            'user' => self::getUserSchema(),
            'complex' => self::getComplexSchema($fieldType),
            'special' => self::getSpecialSchema($fieldType),
        ];

        return $schemas[$category] ?? $schemas['text'];
    }

    /**
     * Get default configuration for a field type
     */
    public static function getDefaultConfig(string $fieldType, ?string $fieldName = null): array
    {
        $category = self::getFieldCategory($fieldType);
        $modes = self::getAvailableModes($fieldType);

        $defaults = [
            'text' => self::getTextDefaults($fieldType, $fieldName),
            'numeric' => self::getNumericDefaults(),
            'datetime' => self::getDateTimeDefaults($fieldType),
            'selection' => self::getSelectionDefaults(),
            'media' => self::getMediaDefaults(),
            'gallery' => self::getGalleryDefaults(),
            'relational' => self::getRelationalDefaults(),
            'user' => self::getUserDefaults(),
            'complex' => self::getComplexDefaults($fieldType),
            'special' => self::getSpecialDefaults($fieldType),
        ];

        $config = $defaults[$category] ?? $defaults['text'];
        $config['mode'] = $modes[0] ?? 'none';
        $config['field_type'] = $fieldType;

        return $config;
    }

    /**
     * Validate a field configuration
     */
    public static function validate(array $config, string $fieldType): array
    {
        $errors = [];
        $schema = self::getSchemaForType($fieldType);
        $availableModes = self::getAvailableModes($fieldType);

        // Check mode
        if (!isset($config['mode'])) {
            $errors[] = 'Mode is required';
        } elseif (!in_array($config['mode'], $availableModes, true)) {
            $errors[] = sprintf(
                'Invalid mode "%s" for field type "%s". Available modes: %s',
                $config['mode'],
                $fieldType,
                implode(', ', $availableModes)
            );
        }

        // Mode-specific validation
        if (isset($config['mode'])) {
            switch ($config['mode']) {
                case 'choose':
                    $errors = array_merge($errors, self::validateChooseMode($config, $schema));
                    break;
                case 'create':
                    $errors = array_merge($errors, self::validateCreateMode($config, $schema));
                    break;
            }
        }

        return $errors;
    }

    /**
     * Validate choose mode configuration
     */
    private static function validateChooseMode(array $config, array $schema): array
    {
        $errors = [];

        if (!isset($config['choose']) || !is_array($config['choose'])) {
            return $errors; // Choose config is optional
        }

        $choose = $config['choose'];
        $chooseSchema = $schema['choose'] ?? [];

        // Validate selection_mode if present
        if (isset($choose['selection_mode'])) {
            $validModes = ['random', 'rotation', 'weighted'];
            if (!in_array($choose['selection_mode'], $validModes, true)) {
                $errors[] = 'Invalid selection_mode. Use: random, rotation, or weighted';
            }
        }

        // Validate probability range
        if (isset($choose['none_probability'])) {
            if ($choose['none_probability'] < 0 || $choose['none_probability'] > 100) {
                $errors[] = 'none_probability must be between 0 and 100';
            }
        }

        return $errors;
    }

    /**
     * Validate create mode configuration
     */
    private static function validateCreateMode(array $config, array $schema): array
    {
        $errors = [];

        if (!isset($config['create']) || !is_array($config['create'])) {
            return $errors; // Create config is optional
        }

        $create = $config['create'];

        // Validate numeric ranges
        if (isset($create['min']) && isset($create['max'])) {
            if ($create['min'] > $create['max']) {
                $errors[] = 'min cannot be greater than max';
            }
        }

        // Validate count ranges
        if (isset($create['count_min']) && isset($create['count_max'])) {
            if ($create['count_min'] > $create['count_max']) {
                $errors[] = 'count_min cannot be greater than count_max';
            }
        }

        // Validate word count ranges
        if (isset($create['word_count_min']) && isset($create['word_count_max'])) {
            if ($create['word_count_min'] > $create['word_count_max']) {
                $errors[] = 'word_count_min cannot be greater than word_count_max';
            }
        }

        return $errors;
    }

    /**
     * Get complete default field_config for a template
     */
    public static function getDefaultFieldConfig(): array
    {
        return [
            'core_fields' => [
                'post_title' => [
                    'mode' => 'create',
                    'field_type' => 'post_title',
                    'create' => [
                        'faker_method' => 'sentence',
                        'word_count_min' => 4,
                        'word_count_max' => 8,
                        'use_smart_detection' => true,
                    ],
                ],
                'post_content' => [
                    'mode' => 'create',
                    'field_type' => 'post_content',
                    'create' => [
                        'faker_method' => 'paragraphs',
                        'paragraph_count_min' => 3,
                        'paragraph_count_max' => 7,
                        'include_html' => true,
                        'html_options' => [
                            'headings' => true,
                            'lists' => true,
                            'blockquotes' => false,
                        ],
                    ],
                ],
                'post_excerpt' => [
                    'mode' => 'none',
                    'field_type' => 'post_excerpt',
                ],
                'post_date' => [
                    'mode' => 'create',
                    'field_type' => 'post_date',
                    'create' => [
                        'range_start' => '-1 year',
                        'range_end' => 'now',
                        'format' => 'Y-m-d H:i:s',
                    ],
                ],
                'post_status' => [
                    'mode' => 'choose',
                    'field_type' => 'post_status',
                    'choose' => [
                        'values' => ['publish'],
                        'selection_mode' => 'random',
                    ],
                ],
                'post_author' => [
                    'mode' => 'create',
                    'field_type' => 'post_author',
                    'create' => [
                        'use_existing_random' => true,
                        'filter_by_role' => ['author', 'editor', 'administrator'],
                    ],
                ],
            ],
            'custom_fields' => [],
        ];
    }

    // ========================================
    // Schema Definitions
    // ========================================

    private static function getTextSchema(string $fieldType): array
    {
        return [
            'mode' => ['none', 'choose', 'create'],
            'choose' => [
                'values' => 'array',
                'selection_mode' => ['random', 'rotation'],
                'include_none' => 'boolean',
                'none_probability' => 'integer',
            ],
            'create' => [
                'faker_method' => ['sentence', 'paragraphs', 'words', 'text'],
                'word_count_min' => 'integer',
                'word_count_max' => 'integer',
                'paragraph_count_min' => 'integer',
                'paragraph_count_max' => 'integer',
                'include_html' => 'boolean',
                'html_options' => [
                    'headings' => 'boolean',
                    'lists' => 'boolean',
                    'blockquotes' => 'boolean',
                ],
                'use_smart_detection' => 'boolean',
            ],
        ];
    }

    private static function getNumericSchema(): array
    {
        return [
            'mode' => ['none', 'choose', 'create'],
            'choose' => [
                'values' => 'array',
                'selection_mode' => ['random', 'rotation'],
            ],
            'create' => [
                'min' => 'number',
                'max' => 'number',
                'step' => 'number',
                'decimal_places' => 'integer',
            ],
        ];
    }

    private static function getDateTimeSchema(string $fieldType): array
    {
        $formats = [
            'date_picker' => 'Y-m-d',
            'date_time_picker' => 'Y-m-d H:i:s',
            'time_picker' => 'H:i:s',
            'post_date' => 'Y-m-d H:i:s',
        ];

        return [
            'mode' => ['none', 'custom', 'create'],
            'custom' => [
                'values' => 'array',
                'selection_mode' => ['random', 'sequential'],
            ],
            'create' => [
                'range_start' => 'string',
                'range_end' => 'string',
                'format' => $formats[$fieldType] ?? 'Y-m-d',
            ],
        ];
    }

    private static function getSelectionSchema(): array
    {
        return [
            'mode' => ['none', 'choose'],
            'choose' => [
                'subset' => 'array',
                'use_all_options' => 'boolean',
                'selection_mode' => ['random', 'rotation', 'weighted'],
                'weights' => 'object',
                'min_selections' => 'integer',
                'max_selections' => 'integer',
            ],
        ];
    }

    private static function getMediaSchema(): array
    {
        return [
            'mode' => ['none', 'choose', 'create'],
            'choose' => [
                'attachment_ids' => 'array',
                'selection_mode' => ['random', 'rotation'],
            ],
            'create' => [
                'provider' => ['picsum', 'pexels', 'pixabay', 'placeholder'],
                'category' => 'string',
                'width' => 'integer',
                'height' => 'integer',
            ],
        ];
    }

    private static function getGallerySchema(): array
    {
        return [
            'mode' => ['none', 'choose', 'create'],
            'choose' => [
                'attachment_ids' => 'array',
                'count_min' => 'integer',
                'count_max' => 'integer',
            ],
            'create' => [
                'count_min' => 'integer',
                'count_max' => 'integer',
                'provider' => ['picsum', 'pexels', 'pixabay', 'placeholder'],
                'category' => 'string',
            ],
        ];
    }

    private static function getRelationalSchema(): array
    {
        return [
            'mode' => ['none', 'choose', 'create'],
            'choose' => [
                'post_ids' => 'array',
                'filter_by_post_type' => 'array',
                'selection_mode' => ['random', 'rotation'],
                'count_min' => 'integer',
                'count_max' => 'integer',
            ],
            'create' => [
                'use_existing_random' => 'boolean',
                'filter_by_post_type' => 'array',
            ],
        ];
    }

    private static function getUserSchema(): array
    {
        return [
            'mode' => ['none', 'choose', 'create'],
            'choose' => [
                'user_ids' => 'array',
                'filter_by_role' => 'array',
                'selection_mode' => ['random', 'rotation'],
            ],
            'create' => [
                'use_existing_random' => 'boolean',
                'filter_by_role' => 'array',
            ],
        ];
    }

    private static function getComplexSchema(string $fieldType): array
    {
        if ($fieldType === 'flexible_content') {
            return [
                'mode' => ['none', 'create'],
                'create' => [
                    'row_count_min' => 'integer',
                    'row_count_max' => 'integer',
                    'layout_weights' => 'object',
                    'layouts' => 'object',
                ],
            ];
        }

        // Repeater and group
        return [
            'mode' => ['none', 'create'],
            'create' => [
                'row_count_min' => 'integer',
                'row_count_max' => 'integer',
                'sub_fields' => 'object',
            ],
        ];
    }

    private static function getSpecialSchema(string $fieldType): array
    {
        $schemas = [
            'color_picker' => [
                'mode' => ['none', 'choose', 'create'],
                'choose' => [
                    'colors' => 'array',
                    'selection_mode' => ['random', 'rotation'],
                ],
                'create' => [
                    'palette' => ['random', 'pastel', 'vibrant', 'monochrome'],
                ],
            ],
            'google_map' => [
                'mode' => ['none', 'choose', 'create'],
                'choose' => [
                    'locations' => 'array',
                    'selection_mode' => ['random', 'rotation'],
                ],
                'create' => [
                    'center_lat' => 'number',
                    'center_lng' => 'number',
                    'radius_km' => 'number',
                ],
            ],
            'link' => [
                'mode' => ['none', 'choose', 'create'],
                'choose' => [
                    'links' => 'array',
                    'selection_mode' => ['random', 'rotation'],
                ],
                'create' => [
                    'use_faker' => 'boolean',
                    'include_title' => 'boolean',
                    'target_blank' => 'boolean',
                ],
            ],
        ];

        return $schemas[$fieldType] ?? self::getTextSchema($fieldType);
    }

    // ========================================
    // Default Configurations
    // ========================================

    private static function getTextDefaults(string $fieldType, ?string $fieldName = null): array
    {
        $defaults = [
            'choose' => [
                'values' => [],
                'selection_mode' => 'random',
                'include_none' => false,
                'none_probability' => 10,
            ],
            'create' => [
                'faker_method' => 'sentence',
                'word_count_min' => 3,
                'word_count_max' => 10,
                'paragraph_count_min' => 2,
                'paragraph_count_max' => 5,
                'include_html' => false,
                'html_options' => [
                    'headings' => true,
                    'lists' => true,
                    'blockquotes' => false,
                ],
                'use_smart_detection' => true,
            ],
        ];

        // Field-name-aware detection for generic text fields.
        // Uses bare FieldNameDetector (pattern matching only, no AI/CPT context)
        // which is sufficient for recognizing common field names at the defaults level.
        if ($fieldName !== null && $fieldType === 'text') {
            $detector = new FieldNameDetector();
            $detectedType = $detector->detectType($fieldName);

            if ($detectedType !== null && isset(self::DETECTED_TYPE_TO_FAKER_METHOD[$detectedType])) {
                $defaults['create'] = [
                    'faker_method' => self::DETECTED_TYPE_TO_FAKER_METHOD[$detectedType],
                    'detected_type' => $detectedType,
                    'use_smart_detection' => true,
                ];

                return $defaults;
            }
        }

        // Adjust for specific field types
        if ($fieldType === 'post_content' || $fieldType === 'wysiwyg') {
            $defaults['create']['faker_method'] = 'paragraphs';
            $defaults['create']['include_html'] = true;
        } elseif ($fieldType === 'post_excerpt' || $fieldType === 'textarea') {
            $defaults['create']['faker_method'] = 'paragraphs';
            $defaults['create']['paragraph_count_max'] = 2;
        } elseif ($fieldType === 'email') {
            $defaults['create']['faker_method'] = 'email';
        } elseif ($fieldType === 'url') {
            $defaults['create']['faker_method'] = 'url';
        }

        return $defaults;
    }

    private static function getNumericDefaults(): array
    {
        return [
            'choose' => [
                'values' => [],
                'selection_mode' => 'random',
            ],
            'create' => [
                'min' => 0,
                'max' => 1000,
                'step' => 1,
                'decimal_places' => 0,
            ],
        ];
    }

    private static function getDateTimeDefaults(string $fieldType): array
    {
        $formats = [
            'date_picker' => 'Y-m-d',
            'date_time_picker' => 'Y-m-d H:i:s',
            'time_picker' => 'H:i:s',
            'post_date' => 'Y-m-d H:i:s',
        ];

        return [
            'custom' => [
                'values' => [],
                'selection_mode' => 'random',
            ],
            'create' => [
                'range_start' => '-1 year',
                'range_end' => 'now',
                'format' => $formats[$fieldType] ?? 'Y-m-d',
            ],
        ];
    }

    private static function getSelectionDefaults(): array
    {
        return [
            'choose' => [
                'subset' => [],
                'use_all_options' => true,
                'selection_mode' => 'random',
                'weights' => [],
                'min_selections' => 1,
                'max_selections' => 1,
            ],
        ];
    }

    private static function getMediaDefaults(): array
    {
        return [
            'choose' => [
                'attachment_ids' => [],
                'selection_mode' => 'random',
            ],
            'create' => [
                'provider' => 'picsum',
                'category' => 'nature',
                'width' => 1200,
                'height' => 800,
            ],
        ];
    }

    private static function getGalleryDefaults(): array
    {
        return [
            'choose' => [
                'attachment_ids' => [],
                'count_min' => 2,
                'count_max' => 5,
            ],
            'create' => [
                'count_min' => 3,
                'count_max' => 8,
                'provider' => 'picsum',
                'category' => 'nature',
            ],
        ];
    }

    private static function getRelationalDefaults(): array
    {
        return [
            'choose' => [
                'post_ids' => [],
                'filter_by_post_type' => [],
                'selection_mode' => 'random',
                'count_min' => 1,
                'count_max' => 5,
            ],
            'create' => [
                'use_existing_random' => true,
                'filter_by_post_type' => [],
            ],
        ];
    }

    private static function getUserDefaults(): array
    {
        return [
            'choose' => [
                'user_ids' => [],
                'filter_by_role' => [],
                'selection_mode' => 'random',
            ],
            'create' => [
                'use_existing_random' => true,
                'filter_by_role' => ['author', 'editor', 'administrator'],
            ],
        ];
    }

    private static function getComplexDefaults(string $fieldType): array
    {
        if ($fieldType === 'flexible_content') {
            return [
                'create' => [
                    'row_count_min' => 2,
                    'row_count_max' => 6,
                    'layout_weights' => [],
                    'layouts' => [],
                ],
            ];
        }

        return [
            'create' => [
                'row_count_min' => 1,
                'row_count_max' => 5,
                'sub_fields' => [],
            ],
        ];
    }

    private static function getSpecialDefaults(string $fieldType): array
    {
        $defaults = [
            'color_picker' => [
                'choose' => [
                    'colors' => [],
                    'selection_mode' => 'random',
                ],
                'create' => [
                    'palette' => 'random',
                ],
            ],
            'google_map' => [
                'choose' => [
                    'locations' => [],
                    'selection_mode' => 'random',
                ],
                'create' => [
                    'center_lat' => 48.8566,
                    'center_lng' => 2.3522,
                    'radius_km' => 50,
                ],
            ],
            'link' => [
                'choose' => [
                    'links' => [],
                    'selection_mode' => 'random',
                ],
                'create' => [
                    'use_faker' => true,
                    'include_title' => true,
                    'target_blank' => false,
                ],
            ],
        ];

        return $defaults[$fieldType] ?? self::getTextDefaults($fieldType);
    }
}
