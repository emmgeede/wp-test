<?php

namespace WPFaker;

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

/**
 * Plugin updater with license validation
 */
class Updater
{
    /**
     * Update metadata endpoint on wpfaker.com
     * Returns PUC-compatible JSON with version + download URL.
     * Uses server-side GITHUB_TOKEN to access private repo releases.
     */
    private const UPDATE_URL = 'https://wpfaker.com/api/update-check.json';

    private static $instance = null;
    private $updateChecker = null;

    /**
     * Get singleton instance
     */
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize the updater
     */
    public function init(): void
    {
        // Skip update checks in local development
        if (wp_get_environment_type() === 'local') {
            return;
        }

        if (!class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
            return;
        }

        // Use wpfaker.com JSON endpoint for update checks.
        // This works with private GitHub repos because the token
        // stays server-side on wpfaker.com (Netlify env var).
        $this->updateChecker = PucFactory::buildUpdateChecker(
            self::UPDATE_URL,
            WPF_PLUGIN_FILE,
            'wpfaker'
        );

        // Add license info to plugin row
        add_filter('plugin_row_meta', [$this, 'addLicenseInfoToPluginRow'], 10, 2);

        // Show update notice if license is invalid
        add_action('admin_notices', [$this, 'showLicenseNotice']);
    }

    /**
     * Add license status info to plugin row
     */
    public function addLicenseInfoToPluginRow(array $links, string $file): array
    {
        if ($file !== WPF_PLUGIN_BASENAME) {
            return $links;
        }

        $status = License::getStatus();

        if ($status['valid']) {
            $links[] = '<span style="color: #46b450;">' . esc_html__('License: Active', 'wpfaker') . '</span>';
        } else {
            $links[] = '<span style="color: #dc3232;">' . esc_html__('License: Inactive', 'wpfaker') . '</span>';
        }

        $links[] = '<a href="https://support.emmgee.de/open.php?topicId=12" target="_blank" rel="noopener noreferrer">' . esc_html__('Support', 'wpfaker') . '</a>';

        return $links;
    }

    /**
     * Show admin notice if license is invalid
     */
    public function showLicenseNotice(): void
    {
        // Only show on plugin pages
        $screen = get_current_screen();
        if (!$screen || !in_array($screen->id, ['plugins', 'tools_page_wpfaker'], true)) {
            return;
        }

        $key = License::getKey();

        // No notice if key is entered and valid
        if (!empty($key) && License::isValid()) {
            return;
        }

        // Show notice for missing or invalid license
        $message = empty($key)
            ? __('WPfaker requires a valid license key to receive updates. Please enter your license key in the settings.', 'wpfaker')
            : __('Your WPfaker license is invalid or expired. Please check your license key or renew your subscription.', 'wpfaker');

        $settings_url = admin_url('tools.php?page=wpfaker#/settings');

        printf(
            '<div class="notice notice-warning"><p>%s <a href="%s">%s</a></p></div>',
            esc_html($message),
            esc_url($settings_url),
            esc_html__('Go to Settings', 'wpfaker')
        );
    }

    /**
     * Check for updates manually
     */
    public function checkForUpdates(): ?object
    {
        if ($this->updateChecker === null) {
            return null;
        }

        return $this->updateChecker->checkForUpdates();
    }

    /**
     * Get the update checker instance
     */
    public function getUpdateChecker()
    {
        return $this->updateChecker;
    }
}
