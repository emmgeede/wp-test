<?php

namespace WPFaker\Controllers;

use WPFaker\Generators\CommentGenerator;
use WPFaker\Generators\PostGenerator;
use WPFaker\Generators\TaxonomyGenerator;
use WPFaker\Generators\UserGenerator;
use WPFaker\Services\AdapterFactory;
use WPFaker\Services\FakerService;
use WPFaker\Services\HistoryService;
use WPFaker\Services\ImageService;
use WPFaker\Services\MediaCleanupService;
use WPFaker\Services\TelemetryService;
use WPFaker\Services\TimeSavingsService;
use WPFaker\Services\AiProviderFactory;
use WPFaker\Services\CptContextService;
use WPFaker\Services\DependencyResolverService;
use WPFaker\Services\TemplateService;
use WPFaker\Services\GenerationLogService;

/**
 * Generator Controller
 *
 * Handles content generation requests from the REST API.
 */
class GeneratorController
{
    /**
     * @var FakerService
     */
    protected FakerService $faker;

    /**
     * @var HistoryService
     */
    protected HistoryService $history;

    /**
     * @var TimeSavingsService
     */
    protected TimeSavingsService $timeSavings;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->faker = new FakerService();
        $this->history = new HistoryService();
        $this->timeSavings = new TimeSavingsService();
    }

    /**
     * Get the configured locale from settings
     *
     * @return string|null
     */
    protected function getConfiguredLocale(): ?string
    {
        $settings = get_option(SettingsController::OPTION_NAME, []);
        $locale = $settings['locale'] ?? 'auto';

        // 'auto' means use WordPress site locale, return null to let FakerService handle it
        if ($locale === 'auto' || empty($locale)) {
            return null;
        }

        return $locale;
    }

    /**
     * Delete posts endpoint (standalone, for chunked generation)
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function deletePostsEndpoint($request): array
    {
        $params = $request->get_json_params();
        $postType = $params['post_type'] ?? 'post';
        $deleteScope = $params['delete_scope'] ?? 'current_type';
        $deleteOptions = [
            'delete_media'    => !empty($params['delete_related_media']),
            'delete_terms'    => !empty($params['delete_related_terms']),
            'delete_authors'  => !empty($params['delete_related_authors']),
            'delete_comments' => !empty($params['delete_related_comments']),
        ];

        $deleteStats = ['posts' => 0, 'media' => 0, 'terms' => 0, 'authors' => 0];
        $deletedRelatedCpts = [];
        $deletedCount = 0;

        if ($deleteScope === 'all') {
            $deleteStats = $this->deleteAllExistingPosts($deleteOptions);
        } else {
            $deleteStats = $this->deleteExistingPostsByType($postType, $deleteOptions);

            if (!empty($params['delete_related_cpts'])) {
                $depResolver = new DependencyResolverService();
                $dependencies = $depResolver->analyzeDependencies($postType);
                $relatedSlugs = [];
                foreach ($dependencies as $dep) {
                    foreach ($dep['target_post_types'] ?? [] as $slug) {
                        $relatedSlugs[$slug] = true;
                    }
                }
                foreach (array_keys($relatedSlugs) as $relatedSlug) {
                    $relatedStats = $this->deleteExistingPostsByType($relatedSlug, $deleteOptions);
                    if ($relatedStats['posts'] > 0) {
                        $deletedRelatedCpts[$relatedSlug] = $relatedStats['posts'];
                        $deleteStats['posts'] += $relatedStats['posts'];
                        $deleteStats['media'] += $relatedStats['media'];
                        $deleteStats['terms'] += $relatedStats['terms'];
                        $deleteStats['authors'] += $relatedStats['authors'];
                    }
                }
            }
        }

        $deletedCount = $deleteStats['posts'] ?? 0;

        return [
            'success'              => true,
            'deleted_count'        => $deletedCount,
            'deleted_stats'        => $deleteStats,
            'deleted_related_cpts' => $deletedRelatedCpts,
            'message'              => sprintf('Deleted %d posts', $deletedCount),
        ];
    }

    /**
     * Generate posts
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function generatePosts($request): array
    {
        $params = $request->get_json_params();

        // If template_id provided, load effective config from template
        $templateId = $params['template_id'] ?? null;
        if ($templateId) {
            $templateService = new TemplateService();
            $effectiveConfig = $templateService->getEffectiveConfig((int) $templateId);
            if ($effectiveConfig) {
                // Template config becomes the base, request params can override count
                $params = array_merge($effectiveConfig, [
                    'post_type'     => $params['post_type'] ?? $effectiveConfig['post_type'] ?? 'post',
                    'count'         => $params['count'] ?? $effectiveConfig['count'] ?? 5,
                    'template_id'   => $templateId,
                    ]);
            }
        }

        $postType = $params['post_type'] ?? 'post';
        $count = (int) ($params['count'] ?? 5);

        GenerationLogService::log('init', sprintf('Starting generation of %d %s posts...', $count, $postType));

        $chunk = (int) ($params['chunk'] ?? 0);
        $totalCount = (int) ($params['total_count'] ?? $count);

        if ($chunk > 0) {
            $totalChunks = (int) ceil($totalCount / $count);
            GenerationLogService::log('init', sprintf('Chunk %d of %d', $chunk, $totalChunks));
        }

        // Detect if media was kept during deletion (for reuse in next generation)
        $reuseExistingMedia = false;

        $options = [
            // Post settings
            'post_type'              => $postType,
            'post_status'            => $params['post_status'] ?? 'publish',
            'date_range_start'       => $params['date_range_start'] ?? '-1 year',
            'date_range_end'         => $params['date_range_end'] ?? 'now',

            // Image settings
            'set_featured_image'     => $params['set_featured_image'] ?? true,
            'download_images'        => $params['download_images'] ?? true,
            'image_provider'         => $params['image_provider'] ?? ImageService::PROVIDER_UNSPLASH,
            'image_category'         => !empty($params['image_category']) ? $params['image_category'] : null,
            'image_width'            => (int) ($params['image_width'] ?? 1200),
            'image_height'           => (int) ($params['image_height'] ?? 800),

            // Content settings
            'populate_custom_fields' => $params['populate_custom_fields'] ?? true,
            'auto_taxonomies'        => $params['auto_taxonomies'] ?? true,

            // Variation settings
            'enable_variation'       => $params['enable_variation'] ?? true,
            'variation_profile'      => $params['variation_profile'] ?? 'random',

            // Auto-creation settings
            'auto_create_authors'    => $params['auto_create_authors'] ?? true,
            'auto_create_taxonomies' => $params['auto_create_taxonomies'] ?? true,
            'author_count'           => (int) ($params['author_count'] ?? 3),
            'max_categories'         => (int) ($params['max_categories'] ?? 5),
            'max_tags'               => (int) ($params['max_tags'] ?? 8),

            // Multilingual settings - use request locale, or fall back to configured locale
            'locale'                 => $params['locale'] ?? $this->getConfiguredLocale(),

            // Template settings
            'template_id'            => $params['template_id'] ?? null,
            'taxonomy_config'        => $params['taxonomy_config'] ?? null,
            'field_config'           => $params['field_config'] ?? null,

            // Related CPT options (per-CPT overrides for auto-created related posts)
            'related_cpt_options'        => $params['related_cpt_options'] ?? null,

            // Auto-comment settings
            'auto_comments'              => $params['auto_comments'] ?? false,
            'comments_per_post_min'      => (int) ($params['comments_per_post_min'] ?? 0),
            'comments_per_post_max'      => (int) ($params['comments_per_post_max'] ?? 10),
            'enable_comment_threading'   => $params['enable_comment_threading'] ?? true,
            'comment_reply_probability'  => (int) ($params['comment_reply_probability'] ?? 40),

            // Media reuse (when media was kept during deletion)
            'reuse_existing_media'       => $reuseExistingMedia,

            // No post_budget: auto-created related posts are lightweight (title+content only)
            // and don't need the same capacity limits as main posts with images/custom fields

            // Chunk info — skip setup phases on subsequent chunks
            'chunk'        => $chunk,
            'total_chunks' => $chunk > 0 ? (int) ceil($totalCount / $count) : 1,
        ];

        // Get adapter if custom fields should be populated
        $adapter = null;
        if ($options['populate_custom_fields']) {
            $adapter = AdapterFactory::getPrimaryAdapter();
        }

        $generator = new PostGenerator($this->faker, $adapter);
        $generator->setPostType($postType);

        // Validate relationship field requirements before generating
        $validation = $generator->validateRelationshipRequirements($count, $options);
        if (!$validation['valid']) {
            return [
                'success' => false,
                'message' => $validation['message'],
            ];
        }

        $generatedIds = $generator->generate($count, $options);

        // Track template usage
        if (!empty($options['template_id'])) {
            TelemetryService::incrementCounter('template_generations');
        }

        // Get variation stats for response
        $variationStats = $generator->getVariationStats();

        // Resolve template name for history logging
        $templateName = null;
        if (!empty($options['template_id'])) {
            $tplService = new TemplateService();
            $tpl = $tplService->get((int) $options['template_id']);
            $templateName = $tpl['name'] ?? null;
        }

        // Log to history
        foreach ($generatedIds as $id) {
            $this->history->log('post', $id, $postType, [
                'template_name' => $templateName,
                'options' => $options,
            ]);
        }

        // Log auto-created related CPT posts to history
        foreach ($generator->getAutoCreatedIdsPerCpt() as $relatedCpt => $relatedIds) {
            foreach ($relatedIds as $relatedId) {
                $this->history->log('post', $relatedId, $relatedCpt);
            }
        }

        // Auto-generate comments if enabled
        $autoCommentIds = [];
        if (!empty($options['auto_comments']) && !empty($generatedIds)) {
            $commentGenerator = new CommentGenerator($this->faker);
            // Pass CPT context from FakerService for domain-aware comments
            if ($this->faker->getCptContext()) {
                $commentGenerator->setCptContext($this->faker->getCptContext());
            }
            foreach ($generatedIds as $postId) {
                if (comments_open($postId)) {
                    $commentIds = $commentGenerator->generateForPost($postId, [
                        'comments_per_post_min' => $options['comments_per_post_min'] ?? 0,
                        'comments_per_post_max' => $options['comments_per_post_max'] ?? 10,
                        'enable_threading'      => $options['enable_comment_threading'] ?? true,
                        'reply_probability'     => $options['comment_reply_probability'] ?? 40,
                        'locale'                => $options['locale'] ?? null,
                    ]);
                    foreach ($commentIds as $cid) {
                        $this->history->log('comment', $cid, $postType);
                    }
                    $autoCommentIds = array_merge($autoCommentIds, $commentIds);
                }
            }
        }

        if (!empty($autoCommentIds)) {
            GenerationLogService::log('gen', sprintf('Generated %d comments', count($autoCommentIds)));
        }

        // Calculate time saved
        $generationResult = [
            'count' => count($generatedIds),
            'variation_stats' => $variationStats,
            'options' => $options,
            'custom_fields_populated' => $options['populate_custom_fields'],
            'created_terms' => $generator->getGeneratedTerms(),
            'created_authors' => $generator->getGeneratedAuthors(),
        ];
        $timeSavedSeconds = $this->timeSavings->calculatePostTimeSaved($generationResult);
        if (!empty($autoCommentIds)) {
            $timeSavedSeconds += $this->timeSavings->calculateCommentTimeSaved(count($autoCommentIds));
        }
        $this->timeSavings->recordTimeSaved($timeSavedSeconds, 'posts');
        $timeSavedFormatted = $this->timeSavings->formatTime($timeSavedSeconds);

        // Build response message
        $message = sprintf('%d %s generated successfully', count($generatedIds), $postType);

        GenerationLogService::log('done', sprintf('✓ %d %s posts created', count($generatedIds), $postType));
        if ($generator->getAutoCreatedRelatedCount() > 0) {
            $parts = [];
            foreach ($generator->getAutoCreatedRelatedPerCpt() as $cpt => $c) {
                $parts[] = "$c $cpt";
            }
            GenerationLogService::log('done', '✓ ' . implode(' + ', $parts) . ' auto-created');
        }
        if (!empty($variationStats)) {
            GenerationLogService::log('done', sprintf('✓ %d/%d with featured images',
                $variationStats['with_featured_image'] ?? 0, count($generatedIds)));
        }
        if ($timeSavedFormatted) {
            GenerationLogService::log('done', sprintf('✓ Time saved: %s', $timeSavedFormatted));
        }

        return [
            'success'              => true,
            'count'                => count($generatedIds),
            'ids'                  => $generatedIds,
            'message'              => $message,
            'warnings'             => $generator->getWarnings(),
            'variation_stats'      => $variationStats,
            'auto_created'         => [
                'authors'           => count($generator->getGeneratedAuthors()),
                'terms'             => array_map('count', $generator->getGeneratedTerms()),
                'comments'          => count($autoCommentIds),
                'related_posts'     => $generator->getAutoCreatedRelatedCount(),
                'related_per_cpt'   => $generator->getAutoCreatedRelatedPerCpt(),
            ],
            'time_saved'           => $timeSavedFormatted,
        ];
    }

    /**
     * Generate posts with SSE streaming
     *
     * Wraps generatePosts() with Server-Sent Events output so each log entry
     * is streamed to the client in real-time.
     *
     * @param \WP_REST_Request $request
     * @return void
     */
    public function generatePostsStream($request)
    {
        // Disable output buffering
        while (ob_get_level()) {
            ob_end_clean();
        }

        // Set SSE headers
        header('Content-Type: text/event-stream');
        header('Cache-Control: no-cache');
        header('X-Accel-Buffering: no');
        header('Connection: keep-alive');

        // Register flush callback — each log() call sends an SSE event
        GenerationLogService::reset();
        GenerationLogService::setFlushCallback(function ($entry) {
            echo 'data: ' . wp_json_encode($entry) . "\n\n";
            if (ob_get_level()) {
                ob_flush();
            }
            flush();
        });

        // Run the actual generation (reuse existing logic)
        try {
            $result = $this->generatePosts($request);
        } catch (\Throwable $e) {
            GenerationLogService::log('error', $e->getMessage());
            $result = [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }

        // Send final complete event
        echo 'data: ' . wp_json_encode([
            'type'   => 'complete',
            'result' => $result,
        ]) . "\n\n";
        flush();

        // Clean up
        GenerationLogService::reset();

        // Prevent WP REST from sending a JSON response
        die();
    }

    /**
     * Generate taxonomy terms
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function generateTerms($request): array
    {
        $params = $request->get_json_params();

        $taxonomy = $params['taxonomy'] ?? 'category';
        $count = (int) ($params['count'] ?? 5);

        // Delete existing generated terms before generating new ones
        $deletedCount = 0;
        if (!empty($params['delete_existing'])) {
            $ids = $this->history->getIdsByType('term', $taxonomy);
            if (!empty($ids)) {
                $generator = new TaxonomyGenerator($this->faker);
                $generator->setTaxonomy($taxonomy);
                $deletedCount = $generator->delete($ids, true);
                $this->history->deleteByIds('term', $ids);
            }
        }

        $options = [
            'taxonomy'               => $taxonomy,
            'random_parent'          => $params['random_parent'] ?? false,
            'populate_custom_fields' => $params['populate_custom_fields'] ?? true,
        ];

        $adapter = null;
        if ($options['populate_custom_fields']) {
            $adapter = AdapterFactory::getPrimaryAdapter();
        }

        $generator = new TaxonomyGenerator($this->faker, $adapter);
        $generator->setTaxonomy($taxonomy);

        // Check if hierarchy generation is requested
        if (!empty($params['generate_hierarchy'])) {
            $depth = (int) ($params['depth'] ?? 3);
            $breadth = (int) ($params['breadth'] ?? 3);
            $levels = $generator->generateHierarchy($depth, $breadth, $options);
            $generatedIds = array_merge(...array_values($levels));
        } else {
            $generatedIds = $generator->generate($count, $options);
        }

        // Log to history
        foreach ($generatedIds as $id) {
            $this->history->log('term', $id, $taxonomy, [
                'options' => $options,
            ]);
        }

        // Calculate time saved
        $hasMeta = $options['populate_custom_fields'] ?? false;
        $timeSavedSeconds = $this->timeSavings->calculateTermTimeSaved(count($generatedIds), $hasMeta);
        $this->timeSavings->recordTimeSaved($timeSavedSeconds, 'terms');
        $timeSavedFormatted = $this->timeSavings->formatTime($timeSavedSeconds);

        $message = sprintf('%d %s terms generated successfully', count($generatedIds), $taxonomy);
        if ($deletedCount > 0) {
            $message = sprintf('%d existing terms deleted, %d new %s terms generated', $deletedCount, count($generatedIds), $taxonomy);
        }

        return [
            'success'       => true,
            'count'         => count($generatedIds),
            'ids'           => $generatedIds,
            'deleted_count' => $deletedCount,
            'message'       => $message,
            'time_saved'    => $timeSavedFormatted,
        ];
    }

    /**
     * Generate users
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function generateUsers($request): array
    {
        $params = $request->get_json_params();

        $count = (int) ($params['count'] ?? 5);

        // Delete existing generated users before generating new ones
        $deletedCount = 0;
        if (!empty($params['delete_existing'])) {
            $ids = $this->history->getIdsByType('user');
            if (!empty($ids)) {
                $generator = new UserGenerator($this->faker);
                $deletedCount = $generator->delete($ids, true);
                $this->history->deleteByIds('user', $ids);
            }
        }

        $options = [
            'role'                   => $params['role'] ?? '',
            'allowed_roles'          => $params['allowed_roles'] ?? ['subscriber', 'contributor', 'author'],
            'populate_custom_fields' => $params['populate_custom_fields'] ?? true,
            'generate_avatars'       => $params['generate_avatars'] ?? true,
            'avatar_provider'        => $params['avatar_provider'] ?? ImageService::PROVIDER_UNSPLASH,
            'date_range_start'       => $params['date_range_start'] ?? '-2 years',
            'date_range_end'         => $params['date_range_end'] ?? 'now',
        ];

        $adapter = null;
        if ($options['populate_custom_fields']) {
            $adapter = AdapterFactory::getPrimaryAdapter();
        }

        $generator = new UserGenerator($this->faker, $adapter);

        // Check for role distribution
        if (!empty($params['role_distribution'])) {
            $results = $generator->generateWithRoleDistribution($params['role_distribution'], $options);
            $generatedIds = array_merge(...array_values($results));
        } else {
            $generatedIds = $generator->generate($count, $options);
        }

        // Log to history
        foreach ($generatedIds as $id) {
            $this->history->log('user', $id, 'user', [
                'options' => $options,
            ]);
        }

        // Calculate time saved
        $hasMeta = $options['populate_custom_fields'] ?? false;
        $timeSavedSeconds = $this->timeSavings->calculateUserTimeSaved(count($generatedIds), $hasMeta);
        $this->timeSavings->recordTimeSaved($timeSavedSeconds, 'users');
        $timeSavedFormatted = $this->timeSavings->formatTime($timeSavedSeconds);

        $message = sprintf('%d users generated successfully', count($generatedIds));
        if ($deletedCount > 0) {
            $message = sprintf('%d existing users deleted, %d new users generated', $deletedCount, count($generatedIds));
        }

        return [
            'success'       => true,
            'count'         => count($generatedIds),
            'ids'           => $generatedIds,
            'deleted_count' => $deletedCount,
            'message'       => $message,
            'time_saved'    => $timeSavedFormatted,
        ];
    }

    /**
     * Generate comments
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function generateComments($request): array
    {
        $params = $request->get_json_params();

        $postType = $params['post_type'] ?? 'post';

        // Delete existing generated comments before generating new ones
        $deletedCount = 0;
        if (!empty($params['delete_existing'])) {
            $generator = new CommentGenerator($this->faker);
            $deletedCount = $generator->deleteGeneratedComments($postType);
            // Also clean up history entries for deleted comments
            $this->history->deleteByType('comment');
        }

        $options = [
            'post_type'             => $postType,
            'post_ids'              => $params['post_ids'] ?? [],
            'comments_per_post_min' => (int) ($params['comments_per_post_min'] ?? 1),
            'comments_per_post_max' => (int) ($params['comments_per_post_max'] ?? 15),
            'enable_threading'      => $params['enable_threading'] ?? true,
            'reply_probability'     => (int) ($params['reply_probability'] ?? 40),
            'pending_percentage'    => (int) ($params['pending_percentage'] ?? 10),
            'anonymous_percentage'  => (int) ($params['anonymous_percentage'] ?? 70),
            'avatar_percentage'     => (int) ($params['avatar_percentage'] ?? 60),
            'avatar_provider'       => $params['avatar_provider'] ?? ImageService::PROVIDER_UNSPLASH,
            'locale'                => $params['locale'] ?? $this->getConfiguredLocale(),
        ];

        $generator = new CommentGenerator($this->faker);

        // Wire CPT context for domain-aware comments
        $aiProvider = AiProviderFactory::getProvider();
        if ($aiProvider && $aiProvider->isAvailable()) {
            $cptObj = get_post_type_object($postType);
            $cptLabel = $cptObj ? ($cptObj->labels->singular_name ?? null) : null;
            $contextService = new CptContextService($aiProvider);
            $cptContext = $contextService->getContext($postType, $cptLabel, $options['locale'] ?? null);
            if ($cptContext) {
                $generator->setCptContext($cptContext);
            }
        }

        $generatedIds = $generator->generate(0, $options);

        // Log to history
        foreach ($generatedIds as $id) {
            $this->history->log('comment', $id, $postType);
        }

        // Calculate time saved
        $timeSavedSeconds = $this->timeSavings->calculateCommentTimeSaved(count($generatedIds));
        $this->timeSavings->recordTimeSaved($timeSavedSeconds, 'comments');
        $timeSavedFormatted = $this->timeSavings->formatTime($timeSavedSeconds);

        // Build message
        $message = sprintf('%d comments generated successfully', count($generatedIds));
        if ($deletedCount > 0) {
            $message = sprintf('%d existing comments deleted, %d new comments generated', $deletedCount, count($generatedIds));
        }

        return [
            'success'       => true,
            'count'         => count($generatedIds),
            'ids'           => $generatedIds,
            'deleted_count' => $deletedCount,
            'message'       => $message,
            'time_saved'    => $timeSavedFormatted,
        ];
    }

    /**
     * Delete generated content
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function deleteGenerated($request): array
    {
        $params = $request->get_json_params();

        $type = $params['type'] ?? 'post';
        $ids = $params['ids'] ?? [];
        $force = $params['force'] ?? false;

        if (empty($ids)) {
            // Delete all generated content of this type from history
            $ids = $this->history->getIdsByType($type);
        }

        $deleted = 0;

        switch ($type) {
            case 'post':
                $generator = new PostGenerator($this->faker);
                $deleted = $generator->delete($ids, $force);
                break;

            case 'term':
                $taxonomy = $params['taxonomy'] ?? 'category';
                $generator = new TaxonomyGenerator($this->faker);
                $generator->setTaxonomy($taxonomy);
                $deleted = $generator->delete($ids, $force);
                break;

            case 'user':
                $generator = new UserGenerator($this->faker);
                $deleted = $generator->delete($ids, $force);
                break;

            case 'comment':
                $generator = new CommentGenerator($this->faker);
                $deleted = $generator->delete($ids, $force);
                break;
        }

        // Remove from history
        $this->history->deleteByIds($type, $ids);

        return [
            'success' => true,
            'deleted' => $deleted,
            'message' => sprintf('%d items deleted', $deleted),
        ];
    }

    /**
     * Get generation statistics
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getStats($request): array
    {
        return [
            'success' => true,
            'stats'   => $this->history->getStats(),
        ];
    }

    /**
     * Get time savings report
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getTimeSavingsReport($request): array
    {
        return [
            'success'      => true,
            'time_savings' => $this->timeSavings->getTimeSavingsReport(),
        ];
    }

    /**
     * Reset time savings data
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function resetTimeSavings($request): array
    {
        $this->timeSavings->resetTimeSavings();

        return [
            'success' => true,
            'message' => __('Time savings data has been reset.', 'wpfaker'),
        ];
    }

    /**
     * Get generation history
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getHistory($request): array
    {
        $params = $request->get_query_params();

        $type = $params['type'] ?? null;
        $limit = (int) ($params['limit'] ?? 50);
        $offset = (int) ($params['offset'] ?? 0);

        TelemetryService::incrementCounter('history_views');

        return [
            'success' => true,
            'history' => $this->history->getHistory($type, $limit, $offset),
            'total'   => $this->history->getCount($type),
        ];
    }

    /**
     * Get available field plugins info
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getFieldPlugins($request): array
    {
        return [
            'success'  => true,
            'adapters' => AdapterFactory::getAdapterInfo(),
            'primary'  => AdapterFactory::getPrimaryAdapter()?->getName() ?? null,
        ];
    }

    /**
     * Get fields for a post type
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getFieldsForPostType($request): array
    {
        $postType = $request->get_param('post_type');
        $adapter = AdapterFactory::getPrimaryAdapter();

        if (!$adapter || !$adapter->isActive()) {
            return [
                'success' => false,
                'message' => 'No field plugin adapter available',
                'fields'  => [],
            ];
        }

        $fields = $adapter->getFieldsForPostType($postType);

        // Simplify field data for frontend
        $simplifiedFields = array_map(function ($field) {
            $simplified = [
                'key'          => $field['key'] ?? '',
                'name'         => $field['name'] ?? '',
                'label'        => $field['label'] ?? $field['name'] ?? '',
                'type'         => $field['type'] ?? 'text',
                'required'     => $field['required'] ?? false,
                'instructions' => $field['instructions'] ?? '',
            ];

            // Include options for selection fields (select, radio, checkbox)
            // Frontend expects array of {value, label} objects
            if (!empty($field['choices'])) {
                $options = [];
                foreach ($field['choices'] as $value => $label) {
                    $options[] = ['value' => $value, 'label' => $label];
                }
                $simplified['options'] = $options;
            }

            // Include multiple flag for multi-select fields
            if (!empty($field['multiple'])) {
                $simplified['multiple'] = true;
            }

            // Include numeric constraints for number/range fields
            if (isset($field['min'])) {
                $simplified['min'] = $field['min'];
            }
            if (isset($field['max'])) {
                $simplified['max'] = $field['max'];
            }
            if (isset($field['step'])) {
                $simplified['step'] = $field['step'];
            }

            return $simplified;
        }, $fields);

        return [
            'success'   => true,
            'post_type' => $postType,
            'fields'    => $simplifiedFields,
            'count'     => count($simplifiedFields),
        ];
    }

    /**
     * Get cross-CPT dependencies for a post type
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getDependencies($request): array
    {
        $postType = $request->get_param('post_type');

        if (!post_type_exists($postType)) {
            return [
                'success'      => false,
                'message'      => 'Post type not found',
                'dependencies' => [],
            ];
        }

        $resolver = new DependencyResolverService();
        $dependencies = $resolver->analyzeDependencies($postType);

        // Build unique targets map with metadata for the UI
        $uniqueTargets = [];
        $templateService = new \WPFaker\Services\TemplateService();

        // Enrich with post type labels for frontend display
        $enriched = array_map(function ($dep) use (&$uniqueTargets, $templateService) {
            $labels = [];
            foreach ($dep['target_post_types'] as $targetCpt) {
                $cptObj = get_post_type_object($targetCpt);
                $labels[$targetCpt] = $cptObj ? $cptObj->labels->singular_name : $targetCpt;

                // Build unique_targets metadata (only once per CPT)
                if (!isset($uniqueTargets[$targetCpt])) {
                    $counts = wp_count_posts($targetCpt);
                    $existingCount = (int) ($counts->publish ?? 0);
                    $defaultTemplate = $templateService->getDefault($targetCpt);
                    $allTemplates = $templateService->getForPostType($targetCpt);
                    $uniqueTargets[$targetCpt] = [
                        'label'            => $cptObj ? $cptObj->labels->singular_name : $targetCpt,
                        'plural_label'     => $cptObj ? $cptObj->labels->name : $targetCpt,
                        'existing_count'   => $existingCount,
                        'has_template'     => $defaultTemplate !== null,
                        'template_name'    => $defaultTemplate ? $defaultTemplate['name'] : null,
                        'is_required'      => false,
                        'required_by_fields' => [],
                        'available_templates' => array_map(function ($t) {
                            $fieldConfig = $t['field_config'] ?? [];
                            $coreFields = $fieldConfig['core_fields'] ?? [];
                            $customFields = $fieldConfig['custom_fields'] ?? [];
                            $taxConfig = $t['taxonomy_config'] ?? [];
                            $config = $t['config'] ?? [];

                            $configuredCore = 0;
                            foreach ($coreFields as $fc) {
                                if (!empty($fc['mode']) && $fc['mode'] !== 'none') {
                                    $configuredCore++;
                                }
                            }
                            $configuredCustom = 0;
                            foreach ($customFields as $fc) {
                                if (!empty($fc['mode']) && $fc['mode'] !== 'none') {
                                    $configuredCustom++;
                                }
                            }
                            $configuredTax = 0;
                            foreach ($taxConfig as $tc) {
                                if (!empty($tc['mode']) && $tc['mode'] !== 'none') {
                                    $configuredTax++;
                                }
                            }

                            return [
                                'id'             => $t['id'],
                                'name'           => $t['name'],
                                'is_default'     => (bool) $t['is_default'],
                                'config_summary' => [
                                    'core_fields'      => $configuredCore,
                                    'custom_fields'    => $configuredCustom,
                                    'taxonomies'       => $configuredTax,
                                    'total_core'       => count($coreFields),
                                    'total_custom'     => count($customFields),
                                    'total_taxonomies' => count($taxConfig),
                                    'featured_image'   => !empty($config['set_featured_image']),
                                    'variation'        => !empty($config['enable_variation']),
                                ],
                            ];
                        }, $allTemplates),
                    ];
                }

                // Track required status across all dependencies
                if (!empty($dep['required'])) {
                    $uniqueTargets[$targetCpt]['is_required'] = true;
                    $uniqueTargets[$targetCpt]['required_by_fields'][] = $dep['field_name'];
                }
            }
            $dep['target_labels'] = $labels;
            return $dep;
        }, $dependencies);

        // Deduplicate required_by_fields
        foreach ($uniqueTargets as $cpt => &$meta) {
            $meta['required_by_fields'] = array_values(array_unique($meta['required_by_fields']));
        }
        unset($meta);

        // Bidirectional dependencies: what this post type provides to others
        $bidirectional = $resolver->analyzeBidirectionalDependencies($postType);

        // Batch wp_count_posts() for unique provides targets (avoid N+1)
        $providesCountMap = [];
        foreach ($bidirectional['provides'] as $dep) {
            $providesCountMap[$dep['target']] = null;
        }
        foreach (array_keys($providesCountMap) as $target) {
            $counts = wp_count_posts($target);
            $providesCountMap[$target] = (int) ($counts->publish ?? 0);
        }

        $enrichedProvides = array_map(function ($dep) use ($providesCountMap) {
            $dep['existing_count'] = $providesCountMap[$dep['target']];
            return $dep;
        }, $this->enrichWithCptLabels($bidirectional['provides']));

        // Missing dependencies: required parent CPTs with zero posts
        // Pass pre-computed $bidirectional to avoid duplicate analyzeBidirectionalDependencies() call
        $missing = $resolver->getMissingDependencies($postType, $bidirectional);
        $enrichedMissing = $this->enrichWithCptLabels($missing);

        return [
            'success'          => true,
            'post_type'        => $postType,
            'dependencies'     => $enriched,
            'unique_targets'   => $uniqueTargets,
            'count'            => count($enriched),
            'provides'         => $enrichedProvides,
            'missing'          => $enrichedMissing,
            'generated_counts' => $this->getMetaGeneratedCounts(),
        ];
    }

    /**
     * Enrich items with CPT label and plural_label based on 'target' key.
     *
     * @param array $items Items with a 'target' key containing a post type slug
     * @return array Items enriched with 'label' and 'plural_label'
     */
    private function enrichWithCptLabels(array $items): array
    {
        return array_map(function ($item) {
            $cptObj = get_post_type_object($item['target']);
            $item['label'] = $cptObj ? $cptObj->labels->singular_name : $item['target'];
            $item['plural_label'] = $cptObj ? $cptObj->labels->name : $item['target'];
            return $item;
        }, $items);
    }

    /**
     * Count posts with _wpfaker_generated meta, grouped by post type.
     *
     * @return array ['post_type' => count]
     */
    protected function getMetaGeneratedCounts(): array
    {
        global $wpdb;

        $results = $wpdb->get_results(
            "SELECT p.post_type, COUNT(DISTINCT p.ID) as count
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             WHERE pm.meta_key = '_wpfaker_generated'
             AND p.post_status != 'trash'
             GROUP BY p.post_type",
            ARRAY_A
        );

        $counts = [];
        foreach ($results ?: [] as $row) {
            $counts[$row['post_type']] = (int) $row['count'];
        }

        return $counts;
    }

    /**
     * Delete all WPfaker-generated posts across all post types
     *
     * @param array $deleteOptions Options for related content deletion
     * @return array Stats with keys: posts, media, terms, authors
     */
    protected function deleteAllExistingPosts(array $deleteOptions = []): array
    {
        $stats = ['posts' => 0, 'media' => 0, 'terms' => 0, 'authors' => 0, 'comments' => 0];

        // Get all post IDs from history (no subtype filter)
        $postIds = $this->history->getIdsByType('post');

        // Also get posts with _wpfaker_generated meta across all post types
        $metaPostIds = get_posts([
            'post_type'      => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_key'       => '_wpfaker_generated',
            'meta_value'     => '1',
            'post_status'    => 'any',
        ]);

        // Merge and dedupe
        $allPostIds = array_unique(array_merge($postIds, $metaPostIds));

        // Clean up MB Relationships BEFORE deleting posts
        if (!empty($allPostIds)) {
            $this->cleanupMBRelationshipsForPosts($allPostIds);
        }

        // Delete media BEFORE posts (so attachments still have parents)
        if (!empty($deleteOptions['delete_media']) && !empty($allPostIds)) {
            foreach ($allPostIds as $pid) {
                $stats['media'] += MediaCleanupService::deletePostMedia($pid);
            }
        }

        if (!empty($allPostIds)) {
            $generator = new PostGenerator($this->faker);
            $stats['posts'] = $generator->delete($allPostIds, true);

            if (!empty($postIds)) {
                $this->history->deleteByIds('post', $postIds);
            }
        }

        // Delete related terms
        if (!empty($deleteOptions['delete_terms'])) {
            $stats['terms'] = $this->deleteAllGeneratedTerms(null);
        }

        // Delete related authors
        if (!empty($deleteOptions['delete_authors'])) {
            $stats['authors'] = $this->deleteAllGeneratedUsers();
        }

        // Delete related comments
        if (!empty($deleteOptions['delete_comments'])) {
            $commentGenerator = new CommentGenerator($this->faker);
            $stats['comments'] = $commentGenerator->deleteGeneratedComments(null);
        }

        return $stats;
    }

    /**
     * Delete all WPfaker-generated posts of a specific post type
     *
     * @param string $postType The post type to delete
     * @param array $deleteOptions Options for related content deletion
     * @return array Stats with keys: posts, media, terms, authors
     */
    protected function deleteExistingPostsByType(string $postType, array $deleteOptions = []): array
    {
        $stats = ['posts' => 0, 'media' => 0, 'terms' => 0, 'authors' => 0, 'comments' => 0];

        // Get all post IDs of this post type from history
        $postIds = $this->history->getIdsByType('post', $postType);

        // Also get posts with _wpfaker_generated meta (fallback for CLI-generated posts)
        $metaPostIds = get_posts([
            'post_type'      => $postType,
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_key'       => '_wpfaker_generated',
            'meta_value'     => '1',
            'post_status'    => 'any',
        ]);

        // Merge and dedupe
        $allPostIds = array_unique(array_merge($postIds, $metaPostIds));

        // Clean up MB Relationships BEFORE deleting posts
        if (!empty($allPostIds)) {
            $adapter = AdapterFactory::getAdapterForPostType($postType);
            if ($adapter && method_exists($adapter, 'deleteMBRelationshipsForPost')) {
                foreach ($allPostIds as $pid) {
                    $adapter->deleteMBRelationshipsForPost($pid, $postType);
                }
            }
        }

        // Delete media BEFORE posts (so attachments still have parents)
        if (!empty($deleteOptions['delete_media']) && !empty($allPostIds)) {
            foreach ($allPostIds as $pid) {
                $stats['media'] += MediaCleanupService::deletePostMedia($pid);
            }
        }

        if (!empty($allPostIds)) {
            $generator = new PostGenerator($this->faker);
            $stats['posts'] = $generator->delete($allPostIds, true);

            if (!empty($postIds)) {
                $this->history->deleteByIds('post', $postIds);
            }
        }

        // Also clean up orphaned media for this CPT (when media deletion is requested)
        if (!empty($deleteOptions['delete_media'])) {
            $stats['media'] += MediaCleanupService::deleteOrphanedMedia($postType);
        }

        // Delete related terms
        if (!empty($deleteOptions['delete_terms'])) {
            $stats['terms'] = $this->deleteAllGeneratedTerms($postType);
        }

        // Delete related authors
        if (!empty($deleteOptions['delete_authors'])) {
            $stats['authors'] = $this->deleteAllGeneratedUsers();
        }

        // Delete related comments
        if (!empty($deleteOptions['delete_comments'])) {
            $commentGenerator = new CommentGenerator($this->faker);
            $stats['comments'] = $commentGenerator->deleteGeneratedComments($postType);
        }

        return $stats;
    }

    /**
     * Clean up MB Relationships for a list of post IDs (any post type)
     *
     * @param array $postIds Post IDs to clean up
     */
    protected function cleanupMBRelationshipsForPosts(array $postIds): void
    {
        if (empty($postIds)) {
            return;
        }

        // Group posts by type to get the right adapter
        $byType = [];
        foreach ($postIds as $pid) {
            $type = get_post_type($pid);
            if ($type) {
                $byType[$type][] = $pid;
            }
        }

        foreach ($byType as $postType => $ids) {
            $adapter = AdapterFactory::getAdapterForPostType($postType);
            if ($adapter && method_exists($adapter, 'deleteMBRelationshipsForPost')) {
                foreach ($ids as $pid) {
                    $adapter->deleteMBRelationshipsForPost($pid, $postType);
                }
            }
        }
    }

    /**
     * Delete all WPfaker-generated taxonomy terms
     *
     * When a post type is provided, also deletes ALL terms from that CPT's
     * associated taxonomies (catches old untracked terms from before the
     * _wpfaker_generated meta was introduced).
     *
     * @param string|null $postType Optional post type for thorough taxonomy cleanup
     * @return int Number of terms deleted
     */
    protected function deleteAllGeneratedTerms(?string $postType = null): int
    {
        $termIds = $this->history->getIdsByType('term');
        $deleted = 0;

        foreach ($termIds as $termId) {
            $term = \get_term($termId);
            if ($term && !\is_wp_error($term)) {
                $result = \wp_delete_term($termId, $term->taxonomy);
                if (!\is_wp_error($result) && $result !== false) {
                    $deleted++;
                }
            }
        }

        if (!empty($termIds)) {
            $this->history->deleteByIds('term', $termIds);
        }

        // Also find and delete terms marked with _wpfaker_generated meta
        // These are created by PostGenerator::ensureTaxonomies() but not tracked in History
        global $wpdb;
        $metaTermIds = $wpdb->get_col(
            "SELECT term_id FROM {$wpdb->termmeta} WHERE meta_key = '_wpfaker_generated' AND meta_value = '1'"
        );

        if (!empty($metaTermIds)) {
            // Exclude already-deleted IDs to avoid double counting
            $metaTermIds = array_diff($metaTermIds, $termIds);

            foreach ($metaTermIds as $termId) {
                $term = \get_term((int) $termId);
                if ($term && !\is_wp_error($term)) {
                    $result = \wp_delete_term((int) $termId, $term->taxonomy);
                    if (!\is_wp_error($result) && $result !== false) {
                        $deleted++;
                    }
                }
            }
        }

        // Third pass: delete ALL terms from the CPT's associated taxonomies
        // This catches old untracked terms (created before _wpfaker_generated meta existed)
        if ($postType) {
            $taxonomies = \get_object_taxonomies($postType, 'names');
            // Exclude built-in taxonomies that users likely manage manually
            $protectedTaxonomies = ['category', 'post_tag', 'post_format'];
            $taxonomies = array_diff($taxonomies, $protectedTaxonomies);

            foreach ($taxonomies as $taxonomy) {
                $remainingTerms = \get_terms([
                    'taxonomy'   => $taxonomy,
                    'hide_empty' => false,
                    'fields'     => 'ids',
                ]);

                if (\is_wp_error($remainingTerms) || empty($remainingTerms)) {
                    continue;
                }

                foreach ($remainingTerms as $termId) {
                    $result = \wp_delete_term((int) $termId, $taxonomy);
                    if (!\is_wp_error($result) && $result !== false) {
                        $deleted++;
                    }
                }
            }
        }

        return $deleted;
    }

    /**
     * Delete all WPfaker-generated users (with safety checks)
     *
     * @return int Number of users deleted
     */
    protected function deleteAllGeneratedUsers(): int
    {
        // wp_delete_user() is in wp-admin/includes/user.php, not loaded during REST requests
        if (!function_exists('wp_delete_user')) {
            require_once ABSPATH . 'wp-admin/includes/user.php';
        }

        $userIds = $this->history->getIdsByType('user');
        $currentUserId = \get_current_user_id();
        $deleted = 0;

        foreach ($userIds as $userId) {
            // Safety: never delete current user
            if ((int) $userId === $currentUserId) {
                continue;
            }

            $user = \get_user_by('ID', $userId);
            if (!$user) {
                continue;
            }

            // Safety: never delete administrators
            if (in_array('administrator', $user->roles, true)) {
                continue;
            }

            if (\wp_delete_user($userId)) {
                $deleted++;
            }
        }

        if (!empty($userIds)) {
            $this->history->deleteByIds('user', $userIds);
        }

        // Also find and delete users marked with _wpfaker_generated meta
        // These are created by PostGenerator::ensureAuthors() but not tracked in History
        $metaUsers = \get_users([
            'meta_key'   => '_wpfaker_generated',
            'meta_value' => '1',
            'fields'     => 'ID',
            'number'     => 200,
        ]);

        foreach ($metaUsers as $metaUserId) {
            $metaUserId = (int) $metaUserId;
            // Skip already-deleted and protected users
            if (in_array($metaUserId, $userIds) || $metaUserId === $currentUserId) {
                continue;
            }
            $user = \get_user_by('ID', $metaUserId);
            if (!$user || in_array('administrator', $user->roles, true)) {
                continue;
            }
            if (\wp_delete_user($metaUserId)) {
                $deleted++;
            }
        }

        return $deleted;
    }
}
