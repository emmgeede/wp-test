<?php

namespace WPFaker\Controllers;

use WPFaker\Services\AdapterFactory;
use WPFaker\Services\TemplateService;
use WPFaker\Services\TaxonomyAssignmentService;
use WPFaker\Schema\FieldConfigSchema;

/**
 * Template Controller
 *
 * Handles REST API endpoints for template management.
 */
class TemplateController
{
    /**
     * Template service instance
     *
     * @var TemplateService
     */
    protected TemplateService $templates;

    /**
     * Taxonomy assignment service instance
     *
     * @var TaxonomyAssignmentService
     */
    protected TaxonomyAssignmentService $taxonomyService;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->templates = new TemplateService();
        $this->taxonomyService = new TaxonomyAssignmentService();
    }

    /**
     * List all templates
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function list(\WP_REST_Request $request): array
    {
        $filters = [];

        if ($request->has_param('post_type')) {
            $filters['post_type'] = sanitize_key($request->get_param('post_type'));
        }

        if ($request->has_param('is_system')) {
            $filters['is_system'] = (bool) $request->get_param('is_system');
        }

        $templates = $this->templates->getAll($filters);
        $stale = get_transient('wpfaker_stale_templates') ?: [];

        // Collect adapter field info per unique post type
        $postTypes = array_unique(array_column($templates, 'post_type'));
        $adapterInfo = [];
        foreach ($postTypes as $pt) {
            $adapters = AdapterFactory::getAdaptersWithFieldsForPostType($pt);
            if (empty($adapters)) {
                continue;
            }
            $fieldNames = [];
            $adapterNames = [];
            foreach ($adapters as $adapter) {
                $adapterNames[] = $adapter->getName();
                foreach ($adapter->getFieldsForPostType($pt) as $field) {
                    $name = $field['name'] ?? '';
                    if ($name !== '') {
                        $fieldNames[$name] = true;
                    }
                }
            }
            $taxonomies = get_object_taxonomies($pt, 'names');
            $taxonomies = array_values(array_diff($taxonomies, ['post_format']));

            $adapterInfo[$pt] = [
                'fields'     => array_keys($fieldNames),
                'taxonomies' => $taxonomies,
                'adapters'   => array_unique($adapterNames),
            ];
        }

        $adapterInfo = apply_filters('wpfaker_template_adapter_info', $adapterInfo);

        return [
            'success'      => true,
            'templates'    => $templates,
            'total'        => count($templates),
            'stale'        => array_map(fn($t) => $t['id'], $stale),
            'adapter_info' => $adapterInfo,
        ];
    }

    /**
     * Get a single template
     *
     * @param \WP_REST_Request $request
     * @return array|\WP_Error
     */
    public function get(\WP_REST_Request $request): array|\WP_Error
    {
        $id = (int) $request->get_param('id');
        $template = $this->templates->get($id);

        if (!$template) {
            return new \WP_Error(
                'template_not_found',
                __('Template not found', 'wpfaker'),
                ['status' => 404]
            );
        }

        $template['linked_parents'] = $this->templates->getLinkedParents($id);

        // Variant with empty field_config: inherit from parent
        if ($template['parent_id'] && empty($template['field_config'])) {
            $parent = $this->templates->get($template['parent_id']);
            if ($parent) {
                $template['field_config'] = $parent['field_config'];
            }
        }

        // Auto-clean stale template_id references in related_cpt_options
        $template = $this->cleanStaleTemplateReferences($template);

        return [
            'success'  => true,
            'template' => $template,
        ];
    }

    /**
     * Create a new template
     *
     * @param \WP_REST_Request $request
     * @return array|\WP_Error
     */
    public function create(\WP_REST_Request $request): array|\WP_Error
    {
        $params = $request->get_json_params();

        // Validate required fields
        if (empty($params['name'])) {
            return new \WP_Error(
                'missing_name',
                __('Template name is required', 'wpfaker'),
                ['status' => 400]
            );
        }

        if (empty($params['post_type'])) {
            return new \WP_Error(
                'missing_post_type',
                __('Post type is required', 'wpfaker'),
                ['status' => 400]
            );
        }

        // Validate taxonomy config if provided
        if (!empty($params['taxonomy_config'])) {
            $validationErrors = $this->validateTaxonomyConfigs($params['taxonomy_config']);
            if (!empty($validationErrors)) {
                return new \WP_Error(
                    'invalid_taxonomy_config',
                    implode(', ', $validationErrors),
                    ['status' => 400]
                );
            }
        }

        $templateId = $this->templates->create([
            'name'            => $params['name'],
            'slug'            => $params['slug'] ?? '',
            'description'     => $params['description'] ?? '',
            'post_type'       => $params['post_type'],
            'config'          => $params['config'] ?? TemplateService::getDefaultConfig(),
            'taxonomy_config' => $params['taxonomy_config'] ?? [],
            'field_config'    => $params['field_config'] ?? [],
            'is_default'      => $params['is_default'] ?? false,
        ]);

        if (!$templateId) {
            return new \WP_Error(
                'create_failed',
                __('Failed to create template', 'wpfaker'),
                ['status' => 500]
            );
        }

        $template = $this->templates->get($templateId);

        return [
            'success'  => true,
            'message'  => __('Template created successfully', 'wpfaker'),
            'template' => $template,
        ];
    }

    /**
     * Update an existing template
     *
     * @param \WP_REST_Request $request
     * @return array|\WP_Error
     */
    public function update(\WP_REST_Request $request): array|\WP_Error
    {
        $id = (int) $request->get_param('id');
        $params = $request->get_json_params();

        $existing = $this->templates->get($id);
        if (!$existing) {
            return new \WP_Error(
                'template_not_found',
                __('Template not found', 'wpfaker'),
                ['status' => 404]
            );
        }

        if ($existing['is_system']) {
            return new \WP_Error(
                'cannot_edit_system',
                __('System templates cannot be edited', 'wpfaker'),
                ['status' => 403]
            );
        }

        // Validate taxonomy config if provided
        if (!empty($params['taxonomy_config'])) {
            $validationErrors = $this->validateTaxonomyConfigs($params['taxonomy_config']);
            if (!empty($validationErrors)) {
                return new \WP_Error(
                    'invalid_taxonomy_config',
                    implode(', ', $validationErrors),
                    ['status' => 400]
                );
            }
        }

        $updated = $this->templates->update($id, $params);

        if (!$updated) {
            return new \WP_Error(
                'update_failed',
                __('Failed to update template', 'wpfaker'),
                ['status' => 500]
            );
        }

        $template = $this->templates->get($id);

        return [
            'success'  => true,
            'message'  => __('Template updated successfully', 'wpfaker'),
            'template' => $template,
        ];
    }

    /**
     * Delete a template
     *
     * @param \WP_REST_Request $request
     * @return array|\WP_Error
     */
    public function delete(\WP_REST_Request $request): array|\WP_Error
    {
        $id = (int) $request->get_param('id');
        $newDefaultId = $request->has_param('new_default_id')
            ? (int) $request->get_param('new_default_id')
            : null;

        $existing = $this->templates->get($id);
        if (!$existing) {
            return new \WP_Error(
                'template_not_found',
                __('Template not found', 'wpfaker'),
                ['status' => 404]
            );
        }

        if ($existing['is_system']) {
            return new \WP_Error(
                'cannot_delete_system',
                __('System templates cannot be deleted', 'wpfaker'),
                ['status' => 403]
            );
        }

        // If deleting a default template, check for other roots
        if ($existing['is_default']) {
            $otherRoots = array_filter(
                $this->templates->getRootTemplatesForPostType($existing['post_type']),
                fn($t) => $t['id'] !== $id && !$t['is_system']
            );

            if (count($otherRoots) > 1 && $newDefaultId === null) {
                // Scenario 1: multiple other roots — client must pick one
                return new \WP_Error(
                    'new_default_required',
                    __('Please select a new default template before deleting.', 'wpfaker'),
                    ['status' => 422]
                );
            }

            if (count($otherRoots) === 1 && $newDefaultId === null) {
                // Scenario 2: exactly one other root — auto-promote
                $newDefaultId = array_values($otherRoots)[0]['id'];
            }

            // Scenario 3: no other roots (last template) — proceed without transfer

            // Validate new_default_id belongs to same CPT and is among other roots
            if ($newDefaultId !== null) {
                $isValidTarget = false;
                foreach ($otherRoots as $root) {
                    if ($root['id'] === $newDefaultId) {
                        $isValidTarget = true;
                        break;
                    }
                }
                if (!$isValidTarget) {
                    return new \WP_Error(
                        'invalid_new_default',
                        __('The selected template is not a valid default target.', 'wpfaker'),
                        ['status' => 422]
                    );
                }
            }
        }

        $result = $this->templates->deleteWithDefaultTransfer($id, $newDefaultId);

        if (!$result['success']) {
            return new \WP_Error(
                $result['error'],
                __('Failed to delete template', 'wpfaker'),
                ['status' => 500]
            );
        }

        return [
            'success'          => true,
            'message'          => __('Template deleted successfully', 'wpfaker'),
            'variants_deleted' => $result['variants_deleted'],
        ];
    }

    /**
     * Set a template as default for its post type
     *
     * @param \WP_REST_Request $request
     * @return array|\WP_Error
     */
    public function setDefault(\WP_REST_Request $request): array|\WP_Error
    {
        $id = (int) $request->get_param('id');

        $existing = $this->templates->get($id);
        if (!$existing) {
            return new \WP_Error(
                'template_not_found',
                __('Template not found', 'wpfaker'),
                ['status' => 404]
            );
        }

        $updated = $this->templates->setDefault($id);

        if (!$updated) {
            return new \WP_Error(
                'update_failed',
                __('Failed to set template as default', 'wpfaker'),
                ['status' => 500]
            );
        }

        $template = $this->templates->get($id);

        return [
            'success'  => true,
            'message'  => __('Template set as default', 'wpfaker'),
            'template' => $template,
        ];
    }

    /**
     * Duplicate a template
     *
     * @param \WP_REST_Request $request
     * @return array|\WP_Error
     */
    public function duplicate(\WP_REST_Request $request): array|\WP_Error
    {
        $id = (int) $request->get_param('id');
        $params = $request->get_json_params();
        $newName = $params['name'] ?? null;

        $existing = $this->templates->get($id);
        if (!$existing) {
            return new \WP_Error(
                'template_not_found',
                __('Template not found', 'wpfaker'),
                ['status' => 404]
            );
        }

        $newId = $this->templates->duplicate($id, $newName);

        if (!$newId) {
            return new \WP_Error(
                'duplicate_failed',
                __('Failed to duplicate template', 'wpfaker'),
                ['status' => 500]
            );
        }

        $template = $this->templates->get($newId);

        return [
            'success'  => true,
            'message'  => __('Template duplicated successfully', 'wpfaker'),
            'template' => $template,
        ];
    }

    /**
     * Export templates
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function export(\WP_REST_Request $request): array
    {
        $ids = $request->get_param('ids');
        $filters = [];

        if ($request->has_param('post_type')) {
            $filters['post_type'] = sanitize_key($request->get_param('post_type'));
        }

        if (!empty($ids) && is_array($ids)) {
            // Export specific templates
            $templates = [];
            foreach ($ids as $id) {
                $template = $this->templates->export((int) $id);
                if ($template) {
                    $templates[] = $template;
                }
            }
        } else {
            // Export all (with optional filters)
            $templates = $this->templates->exportAll($filters);
        }

        return [
            'success'   => true,
            'templates' => $templates,
            'count'     => count($templates),
            'version'   => '1.0',
            'exported'  => current_time('mysql'),
        ];
    }

    /**
     * Import templates
     *
     * @param \WP_REST_Request $request
     * @return array|\WP_Error
     */
    public function import(\WP_REST_Request $request): array|\WP_Error
    {
        $params = $request->get_json_params();
        $templates = $params['templates'] ?? [];

        if (empty($templates) || !is_array($templates)) {
            return new \WP_Error(
                'no_templates',
                __('No templates provided for import', 'wpfaker'),
                ['status' => 400]
            );
        }

        $results = $this->templates->importAll($templates);

        $successCount = count(array_filter($results, fn($r) => $r['success']));
        $failCount = count($results) - $successCount;

        return [
            'success' => $successCount > 0,
            'message' => sprintf(
                __('Imported %d templates. %d failed.', 'wpfaker'),
                $successCount,
                $failCount
            ),
            'results' => $results,
        ];
    }

    /**
     * Get taxonomy terms for multiselect
     *
     * @param \WP_REST_Request $request
     * @return array|\WP_Error
     */
    public function getTaxonomyTerms(\WP_REST_Request $request): array|\WP_Error
    {
        $taxonomy = sanitize_key($request->get_param('taxonomy'));

        if (!taxonomy_exists($taxonomy)) {
            return new \WP_Error(
                'invalid_taxonomy',
                __('Taxonomy does not exist', 'wpfaker'),
                ['status' => 404]
            );
        }

        $args = [];

        if ($request->has_param('search')) {
            $args['search'] = sanitize_text_field($request->get_param('search'));
        }

        if ($request->has_param('parent')) {
            $args['parent'] = (int) $request->get_param('parent');
        }

        if ($request->has_param('per_page')) {
            $args['number'] = min(100, max(1, (int) $request->get_param('per_page')));
        }

        $terms = $this->taxonomyService->getTermsForSelect($taxonomy, $args);

        return [
            'success'  => true,
            'taxonomy' => $taxonomy,
            'terms'    => $terms,
            'total'    => count($terms),
        ];
    }

    /**
     * Get taxonomies for a post type
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getPostTypeTaxonomies(\WP_REST_Request $request): array
    {
        $postType = sanitize_key($request->get_param('post_type'));

        if (!post_type_exists($postType)) {
            return [
                'success'    => false,
                'message'    => __('Post type does not exist', 'wpfaker'),
                'taxonomies' => [],
            ];
        }

        $taxonomies = get_object_taxonomies($postType, 'objects');
        $result = [];

        foreach ($taxonomies as $taxonomy) {
            if (!$taxonomy->public) {
                continue;
            }

            $result[] = [
                'name'         => $taxonomy->name,
                'label'        => $taxonomy->label,
                'singular'     => $taxonomy->labels->singular_name,
                'hierarchical' => $taxonomy->hierarchical,
                'term_count'   => wp_count_terms(['taxonomy' => $taxonomy->name, 'hide_empty' => false]),
            ];
        }

        return [
            'success'    => true,
            'post_type'  => $postType,
            'taxonomies' => $result,
        ];
    }

    /**
     * Validate taxonomy configurations
     *
     * @param array $taxonomyConfig
     * @return array Array of error messages
     */
    protected function validateTaxonomyConfigs(array $taxonomyConfig): array
    {
        $errors = [];

        foreach ($taxonomyConfig as $taxonomy => $config) {
            $taxonomyErrors = $this->taxonomyService->validateConfig($taxonomy, $config);
            foreach ($taxonomyErrors as $error) {
                $errors[] = sprintf('%s: %s', $taxonomy, $error);
            }
        }

        return $errors;
    }

    /**
     * Get all fields for a post type (Core + Custom)
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getFields(\WP_REST_Request $request): array
    {
        $postType = sanitize_key($request->get_param('post_type'));

        if (!post_type_exists($postType)) {
            return [
                'success' => false,
                'message' => __('Post type does not exist', 'wpfaker'),
                'fields'  => [],
            ];
        }

        // Get core fields filtered by what the CPT actually supports
        $coreFields = $this->getCoreFieldDefinitions($postType);

        // Get custom fields from field plugin adapter
        $customFields = $this->getCustomFieldDefinitions($postType);

        return [
            'success'       => true,
            'post_type'     => $postType,
            'core_fields'   => $coreFields,
            'custom_fields' => $customFields,
        ];
    }

    /**
     * Get core field definitions, filtered by what the CPT supports
     *
     * @param string|null $postType Post type to filter by (null = return all)
     * @return array
     */
    protected function getCoreFieldDefinitions(?string $postType = null): array
    {
        // Map core fields to their post_type_supports() feature key
        // post_date and post_status are always available (every post has these)
        $supportMap = [
            'post_title'   => 'title',
            'post_content' => 'editor',
            'post_excerpt' => 'excerpt',
            'post_date'    => null, // always available
            'post_status'  => null, // always available
            'post_author'  => 'author',
        ];

        $allFields = [
            'post_title' => [
                'name'        => 'post_title',
                'label'       => __('Title', 'wpfaker'),
                'type'        => 'post_title',
                'category'    => 'text',
                'required'    => true, // Title is always required
                'modes'       => FieldConfigSchema::getAvailableModes('post_title'),
                'default'     => FieldConfigSchema::getDefaultConfig('post_title'),
            ],
            'post_content' => [
                'name'        => 'post_content',
                'label'       => __('Content', 'wpfaker'),
                'type'        => 'post_content',
                'category'    => 'text',
                'required'    => false,
                'modes'       => FieldConfigSchema::getAvailableModes('post_content'),
                'default'     => FieldConfigSchema::getDefaultConfig('post_content'),
            ],
            'post_excerpt' => [
                'name'        => 'post_excerpt',
                'label'       => __('Excerpt', 'wpfaker'),
                'type'        => 'post_excerpt',
                'category'    => 'text',
                'required'    => false,
                'modes'       => FieldConfigSchema::getAvailableModes('post_excerpt'),
                'default'     => FieldConfigSchema::getDefaultConfig('post_excerpt'),
            ],
            'post_date' => [
                'name'        => 'post_date',
                'label'       => __('Date', 'wpfaker'),
                'type'        => 'post_date',
                'category'    => 'datetime',
                'required'    => false,
                'modes'       => FieldConfigSchema::getAvailableModes('post_date'),
                'default'     => FieldConfigSchema::getDefaultConfig('post_date'),
            ],
            'post_status' => [
                'name'        => 'post_status',
                'label'       => __('Status', 'wpfaker'),
                'type'        => 'post_status',
                'category'    => 'selection',
                'required'    => false,
                'modes'       => FieldConfigSchema::getAvailableModes('post_status'),
                'default'     => FieldConfigSchema::getDefaultConfig('post_status'),
                'options'     => $this->getPostStatusOptions(),
            ],
            'post_author' => [
                'name'        => 'post_author',
                'label'       => __('Author', 'wpfaker'),
                'type'        => 'post_author',
                'category'    => 'user',
                'required'    => false,
                'modes'       => FieldConfigSchema::getAvailableModes('post_author'),
                'default'     => FieldConfigSchema::getDefaultConfig('post_author'),
            ],
        ];

        // Filter by CPT supports when a post type is specified
        if ($postType && post_type_exists($postType)) {
            foreach ($supportMap as $fieldKey => $feature) {
                if ($feature !== null && !post_type_supports($postType, $feature)) {
                    unset($allFields[$fieldKey]);
                }
            }
        }

        return $allFields;
    }

    /**
     * Get post status options
     *
     * @return array
     */
    protected function getPostStatusOptions(): array
    {
        $statuses = get_post_stati(['show_in_admin_status_list' => true], 'objects');
        $options = [];

        foreach ($statuses as $status) {
            $options[] = [
                'value' => $status->name,
                'label' => $status->label,
            ];
        }

        return $options;
    }

    /**
     * Get custom field definitions for a post type
     *
     * @param string $postType
     * @return array
     */
    protected function getCustomFieldDefinitions(string $postType): array
    {
        $result = [];
        $allFieldNames = [];

        // Collect fields from ALL registered adapters (primary + addon adapters)
        $allAdapters = AdapterFactory::getAdaptersWithFieldsForPostType($postType);

        // Also include the primary adapter if it has fields but wasn't in the list
        $primaryAdapter = AdapterFactory::getPrimaryAdapter();
        if ($primaryAdapter && $primaryAdapter->isActive()) {
            $primaryKey = sanitize_key($primaryAdapter->getName());
            $found = false;
            foreach ($allAdapters as $key => $adapter) {
                if (sanitize_key($adapter->getName()) === $primaryKey) {
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $primaryFields = $primaryAdapter->getFieldsForPostType($postType);
                if (!empty($primaryFields)) {
                    $allAdapters = [$primaryKey => $primaryAdapter] + $allAdapters;
                }
            }
        }

        if (empty($allAdapters)) {
            // Fall back to native meta fields only - wrap in group format
            $nativeFields = $this->getNativeMetaFields($postType);
            if (empty($nativeFields)) {
                return [];
            }
            return [
                'native_meta' => [
                    'group_title' => __('Native Meta Fields', 'wpfaker'),
                    'fields'      => $nativeFields,
                ],
            ];
        }

        foreach ($allAdapters as $key => $adapter) {
            $adapterFields = $adapter->getFieldsForPostType($postType);
            if (empty($adapterFields)) {
                continue;
            }

            // Transform adapter fields to template editor format
            $fields = array_map(function ($field) {
                $fieldType = $field['type'] ?? 'text';
                $category = FieldConfigSchema::getFieldCategory($fieldType);

                $fieldDef = [
                    'key'         => $field['key'] ?? $field['name'] ?? '',
                    'name'        => $field['name'] ?? '',
                    'label'       => $field['label'] ?? $field['name'] ?? '',
                    'type'        => $fieldType,
                    'category'    => $category,
                    'modes'       => FieldConfigSchema::getAvailableModes($fieldType),
                    'default'     => FieldConfigSchema::getDefaultConfig($fieldType, $field['name'] ?? null),
                    'required'    => $field['required'] ?? false,
                    'sub_fields'  => $field['sub_fields'] ?? [],
                    'layouts'     => $field['layouts'] ?? [],
                    'parent_field' => $field['parent_field'] ?? null,
                ];

                // Include options for selection fields as array of {value, label} objects
                // Don't include 'choices' as object - frontend expects 'options' as array
                if (!empty($field['choices'])) {
                    $options = [];
                    foreach ($field['choices'] as $value => $label) {
                        $options[] = ['value' => $value, 'label' => $label];
                    }
                    $fieldDef['options'] = $options;
                }

                // Include multiple flag for multi-select fields
                if (!empty($field['multiple'])) {
                    $fieldDef['multiple'] = true;
                }

                // Include numeric constraints for number/range fields
                if (isset($field['min'])) {
                    $fieldDef['min'] = $field['min'];
                }
                if (isset($field['max'])) {
                    $fieldDef['max'] = $field['max'];
                }
                if (isset($field['step'])) {
                    $fieldDef['step'] = $field['step'];
                }

                // Forward custom default config for template editor UI
                if (!empty($field['default_config'])) {
                    $fieldDef['default_config'] = $field['default_config'];
                }

                return $fieldDef;
            }, $adapterFields);

            // Track all field names to deduplicate native meta later
            foreach ($fields as $f) {
                $allFieldNames[] = $f['name'];
            }

            $adapterName = $adapter->getName();
            $groupKey = sanitize_key($adapterName);

            $result[$groupKey] = [
                'group_title' => $adapterName . ' ' . __('Fields', 'wpfaker'),
                'fields'      => $fields,
            ];
        }

        // Also include native meta fields that might not be covered by any adapter
        $nativeFields = $this->getNativeMetaFields($postType);
        if (!empty($nativeFields)) {
            $uniqueNativeFields = array_filter($nativeFields, function ($field) use ($allFieldNames) {
                return !in_array($field['name'], $allFieldNames);
            });

            if (!empty($uniqueNativeFields)) {
                $result['native_meta'] = [
                    'group_title' => __('Native Meta Fields', 'wpfaker'),
                    'fields'      => array_values($uniqueNativeFields),
                ];
            }
        }

        return $result;
    }

    /**
     * Get native WordPress meta fields registered with register_post_meta
     *
     * @param string $postType
     * @return array
     */
    protected function getNativeMetaFields(string $postType): array
    {
        $registeredMeta = get_registered_meta_keys('post', $postType);

        if (empty($registeredMeta)) {
            return [];
        }

        $fields = [];

        foreach ($registeredMeta as $metaKey => $metaArgs) {
            // Skip private/internal meta keys (those starting with _wp_)
            if (strpos($metaKey, '_wp_') === 0) {
                continue;
            }

            // Determine field type based on meta type
            $metaType = $metaArgs['type'] ?? 'string';
            $fieldType = $this->mapMetaTypeToFieldType($metaType, $metaKey);
            $category = FieldConfigSchema::getFieldCategory($fieldType);

            // Create a nice label from the meta key
            $label = $this->formatMetaKeyAsLabel($metaKey);

            $fields[] = [
                'key'         => $metaKey,
                'name'        => $metaKey,
                'label'       => $metaArgs['description'] ?: $label,
                'type'        => $fieldType,
                'category'    => $category,
                'modes'       => FieldConfigSchema::getAvailableModes($fieldType),
                'default'     => FieldConfigSchema::getDefaultConfig($fieldType, $metaKey),
                'required'    => false,
                'choices'     => [],
                'sub_fields'  => [],
                'layouts'     => [],
                'source'      => 'native', // Mark as native WordPress meta
            ];
        }

        if (empty($fields)) {
            return [];
        }

        return [
            'native_meta' => [
                'group_key'   => 'native_meta',
                'group_title' => __('Native Meta Fields', 'wpfaker'),
                'fields'      => $fields,
            ],
        ];
    }

    /**
     * Map WordPress meta type to WPfaker field type
     *
     * @param string $metaType
     * @param string $metaKey
     * @return string
     */
    protected function mapMetaTypeToFieldType(string $metaType, string $metaKey): string
    {
        // Check meta key for hints about field type
        $keyLower = strtolower($metaKey);

        // Email fields
        if (strpos($keyLower, 'email') !== false || strpos($keyLower, 'e_mail') !== false) {
            return 'email';
        }

        // URL fields
        if (strpos($keyLower, 'url') !== false || strpos($keyLower, 'link') !== false ||
            strpos($keyLower, 'video') !== false || strpos($keyLower, 'website') !== false) {
            return 'url';
        }

        // Date fields
        if (strpos($keyLower, 'date') !== false || strpos($keyLower, 'datum') !== false) {
            return 'date_picker';
        }

        // Textarea-like fields (long text)
        if (strpos($keyLower, 'description') !== false || strpos($keyLower, 'beschreibung') !== false ||
            strpos($keyLower, 'content') !== false || strpos($keyLower, 'inhalt') !== false ||
            strpos($keyLower, 'text') !== false || strpos($keyLower, 'anleitung') !== false ||
            strpos($keyLower, 'liste') !== false || strpos($keyLower, 'tipps') !== false) {
            return 'textarea';
        }

        // Based on meta type
        return match ($metaType) {
            'integer' => 'number',
            'number'  => 'number',
            'boolean' => 'true_false',
            'array'   => 'text',
            'object'  => 'text',
            default   => 'text',
        };
    }

    /**
     * Format a meta key as a human-readable label
     *
     * @param string $metaKey
     * @return string
     */
    protected function formatMetaKeyAsLabel(string $metaKey): string
    {
        // Remove common prefixes
        $label = preg_replace('/^_?(rezept_|meta_|field_|custom_)/', '', $metaKey);

        // Replace underscores with spaces
        $label = str_replace('_', ' ', $label);

        // Capitalize words
        $label = ucwords($label);

        return $label;
    }

    /**
     * Get ACF fields for a post type
     *
     * @param string $postType
     * @return array
     */
    protected function getAcfFields(string $postType): array
    {
        // Get all field groups and filter by location rules
        $allFieldGroups = acf_get_field_groups();
        $fields = [];

        foreach ($allFieldGroups as $group) {
            // Check if this field group applies to the post type
            if (!$this->acfGroupAppliesToPostType($group, $postType)) {
                continue;
            }

            $groupFields = acf_get_fields($group['key']);

            if (!$groupFields) {
                continue;
            }

            $fields[$group['key']] = [
                'group_key'   => $group['key'],
                'group_title' => $group['title'],
                'fields'      => $this->formatAcfFields($groupFields),
            ];
        }

        return $fields;
    }

    /**
     * Check if an ACF field group applies to a post type
     *
     * @param array $group
     * @param string $postType
     * @return bool
     */
    protected function acfGroupAppliesToPostType(array $group, string $postType): bool
    {
        if (empty($group['location'])) {
            return false;
        }

        // Check each location group (OR logic between groups)
        foreach ($group['location'] as $locationGroup) {
            $groupMatches = true;
            $hasPostTypeRule = false;
            $postTypeMatched = false;

            // Check each rule in the group (AND logic within group)
            foreach ($locationGroup as $rule) {
                if ($rule['param'] === 'post_type') {
                    $hasPostTypeRule = true;
                    $operator = $rule['operator'] ?? '==';
                    $value = $rule['value'] ?? '';

                    if ($operator === '==') {
                        // Handle "all" which means all post types
                        if ($value === 'all' || $value === $postType) {
                            $postTypeMatched = true;
                        } else {
                            $groupMatches = false;
                            break;
                        }
                    } elseif ($operator === '!=') {
                        if ($value === $postType) {
                            $groupMatches = false;
                            break;
                        } else {
                            $postTypeMatched = true;
                        }
                    }
                }
            }

            // If this location group matches and has a post_type rule that matched
            if ($groupMatches && $hasPostTypeRule && $postTypeMatched) {
                return true;
            }
        }

        return false;
    }

    /**
     * Format ACF fields for the API
     *
     * @param array $fields
     * @return array
     */
    protected function formatAcfFields(array $fields): array
    {
        $formatted = [];

        foreach ($fields as $field) {
            $fieldType = $field['type'];
            $category = FieldConfigSchema::getFieldCategory($fieldType);

            $formatted[] = [
                'key'         => $field['key'],
                'name'        => $field['name'],
                'label'       => $field['label'],
                'type'        => $fieldType,
                'category'    => $category,
                'modes'       => FieldConfigSchema::getAvailableModes($fieldType),
                'default'     => FieldConfigSchema::getDefaultConfig($fieldType, $field['name'] ?? null),
                'required'    => !empty($field['required']),
                'choices'     => $this->formatAcfChoices($field['choices'] ?? []),
                'sub_fields'  => !empty($field['sub_fields']) ? $this->formatAcfFields($field['sub_fields']) : [],
                'layouts'     => !empty($field['layouts']) ? $this->formatAcfLayouts($field['layouts']) : [],
            ];
        }

        return $formatted;
    }

    /**
     * Format ACF choices from associative array to array of objects
     *
     * @param array $choices
     * @return array
     */
    protected function formatAcfChoices(array $choices): array
    {
        if (empty($choices)) {
            return [];
        }

        $formatted = [];

        foreach ($choices as $value => $label) {
            // Handle nested choices (optgroups)
            if (is_array($label)) {
                foreach ($label as $subValue => $subLabel) {
                    $formatted[] = [
                        'value' => (string) $subValue,
                        'label' => (string) $subLabel,
                    ];
                }
            } else {
                $formatted[] = [
                    'value' => (string) $value,
                    'label' => (string) $label,
                ];
            }
        }

        return $formatted;
    }

    /**
     * Format ACF flexible content layouts
     *
     * @param array $layouts
     * @return array
     */
    protected function formatAcfLayouts(array $layouts): array
    {
        $formatted = [];

        foreach ($layouts as $layout) {
            $formatted[$layout['name']] = [
                'key'        => $layout['key'],
                'name'       => $layout['name'],
                'label'      => $layout['label'],
                'sub_fields' => !empty($layout['sub_fields']) ? $this->formatAcfFields($layout['sub_fields']) : [],
            ];
        }

        return $formatted;
    }

    /**
     * Get Meta Box fields for a post type
     *
     * @param string $postType
     * @return array
     */
    protected function getMetaBoxFields(string $postType): array
    {
        $fields = rwmb_get_object_fields($postType);
        $formatted = [];

        foreach ($fields as $field) {
            $fieldType = $field['type'];
            $category = FieldConfigSchema::getFieldCategory($fieldType);

            $formatted[] = [
                'key'      => $field['id'],
                'name'     => $field['id'],
                'label'    => $field['name'] ?? $field['id'],
                'type'     => $fieldType,
                'category' => $category,
                'modes'    => FieldConfigSchema::getAvailableModes($fieldType),
                'default'  => FieldConfigSchema::getDefaultConfig($fieldType, $field['id'] ?? null),
                'required' => !empty($field['required']),
                'options'  => $field['options'] ?? [],
            ];
        }

        return ['default' => ['group_title' => 'Meta Box Fields', 'fields' => $formatted]];
    }

    /**
     * Get field schema for a specific field type
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getFieldSchema(\WP_REST_Request $request): array
    {
        $fieldType = sanitize_key($request->get_param('field_type'));

        return [
            'success'   => true,
            'type'      => $fieldType,
            'category'  => FieldConfigSchema::getFieldCategory($fieldType),
            'modes'     => FieldConfigSchema::getAvailableModes($fieldType),
            'schema'    => FieldConfigSchema::getSchemaForType($fieldType),
            'default'   => FieldConfigSchema::getDefaultConfig($fieldType),
        ];
    }

    /**
     * Get images from media library
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getMediaImages(\WP_REST_Request $request): array
    {
        $perPage = min(100, max(1, (int) ($request->get_param('per_page') ?? 20)));
        $page = max(1, (int) ($request->get_param('page') ?? 1));
        $search = sanitize_text_field($request->get_param('search') ?? '');

        $args = [
            'post_type'      => 'attachment',
            'post_mime_type' => 'image',
            'post_status'    => 'inherit',
            'posts_per_page' => $perPage,
            'paged'          => $page,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ];

        if (!empty($search)) {
            $args['s'] = $search;
        }

        $query = new \WP_Query($args);
        $images = [];

        foreach ($query->posts as $attachment) {
            $images[] = [
                'id'         => $attachment->ID,
                'title'      => $attachment->post_title,
                'url'        => wp_get_attachment_url($attachment->ID),
                'thumbnail'  => wp_get_attachment_image_url($attachment->ID, 'thumbnail'),
                'medium'     => wp_get_attachment_image_url($attachment->ID, 'medium'),
                // WPfaker metadata (if available)
                'dimensions' => get_post_meta($attachment->ID, '_wpfaker_dimensions', true) ?: null,
                'ratio'      => get_post_meta($attachment->ID, '_wpfaker_aspect_ratio', true) ?: null,
                'generated'  => (bool) get_post_meta($attachment->ID, '_wpfaker_generated', true),
            ];
        }

        return [
            'success'     => true,
            'images'      => $images,
            'total'       => $query->found_posts,
            'total_pages' => $query->max_num_pages,
            'page'        => $page,
        ];
    }

    /**
     * Get non-image files from media library (for file fields)
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getMediaFiles(\WP_REST_Request $request): array
    {
        $perPage = min(100, max(1, (int) ($request->get_param('per_page') ?? 50)));
        $page = max(1, (int) ($request->get_param('page') ?? 1));
        $fileType = sanitize_key($request->get_param('file_type') ?? '');

        // Define non-image mime types
        $mimeTypes = [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'text/csv',
            'application/zip',
            'application/x-rar-compressed',
            'application/x-7z-compressed',
            'text/plain',
            'application/rtf',
        ];

        // Filter by file type if specified
        if (!empty($fileType)) {
            switch ($fileType) {
                case 'pdf':
                    $mimeTypes = ['application/pdf'];
                    break;
                case 'document':
                    $mimeTypes = [
                        'application/msword',
                        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    ];
                    break;
                case 'spreadsheet':
                    $mimeTypes = [
                        'application/vnd.ms-excel',
                        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                        'text/csv',
                    ];
                    break;
                case 'archive':
                    $mimeTypes = [
                        'application/zip',
                        'application/x-rar-compressed',
                        'application/x-7z-compressed',
                    ];
                    break;
            }
        }

        $args = [
            'post_type'      => 'attachment',
            'post_mime_type' => $mimeTypes,
            'post_status'    => 'inherit',
            'posts_per_page' => $perPage,
            'paged'          => $page,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ];

        $query = new \WP_Query($args);
        $files = [];

        foreach ($query->posts as $attachment) {
            $metadata = wp_get_attachment_metadata($attachment->ID);
            $filePath = get_attached_file($attachment->ID);
            $fileSize = $filePath ? filesize($filePath) : 0;
            $extension = pathinfo($attachment->guid, PATHINFO_EXTENSION);

            $files[] = [
                'id'        => $attachment->ID,
                'title'     => $attachment->post_title,
                'filename'  => basename($attachment->guid),
                'url'       => wp_get_attachment_url($attachment->ID),
                'mime_type' => $attachment->post_mime_type,
                'extension' => $extension,
                'filesize'  => $fileSize,
                'uploaded'  => (bool) get_post_meta($attachment->ID, '_wpfaker_uploaded', true),
            ];
        }

        return [
            'success'     => true,
            'files'       => $files,
            'total'       => $query->found_posts,
            'total_pages' => $query->max_num_pages,
            'page'        => $page,
        ];
    }

    /**
     * Get users for author selection
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getUsers(\WP_REST_Request $request): array
    {
        $roles = $request->get_param('roles') ?? [];
        $search = sanitize_text_field($request->get_param('search') ?? '');
        $perPage = min(100, max(1, (int) ($request->get_param('per_page') ?? 50)));

        $args = [
            'number'  => $perPage,
            'orderby' => 'display_name',
            'order'   => 'ASC',
        ];

        if (!empty($roles)) {
            $args['role__in'] = array_map('sanitize_key', (array) $roles);
        }

        if (!empty($search)) {
            $args['search'] = '*' . $search . '*';
            $args['search_columns'] = ['display_name', 'user_login', 'user_email'];
        }

        $userQuery = new \WP_User_Query($args);
        $users = [];

        foreach ($userQuery->get_results() as $user) {
            $users[] = [
                'id'           => $user->ID,
                'display_name' => $user->display_name,
                'user_login'   => $user->user_login,
                'email'        => $user->user_email,
                'roles'        => $user->roles,
                'avatar'       => get_avatar_url($user->ID, ['size' => 48]),
            ];
        }

        return [
            'success' => true,
            'users'   => $users,
            'total'   => $userQuery->get_total(),
        ];
    }

    /**
     * Get available user roles
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getUserRoles(\WP_REST_Request $request): array
    {
        global $wp_roles;

        $roles = [];
        foreach ($wp_roles->roles as $key => $role) {
            $roles[] = [
                'key'  => $key,
                'name' => $role['name'],
            ];
        }

        return [
            'success' => true,
            'roles'   => $roles,
        ];
    }

    /**
     * Create a variant of an existing template
     *
     * @param \WP_REST_Request $request
     * @return array|\WP_Error
     */
    public function createVariant(\WP_REST_Request $request)
    {
        $parentId = (int) $request->get_param('id');
        $params = $request->get_json_params();
        $name = sanitize_text_field($params['name'] ?? '');
        $overrides = $params['config_overrides'] ?? [];

        if (empty($name)) {
            return new \WP_Error(
                'missing_name',
                __('Name is required', 'wpfaker'),
                ['status' => 400]
            );
        }

        $variantId = $this->templates->createVariant($parentId, $name, $overrides);

        if (!$variantId) {
            return new \WP_Error(
                'variant_create_failed',
                __('Failed to create variant', 'wpfaker'),
                ['status' => 500]
            );
        }

        return [
            'success'  => true,
            'template' => $this->templates->get($variantId),
        ];
    }

    /**
     * Get the effective (merged) config for a template
     *
     * @param \WP_REST_Request $request
     * @return array|\WP_Error
     */
    public function getEffectiveConfig(\WP_REST_Request $request)
    {
        $id = (int) $request->get_param('id');
        $config = $this->templates->getEffectiveConfig($id);

        if ($config === null) {
            return new \WP_Error(
                'template_not_found',
                __('Template not found', 'wpfaker'),
                ['status' => 404]
            );
        }

        return ['success' => true, 'config' => $config];
    }

    /**
     * Get stale templates
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getStaleTemplates(\WP_REST_Request $request): array
    {
        return [
            'success'   => true,
            'templates' => $this->templates->detectStaleTemplates(),
        ];
    }

    /**
     * Auto-clean stale template_id references in related_cpt_options.
     * If a referenced template no longer exists, remove the reference and persist.
     */
    protected function cleanStaleTemplateReferences(array $template): array
    {
        $relatedOpts = $template['config']['related_cpt_options'] ?? [];
        if (empty($relatedOpts)) {
            return $template;
        }

        $changed = false;
        foreach ($relatedOpts as $cpt => $cptConfig) {
            if (!is_array($cptConfig) || empty($cptConfig['template_id'])) {
                continue;
            }

            $linked = $this->templates->get((int) $cptConfig['template_id']);
            if (!$linked) {
                unset($relatedOpts[$cpt]['template_id']);
                unset($relatedOpts[$cpt]['template_name']);
                $changed = true;
            }
        }

        if ($changed) {
            $template['config']['related_cpt_options'] = $relatedOpts;
            $this->templates->update($template['id'], ['config' => $template['config']]);
        }

        return $template;
    }
}
