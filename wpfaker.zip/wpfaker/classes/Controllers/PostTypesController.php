<?php

namespace WPFaker\Controllers;

/**
 * Post Types Controller
 *
 * Handles operations related to WordPress post types.
 */
class PostTypesController
{
    /**
     * Get all registered post types
     *
     * @return array
     */
    public function wpf_get_all_cpts(): array
    {
        $postTypes = get_post_types(['public' => true], 'objects');
        $result = [];

        // Exclude post types that shouldn't be generated
        $excludedTypes = ['attachment', 'page'];

        foreach ($postTypes as $postType) {
            if (in_array($postType->name, $excludedTypes, true)) {
                continue;
            }
            $result[] = [
                'name'         => $postType->name,
                'label'        => $postType->label,
                'labels'       => $postType->labels,
                'description'  => $postType->description,
                'public'       => $postType->public,
                'hierarchical' => $postType->hierarchical,
                'has_archive'  => $postType->has_archive,
                'rewrite'      => $postType->rewrite,
                'supports'     => get_all_post_type_supports($postType->name),
                'taxonomies'   => get_object_taxonomies($postType->name),
                'menu_icon'    => $postType->menu_icon,
                'count'        => wp_count_posts($postType->name),
            ];
        }

        return $result;
    }

    /**
     * Get post type supports
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function wpf_get_type_supports($request): array
    {
        $postType = $request->get_param('cpt');

        if (!post_type_exists($postType)) {
            return [
                'error'   => true,
                'message' => 'Post type does not exist',
            ];
        }

        return [
            'post_type' => $postType,
            'supports'  => get_all_post_type_supports($postType),
        ];
    }

    /**
     * Get post type by name
     *
     * @param string $name
     * @return \WP_Post_Type|null
     */
    public function getPostType(string $name): ?\WP_Post_Type
    {
        return get_post_type_object($name);
    }

    /**
     * Get all taxonomies for a post type
     *
     * @param string $postType
     * @return array
     */
    public function getTaxonomiesForPostType(string $postType): array
    {
        $taxonomies = get_object_taxonomies($postType, 'objects');
        $result = [];

        foreach ($taxonomies as $taxonomy) {
            $result[] = [
                'name'         => $taxonomy->name,
                'label'        => $taxonomy->label,
                'hierarchical' => $taxonomy->hierarchical,
                'public'       => $taxonomy->public,
                'count'        => wp_count_terms(['taxonomy' => $taxonomy->name, 'hide_empty' => false]),
            ];
        }

        return $result;
    }
}
