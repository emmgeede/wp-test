<?php

namespace WPFaker\Controllers;

use WPFaker\License;
use WPFaker\Services\AbstractAiProvider;
use WPFaker\Services\AiProviderFactory;
use WPFaker\Services\ImageService;
use WPFaker\Services\SyncService;

/**
 * Settings Controller
 *
 * Handles plugin settings and AI configuration.
 */
class SettingsController
{
    /**
     * Option name for general settings
     */
    public const OPTION_NAME = 'wpfaker_settings';

    /**
     * Get all settings
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getSettings($request): array
    {
        // Merge saved settings with defaults to ensure new settings are included
        $savedSettings = get_option(self::OPTION_NAME, []);
        $generalSettings = array_merge($this->getDefaultSettings(), $savedSettings);
        $aiSettings = AbstractAiProvider::getSettings();

        return [
            'success' => true,
            'settings' => [
                'general' => $generalSettings,
                'ai' => $aiSettings,
            ],
        ];
    }

    /**
     * Save general settings
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function saveSettings($request): array
    {
        $params = $request->get_json_params();

        $settings = [
            'admin_locale' => sanitize_text_field($params['admin_locale'] ?? 'auto'),
            'locale' => sanitize_text_field($params['locale'] ?? 'auto'),
            'default_post_count' => absint($params['default_post_count'] ?? 5),
            'default_term_count' => absint($params['default_term_count'] ?? 5),
            'default_user_count' => absint($params['default_user_count'] ?? 5),
            'delete_history_on_deactivate' => !empty($params['delete_history_on_deactivate']),
            'delete_media_with_posts' => !empty($params['delete_media_with_posts']),
            'auto_select_default_template' => array_key_exists('auto_select_default_template', $params)
                ? filter_var($params['auto_select_default_template'], FILTER_VALIDATE_BOOLEAN)
                : true,
            'delete_related_media' => array_key_exists('delete_related_media', $params)
                ? filter_var($params['delete_related_media'], FILTER_VALIDATE_BOOLEAN)
                : true,
            'delete_related_terms' => array_key_exists('delete_related_terms', $params)
                ? filter_var($params['delete_related_terms'], FILTER_VALIDATE_BOOLEAN)
                : true,
            'delete_related_authors' => array_key_exists('delete_related_authors', $params)
                ? filter_var($params['delete_related_authors'], FILTER_VALIDATE_BOOLEAN)
                : true,
            'delete_related_comments' => array_key_exists('delete_related_comments', $params)
                ? filter_var($params['delete_related_comments'], FILTER_VALIDATE_BOOLEAN)
                : true,
            'default_image_provider' => in_array($params['default_image_provider'] ?? 'unsplash', [
                'picsum', 'unsplash', 'pexels', 'pixabay', 'placeholder',
            ]) ? $params['default_image_provider'] : 'unsplash',
            'telemetry_enabled' => array_key_exists('telemetry_enabled', $params)
                ? filter_var($params['telemetry_enabled'], FILTER_VALIDATE_BOOLEAN)
                : true,
            'save_and_generate_auto_run' => array_key_exists('save_and_generate_auto_run', $params)
                ? filter_var($params['save_and_generate_auto_run'], FILTER_VALIDATE_BOOLEAN)
                : true,
            'child_generate_behavior' => in_array($params['child_generate_behavior'] ?? 'ask', [
                'ask', 'child_only', 'parent_chain',
            ]) ? $params['child_generate_behavior'] : 'ask',
            'hourly_rate' => max(1, (float) ($params['hourly_rate'] ?? 75)),
            'text_source' => in_array($params['text_source'] ?? 'realtext', [
                'realtext', 'lorem',
            ]) ? $params['text_source'] : 'realtext',
        ];

        update_option(self::OPTION_NAME, $settings);

        return [
            'success' => true,
            'message' => __('Settings saved successfully', 'wpfaker'),
            'settings' => $settings,
        ];
    }

    /**
     * Get AI settings
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getAiSettings($request): array
    {
        $allSettings = AbstractAiProvider::getSettings();
        $providerKey = $allSettings['provider'] ?? 'gemini';

        // Build per-provider data with masked keys
        $providers = [];
        foreach (['gemini', 'anthropic', 'openai'] as $key) {
            $p = AiProviderFactory::createProvider($key);
            $masked = $p ? $p->getMaskedApiKey() : '';
            $providers[$key] = [
                'has_api_key' => !empty($masked),
                'masked_api_key' => $masked,
            ];
        }

        return [
            'success' => true,
            'settings' => [
                'enabled' => !empty($allSettings['enabled']),
                'provider' => $providerKey,
                'has_api_key' => $providers[$providerKey]['has_api_key'],
                'hive_enabled' => $allSettings['hive_enabled'] ?? false,
                'providers' => $providers,
            ],
        ];
    }

    /**
     * Save AI settings
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function saveAiSettings($request): array
    {
        $params = $request->get_json_params();

        $settings = [
            'enabled' => !empty($params['enabled']),
            'provider' => sanitize_text_field($params['provider'] ?? 'gemini'),
            'hive_enabled' => !empty($params['hive_enabled']),
        ];

        // Handle per-provider API keys
        foreach (['gemini', 'anthropic', 'openai'] as $providerKey) {
            $keyField = $providerKey . '_api_key';
            if (!empty($params[$keyField])) {
                $settings[$keyField] = $params[$keyField];
            }
        }

        AbstractAiProvider::saveSettings($settings);

        // Clear caches when settings change
        AbstractAiProvider::clearCache();
        AiProviderFactory::clearInstance();

        // Get updated settings for response
        $allSettings = AbstractAiProvider::getSettings();
        $providerKey = $allSettings['provider'] ?? 'gemini';

        $providers = [];
        foreach (['gemini', 'anthropic', 'openai'] as $key) {
            $p = AiProviderFactory::createProvider($key);
            $masked = $p ? $p->getMaskedApiKey() : '';
            $providers[$key] = [
                'has_api_key' => !empty($masked),
                'masked_api_key' => $masked,
            ];
        }

        return [
            'success' => true,
            'message' => __('AI settings saved successfully', 'wpfaker'),
            'settings' => [
                'enabled' => !empty($allSettings['enabled']),
                'provider' => $providerKey,
                'has_api_key' => $providers[$providerKey]['has_api_key'],
                'hive_enabled' => $allSettings['hive_enabled'] ?? false,
                'providers' => $providers,
            ],
        ];
    }

    /**
     * Test AI connection
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function testAiConnection($request): array
    {
        $params = $request->get_json_params();
        $providerKey = sanitize_text_field($params['provider'] ?? '');

        // Use specified provider or active provider
        if ($providerKey) {
            $provider = AiProviderFactory::createProvider($providerKey);
        } else {
            $provider = AiProviderFactory::getProvider();
        }

        if (!$provider) {
            return [
                'success' => false,
                'message' => __('No AI provider configured', 'wpfaker'),
            ];
        }

        $result = $provider->testConnection();

        return [
            'success' => $result['success'],
            'message' => $result['message'],
        ];
    }

    /**
     * Clear AI cache
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function clearAiCache($request): array
    {
        AbstractAiProvider::clearCache();

        return [
            'success' => true,
            'message' => __('AI detection cache cleared', 'wpfaker'),
        ];
    }

    /**
     * Get default settings
     *
     * @return array
     */
    protected function getDefaultSettings(): array
    {
        return [
            'admin_locale' => 'auto',
            'locale' => 'auto',
            'default_post_count' => 5,
            'default_term_count' => 5,
            'default_user_count' => 5,
            'delete_history_on_deactivate' => false,
            'delete_media_with_posts' => false,
            'auto_select_default_template' => true,
            'delete_related_media' => true,
            'delete_related_terms' => true,
            'delete_related_authors' => true,
            'delete_related_comments' => true,
            'default_image_provider' => 'unsplash',
            'telemetry_enabled' => true,
            'save_and_generate_auto_run' => true,
            'child_generate_behavior' => 'ask',
            'hourly_rate' => 75,
            'text_source' => 'realtext',
        ];
    }

    /**
     * Get image provider settings (API keys)
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getImageProviderSettings($request): array
    {
        return [
            'success'  => true,
            'settings' => ImageService::getProviderSettings(),
        ];
    }

    /**
     * Save image provider settings (API keys)
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function saveImageProviderSettings($request): array
    {
        $params = $request->get_json_params();

        if (!empty($params['pexels_api_key'])) {
            ImageService::saveApiKey('pexels', $params['pexels_api_key']);
        }
        if (!empty($params['pixabay_api_key'])) {
            ImageService::saveApiKey('pixabay', $params['pixabay_api_key']);
        }

        return [
            'success'  => true,
            'message'  => __('Image provider settings saved successfully', 'wpfaker'),
            'settings' => ImageService::getProviderSettings(),
        ];
    }

    /**
     * Get license status
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function getLicenseStatus($request): array
    {
        $status = License::getStatus();
        $key = License::getKey();
        $fingerprintInfo = License::getFingerprintInfo();

        return [
            'success' => true,
            'license' => [
                'key' => $key ? $this->maskLicenseKey($key) : '',
                'has_key' => !empty($key),
                'valid' => $status['valid'] ?? false,
                'status' => $status['status'] ?? 'inactive',
                'message' => $status['message'] ?? '',
                'expires' => $status['expires'] ?? null,
                'customer' => $status['customer'] ?? null,
                'site_fingerprint' => $fingerprintInfo['fingerprint'],
                'site_url' => home_url(),
            ],
        ];
    }

    /**
     * Activate license
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function activateLicense($request): array
    {
        $params = $request->get_json_params();
        $key = sanitize_text_field($params['license_key'] ?? '');

        if (empty($key)) {
            return [
                'success' => false,
                'message' => __('Please enter a license key.', 'wpfaker'),
            ];
        }

        $result = License::activate($key);

        if ($result['success']) {
            return [
                'success' => true,
                'message' => $result['message'] ?? __('License activated successfully.', 'wpfaker'),
                'license' => [
                    'key' => $this->maskLicenseKey($key),
                    'has_key' => true,
                    'valid' => true,
                    'status' => 'active',
                    'expires' => $result['data']['expires'] ?? null,
                    'customer' => $result['data']['customer'] ?? null,
                ],
            ];
        }

        return [
            'success' => false,
            'message' => $result['message'] ?? __('Could not activate license.', 'wpfaker'),
        ];
    }

    /**
     * Deactivate license
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function deactivateLicense($request): array
    {
        $result = License::deactivate();

        if ($result['success']) {
            return [
                'success' => true,
                'message' => __('License deactivated successfully.', 'wpfaker'),
                'license' => [
                    'key' => '',
                    'has_key' => false,
                    'valid' => false,
                    'status' => 'inactive',
                ],
            ];
        }

        return [
            'success' => false,
            'message' => $result['message'] ?? __('Could not deactivate license.', 'wpfaker'),
        ];
    }

    /**
     * Refresh license status
     *
     * @param \WP_REST_Request $request
     * @return array
     */
    public function refreshLicense($request): array
    {
        $status = License::refreshStatus();
        $key = License::getKey();

        return [
            'success' => true,
            'message' => __('License status refreshed.', 'wpfaker'),
            'license' => [
                'key' => $key ? $this->maskLicenseKey($key) : '',
                'has_key' => !empty($key),
                'valid' => $status['valid'] ?? false,
                'status' => $status['status'] ?? 'inactive',
                'message' => $status['message'] ?? '',
                'expires' => $status['expires'] ?? null,
            ],
        ];
    }

    /**
     * Get sync status for dashboard display.
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function getSyncStatus($request): \WP_REST_Response
    {
        return rest_ensure_response(SyncService::getStatus());
    }

    /**
     * Mark last sync notification as seen.
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function markSyncSeen($request): \WP_REST_Response
    {
        SyncService::markResultSeen();
        return rest_ensure_response(['success' => true]);
    }

    /**
     * Mask license key for display
     *
     * @param string $key
     * @return string
     */
    private function maskLicenseKey(string $key): string
    {
        if (strlen($key) <= 8) {
            return str_repeat('*', strlen($key));
        }

        return substr($key, 0, 4) . str_repeat('*', strlen($key) - 8) . substr($key, -4);
    }
}
