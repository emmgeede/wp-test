<?php

namespace WPFaker;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Tour Class
 *
 * Handles onboarding tour state, demo CPT management, and REST endpoints.
 */
class Tour
{
    private const DEMO_POST_TYPE = 'wpf_movie';
    public const OPTION_COMPLETED = 'wpfaker_tour_completed';
    public const OPTION_DEMO_ACTIVE = 'wpfaker_tour_demo_active';

    /**
     * Get current tour state
     */
    public function getTourState(): array
    {
        return [
            'completed'   => (bool) get_option(self::OPTION_COMPLETED, false),
            'demo_active' => (bool) get_option(self::OPTION_DEMO_ACTIVE, false),
        ];
    }

    /**
     * Mark tour as completed
     */
    public function completeTour(): void
    {
        update_option(self::OPTION_COMPLETED, true);
    }

    /**
     * Reset tour (for restart from Settings)
     */
    public function resetTour(): void
    {
        update_option(self::OPTION_COMPLETED, false);
    }

    /**
     * Get demo CPT configuration
     */
    public function getDemoCptConfig(): array
    {
        return [
            'post_type' => self::DEMO_POST_TYPE,
            'label'     => 'Movies',
            'fields'    => [
                'movie_title'    => ['type' => 'string',  'description' => 'Movie title'],
                'movie_director' => ['type' => 'string',  'description' => 'Director name'],
                'movie_year'     => ['type' => 'integer', 'description' => 'Release year'],
                'movie_genre'    => ['type' => 'string',  'description' => 'Genre'],
                'movie_poster'   => ['type' => 'string',  'description' => 'Poster image URL'],
            ],
        ];
    }

    /**
     * Register the demo Movies CPT + meta fields
     */
    public function registerDemoCpt(): void
    {
        $config = $this->getDemoCptConfig();

        register_post_type($config['post_type'], [
            'label'               => $config['label'],
            'public'              => true,
            'show_ui'             => true,
            'show_in_rest'        => true,
            'supports'            => ['title', 'editor', 'thumbnail', 'custom-fields'],
            'menu_icon'           => 'dashicons-video-alt2',
            'has_archive'         => false,
            'exclude_from_search' => true,
        ]);

        foreach ($config['fields'] as $key => $field) {
            register_post_meta($config['post_type'], $key, [
                'type'         => $field['type'],
                'description'  => $field['description'],
                'single'       => true,
                'show_in_rest' => true,
            ]);
        }

        update_option(self::OPTION_DEMO_ACTIVE, true);
    }

    /**
     * Clean up demo CPT and all generated data
     */
    public function cleanupDemoCpt(): void
    {
        $posts = get_posts([
            'post_type'   => self::DEMO_POST_TYPE,
            'numberposts' => -1,
            'post_status' => 'any',
            'fields'      => 'ids',
        ]);

        foreach ($posts as $postId) {
            wp_delete_post($postId, true);
        }

        unregister_post_type(self::DEMO_POST_TYPE);
        update_option(self::OPTION_DEMO_ACTIVE, false);
    }

    /**
     * Check for available CPTs with custom fields.
     * Uses WPfaker's adapter system to detect fields from ACF, Meta Box, JetEngine, etc.
     */
    public function checkAvailableCpts(): array
    {
        $postTypes = get_post_types(['public' => true, '_builtin' => false], 'objects');
        $cptsWithFields = [];

        foreach ($postTypes as $postType) {
            $adapters = \WPFaker\Services\AdapterFactory::getAdaptersWithFieldsForPostType($postType->name);
            if (!empty($adapters)) {
                $adapter = reset($adapters);
                $fields = $adapter->getFieldsForPostType($postType->name);
                $cptsWithFields[] = [
                    'name'        => $postType->name,
                    'label'       => $postType->label,
                    'field_count' => count($fields),
                ];
            }
        }

        return [
            'has_cpts_with_fields' => !empty($cptsWithFields),
            'suggested_cpt'       => $cptsWithFields[0]['name'] ?? null,
            'available_cpts'      => $cptsWithFields,
        ];
    }

    // =========================================================================
    // REST Endpoint Callbacks
    // =========================================================================

    /**
     * GET /wpfaker/v1/tour/state
     */
    public function handleGetState(\WP_REST_Request $request): \WP_REST_Response
    {
        return new \WP_REST_Response($this->getTourState());
    }

    /**
     * POST /wpfaker/v1/tour/complete
     */
    public function handleComplete(\WP_REST_Request $request): \WP_REST_Response
    {
        $this->completeTour();
        return new \WP_REST_Response(['success' => true]);
    }

    /**
     * POST /wpfaker/v1/tour/reset
     */
    public function handleReset(\WP_REST_Request $request): \WP_REST_Response
    {
        $this->resetTour();
        return new \WP_REST_Response(['success' => true]);
    }

    /**
     * POST /wpfaker/v1/tour/setup-demo
     */
    public function handleSetupDemo(\WP_REST_Request $request): \WP_REST_Response
    {
        $available = $this->checkAvailableCpts();

        if ($available['has_cpts_with_fields']) {
            return new \WP_REST_Response([
                'demo_created'  => false,
                'use_existing'  => true,
                'suggested_cpt' => $available['suggested_cpt'],
                'available_cpts' => $available['available_cpts'],
            ]);
        }

        $this->registerDemoCpt();
        $config = $this->getDemoCptConfig();

        return new \WP_REST_Response([
            'demo_created' => true,
            'use_existing' => false,
            'post_type'    => $config['post_type'],
            'label'        => $config['label'],
        ]);
    }

    /**
     * POST /wpfaker/v1/tour/cleanup-demo
     */
    public function handleCleanupDemo(\WP_REST_Request $request): \WP_REST_Response
    {
        if (!get_option(self::OPTION_DEMO_ACTIVE)) {
            return new \WP_REST_Response([
                'success' => true,
                'message' => 'No demo CPT active',
            ]);
        }

        $this->cleanupDemoCpt();

        return new \WP_REST_Response([
            'success' => true,
            'message' => 'Demo CPT and data cleaned up',
        ]);
    }

    /**
     * GET /wpfaker/v1/tour/check-cpts
     */
    public function handleCheckCpts(\WP_REST_Request $request): \WP_REST_Response
    {
        return new \WP_REST_Response($this->checkAvailableCpts());
    }
}
