<?php

namespace WPFaker\Adapters;

use WPFaker\Contracts\FieldPluginAdapterInterface;
use WPFaker\Services\FakerService;
use WPFaker\Services\FieldNameDetector;
use WPFaker\Services\FakeFileService;
use WPFaker\Services\LogoService;

/**
 * Abstract base class for Field Plugin Adapters
 *
 * Provides common functionality shared across all field plugin adapters.
 */
abstract class AbstractFieldPluginAdapter implements FieldPluginAdapterInterface
{
    /**
     * The Faker service instance
     *
     * @var FakerService
     */
    protected FakerService $faker;

    /**
     * Field name detector service
     *
     * @var FieldNameDetector
     */
    protected FieldNameDetector $fieldDetector;

    /**
     * Fake file service
     *
     * @var FakeFileService
     */
    protected FakeFileService $fileService;

    /**
     * Current locale for generation
     *
     * @var string|null
     */
    protected ?string $locale = null;

    /**
     * Cached field groups
     *
     * @var array|null
     */
    protected ?array $cachedFieldGroups = null;

    /**
     * Cached post types
     *
     * @var array|null
     */
    protected ?array $cachedPostTypes = null;

    /**
     * Cached taxonomies
     *
     * @var array|null
     */
    protected ?array $cachedTaxonomies = null;

    /**
     * Default field type to Faker method mapping
     *
     * @var array
     */
    protected array $defaultFieldTypeMap = [
        'text'          => 'sentence',
        'textarea'      => 'paragraphs',
        'number'        => 'randomNumber',
        'range'         => 'numberBetween',
        'email'         => 'safeEmail',
        'url'           => 'url',
        'password'      => 'password',
        'wysiwyg'       => 'paragraphs',
        'oembed'        => 'url',
        'image'         => 'imageUrl',
        'file'          => 'url',
        'gallery'       => 'imageUrl',
        'select'        => 'randomElement',
        'checkbox'      => 'randomElements',
        'radio'         => 'randomElement',
        'button_group'  => 'randomElement',
        'true_false'    => 'boolean',
        'link'          => 'url',
        'page_link'     => 'randomNumber',
        'post_object'   => 'randomNumber',
        'relationship'  => 'randomNumber',
        'taxonomy'      => 'randomNumber',
        'user'          => 'randomNumber',
        'google_map'    => 'address',
        'date_picker'   => 'date',
        'date_time_picker' => 'dateTime',
        'time_picker'   => 'time',
        'color_picker'  => 'hexColor',
    ];

    /**
     * Constructor
     *
     * @param FakerService|null $faker
     */
    public function __construct(?FakerService $faker = null)
    {
        $this->faker = $faker ?? new FakerService();
        $this->fieldDetector = new FieldNameDetector($this->faker);
        $this->fileService = new FakeFileService($this->faker);
    }

    /**
     * Set the locale for content generation
     *
     * @param string|null $locale
     * @return self
     */
    public function setLocale(?string $locale): self
    {
        $this->locale = $locale;
        if ($locale) {
            $this->faker->setLocale($locale);
        }
        return $this;
    }

    /**
     * Get the current locale
     *
     * @return string|null
     */
    public function getLocale(): ?string
    {
        return $this->locale;
    }

    /**
     * Set CPT context on the field name detector for disambiguation
     *
     * @param string $slug Post type slug
     * @param string|null $label Post type label
     * @return self
     */
    public function setCptContext(string $slug, ?string $label = null): self
    {
        $this->fieldDetector->setCptContext($slug, $label);
        return $this;
    }

    /**
     * Clear all caches
     *
     * @return void
     */
    public function clearCache(): void
    {
        $this->cachedFieldGroups = null;
        $this->cachedPostTypes = null;
        $this->cachedTaxonomies = null;
    }

    /**
     * Get the Faker service
     *
     * @return FakerService
     */
    public function getFaker(): FakerService
    {
        return $this->faker;
    }

    /**
     * Set the Faker service
     *
     * @param FakerService $faker
     * @return self
     */
    public function setFaker(FakerService $faker): self
    {
        $this->faker = $faker;
        return $this;
    }

    /**
     * Map field type to Faker method using default mapping
     *
     * @param array $field The field configuration
     * @return string The Faker method to use
     */
    public function mapFieldTypeToFaker(array $field): string
    {
        $type = $field['type'] ?? 'text';
        return $this->defaultFieldTypeMap[$type] ?? 'sentence';
    }

    /**
     * Get a locale-aware faker instance
     *
     * @return \Faker\Generator
     */
    protected function getLocaleFaker(): \Faker\Generator
    {
        return $this->locale ? $this->faker->forLocale($this->locale) : $this->faker->getInstance();
    }

    /**
     * Get supported field types
     *
     * @return array
     */
    public function getSupportedFieldTypes(): array
    {
        return array_keys($this->defaultFieldTypeMap);
    }

    /**
     * Generate a fake value based on field configuration
     *
     * @param array $field The field configuration
     * @return mixed The generated value
     */
    public function generateFakeValue(array $field): mixed
    {
        $type = $field['type'] ?? 'text';
        $fieldName = $field['name'] ?? '';
        $faker = $this->getLocaleFaker();

        if (in_array($type, ['date_picker', 'date_time_picker', 'time_picker'])) {
            error_log('[WPFaker DATE DEBUG] AbstractFieldPluginAdapter::generateFakeValue called for date type=' . $type . ' fieldName=' . $fieldName);
        }

        // For text-based fields, try smart field name detection first
        if (in_array($type, ['text', 'textarea', 'number', 'range'])) {
            $smartValue = $this->fieldDetector->detectAndGenerate($fieldName, $field, $this->locale);
            if ($smartValue !== null) {
                // Convert to appropriate type if needed
                if ($type === 'number' || $type === 'range') {
                    return is_numeric($smartValue) ? $smartValue : null;
                }
                return $smartValue;
            }
        }

        return match ($type) {
            'text' => $faker->sentence(rand(3, 8)),
            'textarea' => implode("\n\n", $faker->paragraphs(rand(2, 4))),
            'number' => $this->generateNumber($field),
            'range' => $this->generateRange($field),
            'email' => $faker->safeEmail(),
            'url' => $faker->url(),
            'password' => $faker->password(8, 16),
            'wysiwyg' => $this->generateWysiwyg($field),
            'oembed' => $this->generateOembed(),
            'image' => $this->generateImageId($field),
            'file' => $this->generateFileId($field),
            'gallery' => $this->generateGallery($field),
            'select' => $this->generateSelect($field),
            'checkbox' => $this->generateCheckbox($field),
            'radio' => $this->generateRadio($field),
            'button_group' => $this->generateButtonGroup($field),
            'true_false' => (int) $faker->boolean(),
            'link' => $this->generateLink(),
            'page_link' => $this->generatePageLink(),
            'post_object' => $this->generatePostObject($field),
            'relationship' => $this->generateRelationship($field),
            'taxonomy' => $this->generateTaxonomy($field),
            'user' => $this->generateUser(),
            'google_map' => $this->generateGoogleMap(),
            'date_picker' => $this->generateSmartDate($fieldName, $field['return_format'] ?? 'Y-m-d'),
            'date_time_picker' => $this->generateSmartDate($fieldName, $field['return_format'] ?? 'Y-m-d H:i:s'),
            'time_picker' => $faker->time($field['return_format'] ?? 'H:i:s'),
            'color_picker' => $faker->hexColor(),
            'repeater' => $this->generateRepeater($field),
            'flexible_content' => $this->generateFlexibleContent($field),
            'group' => $this->generateGroup($field),
            default => $faker->sentence(),
        };
    }

    /**
     * Generate a smart date value with field-name-aware ranges.
     * Avoids FakerPHP's default -30 year range by using context from the field name.
     */
    protected function generateSmartDate(string $fieldName, string $format): string
    {
        $fn = strtolower($fieldName);
        $rangeStart = '-1 year';
        $rangeEnd = 'now';

        // Future dates: warranty, expires, until, deadline, due, valid, renewal
        if (preg_match('/(warranty|garantie|expires?|expir|until|bis|deadline|fällig|due|valid|gültig|renewal|verlängerung|support_until|trial)/', $fn)) {
            $rangeStart = '+1 month';
            $rangeEnd = '+5 years';
        }
        // Recent past dates: registration, created, signup, joined, purchased, bought
        elseif (preg_match('/(registration|registrier|anmeld|created|erstell|signup|joined|beigetr|purchased|gekauft|bought|acquired|erworben)/', $fn)) {
            $rangeStart = '-3 years';
            $rangeEnd = '-1 month';
        }
        // Publication/release dates: published, released, launched
        elseif (preg_match('/(publish|veröffentlich|released?|erschienen|launch|gestartet)/', $fn)) {
            $rangeStart = '-2 years';
            $rangeEnd = 'now';
        }
        // Birthday/birth dates
        elseif (preg_match('/(birth|geburt|dob|born|geboren)/', $fn)) {
            $rangeStart = '-65 years';
            $rangeEnd = '-18 years';
        }
        // Start dates
        elseif (preg_match('/(start|beginn|anfang|von|from)/', $fn)) {
            $rangeStart = '-1 year';
            $rangeEnd = '+3 months';
        }
        // End dates
        elseif (preg_match('/(end|ende|schluss|to)/', $fn)) {
            $rangeStart = '+1 month';
            $rangeEnd = '+2 years';
        }
        // Listing dates
        elseif (preg_match('/(listing|inserat|anzeige|eingestellt|gelistet)/', $fn)) {
            $rangeStart = '-6 months';
            $rangeEnd = 'now';
        }
        // Catch-all: any field with "date" or "datum" in name defaults to recent
        elseif (preg_match('/(date|datum)/', $fn)) {
            $rangeStart = '-2 years';
            $rangeEnd = 'now';
        }

        $startTimestamp = strtotime($rangeStart) ?: strtotime('-1 year');
        $endTimestamp = strtotime($rangeEnd) ?: time();

        return date($format, rand($startTimestamp, $endTimestamp));
    }

    /**
     * Generate a number value with field-name-aware ranges
     *
     * When a field has no custom constraints (empty or default min/max),
     * uses the field name to determine a realistic range (e.g. "doors" → 2-5).
     */
    protected function generateNumber(array $field): int|float
    {
        $faker = $this->getLocaleFaker();
        $fieldName = $field['name'] ?? '';
        $prefix = $field['prefix'] ?? $field['prepend'] ?? '';
        $suffix = $field['suffix'] ?? $field['append'] ?? '';

        // Check if the field has meaningful custom constraints
        $minVal = $field['min'] ?? null;
        $maxVal = $field['max'] ?? null;
        $hasCustomConstraints = (
            $minVal !== null && $minVal !== '' && is_numeric($minVal) &&
            $maxVal !== null && $maxVal !== '' && is_numeric($maxVal) &&
            !((int) $minVal === 0 && (int) $maxVal >= 1000)
        );

        if (!$hasCustomConstraints) {
            // Priority 1: prefix/suffix unit detection (highest confidence)
            $unitRange = $this->detectUnitRange((string) $prefix, (string) $suffix);
            if ($unitRange !== null) {
                if (($unitRange['decimals'] ?? 0) > 0) {
                    return $faker->randomFloat($unitRange['decimals'], $unitRange['min'], $unitRange['max']);
                }
                return $faker->numberBetween($unitRange['min'], $unitRange['max']);
            }

            // Priority 2: Hive API for unknown prefix/suffix combos
            if ($prefix !== '' || $suffix !== '') {
                $hive = new \WPFaker\Services\HiveService();
                $hiveRange = $hive->queryNumberRange(
                    (string) $prefix,
                    (string) $suffix,
                    $fieldName,
                    $this->fieldDetector->getCptSlug() ?? ''
                );
                if ($hiveRange !== null) {
                    if (($hiveRange['decimals'] ?? 0) > 0) {
                        return $faker->randomFloat($hiveRange['decimals'], $hiveRange['min'], $hiveRange['max']);
                    }
                    return $faker->numberBetween($hiveRange['min'], $hiveRange['max']);
                }
            }

            // Priority 3: field name pattern detection
            if ($fieldName) {
                $smartRange = $this->detectSmartNumberRange($fieldName);
                if ($smartRange !== null) {
                    return $faker->numberBetween($smartRange['min'], $smartRange['max']);
                }
            }
        }

        $min = (int) ($field['min'] ?? 0);
        $max = (int) ($field['max'] ?? 1000);
        $step = (float) ($field['step'] ?? 1);

        if ($step === 1.0) {
            return $faker->numberBetween($min, $max);
        }

        return round($faker->randomFloat(2, $min, $max) / $step) * $step;
    }

    /**
     * Unit-based number range patterns.
     *
     * Each entry: [prefix_regex|null, suffix_regex|null, ['min' => int, 'max' => int, 'decimals' => int]]
     * Checked in order — first match wins. More specific patterns (currency + million)
     * must come before generic ones (plain currency).
     */
    protected const UNIT_RANGE_PATTERNS = [
        // === CURRENCY + SCALE MODIFIER (must come first — more specific) ===
        ['/[\$€£¥₹₩₪₽₴₺₿]|CHF|kr|R\$/i', '/mrd\.?|billion|bln|\bb$/i', ['min' => 1, 'max' => 100, 'decimals' => 1]],
        ['/[\$€£¥₹₩₪₽₴₺₿]|CHF|kr|R\$/i', '/mio\.?|million|mln|\bm$/i', ['min' => 1, 'max' => 500, 'decimals' => 1]],
        ['/[\$€£¥₹₩₪₽₴₺₿]|CHF|kr|R\$/i', '/k$|tsd\.?|thousand/i', ['min' => 1, 'max' => 999, 'decimals' => 0]],

        // === PLAIN CURRENCY (no scale modifier) ===
        ['/[\$€£¥₹₩₪₽₴₺₿]|CHF|kr|R\$/i', null, ['min' => 1, 'max' => 9999, 'decimals' => 2]],

        // === PERCENTAGE ===
        [null, '/%|prozent|percent|pourcent|porcentaje/i', ['min' => 0, 'max' => 100, 'decimals' => 1]],

        // === WEIGHT ===
        [null, '/\bkg\b|kilogram/i', ['min' => 1, 'max' => 200, 'decimals' => 1]],
        [null, '/\bg\b(?!B)|gram/i', ['min' => 1, 'max' => 1000, 'decimals' => 0]],
        [null, '/\blbs?\b|pounds?/i', ['min' => 1, 'max' => 400, 'decimals' => 1]],
        [null, '/\bt\b|tonnes?|tons?/i', ['min' => 1, 'max' => 50, 'decimals' => 1]],

        // === DISTANCE / LENGTH ===
        [null, '/\bkm\b(?!\/)|kilometer/i', ['min' => 1, 'max' => 500, 'decimals' => 0]],
        [null, '/\bm\b(?!²|2|B|Hz|ph)|meter\b/i', ['min' => 1, 'max' => 100, 'decimals' => 1]],
        [null, '/\bcm\b|centimeter/i', ['min' => 1, 'max' => 200, 'decimals' => 0]],
        [null, '/\bmm\b|millimeter/i', ['min' => 1, 'max' => 999, 'decimals' => 0]],
        [null, '/\bmi\b|miles?\b/i', ['min' => 1, 'max' => 300, 'decimals' => 0]],
        [null, '/\bft\b|feet|foot/i', ['min' => 1, 'max' => 100, 'decimals' => 0]],
        [null, '/\bin\b|inch|zoll/i', ['min' => 1, 'max' => 72, 'decimals' => 0]],

        // === AREA ===
        [null, '/m²|m2|sqm|quadratmeter/i', ['min' => 20, 'max' => 500, 'decimals' => 0]],
        [null, '/ft²|sqft|sq\s*ft/i', ['min' => 200, 'max' => 5000, 'decimals' => 0]],
        [null, '/\bha\b|hektar|hectare/i', ['min' => 1, 'max' => 100, 'decimals' => 1]],
        [null, '/\bacres?\b/i', ['min' => 1, 'max' => 200, 'decimals' => 1]],

        // === VOLUME ===
        [null, '/\bl\b|liter|litre/i', ['min' => 1, 'max' => 100, 'decimals' => 1]],
        [null, '/\bml\b|milliliter/i', ['min' => 1, 'max' => 1000, 'decimals' => 0]],
        [null, '/\bgal\b|gallon/i', ['min' => 1, 'max' => 50, 'decimals' => 1]],

        // === TEMPERATURE ===
        [null, '/°[CF]|celsius|fahrenheit/i', ['min' => -10, 'max' => 40, 'decimals' => 1]],

        // === SPEED (before time — "km/h" must not match the "h" time pattern) ===
        [null, '/km\/h|kmh/i', ['min' => 30, 'max' => 250, 'decimals' => 0]],
        [null, '/mph|mi\/h/i', ['min' => 20, 'max' => 150, 'decimals' => 0]],

        // === RATES (before time — "/month" must not match the "months?" time pattern) ===
        [null, '/\/month|\/monat|\/mois|pro\s*monat/i', ['min' => 10, 'max' => 5000, 'decimals' => 2]],
        [null, '/\/year|\/jahr|\/an\b|pro\s*jahr/i', ['min' => 100, 'max' => 100000, 'decimals' => 2]],
        [null, '/\/hour|\/stunde|\/heure|pro\s*stunde/i', ['min' => 10, 'max' => 500, 'decimals' => 2]],

        // === TIME ===
        [null, '/\bmin\b|minutes?|minuten?/i', ['min' => 1, 'max' => 180, 'decimals' => 0]],
        [null, '/\bh\b|hours?|stunden?|heures?/i', ['min' => 1, 'max' => 48, 'decimals' => 0]],
        [null, '/\bdays?\b|tage?\b/i', ['min' => 1, 'max' => 30, 'decimals' => 0]],
        [null, '/\bweeks?\b|wochen?\b/i', ['min' => 1, 'max' => 52, 'decimals' => 0]],
        [null, '/\bmonths?\b|monate?\b|mois\b/i', ['min' => 1, 'max' => 24, 'decimals' => 0]],
        [null, '/\byears?\b|jahre?\b|ans?\b|años?\b/i', ['min' => 1, 'max' => 30, 'decimals' => 0]],

        // === COMPUTING ===
        [null, '/\bGB\b|gigabyte/i', ['min' => 1, 'max' => 2000, 'decimals' => 0]],
        [null, '/\bMB\b|megabyte/i', ['min' => 1, 'max' => 1024, 'decimals' => 0]],
        [null, '/\bTB\b|terabyte/i', ['min' => 1, 'max' => 16, 'decimals' => 0]],
        [null, '/\bGHz\b|gigahertz/i', ['min' => 1, 'max' => 6, 'decimals' => 1]],

        // === ENERGY / POWER ===
        [null, '/\bkW\b|kilowatt/i', ['min' => 1, 'max' => 500, 'decimals' => 0]],
        [null, '/\bkWh\b/i', ['min' => 1, 'max' => 100, 'decimals' => 1]],
        [null, '/\bPS\b|\bHP\b|horse\s*power|pferdestärke/i', ['min' => 60, 'max' => 500, 'decimals' => 0]],

        // === FOOD / NUTRITION ===
        [null, '/\bkcal\b|calories?|kalorien?/i', ['min' => 50, 'max' => 800, 'decimals' => 0]],
        [null, '/\bkJ\b|kilojoule/i', ['min' => 200, 'max' => 3500, 'decimals' => 0]],
    ];

    /**
     * Detect a realistic number range from prefix/suffix unit signals.
     *
     * @param string $prefix The field's prepend/prefix value (e.g. "$", "€")
     * @param string $suffix The field's append/suffix value (e.g. "kg", "%", "Mio.")
     * @return array|null ['min' => int, 'max' => int, 'decimals' => int] or null
     */
    protected function detectUnitRange(string $prefix, string $suffix): ?array
    {
        return static::detectUnitRangeStatic($prefix, $suffix);
    }

    /**
     * Static wrapper for detectUnitRange(), usable from FieldAssignmentService.
     */
    public static function detectUnitRangeStatic(string $prefix, string $suffix): ?array
    {
        $prefix = trim($prefix);
        $suffix = trim($suffix);

        if ($prefix === '' && $suffix === '') {
            return null;
        }

        foreach (static::UNIT_RANGE_PATTERNS as [$prefixPattern, $suffixPattern, $range]) {
            $prefixMatches = ($prefixPattern === null)
                || ($prefix !== '' && preg_match($prefixPattern, $prefix));
            $suffixMatches = ($suffixPattern === null)
                || ($suffix !== '' && preg_match($suffixPattern, $suffix));

            // Both must match. If a pattern has null for prefix, any prefix (including empty) is fine.
            // But at least one of prefix/suffix must actually be non-empty (guaranteed above).
            if ($prefixMatches && $suffixMatches) {
                // For patterns with both prefix and suffix regex: both must be non-empty
                if ($prefixPattern !== null && $suffixPattern !== null) {
                    if ($prefix === '' || $suffix === '') {
                        continue;
                    }
                }
                return $range;
            }
        }

        return null;
    }

    /**
     * Detect a smart number range from a field name.
     *
     * Returns ['min' => int, 'max' => int] if matched, null otherwise.
     * Mirrors the patterns in FieldAssignmentService::generateNumberField().
     */
    protected function detectSmartNumberRange(string $fieldName): ?array
    {
        $fn = strtolower($fieldName);

        // Price fields: realistic price ranges
        if (preg_match('/(price|preis|cost|kosten|betrag|amount|fee|gebühr)/', $fn)) {
            return ['min' => 500, 'max' => 75000];
        }
        // Percentage fields
        if (preg_match('/(percent|prozent|rate|anteil|ratio)/', $fn)) {
            return ['min' => 0, 'max' => 100];
        }
        // Door count
        if (preg_match('/(doors?|türen?)/', $fn)) {
            return ['min' => 2, 'max' => 5];
        }
        // Seat/seating count
        if (preg_match('/(seats?|sitz|seating|plätze|passagier|passenger)/', $fn)) {
            return ['min' => 2, 'max' => 7];
        }
        // Owner count / previous owners
        if (preg_match('/(owner|besitzer|vorbesitzer|previous)/', $fn)) {
            return ['min' => 0, 'max' => 4];
        }
        // Mileage / kilometers
        if (preg_match('/(mileage|kilomet|km_stand|laufleistung|miles)/', $fn)) {
            return ['min' => 5000, 'max' => 200000];
        }
        // Year fields
        if (preg_match('/(year|jahr|baujahr|model_year|modelljahr)/', $fn)) {
            return ['min' => 2015, 'max' => (int) date('Y')];
        }
        // Weight in kg
        if (preg_match('/(weight|gewicht|kg|mass)/', $fn)) {
            return ['min' => 800, 'max' => 3000];
        }
        // HP / Power
        if (preg_match('/(horse.*power|hp|ps|leistung|kw|power)/', $fn)) {
            return ['min' => 60, 'max' => 500];
        }
        // Capacity / displacement (engine)
        if (preg_match('/(displacement|hubraum|ccm|liter|capacity|engine.*size)/', $fn)) {
            return ['min' => 800, 'max' => 5000];
        }
        // Quantity / count (small numbers)
        if (preg_match('/(count|anzahl|quantity|menge|stück|number_of|num_)/', $fn)) {
            return ['min' => 1, 'max' => 10];
        }
        // Rating / score
        if (preg_match('/(rating|bewertung|score|stars?|sterne)/', $fn)) {
            return ['min' => 1, 'max' => 5];
        }
        // Rooms
        if (preg_match('/(rooms?|zimmer|räume)/', $fn)) {
            return ['min' => 1, 'max' => 10];
        }
        // Floor / story
        if (preg_match('/(floor|etage|stockwerk)/', $fn)) {
            return ['min' => -2, 'max' => 30];
        }

        return null;
    }

    /**
     * Generate a range value
     */
    protected function generateRange(array $field): int
    {
        $faker = $this->getLocaleFaker();
        $min = (int) ($field['min'] ?? 0);
        $max = (int) ($field['max'] ?? 100);
        return $faker->numberBetween($min, $max);
    }

    /**
     * Generate WYSIWYG content
     */
    protected function generateWysiwyg(array $field): string
    {
        $faker = $this->getLocaleFaker();
        $paragraphs = [];

        for ($i = 0; $i < rand(3, 6); $i++) {
            $paragraphs[] = '<p>' . $faker->paragraph(rand(3, 6)) . '</p>';
        }

        // Add some headings
        if (rand(0, 1)) {
            array_splice($paragraphs, 1, 0, '<h2>' . $faker->sentence(rand(3, 6)) . '</h2>');
        }

        // Add a list sometimes
        if (rand(0, 1)) {
            $listItems = array_map(
                fn($item) => '<li>' . $item . '</li>',
                $faker->sentences(rand(3, 5))
            );
            $paragraphs[] = '<ul>' . implode('', $listItems) . '</ul>';
        }

        return implode("\n", $paragraphs);
    }

    /**
     * Generate an oEmbed URL
     */
    protected function generateOembed(): string
    {
        $videos = [
            'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
            'https://vimeo.com/148751763',
            'https://www.youtube.com/watch?v=jNQXAC9IVRw',
        ];
        return $videos[array_rand($videos)];
    }

    /**
     * Generate an image attachment ID
     */
    protected function generateImageId(array $field = []): int
    {
        // Check if this is a logo field
        $fieldName = $field['name'] ?? '';
        if (!empty($fieldName) && FieldNameDetector::isLogoField($fieldName)) {
            $seed = $this->getLogoSeed();
            $logoId = LogoService::generateLogo($seed);
            if ($logoId > 0) {
                return $logoId;
            }
        }

        // Fallback: existing random image behavior
        $attachments = get_posts([
            'post_type'      => 'attachment',
            'post_mime_type' => 'image',
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ]);

        if (empty($attachments)) {
            return 0;
        }

        return $attachments[array_rand($attachments)];
    }

    /**
     * Generate a seed string for logo generation based on context.
     */
    protected function getLogoSeed(): string
    {
        $faker = $this->getLocaleFaker();
        return $faker->company();
    }

    /**
     * Generate a file attachment ID
     *
     * @param array $field Optional field configuration to determine file type
     */
    protected function generateFileId(array $field = []): int
    {
        // Determine file type from field configuration
        $mimeTypes = $field['mime_types'] ?? '';
        $fileType = 'pdf'; // default

        if (!empty($mimeTypes)) {
            $types = array_map('trim', explode(',', $mimeTypes));
            // Pick a random allowed type
            $allowedTypes = array_intersect($types, $this->fileService->getSupportedTypes());
            if (!empty($allowedTypes)) {
                $fileType = $allowedTypes[array_rand($allowedTypes)];
            }
        }

        // Try to get or generate a fake file
        $fakeFileId = $this->fileService->getFakeFile($fileType);
        if ($fakeFileId > 0) {
            return $fakeFileId;
        }

        // Fallback: find any existing attachment
        $attachments = get_posts([
            'post_type'      => 'attachment',
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ]);

        if (empty($attachments)) {
            return 0;
        }

        return $attachments[array_rand($attachments)];
    }

    /**
     * Generate gallery (array of image IDs)
     */
    protected function generateGallery(array $field): array
    {
        $min = (int) ($field['min'] ?? 1);
        $max = (int) ($field['max'] ?? 5);
        $count = rand($min, $max);

        $attachments = get_posts([
            'post_type'      => 'attachment',
            'post_mime_type' => 'image',
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ]);

        if (empty($attachments)) {
            return [];
        }

        shuffle($attachments);
        return array_slice($attachments, 0, min($count, count($attachments)));
    }

    /**
     * Generate select value
     */
    protected function generateSelect(array $field): string|array
    {
        $choices = $field['choices'] ?? [];

        if (empty($choices)) {
            return '';
        }

        $keys = array_keys($choices);

        if (!empty($field['multiple'])) {
            $count = rand(1, min(3, count($keys)));
            shuffle($keys);
            return array_slice($keys, 0, $count);
        }

        return $keys[array_rand($keys)];
    }

    /**
     * Generate checkbox values
     */
    protected function generateCheckbox(array $field): array
    {
        $choices = $field['choices'] ?? [];

        if (empty($choices)) {
            return [];
        }

        $keys = array_keys($choices);
        $count = rand(1, min(3, count($keys)));
        shuffle($keys);

        return array_slice($keys, 0, $count);
    }

    /**
     * Generate radio value
     */
    protected function generateRadio(array $field): string
    {
        $choices = $field['choices'] ?? [];

        if (empty($choices)) {
            return '';
        }

        $keys = array_keys($choices);
        return $keys[array_rand($keys)];
    }

    /**
     * Generate button group value
     */
    protected function generateButtonGroup(array $field): string
    {
        return $this->generateRadio($field);
    }

    /**
     * Generate link value
     */
    protected function generateLink(): array
    {
        $faker = $this->getLocaleFaker();

        return [
            'title'  => $faker->sentence(rand(2, 4)),
            'url'    => $faker->url(),
            'target' => rand(0, 1) ? '_blank' : '',
        ];
    }

    /**
     * Generate page link value
     */
    protected function generatePageLink(): int|array
    {
        $pages = get_posts([
            'post_type'      => 'page',
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ]);

        if (empty($pages)) {
            return 0;
        }

        return $pages[array_rand($pages)];
    }

    /**
     * Generate post object value
     */
    protected function generatePostObject(array $field): int|array
    {
        $postTypes = $field['post_type'] ?? ['post'];

        if (!is_array($postTypes)) {
            $postTypes = [$postTypes];
        }

        $posts = get_posts([
            'post_type'      => $postTypes,
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ]);

        if (empty($posts)) {
            return 0;
        }

        if (!empty($field['multiple'])) {
            $count = rand(1, min(3, count($posts)));
            shuffle($posts);
            return array_slice($posts, 0, $count);
        }

        return $posts[array_rand($posts)];
    }

    /**
     * Generate relationship value
     */
    protected function generateRelationship(array $field): array
    {
        $postTypes = $field['post_type'] ?? ['post'];
        $min = (int) ($field['min'] ?? 1);
        $max = (int) ($field['max'] ?? 5);

        if (!is_array($postTypes)) {
            $postTypes = [$postTypes];
        }

        $posts = get_posts([
            'post_type'      => $postTypes,
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ]);

        if (empty($posts)) {
            return [];
        }

        $count = rand($min, min($max, count($posts)));
        shuffle($posts);

        return array_slice($posts, 0, $count);
    }

    /**
     * Generate taxonomy value using 3-layer constraint pipeline:
     * Layer 1: Explicit plugin constraints (getTaxonomyConstraints)
     * Layer 2: Taxonomy semantics heuristic
     * Layer 3: Existing fallback logic
     */
    protected function generateTaxonomy(array $field): int|array
    {
        $taxonomy = $field['taxonomy'] ?? 'category';

        $terms = get_terms([
            'taxonomy'   => $taxonomy,
            'hide_empty' => false,
            'fields'     => 'ids',
            'number'     => 50,
        ]);

        if (is_wp_error($terms) || empty($terms)) {
            return 0;
        }

        // Layer 1: Explicit plugin constraints
        $constraints = $this->getTaxonomyConstraints($field);

        if (!empty($constraints)) {
            return $this->applyTaxonomyConstraints($terms, $constraints);
        }

        // Layer 2: Taxonomy semantics heuristic
        $heuristic = $this->inferTaxonomyHeuristic($taxonomy, count($terms));

        if (!empty($heuristic)) {
            return $this->applyTaxonomyConstraints($terms, $heuristic);
        }

        // Layer 3: Existing fallback
        if (!empty($field['multiple']) || ($field['field_type'] ?? '') === 'multi_select' || ($field['field_type'] ?? '') === 'checkbox') {
            $count = rand(1, min(3, count($terms)));
            shuffle($terms);
            return array_slice($terms, 0, $count);
        }

        return $terms[array_rand($terms)];
    }

    /**
     * Get taxonomy assignment constraints from plugin field config.
     * Override in adapter subclasses.
     *
     * @param array $field Normalized field config
     * @return array ['mode' => 'single'|'multiple', 'min' => int, 'max' => int|null] or []
     */
    public function getTaxonomyConstraints(array $field): array
    {
        return [];
    }

    /**
     * Infer taxonomy assignment behavior from taxonomy properties.
     *
     * @param string $taxonomy Taxonomy name
     * @param int $termCount Number of available terms
     * @return array Constraint array or [] if no heuristic applies
     */
    protected function inferTaxonomyHeuristic(string $taxonomy, int $termCount): array
    {
        $taxObj = get_taxonomy($taxonomy);
        if (!$taxObj) {
            return [];
        }

        $isHierarchical = $taxObj->hierarchical;

        // Hierarchical + few terms → categorical (single)
        if ($isHierarchical && $termCount <= 15) {
            return ['mode' => 'single', 'min' => 1, 'max' => 1];
        }

        // Non-hierarchical → tagging (multiple, max 3-5)
        if (!$isHierarchical) {
            return ['mode' => 'multiple', 'min' => 1, 'max' => min(5, $termCount)];
        }

        // Hierarchical + many terms → multiple, max 2-3
        if ($isHierarchical && $termCount > 15) {
            return ['mode' => 'multiple', 'min' => 1, 'max' => min(3, $termCount)];
        }

        return [];
    }

    /**
     * Apply taxonomy constraints to select terms.
     *
     * @param array $terms Available term IDs
     * @param array $constraints ['mode', 'min', 'max']
     * @return int|array Single term ID or array of term IDs
     */
    protected function applyTaxonomyConstraints(array $terms, array $constraints): int|array
    {
        $mode = $constraints['mode'] ?? 'single';
        $min = $constraints['min'] ?? 1;
        $max = $constraints['max'] ?? null;

        if ($mode === 'single') {
            return $terms[array_rand($terms)];
        }

        // Multiple mode
        $effectiveMax = $max !== null ? min($max, count($terms)) : min(5, count($terms));
        $effectiveMin = min($min, count($terms));
        $count = rand($effectiveMin, $effectiveMax);

        shuffle($terms);
        return array_slice($terms, 0, $count);
    }

    /**
     * Generate user value
     */
    protected function generateUser(): int
    {
        $users = get_users([
            'fields' => 'ID',
            'number' => 50,
        ]);

        if (empty($users)) {
            return get_current_user_id();
        }

        return $users[array_rand($users)];
    }

    /**
     * Generate Google Map value
     */
    protected function generateGoogleMap(): array
    {
        $faker = $this->getLocaleFaker();

        return [
            'address' => $faker->address(),
            'lat'     => $faker->latitude(),
            'lng'     => $faker->longitude(),
        ];
    }

    /**
     * Generate repeater value (for ACF Pro)
     */
    protected function generateRepeater(array $field): array
    {
        $min = (int) ($field['min'] ?? 0);
        $max = (int) ($field['max'] ?? 0);
        // ACF uses 0 to mean "no limit" — apply sensible defaults
        if ($min <= 0) { $min = 1; }
        if ($max <= 0) { $max = 3; }
        $count = rand($min, $max);
        $subFields = $field['sub_fields'] ?? [];
        $rows = [];

        for ($i = 0; $i < $count; $i++) {
            $row = [];
            foreach ($subFields as $subField) {
                $row[$subField['name']] = $this->generateFakeValue($subField);
            }
            $rows[] = $row;
        }

        return $rows;
    }

    /**
     * Generate flexible content value (for ACF Pro)
     */
    protected function generateFlexibleContent(array $field): array
    {
        $min = (int) ($field['min'] ?? 0);
        $max = (int) ($field['max'] ?? 0);
        // ACF uses 0 to mean "no limit" — apply sensible defaults
        if ($min <= 0) { $min = 1; }
        if ($max <= 0) { $max = 3; }
        $count = rand($min, $max);
        $layouts = $field['layouts'] ?? [];
        $rows = [];

        if (empty($layouts)) {
            return [];
        }

        for ($i = 0; $i < $count; $i++) {
            $layout = $layouts[array_rand($layouts)];
            $row = ['acf_fc_layout' => $layout['name']];

            foreach ($layout['sub_fields'] ?? [] as $subField) {
                $row[$subField['name']] = $this->generateFakeValue($subField);
            }

            $rows[] = $row;
        }

        return $rows;
    }

    /**
     * Generate group value
     */
    protected function generateGroup(array $field): ?array
    {
        $subFields = $field['sub_fields'] ?? [];
        $values = [];

        foreach ($subFields as $subField) {
            $values[$subField['name']] = $this->generateFakeValue($subField);
        }

        return $values ?: null;
    }
}
