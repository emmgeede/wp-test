<?php

namespace WPFaker\Adapters;

use WPFaker\Services\FakerService;

/**
 * JetEngine Adapter
 *
 * Adapter for JetEngine plugin by Crocoblock.
 * Handles detection and generation of fake data for JetEngine meta field types.
 */
class JetEngineAdapter extends AbstractFieldPluginAdapter
{
    /**
     * Plugin file path for activation check
     */
    protected const PLUGIN_FILE = 'jet-engine/jet-engine.php';

    /**
     * JetEngine specific field type mapping
     *
     * @var array
     */
    protected array $jetEngineFieldTypeMap = [
        'text'           => 'sentence',
        'textarea'       => 'paragraphs',
        'number'         => 'randomNumber',
        'email'          => 'safeEmail',
        'url'            => 'url',
        'password'       => 'password',
        'wysiwyg'        => 'paragraphs',
        'media'          => 'imageUrl',
        'gallery'        => 'imageUrl',
        'select'         => 'randomElement',
        'checkbox'       => 'randomElements',
        'radio'          => 'randomElement',
        'switcher'       => 'boolean',
        'date'           => 'date',
        'time'           => 'time',
        'datetime'       => 'dateTime',
        'datetime-local' => 'dateTime',
        'colorpicker'    => 'hexColor',
        'iconpicker'     => 'randomElement',
        'posts'          => 'randomNumber',
        'repeater'       => 'repeaterData',
        'range'          => 'numberBetween',
        'hidden'         => 'sentence',
        'html'           => 'paragraphs',
    ];

    /**
     * Layout field types that should be skipped
     *
     * @var array
     */
    protected array $layoutFieldTypes = ['tab', 'accordion', 'endpoint', 'html'];

    /**
     * Constructor
     *
     * @param FakerService|null $faker
     */
    public function __construct(?FakerService $faker = null)
    {
        parent::__construct($faker);
        // Merge JetEngine types with default mapping
        $this->defaultFieldTypeMap = array_merge($this->defaultFieldTypeMap, $this->jetEngineFieldTypeMap);
    }

    /**
     * Check if JetEngine is active
     *
     * @return bool
     */
    public function isActive(): bool
    {
        return function_exists('jet_engine') || class_exists('Jet_Engine');
    }

    /**
     * Get the plugin name
     *
     * @return string
     */
    public function getName(): string
    {
        return 'JetEngine';
    }

    /**
     * Get the plugin version
     *
     * @return string
     */
    public function getVersion(): string
    {
        if (defined('JET_ENGINE_VERSION')) {
            return JET_ENGINE_VERSION;
        }

        return '0.0.0';
    }

    /**
     * Get all custom post types registered by JetEngine
     *
     * @return array
     */
    public function getCustomPostTypes(): array
    {
        if ($this->cachedPostTypes !== null) {
            return $this->cachedPostTypes;
        }

        if (!$this->isActive()) {
            return [];
        }

        // JetEngine stores CPTs in options
        $cptItems = get_option('jet_engine_post_types', []);

        $this->cachedPostTypes = [];

        foreach ($cptItems as $cpt) {
            $args = $cpt['args'] ?? [];
            $this->cachedPostTypes[] = [
                'id'        => $cpt['id'] ?? '',
                'slug'      => $cpt['slug'] ?? '',
                'name'      => $args['name'] ?? $cpt['slug'] ?? '',
                'labels'    => $args['labels'] ?? [],
            ];
        }

        return $this->cachedPostTypes;
    }

    /**
     * Get all custom taxonomies registered by JetEngine
     *
     * @return array
     */
    public function getCustomTaxonomies(): array
    {
        if ($this->cachedTaxonomies !== null) {
            return $this->cachedTaxonomies;
        }

        if (!$this->isActive()) {
            return [];
        }

        // JetEngine stores taxonomies in options
        $taxItems = get_option('jet_engine_taxonomies', []);

        $this->cachedTaxonomies = [];

        foreach ($taxItems as $tax) {
            $args = $tax['args'] ?? [];
            $this->cachedTaxonomies[] = [
                'id'       => $tax['id'] ?? '',
                'slug'     => $tax['slug'] ?? '',
                'name'     => $args['name'] ?? $tax['slug'] ?? '',
                'labels'   => $args['labels'] ?? [],
            ];
        }

        return $this->cachedTaxonomies;
    }

    /**
     * Get all field groups (meta boxes)
     *
     * @return array
     */
    public function getFieldGroups(): array
    {
        if ($this->cachedFieldGroups !== null) {
            return $this->cachedFieldGroups;
        }

        if (!$this->isActive()) {
            return [];
        }

        // JetEngine stores meta boxes in wp_options
        $metaBoxes = get_option('jet_engine_meta_boxes', []);

        $this->cachedFieldGroups = [];

        foreach ($metaBoxes as $key => $metaBox) {
            $args = $metaBox['args'] ?? [];
            $this->cachedFieldGroups[] = [
                'id'                 => $key,
                'title'              => $args['name'] ?? $key,
                'object_type'        => $args['object_type'] ?? 'post',
                'allowed_post_type'  => $args['allowed_post_type'] ?? [],
                'allowed_tax'        => $args['allowed_tax'] ?? [],
                'meta_fields'        => $metaBox['meta_fields'] ?? [],
            ];
        }

        return $this->cachedFieldGroups;
    }

    /**
     * Get field groups for a specific post type
     *
     * @param string $postType The post type slug
     * @return array
     */
    public function getFieldGroupsForPostType(string $postType): array
    {
        $allGroups = $this->getFieldGroups();
        $matchingGroups = [];

        foreach ($allGroups as $group) {
            // Check if this is a post meta box
            if ($group['object_type'] !== 'post') {
                continue;
            }

            // Check if this meta box applies to the post type
            $allowedPostTypes = $group['allowed_post_type'] ?? [];

            if (in_array($postType, $allowedPostTypes)) {
                $matchingGroups[] = $group;
            }
        }

        return $matchingGroups;
    }

    /**
     * Get fields from a field group
     *
     * @param int|string $fieldGroupId The field group ID or key
     * @return array
     */
    public function getFields($fieldGroupId): array
    {
        $allGroups = $this->getFieldGroups();

        foreach ($allGroups as $group) {
            if ($group['id'] === $fieldGroupId) {
                return $this->filterFields($group['meta_fields'] ?? []);
            }
        }

        return [];
    }

    /**
     * Get all fields for a specific post type
     *
     * @param string $postType The post type slug
     * @return array
     */
    public function getFieldsForPostType(string $postType): array
    {
        $fieldGroups = $this->getFieldGroupsForPostType($postType);
        $allFields = [];

        foreach ($fieldGroups as $fieldGroup) {
            $fields = $this->filterFields($fieldGroup['meta_fields'] ?? []);
            $allFields = array_merge($allFields, $this->flattenFields($fields));
        }

        // Deduplicate by field name (keep first occurrence)
        $seen = [];
        $unique = [];
        foreach ($allFields as $field) {
            $name = $field['name'] ?? '';
            if ($name !== '' && !isset($seen[$name])) {
                $seen[$name] = true;
                $unique[] = $field;
            }
        }

        return $unique;
    }

    /**
     * Filter out layout fields (tabs, accordions, etc.)
     *
     * @param array $fields
     * @return array
     */
    protected function filterFields(array $fields): array
    {
        return array_filter($fields, function ($field) {
            $objectType = $field['object_type'] ?? 'field';
            $type = $field['type'] ?? '';

            // Only include actual fields, not layout elements
            return $objectType === 'field' && !in_array($type, $this->layoutFieldTypes);
        });
    }

    /**
     * Flatten nested fields (from repeaters) into a single array
     *
     * @param array $fields
     * @return array
     */
    protected function flattenFields(array $fields): array
    {
        $flattened = [];

        foreach ($fields as $field) {
            // Normalize field structure for WPfaker
            $normalizedField = $this->normalizeField($field);
            $flattened[] = $normalizedField;

            // Include sub-fields for repeaters
            if (!empty($field['repeater-fields'])) {
                foreach ($field['repeater-fields'] as $subField) {
                    $subField['parent_field'] = $field['name'];
                    $flattened[] = $this->normalizeField($subField);
                }
            }
        }

        return $flattened;
    }

    /**
     * Normalize JetEngine field structure to match WPfaker expectations
     *
     * @param array $field
     * @return array
     */
    protected function normalizeField(array $field): array
    {
        $normalized = [
            'name'        => $field['name'] ?? '',
            'type'        => $field['type'] ?? 'text',
            'label'       => $field['title'] ?? $field['name'] ?? '',
            'description' => $field['description'] ?? '',
            'required'    => !empty($field['is_required']),
            'default'     => $field['default_val'] ?? '',
        ];

        // Map JetEngine-specific properties

        // Options for select, radio, checkbox
        if (!empty($field['options'])) {
            $normalized['choices'] = $this->normalizeOptions($field['options']);
        }

        // Multiple selection
        if (!empty($field['is_multiple'])) {
            $normalized['multiple'] = true;
        }

        // Array output for checkboxes
        if (!empty($field['is_array'])) {
            $normalized['is_array'] = true;
        }

        // Number/Range min/max
        if (isset($field['min_value'])) {
            $normalized['min'] = $field['min_value'];
        }
        if (isset($field['max_value'])) {
            $normalized['max'] = $field['max_value'];
        }
        if (isset($field['step_value'])) {
            $normalized['step'] = $field['step_value'];
        }

        // Date timestamp conversion
        if (!empty($field['is_timestamp'])) {
            $normalized['is_timestamp'] = true;
        }

        // Media value format (id, url, both)
        if (!empty($field['value_format'])) {
            $normalized['value_format'] = $field['value_format'];
        }

        // Repeater fields
        if (!empty($field['repeater-fields'])) {
            $normalized['sub_fields'] = array_map(
                fn($f) => $this->normalizeField($f),
                $field['repeater-fields']
            );
        }

        // Posts field - search post type
        if (!empty($field['search_post_type'])) {
            $normalized['post_type'] = $field['search_post_type'];
        }

        // Iconpicker library
        if (!empty($field['iconpicker_library'])) {
            $normalized['iconpicker_library'] = $field['iconpicker_library'];
        }

        // Save original JetEngine field for reference
        $normalized['_jetengine_field'] = $field;

        return $normalized;
    }

    /**
     * Normalize JetEngine options format to standard choices format
     *
     * @param array $options
     * @return array
     */
    protected function normalizeOptions(array $options): array
    {
        $choices = [];

        foreach ($options as $option) {
            if (is_array($option)) {
                $value = $option['value'] ?? $option['key'] ?? '';
                $label = $option['label'] ?? $value;
                $choices[$value] = $label;
            } else {
                // Simple value
                $choices[$option] = $option;
            }
        }

        return $choices;
    }

    /**
     * Save a field value for a post
     *
     * @param int $postId The post ID
     * @param string $fieldName The field name/key
     * @param mixed $value The value to save
     * @return bool
     */
    public function saveFieldValue(int $postId, string $fieldName, $value): bool
    {
        // JetEngine uses standard WordPress post meta
        $result = update_post_meta($postId, $fieldName, $value);
        return $result !== false;
    }

    /**
     * Get field configuration by name or key
     *
     * @param string $fieldNameOrKey The field name or key
     * @return array|null
     */
    public function getFieldConfig(string $fieldNameOrKey): ?array
    {
        $allGroups = $this->getFieldGroups();

        foreach ($allGroups as $group) {
            foreach ($group['meta_fields'] ?? [] as $field) {
                if (($field['name'] ?? '') === $fieldNameOrKey) {
                    return $this->normalizeField($field);
                }
            }
        }

        return null;
    }

    /**
     * Generate a fake value based on JetEngine field configuration
     *
     * @param array $field The field configuration
     * @return mixed The generated value
     */
    public function generateFakeValue(array $field): mixed
    {
        $type = $field['type'] ?? 'text';
        $fieldName = $field['name'] ?? '';
        $faker = $this->getLocaleFaker();

        // For text-based fields, try smart field name detection first
        if (in_array($type, ['text', 'textarea', 'number', 'range'])) {
            $smartValue = $this->fieldDetector->detectAndGenerate($fieldName, $field, $this->locale);
            if ($smartValue !== null) {
                if ($type === 'number' || $type === 'range') {
                    return is_numeric($smartValue) ? $smartValue : null;
                }
                return $smartValue;
            }
        }

        return match ($type) {
            'text' => $faker->sentence(rand(3, 8)),
            'textarea' => implode("\n\n", $faker->paragraphs(rand(2, 4))),
            'number' => $this->generateNumber($field),
            'range' => $this->generateRange($field),
            'email' => $faker->safeEmail(),
            'url' => $faker->url(),
            'password' => $faker->password(8, 16),
            'wysiwyg' => $this->generateWysiwyg($field),
            'media' => $this->generateMedia($field),
            'gallery' => $this->generateGallery($field),
            'select' => $this->generateJetEngineSelect($field),
            'checkbox', 'checkbox-raw' => $this->generateJetEngineCheckbox($field),
            'radio' => $this->generateJetEngineRadio($field),
            'switcher' => (int) $faker->boolean(),
            'date' => $this->generateDate($field),
            'time' => $faker->time('H:i'),
            'datetime', 'datetime-local' => $this->generateDateTime($field),
            'colorpicker' => $faker->hexColor(),
            'iconpicker' => $this->generateIconPicker($field),
            'posts' => $this->generatePostsField($field),
            'repeater' => $this->generateJetEngineRepeater($field),
            'hidden' => $field['default'] ?? $faker->word(),
            default => $faker->sentence(),
        };
    }

    /**
     * Generate media field value
     */
    protected function generateMedia(array $field): int|string|array
    {
        $valueFormat = $field['value_format'] ?? 'id';
        $imageId = $this->generateImageId($field);

        if ($imageId === 0) {
            return $valueFormat === 'id' ? 0 : '';
        }

        return match ($valueFormat) {
            'url' => wp_get_attachment_url($imageId) ?: '',
            'both' => [
                'id'  => $imageId,
                'url' => wp_get_attachment_url($imageId) ?: '',
            ],
            default => $imageId, // 'id' format
        };
    }

    /**
     * Get choices from field (supports both normalized 'choices' and JetEngine 'options')
     */
    protected function getFieldChoices(array $field): array
    {
        // First check normalized choices
        if (!empty($field['choices'])) {
            return $field['choices'];
        }

        // Then check JetEngine options format
        if (!empty($field['options'])) {
            return $this->normalizeOptions($field['options']);
        }

        return [];
    }

    /**
     * Generate JetEngine select value
     */
    protected function generateJetEngineSelect(array $field): string|array
    {
        $choices = $this->getFieldChoices($field);

        if (empty($choices)) {
            return '';
        }

        $keys = array_keys($choices);
        $isMultiple = !empty($field['multiple']) || !empty($field['is_multiple']);

        if ($isMultiple) {
            $count = rand(1, min(3, count($keys)));
            shuffle($keys);
            return array_slice($keys, 0, $count);
        }

        return $keys[array_rand($keys)];
    }

    /**
     * Generate JetEngine checkbox values
     */
    protected function generateJetEngineCheckbox(array $field): array|string
    {
        $choices = $this->getFieldChoices($field);

        if (empty($choices)) {
            return !empty($field['is_array']) ? [] : '';
        }

        $keys = array_keys($choices);
        $count = rand(1, min(3, count($keys)));
        shuffle($keys);

        $selected = array_slice($keys, 0, $count);

        // Return as comma-separated string if not array mode
        if (empty($field['is_array'])) {
            return implode(',', $selected);
        }

        return $selected;
    }

    /**
     * Generate JetEngine radio value
     */
    protected function generateJetEngineRadio(array $field): string
    {
        $choices = $this->getFieldChoices($field);

        if (empty($choices)) {
            return '';
        }

        $keys = array_keys($choices);
        return $keys[array_rand($keys)];
    }

    /**
     * Generate date value with optional timestamp
     */
    protected function generateDate(array $field): string|int
    {
        $fieldName = $field['name'] ?? '';
        $date = $this->generateSmartDate($fieldName, 'Y-m-d');

        if (!empty($field['is_timestamp'])) {
            return strtotime($date);
        }

        return $date;
    }

    /**
     * Generate datetime value with optional timestamp
     */
    protected function generateDateTime(array $field): string|int
    {
        $fieldName = $field['name'] ?? '';
        $datetime = $this->generateSmartDate($fieldName, 'Y-m-d H:i:s');

        if (!empty($field['is_timestamp'])) {
            return strtotime($datetime);
        }

        return $datetime;
    }

    /**
     * Generate icon picker value
     */
    protected function generateIconPicker(array $field): string
    {
        $library = $field['iconpicker_library'] ?? 'dashicons';

        // Common icons per library
        $icons = match ($library) {
            'dashicons' => [
                'dashicons-admin-home',
                'dashicons-admin-users',
                'dashicons-admin-settings',
                'dashicons-calendar',
                'dashicons-email',
                'dashicons-heart',
                'dashicons-star-filled',
                'dashicons-flag',
                'dashicons-location',
                'dashicons-phone',
            ],
            'fontawesome' => [
                'fa fa-home',
                'fa fa-user',
                'fa fa-cog',
                'fa fa-calendar',
                'fa fa-envelope',
                'fa fa-heart',
                'fa fa-star',
                'fa fa-flag',
                'fa fa-map-marker',
                'fa fa-phone',
            ],
            default => ['icon-default'],
        };

        return $icons[array_rand($icons)];
    }

    /**
     * Generate posts field value (post ID or array of IDs)
     */
    protected function generatePostsField(array $field): int|array
    {
        // JetEngine uses 'search_post_type', ACF uses 'post_type'
        $postType = $field['search_post_type'] ?? $field['post_type'] ?? 'post';

        if (!is_array($postType)) {
            $postType = [$postType];
        }

        $queryArgs = [
            'post_type'      => $postType,
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ];

        // Exclude current post to prevent self-reference
        if (!empty($field['exclude_post_id'])) {
            $queryArgs['post__not_in'] = [$field['exclude_post_id']];
        }

        $posts = get_posts($queryArgs);

        if (empty($posts)) {
            return 0;
        }

        // JetEngine uses 'is_multiple', ACF uses 'multiple'
        $isMultiple = !empty($field['is_multiple']) || !empty($field['multiple']);

        if ($isMultiple) {
            $count = rand(1, min(3, count($posts)));
            shuffle($posts);
            return array_slice($posts, 0, $count);
        }

        return $posts[array_rand($posts)];
    }

    /**
     * Generate JetEngine repeater value
     */
    protected function generateJetEngineRepeater(array $field): array
    {
        $min = (int) ($field['min'] ?? 1);
        $max = (int) ($field['max'] ?? 3);
        $count = rand($min, $max);
        $subFields = $field['sub_fields'] ?? [];
        $rows = [];

        for ($i = 0; $i < $count; $i++) {
            $row = [];
            foreach ($subFields as $subField) {
                $row[$subField['name']] = $this->generateFakeValue($subField);
            }
            $rows[] = $row;
        }

        return $rows;
    }

    /**
     * Get taxonomy assignment constraints from JetEngine field config.
     *
     * JetEngine handles taxonomies through its Relations system, not through
     * individual field types. Always returns empty (no taxonomy field constraints).
     *
     * @param array $field Normalized field config
     * @return array Always empty — JetEngine has no taxonomy field type
     */
    public function getTaxonomyConstraints(array $field): array
    {
        return [];
    }

    /**
     * Get supported field types
     *
     * @return array
     */
    public function getSupportedFieldTypes(): array
    {
        return array_keys($this->jetEngineFieldTypeMap);
    }

    // =========================================================================
    // JetEngine Relations Support
    // =========================================================================

    /**
     * Get all JetEngine Relations
     *
     * @return array Array of relation configurations
     */
    public function getRelations(): array
    {
        if (!$this->isActive() || !function_exists('jet_engine')) {
            return [];
        }

        $relationsComponent = jet_engine()->relations ?? null;
        if (!$relationsComponent) {
            return [];
        }

        $activeRelations = $relationsComponent->get_active_relations();
        if (empty($activeRelations)) {
            return [];
        }

        $relations = [];
        foreach ($activeRelations as $relId => $relation) {
            $relations[$relId] = [
                'id'            => $relId,
                'name'          => $relation->get_args('name') ?? $relId,
                'type'          => $relation->get_args('type') ?? 'one_to_many',
                'parent_object' => $relation->get_args('parent_object'),
                'child_object'  => $relation->get_args('child_object'),
                'meta_fields'   => $relation->get_args('meta_fields') ?? [],
                '_relation'     => $relation, // Keep reference to the relation object
            ];
        }

        return $relations;
    }

    /**
     * Get relations for a specific post type
     *
     * Returns relations where this post type is either parent or child.
     *
     * @param string $postType The post type slug
     * @return array Array of relation configurations with role indicator
     */
    public function getRelationsForPostType(string $postType): array
    {
        $allRelations = $this->getRelations();
        $matchingRelations = [];

        $postTypeIdentifier = 'posts::' . $postType;

        foreach ($allRelations as $relId => $relation) {
            $parentObject = $relation['parent_object'] ?? '';
            $childObject = $relation['child_object'] ?? '';

            // Check if this post type is the parent
            if ($parentObject === $postTypeIdentifier) {
                $relation['role'] = 'parent';
                $relation['related_object'] = $childObject;
                $matchingRelations[$relId] = $relation;
            }
            // Check if this post type is the child
            elseif ($childObject === $postTypeIdentifier) {
                $relation['role'] = 'child';
                $relation['related_object'] = $parentObject;
                $matchingRelations[$relId] = $relation;
            }
        }

        return $matchingRelations;
    }

    /**
     * Create a relation between two posts
     *
     * @param string $relationId The relation ID
     * @param int $parentId The parent post ID
     * @param int $childId The child post ID
     * @param array $meta Optional meta data for the relation
     * @return bool Success status
     */
    public function createRelation(string $relationId, int $parentId, int $childId, array $meta = []): bool
    {
        if (!$this->isActive() || !function_exists('jet_engine')) {
            return false;
        }

        $relationsComponent = jet_engine()->relations ?? null;
        if (!$relationsComponent) {
            return false;
        }

        $relation = $relationsComponent->get_active_relations($relationId);
        if (!$relation) {
            return false;
        }

        // Create the relationship
        $relation->update($parentId, $childId);

        // Add meta if provided
        if (!empty($meta)) {
            $relation->update_all_meta($meta, $parentId, $childId);
        }

        return true;
    }

    /**
     * Populate relations for a post
     *
     * Automatically creates relations with other existing posts.
     * When batch post IDs are provided, uses batch-aware generation:
     * - Without variation: full interconnection (all batch posts)
     * - With variation: random subset of batch posts
     *
     * @param int $postId The post ID
     * @param string $postType The post type
     * @param int|null $excludePostId Post ID to exclude (to prevent self-reference)
     * @param array $batchPostIds Other post IDs from the current batch
     * @param bool $useVariation Whether to randomize relations
     * @return array Array of created relations
     */
    public function populateRelationsForPost(
        int $postId,
        string $postType,
        ?int $excludePostId = null,
        array $batchPostIds = [],
        bool $useVariation = false,
        array $relatedPostPool = []
    ): array {
        $relations = $this->getRelationsForPostType($postType);
        $createdRelations = [];

        foreach ($relations as $relId => $relation) {
            $role = $relation['role'];
            $relationType = $relation['type'] ?? 'one_to_many';
            $relatedObject = $relation['related_object'] ?? '';
            $relationObj = $relation['_relation'] ?? null;

            if (!$relationObj) {
                continue;
            }

            // Parse the related object to get post type
            // Format: "posts::post_type" or "terms::taxonomy"
            if (!str_starts_with($relatedObject, 'posts::')) {
                continue; // Only support post relations for now
            }

            $relatedPostType = str_replace('posts::', '', $relatedObject);

            // Cross-CPT: use related post pool if the target is a different post type
            if ($relatedPostType !== $postType && !empty($relatedPostPool[$relatedPostType])) {
                $availablePoolPosts = $relatedPostPool[$relatedPostType];

                if (!$useVariation) {
                    $selectedPosts = $availablePoolPosts;
                } else {
                    $maxCount = count($availablePoolPosts);
                    $relationCount = match ($relationType) {
                        'one_to_one' => 1,
                        'one_to_many' => rand(1, min(3, $maxCount)),
                        'many_to_many' => rand(1, min(3, $maxCount)),
                        default => 1,
                    };
                    shuffle($availablePoolPosts);
                    $selectedPosts = array_slice($availablePoolPosts, 0, $relationCount);
                }

                foreach ($selectedPosts as $relatedPostId) {
                    if ($role === 'parent') {
                        $this->createRelation($relId, $postId, $relatedPostId);
                        $createdRelations[] = [
                            'relation_id' => $relId,
                            'parent_id'   => $postId,
                            'child_id'    => $relatedPostId,
                        ];
                    } else {
                        $this->createRelation($relId, $relatedPostId, $postId);
                        $createdRelations[] = [
                            'relation_id' => $relId,
                            'parent_id'   => $relatedPostId,
                            'child_id'    => $postId,
                        ];
                    }
                }
                continue;
            }

            // Batch-aware generation: use batch post IDs if available
            if (!empty($batchPostIds)) {
                // Filter batch IDs: exclude current post
                $availableBatchPosts = array_values(array_diff($batchPostIds, [$postId]));

                if (empty($availableBatchPosts)) {
                    continue;
                }

                if (!$useVariation) {
                    // Full interconnection: use all batch posts
                    $selectedPosts = $availableBatchPosts;
                } else {
                    // Random subset based on relation type
                    $maxCount = count($availableBatchPosts);
                    $relationCount = match ($relationType) {
                        'one_to_one' => 1,
                        'one_to_many' => rand(1, $maxCount),
                        'many_to_many' => rand(1, $maxCount),
                        default => 1,
                    };
                    shuffle($availableBatchPosts);
                    $selectedPosts = array_slice($availableBatchPosts, 0, $relationCount);
                }
            } else {
                // Fallback: existing get_posts() logic for non-batch cases
                $queryArgs = [
                    'post_type'      => $relatedPostType,
                    'posts_per_page' => 50,
                    'fields'         => 'ids',
                    'post_status'    => 'any',
                ];

                // Exclude current post and optionally another post
                $excludeIds = [$postId];
                if ($excludePostId) {
                    $excludeIds[] = $excludePostId;
                }
                $queryArgs['post__not_in'] = $excludeIds;

                $availablePosts = get_posts($queryArgs);

                if (empty($availablePosts)) {
                    continue;
                }

                // Determine how many relations to create based on relation type
                $relationCount = match ($relationType) {
                    'one_to_one' => 1,
                    'one_to_many' => rand(1, min(3, count($availablePosts))),
                    'many_to_many' => rand(1, min(3, count($availablePosts))),
                    default => 1,
                };

                shuffle($availablePosts);
                $selectedPosts = array_slice($availablePosts, 0, $relationCount);
            }

            foreach ($selectedPosts as $relatedPostId) {
                // Create relation based on role
                if ($role === 'parent') {
                    $this->createRelation($relId, $postId, $relatedPostId);
                    $createdRelations[] = [
                        'relation_id' => $relId,
                        'parent_id'   => $postId,
                        'child_id'    => $relatedPostId,
                    ];
                } else {
                    $this->createRelation($relId, $relatedPostId, $postId);
                    $createdRelations[] = [
                        'relation_id' => $relId,
                        'parent_id'   => $relatedPostId,
                        'child_id'    => $postId,
                    ];
                }
            }
        }

        return $createdRelations;
    }

    /**
     * Delete all relations for a post
     *
     * @param int $postId The post ID
     * @param string $postType The post type
     * @return int Number of relations deleted
     */
    public function deleteRelationsForPost(int $postId, string $postType): int
    {
        $relations = $this->getRelationsForPostType($postType);
        $deletedCount = 0;

        foreach ($relations as $relation) {
            $relationObj = $relation['_relation'] ?? null;
            if (!$relationObj) {
                continue;
            }

            $role = $relation['role'];

            // Delete relations where this post is either parent or child
            if ($role === 'parent') {
                $relationObj->delete_rows($postId, false);
            } else {
                $relationObj->delete_rows(false, $postId);
            }

            $deletedCount++;
        }

        return $deletedCount;
    }

    // =========================================================================
    // JetEngine Options Pages Support
    // =========================================================================

    /**
     * Get all JetEngine Options Pages
     *
     * @return array Array of options page configurations
     */
    public function getOptionsPages(): array
    {
        if (!$this->isActive() || !function_exists('jet_engine')) {
            return [];
        }

        $optionsPagesComponent = jet_engine()->options_pages ?? null;
        if (!$optionsPagesComponent || !$optionsPagesComponent->data) {
            return [];
        }

        $items = $optionsPagesComponent->data->get_items();
        if (empty($items)) {
            return [];
        }

        $pages = [];
        foreach ($items as $item) {
            $labels = maybe_unserialize($item['labels'] ?? '');
            $args = maybe_unserialize($item['args'] ?? '');
            $metaFields = maybe_unserialize($item['meta_fields'] ?? '');

            $pages[$item['slug']] = [
                'id'           => $item['id'] ?? '',
                'slug'         => $item['slug'] ?? '',
                'name'         => $labels['name'] ?? $item['slug'],
                'labels'       => $labels,
                'args'         => $args,
                'storage_type' => $args['storage_type'] ?? 'default',
                'meta_fields'  => $metaFields,
            ];
        }

        return $pages;
    }

    /**
     * Get fields for an options page
     *
     * @param string $pageSlug The options page slug
     * @return array Array of field configurations
     */
    public function getOptionsPageFields(string $pageSlug): array
    {
        $pages = $this->getOptionsPages();

        if (!isset($pages[$pageSlug])) {
            return [];
        }

        $metaFields = $pages[$pageSlug]['meta_fields'] ?? [];
        $normalizedFields = [];

        foreach ($metaFields as $field) {
            // Skip non-field elements (tabs, html, endpoints)
            $element = $field['element'] ?? 'control';
            if ($element !== 'control' && $element !== 'field') {
                continue;
            }

            $type = $field['type'] ?? 'text';
            if (in_array($type, $this->layoutFieldTypes, true)) {
                continue;
            }

            $normalizedFields[] = $this->normalizeField($field);
        }

        return $normalizedFields;
    }

    /**
     * Get an options page value
     *
     * @param string $pageSlug The options page slug
     * @param string $fieldName The field name
     * @param mixed $default Default value if not found
     * @return mixed The field value
     */
    public function getOptionsPageValue(string $pageSlug, string $fieldName, $default = null)
    {
        if (!$this->isActive() || !function_exists('jet_engine')) {
            return $default;
        }

        $optionsPagesComponent = jet_engine()->options_pages ?? null;
        if (!$optionsPagesComponent) {
            return $default;
        }

        $page = $optionsPagesComponent->registered_pages[$pageSlug] ?? null;
        if (!$page) {
            return $default;
        }

        $value = $page->get($fieldName);
        return $value !== false ? $value : $default;
    }

    /**
     * Set an options page value
     *
     * @param string $pageSlug The options page slug
     * @param string $fieldName The field name
     * @param mixed $value The value to set
     * @return bool Success status
     */
    public function setOptionsPageValue(string $pageSlug, string $fieldName, $value): bool
    {
        if (!$this->isActive() || !function_exists('jet_engine')) {
            return false;
        }

        $optionsPagesComponent = jet_engine()->options_pages ?? null;
        if (!$optionsPagesComponent) {
            return false;
        }

        $page = $optionsPagesComponent->registered_pages[$pageSlug] ?? null;
        if (!$page) {
            return false;
        }

        $page->update_options([$fieldName => $value], false, true);
        return true;
    }

    /**
     * Set multiple options page values at once
     *
     * @param string $pageSlug The options page slug
     * @param array $values Array of field_name => value pairs
     * @param bool $rewrite Whether to completely replace existing values
     * @return bool Success status
     */
    public function setOptionsPageValues(string $pageSlug, array $values, bool $rewrite = false): bool
    {
        if (!$this->isActive() || !function_exists('jet_engine')) {
            return false;
        }

        $optionsPagesComponent = jet_engine()->options_pages ?? null;
        if (!$optionsPagesComponent) {
            return false;
        }

        $page = $optionsPagesComponent->registered_pages[$pageSlug] ?? null;
        if (!$page) {
            return false;
        }

        $page->update_options($values, $rewrite, true);
        return true;
    }

    /**
     * Populate all fields in an options page with fake data
     *
     * @param string $pageSlug The options page slug
     * @return array Generated values
     */
    public function populateOptionsPage(string $pageSlug): array
    {
        $fields = $this->getOptionsPageFields($pageSlug);
        if (empty($fields)) {
            return [];
        }

        $generatedValues = [];

        foreach ($fields as $field) {
            $fieldName = $field['name'] ?? '';
            if (empty($fieldName)) {
                continue;
            }

            $value = $this->generateFakeValue($field);
            if ($value !== null) {
                $generatedValues[$fieldName] = $value;
            }
        }

        if (!empty($generatedValues)) {
            $this->setOptionsPageValues($pageSlug, $generatedValues, false);
        }

        return $generatedValues;
    }

    /**
     * Clear all values from an options page
     *
     * @param string $pageSlug The options page slug
     * @return bool Success status
     */
    public function clearOptionsPage(string $pageSlug): bool
    {
        $fields = $this->getOptionsPageFields($pageSlug);
        if (empty($fields)) {
            return false;
        }

        $emptyValues = [];
        foreach ($fields as $field) {
            $fieldName = $field['name'] ?? '';
            if (empty($fieldName)) {
                continue;
            }

            $type = $field['type'] ?? 'text';

            // Set appropriate empty value based on field type
            $emptyValues[$fieldName] = match ($type) {
                'checkbox', 'gallery', 'repeater' => [],
                'number', 'range' => 0,
                'switcher' => false,
                default => '',
            };
        }

        return $this->setOptionsPageValues($pageSlug, $emptyValues, true);
    }
}
