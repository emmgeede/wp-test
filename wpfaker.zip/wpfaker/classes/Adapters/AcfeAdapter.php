<?php

namespace WPFaker\Adapters;

/**
 * ACF Extended Adapter
 *
 * Adapter for ACF Extended (ACFE).
 * Extends the ACF Pro adapter with ACFE-specific field types.
 *
 * @see https://www.acf-extended.com/
 */
class AcfeAdapter extends AcfProAdapter
{
    /**
     * Check if ACF Extended is active
     *
     * @return bool
     */
    public function isActive(): bool
    {
        // ACFE requires ACF Pro, so check both
        if (!parent::isActive()) {
            return false;
        }

        // Check for ACFE class or constant
        return class_exists('ACFE') || defined('ACFE_VERSION');
    }

    /**
     * Check if ACF Extended Pro is active
     *
     * @return bool
     */
    public function isProActive(): bool
    {
        return class_exists('ACFE_Pro') || defined('ACFE_PRO');
    }

    /**
     * Get the plugin name
     *
     * @return string
     */
    public function getName(): string
    {
        if ($this->isProActive()) {
            return 'ACF Extended Pro';
        }

        return 'ACF Extended';
    }

    /**
     * Get the plugin version
     *
     * @return string
     */
    public function getVersion(): string
    {
        if (defined('ACFE_VERSION')) {
            return ACFE_VERSION;
        }

        return '0.0.0';
    }

    /**
     * Save field value with ACFE-specific handling
     *
     * Some ACFE field types store data as sub-field meta keys (e.g., date_range_picker
     * saves {field}_start and {field}_end). This override ensures proper persistence.
     *
     * @param int $postId
     * @param string $fieldName Field key or name
     * @param mixed $value
     * @return bool
     */
    public function saveFieldValue(int $postId, string $fieldName, $value): bool
    {
        if (!$this->isActive() || !function_exists('update_field')) {
            return false;
        }

        $field = acf_get_field($fieldName);
        $type = $field['type'] ?? '';

        // Date range picker: ACFE stores start/end in separate meta keys
        // The update_value() handler expects "Ymd-Ymd" string format
        if ($type === 'acfe_date_range_picker' && is_string($value)) {
            return update_field($fieldName, $value, $postId) !== false;
        }

        // Address: pass array through — ACFE's update_value() handles serialization
        if ($type === 'acfe_address' && is_array($value)) {
            return update_field($fieldName, $value, $postId) !== false;
        }

        // Payment fields: bypass ACFE's update_value() which expects encrypted data
        // from a real Stripe/PayPal transaction. Save sub-keys directly to post meta.
        if (in_array($type, ['acfe_payment', 'acfe_payment_cart']) && is_array($value)) {
            $subFields = ['id', 'gateway', 'amount', 'currency', 'items', 'date', 'ip', 'mode', 'object'];
            foreach ($subFields as $subKey) {
                $subValue = $value[$subKey] ?? '';
                $metaKey = "{$field['name']}_{$subKey}";
                update_post_meta($postId, $metaKey, $subValue);
                update_post_meta($postId, "_{$metaKey}", $field['key']);
            }
            update_post_meta($postId, $field['name'], '');
            update_post_meta($postId, "_{$field['name']}", $field['key']);
            return true;
        }

        return parent::saveFieldValue($postId, $fieldName, $value);
    }

    /**
     * Get ACFE supported field types
     *
     * @return array
     */
    public function getSupportedFieldTypes(): array
    {
        // Get ACF Pro field types
        $baseTypes = parent::getSupportedFieldTypes();

        // Add ACFE-specific field types
        $acfeTypes = [
            // ACFE Basic Fields
            'acfe_advanced_link',
            'acfe_code_editor',
            'acfe_slug',
            'acfe_hidden',

            // ACFE Choice Fields
            'acfe_image_selector',
            'acfe_button',

            // ACFE Date Fields
            'acfe_date_range_picker',

            // ACFE Selector Fields
            'acfe_countries',
            'acfe_currencies',
            'acfe_languages',
            'acfe_menus',
            'acfe_menu_locations',
            'acfe_post_formats',
            'acfe_post_statuses',
            'acfe_post_types',
            'acfe_taxonomies',
            'acfe_user_roles',
            'acfe_options_pages',
            'acfe_templates',
            'acfe_field_groups',
            'acfe_fields',
            'acfe_post_type_archive',
            'acfe_taxonomy_terms',
            'acfe_block_types',

            // ACFE Layout Fields
            'acfe_column',
            'acfe_dynamic_render',
            'acfe_recaptcha',
            'acfe_forms',

            // ACFE Pro Fields
            'acfe_address',
            'acfe_phone_number',
            'acfe_block_editor',
            'acfe_field_types',
            'acfe_image_sizes',
            'acfe_post_field',
            'acfe_payment',
            'acfe_payment_cart',
            'acfe_payment_selector',
        ];

        return array_merge($baseTypes, $acfeTypes);
    }

    /**
     * Generate fake value for ACFE specific fields
     *
     * @param array $field The field configuration
     * @return mixed
     */
    public function generateFakeValue(array $field): mixed
    {
        $type = $field['type'] ?? 'text';
        $faker = $this->getLocaleFaker();

        // ACFE field types - support both prefixed and non-prefixed versions
        return match ($type) {
            // Basic Fields
            'acfe_advanced_link', 'advanced_link' => $this->generateAdvancedLink(),
            'acfe_code_editor', 'code_editor' => $this->generateCodeEditor($field),
            'acfe_slug', 'slug' => $faker->slug(rand(2, 4)),
            'acfe_hidden', 'hidden' => $faker->sentence(rand(2, 5)),

            // Choice Fields
            'acfe_image_selector', 'image_selector' => $this->generateImageSelector($field),
            'acfe_button', 'button' => null, // Buttons don't store values

            // Date Fields
            'acfe_date_range_picker', 'date_range_picker' => $this->generateDateRange(),

            // Selector Fields
            'acfe_countries', 'countries' => $this->generateCountries($field),
            'acfe_currencies', 'currencies' => $this->generateCurrencies($field),
            'acfe_languages', 'languages' => $this->generateLanguages($field),
            'acfe_menus', 'menus' => $this->generateMenus($field),
            'acfe_menu_locations', 'menu_locations' => $this->generateMenuLocations($field),
            'acfe_post_formats', 'post_formats' => $this->generatePostFormats($field),
            'acfe_post_statuses', 'post_statuses' => $this->generatePostStatuses($field),
            'acfe_post_types', 'post_types' => $this->generatePostTypes($field),
            'acfe_taxonomies', 'taxonomies' => $this->generateTaxonomiesSelector($field),
            'acfe_user_roles', 'user_roles' => $this->generateUserRoles($field),
            'acfe_options_pages', 'options_pages' => $this->generateOptionsPages($field),
            'acfe_templates', 'templates' => $this->generateTemplates($field),
            'acfe_field_groups', 'field_groups' => $this->generateFieldGroups($field),
            'acfe_fields', 'fields' => $this->generateFields($field),
            'acfe_post_type_archive', 'post_type_archive' => $this->generatePostTypeArchive($field),
            'acfe_taxonomy_terms', 'taxonomy_terms' => $this->generateTaxonomyTermsAcfe($field),
            'acfe_block_types', 'block_types' => $this->generateBlockTypes($field),

            // Layout Fields
            'acfe_column', 'column' => null, // Layout field, no value
            'acfe_dynamic_render', 'dynamic_render' => null, // Render field, no value
            'acfe_recaptcha', 'recaptcha' => '', // reCAPTCHA token (empty for fake)
            'acfe_forms', 'forms' => $this->generateAcfeForms($field),

            // Pro Fields
            'acfe_address', 'address' => $this->generateAddress($field),
            'acfe_phone_number', 'phone_number' => $this->generatePhoneNumber(),
            'acfe_block_editor', 'block_editor' => $this->generateBlockEditor(),
            'acfe_field_types', 'field_types' => $this->generateFieldTypes($field),
            'acfe_image_sizes', 'image_sizes' => $this->generateImageSizes($field),
            'acfe_post_field', 'post_field' => null, // UI-only, maps to native WP fields
            'acfe_payment', 'payment' => $this->generatePayment(),
            'acfe_payment_cart', 'payment_cart' => $this->generatePaymentCart(),
            'acfe_payment_selector', 'payment_selector' => $this->generatePaymentSelector($field),

            default => parent::generateFakeValue($field),
        };
    }

    /**
     * Generate advanced link value
     *
     * ACFE stores advanced links as: {type, value, title, target}
     */
    protected function generateAdvancedLink(): array
    {
        $faker = $this->getLocaleFaker();

        return [
            'type'   => 'url',
            'value'  => $faker->url(),
            'title'  => $faker->sentence(rand(2, 4)),
            'target' => (bool) rand(0, 1),
        ];
    }

    /**
     * Generate code editor value
     */
    protected function generateCodeEditor(array $field): string
    {
        $mode = strtolower($field['mode'] ?? 'html');
        $faker = $this->getLocaleFaker();

        // Normalize mode strings (ACFE uses various formats)
        if (str_contains($mode, 'html')) {
            return '<div class="container">' . "\n" .
                '    <h1>' . $faker->sentence(3) . '</h1>' . "\n" .
                '    <p>' . $faker->paragraph() . '</p>' . "\n" .
                '</div>';
        }

        if (str_contains($mode, 'css')) {
            $className = $faker->word();
            return ".{$className} {\n" .
                "    display: flex;\n" .
                "    max-width: 1200px;\n" .
                "    margin: 0 auto;\n" .
                "    padding: 20px;\n" .
                "    background-color: #f5f5f5;\n" .
                "}";
        }

        if (str_contains($mode, 'javascript') || str_contains($mode, 'js')) {
            $funcName = $faker->word();
            return "function {$funcName}() {\n" .
                "    const items = ['item1', 'item2', 'item3'];\n" .
                "    items.forEach(item => {\n" .
                "        console.log(item);\n" .
                "    });\n" .
                "    return true;\n" .
                "}";
        }

        if (str_contains($mode, 'php')) {
            return "<?php\n" .
                "\$items = [\n" .
                "    '" . $faker->word() . "',\n" .
                "    '" . $faker->word() . "',\n" .
                "];\n\n" .
                "foreach (\$items as \$item) {\n" .
                "    echo \$item;\n" .
                "}";
        }

        // Default: generate HTML-like code
        return '<section class="content">' . "\n" .
            '    <h2>' . $faker->sentence(4) . '</h2>' . "\n" .
            '    <p>' . $faker->sentence() . '</p>' . "\n" .
            '</section>';
    }

    /**
     * Generate image selector value
     */
    protected function generateImageSelector(array $field): string|int
    {
        $choices = $field['choices'] ?? [];

        if (!empty($choices)) {
            $keys = array_keys($choices);
            return $keys[array_rand($keys)];
        }

        // Fallback to image ID
        return $this->generateImageId($field);
    }

    /**
     * Generate date range value
     *
     * ACFE stores date ranges as "Ymd-Ymd" string (e.g., "20240115-20240620").
     * The update_value() handler splits this and saves to {field}_start and {field}_end sub-fields.
     */
    protected function generateDateRange(): string
    {
        $faker = $this->getLocaleFaker();
        $startDate = $faker->dateTimeBetween('-1 year', 'now');
        $endDate = $faker->dateTimeBetween($startDate, '+1 year');

        return $startDate->format('Ymd') . '-' . $endDate->format('Ymd');
    }

    /**
     * Generate countries value
     * ACFE expects lowercase ISO 3166-1 alpha-2 codes (e.g., 'de', 'us', 'fr')
     */
    protected function generateCountries(array $field): string|array
    {
        // ACFE uses lowercase country codes
        $countries = ['de', 'at', 'ch', 'us', 'gb', 'fr', 'it', 'es', 'nl', 'be'];

        if (!empty($field['multiple'])) {
            shuffle($countries);
            return array_slice($countries, 0, rand(1, 3));
        }

        return $countries[array_rand($countries)];
    }

    /**
     * Generate currencies value
     */
    protected function generateCurrencies(array $field): string|array
    {
        $currencies = ['EUR', 'USD', 'GBP', 'CHF', 'JPY', 'CAD', 'AUD'];

        if (!empty($field['multiple'])) {
            shuffle($currencies);
            return array_slice($currencies, 0, rand(1, 3));
        }

        return $currencies[array_rand($currencies)];
    }

    /**
     * Generate languages value
     * ACFE expects locale format codes (e.g., 'de_DE', 'en_US', 'fr_FR')
     */
    protected function generateLanguages(array $field): string|array
    {
        // ACFE uses locale format for languages
        $languages = ['de_DE', 'en_US', 'en_GB', 'fr_FR', 'es_ES', 'it_IT', 'nl_NL', 'pt_BR', 'ru_RU', 'ja_JP', 'zh_CN'];

        if (!empty($field['multiple'])) {
            shuffle($languages);
            return array_slice($languages, 0, rand(1, 3));
        }

        return $languages[array_rand($languages)];
    }

    /**
     * Generate menus value
     * Returns menu term IDs
     */
    protected function generateMenus(array $field): int|array|null
    {
        $menus = wp_get_nav_menus(['fields' => 'ids']);

        if (empty($menus)) {
            // Return null if no menus exist, not 0
            return null;
        }

        if (!empty($field['multiple'])) {
            shuffle($menus);
            return array_slice($menus, 0, min(rand(1, 3), count($menus)));
        }

        return $menus[array_rand($menus)];
    }

    /**
     * Generate menu locations value
     */
    protected function generateMenuLocations(array $field): string|array
    {
        $locations = array_keys(get_registered_nav_menus());

        if (empty($locations)) {
            return '';
        }

        if (!empty($field['multiple'])) {
            shuffle($locations);
            return array_slice($locations, 0, min(rand(1, 2), count($locations)));
        }

        return $locations[array_rand($locations)];
    }

    /**
     * Generate post formats value
     */
    protected function generatePostFormats(array $field): string|array
    {
        $formats = ['standard', 'aside', 'gallery', 'link', 'image', 'quote', 'status', 'video', 'audio', 'chat'];

        if (!empty($field['multiple'])) {
            shuffle($formats);
            return array_slice($formats, 0, rand(1, 3));
        }

        return $formats[array_rand($formats)];
    }

    /**
     * Generate post statuses value
     */
    protected function generatePostStatuses(array $field): string|array
    {
        $statuses = ['publish', 'draft', 'pending', 'private', 'future'];

        if (!empty($field['multiple'])) {
            shuffle($statuses);
            return array_slice($statuses, 0, rand(1, 2));
        }

        return $statuses[array_rand($statuses)];
    }

    /**
     * Generate post types value
     */
    protected function generatePostTypes(array $field): string|array
    {
        $postTypes = get_post_types(['public' => true], 'names');
        $postTypes = array_values($postTypes);

        if (empty($postTypes)) {
            return 'post';
        }

        if (!empty($field['multiple'])) {
            shuffle($postTypes);
            return array_slice($postTypes, 0, min(rand(1, 3), count($postTypes)));
        }

        return $postTypes[array_rand($postTypes)];
    }

    /**
     * Generate taxonomies selector value
     */
    protected function generateTaxonomiesSelector(array $field): string|array
    {
        $taxonomies = get_taxonomies(['public' => true], 'names');
        $taxonomies = array_values($taxonomies);

        if (empty($taxonomies)) {
            return 'category';
        }

        if (!empty($field['multiple'])) {
            shuffle($taxonomies);
            return array_slice($taxonomies, 0, min(rand(1, 3), count($taxonomies)));
        }

        return $taxonomies[array_rand($taxonomies)];
    }

    /**
     * Generate user roles value
     */
    protected function generateUserRoles(array $field): string|array
    {
        $roles = array_keys(wp_roles()->roles);

        if (empty($roles)) {
            return 'subscriber';
        }

        if (!empty($field['multiple'])) {
            shuffle($roles);
            return array_slice($roles, 0, min(rand(1, 2), count($roles)));
        }

        return $roles[array_rand($roles)];
    }

    /**
     * Generate options pages value
     */
    protected function generateOptionsPages(array $field): string|array
    {
        if (!function_exists('acf_get_options_pages')) {
            return '';
        }

        $pages = acf_get_options_pages();
        if (empty($pages)) {
            return '';
        }

        $slugs = array_keys($pages);

        if (!empty($field['multiple'])) {
            shuffle($slugs);
            return array_slice($slugs, 0, min(rand(1, 2), count($slugs)));
        }

        return $slugs[array_rand($slugs)];
    }

    /**
     * Generate templates value
     */
    protected function generateTemplates(array $field): string|array
    {
        $templates = wp_get_theme()->get_page_templates();
        $templates = array_keys($templates);

        // Add default template
        array_unshift($templates, 'default');

        if (!empty($field['multiple'])) {
            shuffle($templates);
            return array_slice($templates, 0, min(rand(1, 2), count($templates)));
        }

        return $templates[array_rand($templates)];
    }

    /**
     * Generate field groups value
     */
    protected function generateFieldGroups(array $field): string|array
    {
        $groups = $this->getFieldGroups();
        if (empty($groups)) {
            return '';
        }

        $keys = array_column($groups, 'key');

        if (!empty($field['multiple'])) {
            shuffle($keys);
            return array_slice($keys, 0, min(rand(1, 3), count($keys)));
        }

        return $keys[array_rand($keys)];
    }

    /**
     * Generate fields value
     */
    protected function generateFields(array $field): string|array
    {
        $groups = $this->getFieldGroups();
        if (empty($groups)) {
            return '';
        }

        $allFieldKeys = [];
        foreach ($groups as $group) {
            $fields = $this->getFields($group['key'] ?? $group['ID']);
            foreach ($fields as $f) {
                if (!empty($f['key'])) {
                    $allFieldKeys[] = $f['key'];
                }
            }
        }

        if (empty($allFieldKeys)) {
            return '';
        }

        if (!empty($field['multiple'])) {
            shuffle($allFieldKeys);
            return array_slice($allFieldKeys, 0, min(rand(1, 3), count($allFieldKeys)));
        }

        return $allFieldKeys[array_rand($allFieldKeys)];
    }

    /**
     * Generate post type archive value
     */
    protected function generatePostTypeArchive(array $field): string|array
    {
        $postTypes = get_post_types(['has_archive' => true], 'names');
        $postTypes = array_values($postTypes);

        if (empty($postTypes)) {
            return '';
        }

        if (!empty($field['multiple'])) {
            shuffle($postTypes);
            return array_slice($postTypes, 0, min(rand(1, 2), count($postTypes)));
        }

        return $postTypes[array_rand($postTypes)];
    }

    /**
     * Generate taxonomy terms (ACFE version)
     */
    protected function generateTaxonomyTermsAcfe(array $field): int|array
    {
        $taxonomy = $field['taxonomy'] ?? 'category';

        $terms = get_terms([
            'taxonomy'   => $taxonomy,
            'hide_empty' => false,
            'fields'     => 'ids',
            'number'     => 50,
        ]);

        if (is_wp_error($terms) || empty($terms)) {
            return [];
        }

        if (!empty($field['multiple'])) {
            shuffle($terms);
            return array_slice($terms, 0, min(rand(1, 5), count($terms)));
        }

        return $terms[array_rand($terms)];
    }

    /**
     * Generate block types value
     */
    protected function generateBlockTypes(array $field): string|array
    {
        $registry = \WP_Block_Type_Registry::get_instance();
        $blocks = array_keys($registry->get_all_registered());

        // Filter to common blocks
        $commonBlocks = array_filter($blocks, fn($b) => str_starts_with($b, 'core/'));

        if (empty($commonBlocks)) {
            $commonBlocks = $blocks;
        }

        if (empty($commonBlocks)) {
            return 'core/paragraph';
        }

        $commonBlocks = array_values($commonBlocks);

        if (!empty($field['multiple'])) {
            shuffle($commonBlocks);
            return array_slice($commonBlocks, 0, min(rand(1, 3), count($commonBlocks)));
        }

        return $commonBlocks[array_rand($commonBlocks)];
    }

    /**
     * Generate ACFE forms value
     */
    protected function generateAcfeForms(array $field): int|array
    {
        // ACFE stores forms as posts
        $forms = get_posts([
            'post_type'      => 'acfe-form',
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ]);

        if (empty($forms)) {
            return 0;
        }

        if (!empty($field['multiple'])) {
            shuffle($forms);
            return array_slice($forms, 0, min(rand(1, 2), count($forms)));
        }

        return $forms[array_rand($forms)];
    }

    /**
     * Generate address value for ACFE Pro Address field
     *
     * ACFE stores the address as a serialized array with geocoding data.
     * Sub-fields are also saved individually ({field}_city, {field}_country, etc.).
     */
    protected function generateAddress(array $field): array
    {
        $faker = $this->getLocaleFaker();

        // Locale-aware address data sets for realistic results
        $addressData = $this->getLocaleAddressData();

        if (!empty($addressData)) {
            $entry = $addressData[array_rand($addressData)];
        } else {
            // Generic fallback
            $entry = [
                'city'          => $faker->city(),
                'state'         => $faker->state ?? $faker->city(),
                'state_short'   => strtoupper(substr($faker->city(), 0, 2)),
                'post_code'     => $faker->postcode(),
                'country'       => 'United States',
                'country_short' => 'US',
                'lat'           => (float) $faker->latitude(25, 48),
                'lng'           => (float) $faker->longitude(-125, -70),
            ];
        }

        $street = $faker->streetAddress();
        $fullAddress = sprintf(
            '%s, %s %s, %s',
            $street,
            $entry['post_code'],
            $entry['city'],
            $entry['country']
        );

        return [
            'address'       => $fullAddress,
            'lat'           => $entry['lat'],
            'lng'           => $entry['lng'],
            'place_id'      => 'ChIJ' . $faker->regexify('[A-Za-z0-9_-]{27}'),
            'name'          => $street,
            'city'          => $entry['city'],
            'state'         => $entry['state'],
            'state_short'   => $entry['state_short'],
            'post_code'     => $entry['post_code'],
            'country'       => $entry['country'],
            'country_short' => $entry['country_short'],
        ];
    }

    /**
     * Get locale-aware address data for realistic address generation
     *
     * @return array
     */
    protected function getLocaleAddressData(): array
    {
        $locale = $this->locale ?? '';
        $lang = strtolower(substr($locale, 0, 2));

        $datasets = [
            'de' => [
                ['city' => 'Berlin', 'state' => 'Berlin', 'state_short' => 'BE', 'post_code' => '10115', 'country' => 'Germany', 'country_short' => 'DE', 'lat' => 52.5200, 'lng' => 13.4050],
                ['city' => 'München', 'state' => 'Bayern', 'state_short' => 'BY', 'post_code' => '80331', 'country' => 'Germany', 'country_short' => 'DE', 'lat' => 48.1351, 'lng' => 11.5820],
                ['city' => 'Hamburg', 'state' => 'Hamburg', 'state_short' => 'HH', 'post_code' => '20095', 'country' => 'Germany', 'country_short' => 'DE', 'lat' => 53.5511, 'lng' => 9.9937],
                ['city' => 'Köln', 'state' => 'Nordrhein-Westfalen', 'state_short' => 'NW', 'post_code' => '50667', 'country' => 'Germany', 'country_short' => 'DE', 'lat' => 50.9375, 'lng' => 6.9603],
                ['city' => 'Frankfurt am Main', 'state' => 'Hessen', 'state_short' => 'HE', 'post_code' => '60311', 'country' => 'Germany', 'country_short' => 'DE', 'lat' => 50.1109, 'lng' => 8.6821],
                ['city' => 'Stuttgart', 'state' => 'Baden-Württemberg', 'state_short' => 'BW', 'post_code' => '70173', 'country' => 'Germany', 'country_short' => 'DE', 'lat' => 48.7758, 'lng' => 9.1829],
                ['city' => 'Düsseldorf', 'state' => 'Nordrhein-Westfalen', 'state_short' => 'NW', 'post_code' => '40213', 'country' => 'Germany', 'country_short' => 'DE', 'lat' => 51.2277, 'lng' => 6.7735],
                ['city' => 'Leipzig', 'state' => 'Sachsen', 'state_short' => 'SN', 'post_code' => '04109', 'country' => 'Germany', 'country_short' => 'DE', 'lat' => 51.3397, 'lng' => 12.3731],
            ],
            'fr' => [
                ['city' => 'Paris', 'state' => 'Île-de-France', 'state_short' => 'IDF', 'post_code' => '75001', 'country' => 'France', 'country_short' => 'FR', 'lat' => 48.8566, 'lng' => 2.3522],
                ['city' => 'Lyon', 'state' => 'Auvergne-Rhône-Alpes', 'state_short' => 'ARA', 'post_code' => '69001', 'country' => 'France', 'country_short' => 'FR', 'lat' => 45.7640, 'lng' => 4.8357],
                ['city' => 'Marseille', 'state' => "Provence-Alpes-Côte d'Azur", 'state_short' => 'PAC', 'post_code' => '13001', 'country' => 'France', 'country_short' => 'FR', 'lat' => 43.2965, 'lng' => 5.3698],
                ['city' => 'Toulouse', 'state' => 'Occitanie', 'state_short' => 'OCC', 'post_code' => '31000', 'country' => 'France', 'country_short' => 'FR', 'lat' => 43.6047, 'lng' => 1.4442],
            ],
            'en' => [
                ['city' => 'New York', 'state' => 'New York', 'state_short' => 'NY', 'post_code' => '10001', 'country' => 'United States', 'country_short' => 'US', 'lat' => 40.7128, 'lng' => -74.0060],
                ['city' => 'Los Angeles', 'state' => 'California', 'state_short' => 'CA', 'post_code' => '90001', 'country' => 'United States', 'country_short' => 'US', 'lat' => 34.0522, 'lng' => -118.2437],
                ['city' => 'Chicago', 'state' => 'Illinois', 'state_short' => 'IL', 'post_code' => '60601', 'country' => 'United States', 'country_short' => 'US', 'lat' => 41.8781, 'lng' => -87.6298],
                ['city' => 'London', 'state' => 'England', 'state_short' => 'ENG', 'post_code' => 'EC1A 1BB', 'country' => 'United Kingdom', 'country_short' => 'GB', 'lat' => 51.5074, 'lng' => -0.1278],
                ['city' => 'San Francisco', 'state' => 'California', 'state_short' => 'CA', 'post_code' => '94102', 'country' => 'United States', 'country_short' => 'US', 'lat' => 37.7749, 'lng' => -122.4194],
                ['city' => 'Austin', 'state' => 'Texas', 'state_short' => 'TX', 'post_code' => '73301', 'country' => 'United States', 'country_short' => 'US', 'lat' => 30.2672, 'lng' => -97.7431],
            ],
            'es' => [
                ['city' => 'Madrid', 'state' => 'Comunidad de Madrid', 'state_short' => 'MD', 'post_code' => '28001', 'country' => 'Spain', 'country_short' => 'ES', 'lat' => 40.4168, 'lng' => -3.7038],
                ['city' => 'Barcelona', 'state' => 'Cataluña', 'state_short' => 'CT', 'post_code' => '08001', 'country' => 'Spain', 'country_short' => 'ES', 'lat' => 41.3851, 'lng' => 2.1734],
                ['city' => 'Valencia', 'state' => 'Comunidad Valenciana', 'state_short' => 'VC', 'post_code' => '46001', 'country' => 'Spain', 'country_short' => 'ES', 'lat' => 39.4699, 'lng' => -0.3763],
            ],
            'it' => [
                ['city' => 'Roma', 'state' => 'Lazio', 'state_short' => 'RM', 'post_code' => '00100', 'country' => 'Italy', 'country_short' => 'IT', 'lat' => 41.9028, 'lng' => 12.4964],
                ['city' => 'Milano', 'state' => 'Lombardia', 'state_short' => 'MI', 'post_code' => '20121', 'country' => 'Italy', 'country_short' => 'IT', 'lat' => 45.4642, 'lng' => 9.1900],
                ['city' => 'Firenze', 'state' => 'Toscana', 'state_short' => 'FI', 'post_code' => '50121', 'country' => 'Italy', 'country_short' => 'IT', 'lat' => 43.7696, 'lng' => 11.2558],
            ],
            'nl' => [
                ['city' => 'Amsterdam', 'state' => 'Noord-Holland', 'state_short' => 'NH', 'post_code' => '1012', 'country' => 'Netherlands', 'country_short' => 'NL', 'lat' => 52.3676, 'lng' => 4.9041],
                ['city' => 'Rotterdam', 'state' => 'Zuid-Holland', 'state_short' => 'ZH', 'post_code' => '3011', 'country' => 'Netherlands', 'country_short' => 'NL', 'lat' => 51.9244, 'lng' => 4.4777],
            ],
            'pt' => [
                ['city' => 'São Paulo', 'state' => 'São Paulo', 'state_short' => 'SP', 'post_code' => '01000-000', 'country' => 'Brazil', 'country_short' => 'BR', 'lat' => -23.5505, 'lng' => -46.6333],
                ['city' => 'Rio de Janeiro', 'state' => 'Rio de Janeiro', 'state_short' => 'RJ', 'post_code' => '20000-000', 'country' => 'Brazil', 'country_short' => 'BR', 'lat' => -22.9068, 'lng' => -43.1729],
            ],
            'ja' => [
                ['city' => 'Tokyo', 'state' => 'Tokyo', 'state_short' => 'TK', 'post_code' => '100-0001', 'country' => 'Japan', 'country_short' => 'JP', 'lat' => 35.6762, 'lng' => 139.6503],
                ['city' => 'Osaka', 'state' => 'Osaka', 'state_short' => 'OS', 'post_code' => '530-0001', 'country' => 'Japan', 'country_short' => 'JP', 'lat' => 34.6937, 'lng' => 135.5023],
            ],
        ];

        // Try exact match, then language prefix, then fall back to 'en'
        return $datasets[$lang] ?? $datasets['en'] ?? [];
    }

    /**
     * Generate ACF field types value
     *
     * ACFE Pro field that lets users select ACF field types (e.g., 'text', 'image', 'repeater').
     */
    protected function generateFieldTypes(array $field): string|array
    {
        $fieldTypes = [
            'text', 'textarea', 'number', 'range', 'email', 'url', 'password',
            'wysiwyg', 'oembed', 'image', 'file', 'gallery',
            'select', 'checkbox', 'radio', 'button_group', 'true_false',
            'link', 'post_object', 'page_link', 'relationship', 'taxonomy', 'user',
            'google_map', 'date_picker', 'date_time_picker', 'time_picker', 'color_picker',
            'repeater', 'flexible_content', 'clone', 'group',
        ];

        if (!empty($field['multiple'])) {
            shuffle($fieldTypes);
            return array_slice($fieldTypes, 0, rand(1, 4));
        }

        return $fieldTypes[array_rand($fieldTypes)];
    }

    /**
     * Generate WordPress image sizes value
     *
     * ACFE Pro field that lets users select registered image sizes.
     */
    protected function generateImageSizes(array $field): string|array
    {
        $sizes = function_exists('wp_get_registered_image_subsizes')
            ? array_keys(wp_get_registered_image_subsizes())
            : [];

        if (empty($sizes)) {
            // Fallback to WordPress defaults
            $sizes = ['thumbnail', 'medium', 'medium_large', 'large', 'full'];
        }

        if (!empty($field['multiple'])) {
            shuffle($sizes);
            return array_slice($sizes, 0, min(rand(1, 3), count($sizes)));
        }

        return $sizes[array_rand($sizes)];
    }

    /**
     * Generate phone number value
     *
     * ACFE Pro stores phone numbers as plain E.164 strings (e.g., "+4930123456").
     * The format_value() handler parses country from the prefix for display.
     */
    protected function generatePhoneNumber(): string
    {
        $faker = $this->getLocaleFaker();

        return $faker->e164PhoneNumber();
    }

    /**
     * Generate block editor content
     */
    protected function generateBlockEditor(): string
    {
        $faker = $this->getLocaleFaker();

        $blocks = [];

        // Add a heading
        $blocks[] = '<!-- wp:heading -->' . "\n" .
            '<h2 class="wp-block-heading">' . $faker->sentence(rand(3, 6)) . '</h2>' . "\n" .
            '<!-- /wp:heading -->';

        // Add paragraphs
        for ($i = 0; $i < rand(2, 4); $i++) {
            $blocks[] = '<!-- wp:paragraph -->' . "\n" .
                '<p>' . $faker->paragraph() . '</p>' . "\n" .
                '<!-- /wp:paragraph -->';
        }

        // Maybe add a list
        if (rand(0, 1)) {
            $items = array_map(
                fn($s) => '<li>' . $s . '</li>',
                $faker->sentences(rand(3, 5))
            );
            $blocks[] = '<!-- wp:list -->' . "\n" .
                '<ul class="wp-block-list">' . implode("\n", $items) . '</ul>' . "\n" .
                '<!-- /wp:list -->';
        }

        return implode("\n\n", $blocks);
    }

    /**
     * Generate payment value (mock)
     */
    protected function generatePayment(): array
    {
        $faker = $this->getLocaleFaker();

        // ACFE payment expects keys: id, gateway, amount, currency, items, date, ip, mode, object
        return [
            'id'       => 'txn_' . $faker->regexify('[A-Za-z0-9]{24}'),
            'gateway'  => $faker->randomElement(['stripe', 'paypal']),
            'amount'   => $faker->randomFloat(2, 10, 500),
            'currency' => $faker->randomElement(['EUR', 'USD', 'GBP']),
            'items'    => [],
            'date'     => time() - rand(0, 86400 * 30),
            'ip'       => '127.0.0.1',
            'mode'     => 'test',
            'object'   => [],
        ];
    }

    /**
     * Generate payment cart value (mock)
     */
    protected function generatePaymentCart(): array
    {
        $faker = $this->getLocaleFaker();
        $items = [];

        for ($i = 0; $i < rand(1, 3); $i++) {
            $items[] = [
                'name'     => $faker->words(rand(2, 4), true),
                'price'    => $faker->randomFloat(2, 5, 100),
                'quantity' => rand(1, 3),
            ];
        }

        return [
            'id'       => 'txn_' . $faker->regexify('[A-Za-z0-9]{24}'),
            'gateway'  => $faker->randomElement(['stripe', 'paypal']),
            'amount'   => array_sum(array_map(fn($i) => $i['price'] * $i['quantity'], $items)),
            'currency' => $faker->randomElement(['EUR', 'USD', 'GBP']),
            'items'    => $items,
            'date'     => time() - rand(0, 86400 * 30),
            'ip'       => '127.0.0.1',
            'mode'     => 'test',
            'object'   => [],
        ];
    }

    /**
     * Generate payment selector value
     */
    protected function generatePaymentSelector(array $field): string
    {
        $methods = ['stripe', 'paypal', 'bank_transfer'];

        $allowedMethods = $field['choices'] ?? [];
        if (!empty($allowedMethods)) {
            $methods = array_keys($allowedMethods);
        }

        return $methods[array_rand($methods)];
    }
}
