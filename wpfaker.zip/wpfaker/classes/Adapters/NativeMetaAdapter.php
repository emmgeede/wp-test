<?php

namespace WPFaker\Adapters;

use WPFaker\Services\FakerService;

/**
 * Native WordPress Meta Adapter
 *
 * Adapter for native WordPress meta fields registered via register_post_meta().
 * Supports fields registered with the REST API for programmatic Custom Post Types.
 */
class NativeMetaAdapter extends AbstractFieldPluginAdapter
{
    /**
     * Cache for meta fields by post type
     *
     * @var array
     */
    protected array $cachedMetaFields = [];

    /**
     * Constructor
     *
     * @param FakerService|null $faker
     */
    public function __construct(?FakerService $faker = null)
    {
        parent::__construct($faker);
    }

    /**
     * Check if native meta is available
     *
     * Always returns true as WordPress native meta is always available.
     *
     * @return bool
     */
    public function isActive(): bool
    {
        return true;
    }

    /**
     * Get the adapter name
     *
     * @return string
     */
    public function getName(): string
    {
        return 'WordPress Native Meta';
    }

    /**
     * Get the WordPress version
     *
     * @return string
     */
    public function getVersion(): string
    {
        global $wp_version;
        return $wp_version ?? '0.0.0';
    }

    /**
     * Get custom post types (none - this adapter doesn't register CPTs)
     *
     * @return array
     */
    public function getCustomPostTypes(): array
    {
        return [];
    }

    /**
     * Get custom taxonomies (none - this adapter doesn't register taxonomies)
     *
     * @return array
     */
    public function getCustomTaxonomies(): array
    {
        return [];
    }

    /**
     * Get all field groups
     *
     * Native meta doesn't have field groups, but we create virtual groups per post type.
     *
     * @return array
     */
    public function getFieldGroups(): array
    {
        $groups = [];
        $postTypes = get_post_types(['public' => true], 'names');

        foreach ($postTypes as $postType) {
            $fields = $this->getFieldsForPostType($postType);
            if (!empty($fields)) {
                $groups[] = [
                    'key' => 'native_meta_' . $postType,
                    'title' => sprintf(__('Native Meta Fields (%s)', 'wpfaker'), $postType),
                    'fields' => $fields,
                    'location' => [
                        [
                            [
                                'param' => 'post_type',
                                'operator' => '==',
                                'value' => $postType,
                            ]
                        ]
                    ],
                    'active' => true,
                ];
            }
        }

        return $groups;
    }

    /**
     * Get field groups for a specific post type
     *
     * @param string $postType The post type slug
     * @return array
     */
    public function getFieldGroupsForPostType(string $postType): array
    {
        $fields = $this->getFieldsForPostType($postType);

        if (empty($fields)) {
            return [];
        }

        return [
            [
                'key' => 'native_meta_' . $postType,
                'title' => sprintf(__('Native Meta Fields (%s)', 'wpfaker'), $postType),
                'fields' => $fields,
                'location' => [
                    [
                        [
                            'param' => 'post_type',
                            'operator' => '==',
                            'value' => $postType,
                        ]
                    ]
                ],
                'active' => true,
            ]
        ];
    }

    /**
     * Get fields from a field group
     *
     * @param int|string $fieldGroupId The field group ID or key
     * @return array
     */
    public function getFields($fieldGroupId): array
    {
        // Extract post type from group key (native_meta_{postType})
        if (is_string($fieldGroupId) && strpos($fieldGroupId, 'native_meta_') === 0) {
            $postType = substr($fieldGroupId, strlen('native_meta_'));
            return $this->getFieldsForPostType($postType);
        }

        return [];
    }

    /**
     * Get all fields for a specific post type
     *
     * @param string $postType The post type slug
     * @return array
     */
    public function getFieldsForPostType(string $postType): array
    {
        // Check cache
        if (isset($this->cachedMetaFields[$postType])) {
            return $this->cachedMetaFields[$postType];
        }

        $fields = [];
        $registeredMeta = get_registered_meta_keys('post', $postType);

        foreach ($registeredMeta as $metaKey => $metaArgs) {
            // Skip internal WordPress meta keys
            if ($this->isInternalMetaKey($metaKey)) {
                continue;
            }

            $field = $this->convertMetaToField($metaKey, $metaArgs);
            if ($field) {
                $fields[] = $field;
            }
        }

        // Cache the result
        $this->cachedMetaFields[$postType] = $fields;

        return $fields;
    }

    /**
     * Check if a meta key is an internal WordPress key
     *
     * @param string $metaKey
     * @return bool
     */
    protected function isInternalMetaKey(string $metaKey): bool
    {
        // Skip common internal meta keys
        $internalKeys = [
            '_edit_lock',
            '_edit_last',
            '_wp_page_template',
            '_wp_trash_meta_status',
            '_wp_trash_meta_time',
            '_wp_old_slug',
            '_wp_old_date',
            '_thumbnail_id',
            '_encloseme',
            '_pingme',
        ];

        return in_array($metaKey, $internalKeys, true);
    }

    /**
     * Convert WordPress meta registration to field configuration
     *
     * @param string $metaKey
     * @param array $metaArgs
     * @return array|null
     */
    protected function convertMetaToField(string $metaKey, array $metaArgs): ?array
    {
        $type = $metaArgs['type'] ?? 'string';
        $description = $metaArgs['description'] ?? '';

        // Map WordPress meta types to our field types
        $fieldType = $this->mapMetaTypeToFieldType($type, $metaKey, $description);

        $field = [
            'key' => 'native_' . $metaKey,
            'name' => $metaKey,
            'label' => $this->generateLabelFromKey($metaKey),
            'type' => $fieldType,
            'description' => $description,
            'required' => false,
            'default_value' => $metaArgs['default'] ?? null,
            'single' => $metaArgs['single'] ?? true,
            '_native_meta' => true, // Mark as native meta field
            '_meta_type' => $type,
        ];

        // Add type-specific configuration
        $field = $this->addTypeSpecificConfig($field, $type, $metaKey, $description);

        return $field;
    }

    /**
     * Map WordPress meta type to field type
     *
     * @param string $metaType
     * @param string $metaKey
     * @param string $description
     * @return string
     */
    protected function mapMetaTypeToFieldType(string $metaType, string $metaKey, string $description): string
    {
        // First, try to detect type from field name patterns
        $keyLower = strtolower($metaKey);
        $descLower = strtolower($description);

        // Email detection
        if (strpos($keyLower, 'email') !== false || strpos($descLower, 'e-mail') !== false) {
            return 'email';
        }

        // URL detection
        if (strpos($keyLower, 'url') !== false || strpos($keyLower, 'link') !== false ||
            strpos($keyLower, 'website') !== false || strpos($descLower, 'url') !== false) {
            return 'url';
        }

        // Date detection
        if (strpos($keyLower, 'date') !== false || strpos($keyLower, 'datum') !== false) {
            return 'date_picker';
        }

        // Image detection
        if (strpos($keyLower, 'image') !== false || strpos($keyLower, 'bild') !== false ||
            strpos($keyLower, 'foto') !== false || strpos($keyLower, 'photo') !== false) {
            return 'image';
        }

        // Textarea detection (lists, instructions, descriptions)
        if (strpos($keyLower, 'liste') !== false || strpos($keyLower, 'list') !== false ||
            strpos($keyLower, 'anleitung') !== false || strpos($keyLower, 'instruction') !== false ||
            strpos($keyLower, 'beschreibung') !== false || strpos($keyLower, 'tipps') !== false) {
            return 'textarea';
        }

        // Default mapping by meta type
        return match ($metaType) {
            'string' => 'text',
            'integer' => 'number',
            'number' => 'number',
            'boolean' => 'true_false',
            'array' => 'select',
            'object' => 'group',
            default => 'text',
        };
    }

    /**
     * Add type-specific configuration to field
     *
     * @param array $field
     * @param string $metaType
     * @param string $metaKey
     * @param string $description
     * @return array
     */
    protected function addTypeSpecificConfig(array $field, string $metaType, string $metaKey, string $description): array
    {
        $keyLower = strtolower($metaKey);

        switch ($field['type']) {
            case 'number':
                // Try to detect reasonable min/max from field name
                if (strpos($keyLower, 'bewertung') !== false || strpos($keyLower, 'rating') !== false) {
                    $field['min'] = 1;
                    $field['max'] = 5;
                    $field['step'] = 0.5;
                } elseif (strpos($keyLower, 'portionen') !== false || strpos($keyLower, 'servings') !== false) {
                    $field['min'] = 1;
                    $field['max'] = 20;
                } elseif (strpos($keyLower, 'kalorien') !== false || strpos($keyLower, 'calories') !== false) {
                    $field['min'] = 50;
                    $field['max'] = 2000;
                } elseif (strpos($keyLower, 'preis') !== false || strpos($keyLower, 'price') !== false) {
                    $field['min'] = 1;
                    $field['max'] = 100;
                    $field['step'] = 0.5;
                } else {
                    $field['min'] = 0;
                    $field['max'] = 1000;
                }
                break;

            case 'text':
                // Detect if this should be a select field with predefined options
                if (strpos($keyLower, 'schwierigkeit') !== false || strpos($keyLower, 'difficulty') !== false) {
                    $field['type'] = 'select';
                    $field['choices'] = [
                        'einfach' => 'Einfach',
                        'mittel' => 'Mittel',
                        'schwer' => 'Schwer',
                        'profi' => 'Profi',
                    ];
                }
                break;
        }

        return $field;
    }

    /**
     * Generate a human-readable label from meta key
     *
     * @param string $metaKey
     * @return string
     */
    protected function generateLabelFromKey(string $metaKey): string
    {
        // Remove common prefixes
        $label = preg_replace('/^_?(rezept_|post_|meta_|field_)/', '', $metaKey);

        // Replace underscores with spaces
        $label = str_replace(['_', '-'], ' ', $label);

        // Capitalize words
        $label = ucwords($label);

        return $label;
    }

    /**
     * Save a field value for a post
     *
     * @param int $postId The post ID
     * @param string $fieldName The field name/key
     * @param mixed $value The value to save
     * @return bool
     */
    public function saveFieldValue(int $postId, string $fieldName, $value): bool
    {
        // Native meta uses update_post_meta directly
        return update_post_meta($postId, $fieldName, $value) !== false;
    }

    /**
     * Get field configuration by name or key
     *
     * @param string $fieldNameOrKey The field name or key
     * @return array|null
     */
    public function getFieldConfig(string $fieldNameOrKey): ?array
    {
        // Check all post types for this field
        $postTypes = get_post_types(['public' => true], 'names');

        foreach ($postTypes as $postType) {
            $fields = $this->getFieldsForPostType($postType);
            foreach ($fields as $field) {
                if ($field['name'] === $fieldNameOrKey || $field['key'] === $fieldNameOrKey) {
                    return $field;
                }
            }
        }

        return null;
    }

    /**
     * Get supported field types
     *
     * @return array
     */
    public function getSupportedFieldTypes(): array
    {
        return [
            'text',
            'textarea',
            'number',
            'email',
            'url',
            'true_false',
            'date_picker',
            'select',
            'image',
        ];
    }

    /**
     * Clear cached meta fields
     *
     * @return void
     */
    public function clearCache(): void
    {
        parent::clearCache();
        $this->cachedMetaFields = [];
    }

    /**
     * Check if a post type has native meta fields
     *
     * @param string $postType
     * @return bool
     */
    public function hasFieldsForPostType(string $postType): bool
    {
        $fields = $this->getFieldsForPostType($postType);
        return !empty($fields);
    }
}
