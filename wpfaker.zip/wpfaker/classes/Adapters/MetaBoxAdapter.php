<?php

namespace WPFaker\Adapters;

use WPFaker\Services\FakerService;

/**
 * Meta Box Adapter
 *
 * Adapter for Meta Box and Meta Box AIO (All-In-One).
 * Handles detection and generation of fake data for ~50 Meta Box field types.
 *
 * @see https://metabox.io/
 */
class MetaBoxAdapter extends AbstractFieldPluginAdapter
{
    /**
     * Cached MB Relationship meta box IDs to exclude from field groups
     *
     * @var array|null
     */
    protected ?array $cachedRelationshipMetaBoxIds = null;

    /**
     * Cached MB Relationships settings
     *
     * @var array|null
     */
    protected ?array $cachedMBRelationships = null;

    /**
     * Meta Box specific field type mapping
     *
     * @var array
     */
    protected array $metaBoxFieldTypeMap = [
        'text'              => 'sentence',
        'textarea'          => 'paragraphs',
        'number'            => 'randomNumber',
        'range'             => 'numberBetween',
        'slider'            => 'numberBetween',
        'email'             => 'safeEmail',
        'url'               => 'url',
        'password'          => 'password',
        'wysiwyg'           => 'paragraphs',
        'oembed'            => 'url',
        'select'            => 'randomElement',
        'select_advanced'   => 'randomElement',
        'radio'             => 'randomElement',
        'checkbox'          => 'boolean',
        'checkbox_list'     => 'randomElements',
        'button_group'      => 'randomElement',
        'autocomplete'      => 'randomElement',
        'image_select'      => 'randomElement',
        'switch'            => 'boolean',
        'date'              => 'date',
        'datetime'          => 'dateTime',
        'time'              => 'time',
        'color'             => 'hexColor',
        'file'              => 'imageUrl',
        'file_input'        => 'url',
        'file_advanced'     => 'imageUrl',
        'file_upload'       => 'imageUrl',
        'image'             => 'imageUrl',
        'image_upload'      => 'imageUrl',
        'image_advanced'    => 'imageUrl',
        'single_image'      => 'imageUrl',
        'video'             => 'url',
        'post'              => 'randomNumber',
        'taxonomy'          => 'randomNumber',
        'taxonomy_advanced' => 'randomNumber',
        'user'              => 'randomNumber',
        'map'               => 'address',
        'osm'               => 'address',
        'sidebar'           => 'randomElement',
        'key_value'         => 'sentence',
        'fieldset_text'     => 'sentence',
        'text_list'         => 'sentence',
        'hidden'            => 'sentence',
        'custom_html'       => 'sentence',
    ];

    /**
     * Layout/UI field types that should be skipped (return null)
     *
     * @var array
     */
    protected array $layoutFieldTypes = [
        'heading', 'divider', 'tab',
    ];

    /**
     * Constructor
     *
     * @param FakerService|null $faker
     */
    public function __construct(?FakerService $faker = null)
    {
        parent::__construct($faker);
        $this->defaultFieldTypeMap = array_merge($this->defaultFieldTypeMap, $this->metaBoxFieldTypeMap);
    }

    /**
     * Check if Meta Box is active
     *
     * @return bool
     */
    public function isActive(): bool
    {
        return class_exists('RWMB_Loader') || defined('RWMB_VER');
    }

    /**
     * Check if Meta Box AIO (All-In-One) or premium extensions are active
     *
     * @return bool
     */
    public function isProActive(): bool
    {
        // Meta Box AIO bundles all premium extensions
        if (class_exists('MB_AIO')) {
            return true;
        }

        // Check for individual premium extensions
        if (class_exists('MBB_Extension_Pack')) {
            return true;
        }

        // MB Custom Post Type extension
        if (class_exists('MB_Custom_Post_Type')) {
            return true;
        }

        return false;
    }

    /**
     * Get the plugin name
     *
     * @return string
     */
    public function getName(): string
    {
        if ($this->isProActive()) {
            return 'Meta Box AIO';
        }

        return 'Meta Box';
    }

    /**
     * Get the plugin version
     *
     * @return string
     */
    public function getVersion(): string
    {
        if (defined('RWMB_VER')) {
            return RWMB_VER;
        }

        return '0.0.0';
    }

    /**
     * Get all custom post types registered by Meta Box
     *
     * Uses MB Custom Post Type extension (stores CPTs as 'mb-post-type' posts)
     *
     * @return array
     */
    public function getCustomPostTypes(): array
    {
        if ($this->cachedPostTypes !== null) {
            return $this->cachedPostTypes;
        }

        if (!$this->isActive()) {
            return [];
        }

        // MB Custom Post Type stores CPTs as posts
        $cptPosts = get_posts([
            'post_type'      => 'mb-post-type',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
        ]);

        $this->cachedPostTypes = array_map(function ($post) {
            $settings = get_post_meta($post->ID, 'args', true);
            $slug = get_post_meta($post->ID, 'post_type', true) ?: $post->post_name;

            return array_merge([
                'ID'        => $post->ID,
                'post_type' => $slug,
                'title'     => $post->post_title,
            ], is_array($settings) ? $settings : []);
        }, $cptPosts);

        return $this->cachedPostTypes;
    }

    /**
     * Get all custom taxonomies registered by Meta Box
     *
     * Uses MB Custom Taxonomy extension (stores taxonomies as 'mb-taxonomy' posts)
     *
     * @return array
     */
    public function getCustomTaxonomies(): array
    {
        if ($this->cachedTaxonomies !== null) {
            return $this->cachedTaxonomies;
        }

        if (!$this->isActive()) {
            return [];
        }

        $taxPosts = get_posts([
            'post_type'      => 'mb-taxonomy',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
        ]);

        $this->cachedTaxonomies = array_map(function ($post) {
            $settings = get_post_meta($post->ID, 'args', true);
            $slug = get_post_meta($post->ID, 'taxonomy', true) ?: $post->post_name;

            return array_merge([
                'ID'       => $post->ID,
                'taxonomy' => $slug,
                'title'    => $post->post_title,
            ], is_array($settings) ? $settings : []);
        }, $taxPosts);

        return $this->cachedTaxonomies;
    }

    /**
     * Get all field groups (meta boxes)
     *
     * Prefers the rwmb_meta_boxes filter which returns plain config arrays.
     * Falls back to the registry (which returns RWMB_Meta_Box objects that
     * need conversion).
     *
     * @return array
     */
    public function getFieldGroups(): array
    {
        if ($this->cachedFieldGroups !== null) {
            return $this->cachedFieldGroups;
        }

        if (!$this->isActive()) {
            return [];
        }

        // Prefer the filter — returns plain config arrays
        $fromFilter = apply_filters('rwmb_meta_boxes', []);
        if (!empty($fromFilter) && is_array($fromFilter)) {
            $this->cachedFieldGroups = $fromFilter;
            return $this->cachedFieldGroups;
        }

        // Fallback: registry (returns RWMB_Meta_Box objects, need conversion)
        if (function_exists('rwmb_get_registry')) {
            $registry = rwmb_get_registry('meta_box');
            if ($registry) {
                $metaBoxes = $registry->all();
                if (is_array($metaBoxes)) {
                    $this->cachedFieldGroups = array_map(
                        [$this, 'convertMetaBoxObject'],
                        $metaBoxes
                    );
                    return $this->cachedFieldGroups;
                }
            }
        }

        $this->cachedFieldGroups = [];
        return $this->cachedFieldGroups;
    }

    /**
     * Convert a RWMB_Meta_Box object to a plain config array
     *
     * @param mixed $metaBox
     * @return array
     */
    protected function convertMetaBoxObject($metaBox): array
    {
        // Already an array
        if (is_array($metaBox)) {
            return $metaBox;
        }

        // RWMB_Meta_Box stores config in the public 'meta_box' property
        if (is_object($metaBox) && isset($metaBox->meta_box)) {
            return $metaBox->meta_box;
        }

        // Try to cast as last resort
        if (is_object($metaBox)) {
            return (array) $metaBox;
        }

        return [];
    }

    /**
     * Get field groups for a specific post type
     *
     * @param string $postType The post type slug
     * @return array
     */
    public function getFieldGroupsForPostType(string $postType): array
    {
        if (!$this->isActive()) {
            return [];
        }

        $allGroups = $this->getFieldGroups();
        $excludeIds = $this->getMBRelationshipMetaBoxIds();
        $matching = [];

        foreach ($allGroups as $group) {
            // Skip MB Relationship meta boxes (handled in dedicated pass)
            $groupId = is_array($group) ? ($group['id'] ?? '') : '';
            if ($groupId !== '' && in_array($groupId, $excludeIds, true)) {
                continue;
            }

            $postTypes = $this->extractPostTypes($group);

            // Only include groups that explicitly target this post type.
            // Groups without post_types are internal duplicates or non-post-type
            // meta boxes (user profile forms, etc.) — skip them.
            // MB Relationship meta boxes are already excluded by ID above.
            if (!empty($postTypes) && in_array($postType, $postTypes)) {
                $matching[] = $group;
            }
        }

        return $matching;
    }

    /**
     * Extract post types from a meta box configuration
     *
     * @param array|object $group The meta box config
     * @return array
     */
    protected function extractPostTypes($group): array
    {
        // Handle object (from registry)
        if (is_object($group)) {
            $group = (array) $group;
        }

        // Meta Box uses 'post_types' key
        $postTypes = $group['post_types'] ?? [];

        if (is_string($postTypes)) {
            $postTypes = [$postTypes];
        }

        return $postTypes;
    }

    /**
     * Get fields from a field group
     *
     * @param int|string $fieldGroupId The field group ID or key
     * @return array
     */
    public function getFields($fieldGroupId): array
    {
        if (!$this->isActive()) {
            return [];
        }

        $allGroups = $this->getFieldGroups();

        foreach ($allGroups as $id => $group) {
            if (is_object($group)) {
                $group = (array) $group;
            }

            $groupId = $group['id'] ?? $id;

            if ($groupId === $fieldGroupId) {
                $fields = $group['fields'] ?? [];
                return $this->normalizeFields($fields);
            }
        }

        return [];
    }

    /**
     * Get all fields for a specific post type
     *
     * @param string $postType The post type slug
     * @return array
     */
    public function getFieldsForPostType(string $postType): array
    {
        $fieldGroups = $this->getFieldGroupsForPostType($postType);
        $allFields = [];

        foreach ($fieldGroups as $group) {
            if (is_object($group)) {
                $group = (array) $group;
            }

            $fields = $group['fields'] ?? [];
            $normalized = $this->normalizeFields($fields);
            $allFields = array_merge($allFields, $normalized);
        }

        // Exclude post-type fields that are handled by MB Relationships
        // (prevents duplicate data: post meta vs relationship table)
        $mbRelPostTypes = [];
        if ($this->isMBRelationshipsActive()) {
            $rels = $this->getMBRelationshipsForPostType($postType);
            foreach ($rels as $rel) {
                $mbRelPostTypes[] = $rel['related_post_type'];
            }
        }

        // Deduplicate by field name (keep first occurrence)
        $seen = [];
        $unique = [];
        foreach ($allFields as $field) {
            $name = $field['name'] ?? '';
            if ($name === '' || isset($seen[$name])) {
                continue;
            }

            // Skip post fields whose target is handled by MB Relationships
            if (($field['type'] ?? '') === 'post' && !empty($mbRelPostTypes)) {
                $fieldPostType = $field['post_type'] ?? '';
                if (in_array($fieldPostType, $mbRelPostTypes, true)) {
                    continue;
                }
            }

            $seen[$name] = true;
            $unique[] = $field;
        }

        return $unique;
    }

    /**
     * Normalize Meta Box fields to WPFaker's internal format
     *
     * Meta Box → WPFaker mapping:
     * - id → name (meta key)
     * - name → label
     * - desc → description
     * - type → type (direct)
     * - clone → _repeater (bool)
     * - clone_limit → max_rows
     * - options → choices
     * - std → default_value
     *
     * @param array $fields Raw Meta Box fields
     * @return array Normalized fields
     */
    protected function normalizeFields(array $fields): array
    {
        $normalized = [];

        foreach ($fields as $field) {
            // Skip layout-only fields
            $type = $field['type'] ?? '';
            if (in_array($type, $this->layoutFieldTypes)) {
                continue;
            }

            $normalized[] = $this->normalizeField($field);
        }

        return $normalized;
    }

    /**
     * Normalize a single Meta Box field
     *
     * @param array $field Raw Meta Box field
     * @return array Normalized field
     */
    protected function normalizeField(array $field): array
    {
        return [
            'name'          => $field['id'] ?? '',
            'label'         => $field['name'] ?? '',
            'description'   => $field['desc'] ?? '',
            'type'          => $field['type'] ?? 'text',
            'required'      => !empty($field['required']),
            'choices'       => $field['options'] ?? [],
            'default_value' => $field['std'] ?? null,
            'min'           => $field['min'] ?? null,
            'max'           => $field['max'] ?? null,
            'step'          => $field['step'] ?? null,
            'clone'         => !empty($field['clone']),
            'clone_limit'   => $field['max_clone'] ?? null,
            'multiple'      => !empty($field['multiple']),
            'post_type'     => $field['post_type'] ?? [],
            'taxonomy'      => $field['taxonomy'] ?? [],
            'query_args'    => $field['query_args'] ?? [],
            'fields'        => $field['fields'] ?? [],
            'placeholder'   => $field['placeholder'] ?? '',
            'js_options'    => $field['js_options'] ?? [],
            'prefix'        => $field['prepend'] ?? $field['prefix'] ?? '',
            'suffix'        => $field['append'] ?? $field['suffix'] ?? '',
            '_raw'          => $field,
        ];
    }

    /**
     * Save a field value for a post
     *
     * @param int $postId The post ID
     * @param string $fieldName The field name/meta key
     * @param mixed $value The value to save
     * @return bool
     */
    public function saveFieldValue(int $postId, string $fieldName, $value): bool
    {
        if (!$this->isActive()) {
            return false;
        }

        // Use Meta Box's API if available
        if (function_exists('rwmb_set_meta')) {
            rwmb_set_meta($postId, $fieldName, $value);
            return true;
        }

        // Fallback to standard WordPress meta
        return update_post_meta($postId, $fieldName, $value) !== false;
    }

    /**
     * Get field configuration by name
     *
     * @param string $fieldNameOrKey The field name (meta key)
     * @return array|null
     */
    public function getFieldConfig(string $fieldNameOrKey): ?array
    {
        if (!$this->isActive()) {
            return null;
        }

        $allGroups = $this->getFieldGroups();

        foreach ($allGroups as $group) {
            if (is_object($group)) {
                $group = (array) $group;
            }

            $fields = $group['fields'] ?? [];

            foreach ($fields as $field) {
                $fieldId = $field['id'] ?? '';

                if ($fieldId === $fieldNameOrKey) {
                    return $this->normalizeField($field);
                }

                // Check sub-fields in groups
                if (($field['type'] ?? '') === 'group' && !empty($field['fields'])) {
                    foreach ($field['fields'] as $subField) {
                        if (($subField['id'] ?? '') === $fieldNameOrKey) {
                            return $this->normalizeField($subField);
                        }
                    }
                }
            }
        }

        return null;
    }

    /**
     * Get taxonomy assignment constraints from Meta Box field config.
     *
     * @param array $field Normalized field config (from normalizeField)
     * @return array ['mode' => 'single'|'multiple', 'min' => int, 'max' => int|null] or [] if not taxonomy
     */
    public function getTaxonomyConstraints(array $field): array
    {
        $type = $field['type'] ?? '';
        if (!in_array($type, ['taxonomy', 'taxonomy_advanced'], true)) {
            return [];
        }

        // taxonomy_advanced always stores multiple values
        // taxonomy with 'multiple' flag also stores multiple
        $isMultiple = $type === 'taxonomy_advanced' || !empty($field['multiple']);

        if (!$isMultiple) {
            return [
                'mode' => 'single',
                'min'  => 1,
                'max'  => 1,
            ];
        }

        $max = isset($field['max']) && $field['max'] !== null && $field['max'] !== '' ? (int) $field['max'] : null;

        return [
            'mode' => 'multiple',
            'min'  => 1,
            'max'  => $max,
        ];
    }


    /**
     * Get supported field types
     *
     * @return array
     */
    public function getSupportedFieldTypes(): array
    {
        return [
            // Text
            'text', 'url', 'email', 'password', 'hidden',

            // Content
            'textarea', 'wysiwyg', 'oembed', 'custom_html',

            // Number
            'number', 'range', 'slider',

            // Selection
            'select', 'select_advanced', 'radio', 'checkbox',
            'checkbox_list', 'button_group', 'autocomplete',
            'image_select', 'switch',

            // Date/Time
            'date', 'datetime', 'time',

            // Color
            'color',

            // File/Media
            'file', 'file_input', 'file_advanced', 'file_upload',
            'image', 'image_upload', 'image_advanced', 'single_image',
            'video',

            // Relational
            'post', 'taxonomy', 'taxonomy_advanced', 'user',

            // Map
            'map', 'osm',

            // Special
            'key_value', 'fieldset_text', 'text_list',
            'background', 'sidebar',
        ];
    }

    /**
     * Generate a fake value based on field configuration
     *
     * Handles Meta Box cloneable fields and all ~50 field types.
     *
     * @param array $field The field configuration
     * @return mixed The generated value
     */
    public function generateFakeValue(array $field): mixed
    {
        $type = $field['type'] ?? 'text';
        $fieldName = $field['name'] ?? $field['id'] ?? '';

        // Handle cloneable fields (Meta Box's repeater mechanism)
        if (!empty($field['clone'])) {
            return $this->generateCloneableValue($field);
        }

        return $this->generateSingleValue($field);
    }

    /**
     * Generate a cloneable (repeatable) field value
     *
     * Meta Box uses `clone => true` instead of a separate repeater type.
     *
     * @param array $field The field configuration
     * @return array Array of cloned values
     */
    protected function generateCloneableValue(array $field): array
    {
        $maxClone = (int) ($field['clone_limit'] ?? $field['max_clone'] ?? 3);
        $count = rand(1, min(3, $maxClone));

        $values = [];
        for ($i = 0; $i < $count; $i++) {
            $values[] = $this->generateSingleValue($field);
        }

        return $values;
    }

    /**
     * Generate a single field value (not cloned)
     *
     * @param array $field The field configuration
     * @return mixed
     */
    protected function generateSingleValue(array $field): mixed
    {
        $type = $field['type'] ?? 'text';
        $fieldName = $field['name'] ?? $field['id'] ?? '';
        $faker = $this->getLocaleFaker();

        // For text-based fields, try smart detection first
        if (in_array($type, ['text', 'textarea', 'number', 'range', 'slider'])) {
            $smartValue = $this->fieldDetector->detectAndGenerate($fieldName, $field, $this->locale);
            if ($smartValue !== null) {
                if (in_array($type, ['number', 'range', 'slider'])) {
                    return is_numeric($smartValue) ? $smartValue : null;
                }
                return $smartValue;
            }
        }

        return match ($type) {
            // Text
            'text'              => $faker->sentence(rand(3, 8)),
            'url'               => $faker->url(),
            'email'             => $faker->safeEmail(),
            'password'          => $faker->password(8, 16),
            'hidden'            => $faker->md5(),

            // Content
            'textarea'          => implode("\n\n", $faker->paragraphs(rand(2, 4))),
            'wysiwyg'           => $this->generateWysiwyg($field),
            'oembed'            => $this->generateOembed(),
            'custom_html'       => '<div class="custom">' . $faker->paragraph() . '</div>',

            // Number
            'number'            => $this->generateNumber($field),
            'range', 'slider'   => $this->generateRange($field),

            // Selection
            'select', 'select_advanced' => $this->generateSelect($field),
            'radio'             => $this->generateRadio($field),
            'checkbox'          => $this->generateMbCheckbox($field),
            'checkbox_list'     => $this->generateCheckbox($field),
            'button_group'      => $this->generateButtonGroup($field),
            'autocomplete'      => $this->generateAutocomplete($field),
            'image_select'      => $this->generateImageSelect($field),
            'switch'            => (int) $faker->boolean(),

            // Date/Time
            'date'              => $this->generateSmartDate($fieldName, 'Y-m-d'),
            'datetime'          => $this->generateSmartDate($fieldName, 'Y-m-d H:i:s'),
            'time'              => $faker->time('H:i:s'),

            // Color
            'color'             => $faker->hexColor(),

            // File/Media
            'file', 'file_advanced', 'file_upload' => $this->generateFileId($field),
            'file_input'        => $faker->url(),
            'image', 'image_upload', 'image_advanced' => $this->generateImageIds($field),
            'single_image'      => $this->generateImageId($field),
            'video'             => $this->generateVideo(),

            // Relational
            'post'              => $this->generatePostObject($field),
            'taxonomy', 'taxonomy_advanced' => $this->generateTaxonomy($field),
            'user'              => $this->generateUser(),

            // Map
            'map', 'osm'        => $this->generateMap(),

            // Special
            'key_value'         => $this->generateKeyValue(),
            'fieldset_text'     => $this->generateFieldsetText($field),
            'text_list'         => $this->generateTextList($field),
            'background'        => $this->generateBackground(),
            'sidebar'           => $this->generateSidebar(),

            // Group fields - generate all sub-field values as associative array
            'group'             => $this->generateGroup($field),

            // Layout fields return null
            'heading', 'divider', 'tab' => null,

            // MB extension types
            'mb_views', 'mb_settings_page' => null,

            // Fallback to parent adapter
            default             => parent::generateFakeValue($field),
        };
    }

    /**
     * Generate Meta Box checkbox value (single checkbox = boolean/1/0)
     *
     * In Meta Box, 'checkbox' is a single on/off toggle, unlike ACF where it's multi-select.
     *
     * @param array $field
     * @return int 1 or 0
     */
    protected function generateMbCheckbox(array $field): int
    {
        return rand(0, 1);
    }

    /**
     * Generate autocomplete value
     *
     * @param array $field
     * @return string|array
     */
    protected function generateAutocomplete(array $field): string|array
    {
        $choices = $field['choices'] ?? $field['options'] ?? [];

        if (empty($choices)) {
            return '';
        }

        $keys = array_keys($choices);
        $count = rand(1, min(3, count($keys)));
        shuffle($keys);

        return array_slice($keys, 0, $count);
    }

    /**
     * Generate image_select value
     *
     * @param array $field
     * @return string
     */
    protected function generateImageSelect(array $field): string
    {
        $choices = $field['choices'] ?? $field['options'] ?? [];

        if (empty($choices)) {
            return '';
        }

        $keys = array_keys($choices);
        return $keys[array_rand($keys)];
    }

    /**
     * Generate multiple image IDs for gallery-like fields
     *
     * @param array $field
     * @return array
     */
    protected function generateImageIds(array $field): array
    {
        $maxFiles = (int) ($field['max_file_uploads'] ?? 5);
        $count = rand(1, min(3, $maxFiles));

        $attachments = get_posts([
            'post_type'      => 'attachment',
            'post_mime_type' => 'image',
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ]);

        if (empty($attachments)) {
            return [];
        }

        shuffle($attachments);
        return array_slice($attachments, 0, min($count, count($attachments)));
    }

    /**
     * Generate a video value
     *
     * Meta Box video field stores video data as an array.
     *
     * @return array
     */
    protected function generateVideo(): array
    {
        $videos = [
            'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
            'https://www.youtube.com/watch?v=9bZkp7q19f0',
            'https://vimeo.com/148751763',
            'https://www.youtube.com/watch?v=jNQXAC9IVRw',
        ];

        return [
            'src'  => $videos[array_rand($videos)],
            'type' => 'video/mp4',
        ];
    }

    /**
     * Generate map value as "lat,lng,zoom" string
     *
     * Meta Box stores map/osm fields as comma-separated "lat,lng,zoom" strings.
     *
     * @return string
     */
    protected function generateMap(): string
    {
        $faker = $this->getLocaleFaker();
        $lat = $faker->latitude();
        $lng = $faker->longitude();

        return "{$lat},{$lng},14";
    }

    /**
     * Generate key_value field data
     *
     * Meta Box key_value stores an array of key-value pairs.
     *
     * @return array
     */
    protected function generateKeyValue(): array
    {
        $faker = $this->getLocaleFaker();
        $pairs = [];
        $count = rand(2, 4);

        for ($i = 0; $i < $count; $i++) {
            $pairs[] = [
                'key'   => $faker->word(),
                'value' => $faker->sentence(rand(2, 5)),
            ];
        }

        return $pairs;
    }

    /**
     * Generate fieldset_text value
     *
     * Fieldset text stores multiple named text inputs as key-value array.
     *
     * @param array $field
     * @return array
     */
    protected function generateFieldsetText(array $field): array
    {
        $faker = $this->getLocaleFaker();
        $options = $field['options'] ?? $field['choices'] ?? [];
        $values = [];

        if (!empty($options)) {
            foreach ($options as $key => $label) {
                $values[$key] = $faker->sentence(rand(2, 5));
            }
        } else {
            $values['field_1'] = $faker->sentence(rand(2, 5));
            $values['field_2'] = $faker->sentence(rand(2, 5));
        }

        return $values;
    }

    /**
     * Generate text_list value
     *
     * Text list stores multiple text inputs as key-value array.
     *
     * @param array $field
     * @return array
     */
    protected function generateTextList(array $field): array
    {
        return $this->generateFieldsetText($field);
    }

    /**
     * Generate background field value
     *
     * Meta Box background stores CSS background properties.
     *
     * @return array
     */
    protected function generateBackground(): array
    {
        $faker = $this->getLocaleFaker();

        return [
            'color'      => $faker->hexColor(),
            'image'      => '',
            'repeat'     => 'no-repeat',
            'position'   => 'center center',
            'attachment' => 'scroll',
            'size'       => 'cover',
        ];
    }

    /**
     * Generate group field value
     *
     * Meta Box group fields contain sub-fields and store values as
     * an associative array: ['sub_field_id' => value, ...]
     * If cloneable, returns array of such objects.
     *
     * @param array $field The group field configuration
     * @return array|null
     */
    protected function generateGroup(array $field): ?array
    {
        $subFields = $field['fields'] ?? $field['_raw']['fields'] ?? [];

        if (empty($subFields)) {
            return null;
        }

        $groupValue = [];

        foreach ($subFields as $subField) {
            $subId = $subField['id'] ?? '';
            if (empty($subId)) {
                continue;
            }

            $subType = $subField['type'] ?? 'text';

            // Skip layout sub-fields
            if (in_array($subType, $this->layoutFieldTypes)) {
                continue;
            }

            // Normalize and generate value for each sub-field
            $normalized = $this->normalizeField($subField);
            $value = $this->generateSingleValue($normalized);

            if ($value !== null) {
                $groupValue[$subId] = $value;
            }
        }

        return $groupValue ?: null;
    }

    /**
     * Generate sidebar value
     *
     * Returns a registered sidebar ID.
     *
     * @return string
     */
    protected function generateSidebar(): string
    {
        global $wp_registered_sidebars;

        if (!empty($wp_registered_sidebars)) {
            $ids = array_keys($wp_registered_sidebars);
            return $ids[array_rand($ids)];
        }

        return 'sidebar-1';
    }

    // =========================================================================
    // MB Relationships Support
    // =========================================================================

    /**
     * Check if MB Relationships is active
     *
     * @return bool
     */
    public function isMBRelationshipsActive(): bool
    {
        return class_exists('MB_Relationships_API');
    }

    /**
     * Get meta box IDs registered by MB Relationships (to exclude from field groups)
     *
     * @return array
     */
    protected function getMBRelationshipMetaBoxIds(): array
    {
        if ($this->cachedRelationshipMetaBoxIds !== null) {
            return $this->cachedRelationshipMetaBoxIds;
        }

        if (!$this->isMBRelationshipsActive()) {
            $this->cachedRelationshipMetaBoxIds = [];
            return [];
        }

        $settings = \MB_Relationships_API::get_all_relationships_settings();
        $ids = [];

        foreach ($settings as $setting) {
            $id = $setting['id'] ?? '';
            if ($id !== '') {
                // MB Relationships registers meta boxes with suffixed IDs
                $ids[] = $id;
                $ids[] = $id . '_relationships_from';
                $ids[] = $id . '_relationships_to';
            }
        }

        $this->cachedRelationshipMetaBoxIds = $ids;
        return $ids;
    }

    /**
     * Get all post-to-post MB Relationships
     *
     * @return array
     */
    public function getMBRelationships(): array
    {
        if ($this->cachedMBRelationships !== null) {
            return $this->cachedMBRelationships;
        }

        if (!$this->isMBRelationshipsActive()) {
            $this->cachedMBRelationships = [];
            return [];
        }

        $settings = \MB_Relationships_API::get_all_relationships_settings();
        $relationships = [];

        foreach ($settings as $setting) {
            $id = $setting['id'] ?? '';
            if ($id === '') {
                continue;
            }

            // Only handle post-to-post relationships
            $fromPostTypes = $setting['from']['meta_box']['post_types'] ?? [];
            $toPostTypes = $setting['to']['meta_box']['post_types'] ?? [];

            if (empty($fromPostTypes) || empty($toPostTypes)) {
                continue;
            }

            $relationships[$id] = [
                'id'              => $id,
                'from_post_type'  => $fromPostTypes[0],
                'to_post_type'    => $toPostTypes[0],
                'cardinality'     => $this->detectMBRelationshipCardinality($setting),
                '_setting'        => $setting,
            ];
        }

        $this->cachedMBRelationships = $relationships;
        return $relationships;
    }

    /**
     * Get MB Relationships for a specific post type
     *
     * Returns relationships where this post type is either 'from' or 'to',
     * with role and related_post_type added.
     *
     * @param string $postType The post type slug
     * @return array
     */
    public function getMBRelationshipsForPostType(string $postType): array
    {
        $allRelationships = $this->getMBRelationships();
        $matching = [];

        foreach ($allRelationships as $relId => $rel) {
            if ($rel['from_post_type'] === $postType) {
                $matching[$relId] = array_merge($rel, [
                    'role'              => 'from',
                    'related_post_type' => $rel['to_post_type'],
                ]);
            } elseif ($rel['to_post_type'] === $postType) {
                $matching[$relId] = array_merge($rel, [
                    'role'              => 'to',
                    'related_post_type' => $rel['from_post_type'],
                ]);
            }
        }

        return $matching;
    }

    /**
     * Detect cardinality from MB Relationship settings
     *
     * from.field.clone=true + to.field.clone=true → many_to_many
     * from.field.clone=false + to.field.clone=false → one_to_one
     * otherwise → one_to_many
     *
     * @param array $setting The relationship setting
     * @return string
     */
    protected function detectMBRelationshipCardinality(array $setting): string
    {
        $fromClone = !empty($setting['from']['field']['clone'] ?? false);
        $toClone = !empty($setting['to']['field']['clone'] ?? false);

        if ($fromClone && $toClone) {
            return 'many_to_many';
        }

        if (!$fromClone && !$toClone) {
            // When field config is missing entirely, default to many_to_many
            $hasFromField = isset($setting['from']['field']);
            $hasToField = isset($setting['to']['field']);
            if (!$hasFromField && !$hasToField) {
                return 'many_to_many';
            }
            return 'one_to_one';
        }

        return 'one_to_many';
    }

    /**
     * Create an MB Relationship connection
     *
     * @param string $relationshipId The relationship ID
     * @param int $fromId The 'from' post ID
     * @param int $toId The 'to' post ID
     * @return bool
     */
    public function createMBRelationship(string $relationshipId, int $fromId, int $toId): bool
    {
        if (!$this->isMBRelationshipsActive()) {
            return false;
        }

        // Check if connection already exists to prevent duplicates
        if (\MB_Relationships_API::has($fromId, $toId, $relationshipId)) {
            return false;
        }

        return \MB_Relationships_API::add($fromId, $toId, $relationshipId);
    }

    /**
     * Populate MB Relationships for a single post
     *
     * Mirrors JetEngineAdapter::populateRelationsForPost() logic.
     *
     * @param int $postId The post ID
     * @param string $postType The post type
     * @param int|null $excludePostId Post ID to exclude
     * @param array $batchPostIds Other post IDs from the current batch
     * @param bool $useVariation Whether to randomize connections
     * @param array $relatedPostPool Cross-CPT post pool
     * @return array Created connections
     */
    public function populateMBRelationshipsForPost(
        int $postId,
        string $postType,
        ?int $excludePostId = null,
        array $batchPostIds = [],
        bool $useVariation = false,
        array $relatedPostPool = []
    ): array {
        $relationships = $this->getMBRelationshipsForPostType($postType);
        $createdConnections = [];

        foreach ($relationships as $relId => $rel) {
            $role = $rel['role'];
            $cardinality = $rel['cardinality'];
            $relatedPostType = $rel['related_post_type'];

            // Cross-CPT: use related post pool if the target is a different post type
            if ($relatedPostType !== $postType && !empty($relatedPostPool[$relatedPostType])) {
                $availablePoolPosts = $relatedPostPool[$relatedPostType];

                // Always randomize connections — full interconnection produces
                // identical data for every post, which is never useful
                $maxCount = count($availablePoolPosts);
                $connectionCount = match ($cardinality) {
                    'one_to_one' => 1,
                    'one_to_many' => rand(1, min(3, $maxCount)),
                    'many_to_many' => rand(1, min(3, $maxCount)),
                    default => 1,
                };
                shuffle($availablePoolPosts);
                $selectedPosts = array_slice($availablePoolPosts, 0, $connectionCount);

                foreach ($selectedPosts as $relatedPostId) {
                    if ($role === 'from') {
                        $this->createMBRelationship($relId, $postId, $relatedPostId);
                    } else {
                        $this->createMBRelationship($relId, $relatedPostId, $postId);
                    }
                    $createdConnections[] = [
                        'relationship_id' => $relId,
                        'from_id'         => $role === 'from' ? $postId : $relatedPostId,
                        'to_id'           => $role === 'from' ? $relatedPostId : $postId,
                    ];
                }
                continue;
            }

            // Same-CPT: use batch post IDs
            if (!empty($batchPostIds)) {
                $availableBatchPosts = array_values(array_diff($batchPostIds, [$postId]));

                if (empty($availableBatchPosts)) {
                    continue;
                }

                // Always randomize connections
                $maxCount = count($availableBatchPosts);
                $connectionCount = match ($cardinality) {
                    'one_to_one' => 1,
                    'one_to_many' => rand(1, min(3, $maxCount)),
                    'many_to_many' => rand(1, min(3, $maxCount)),
                    default => 1,
                };
                shuffle($availableBatchPosts);
                $selectedPosts = array_slice($availableBatchPosts, 0, $connectionCount);
            } else {
                // Fallback: query existing posts
                $existingPosts = get_posts([
                    'post_type'      => $relatedPostType,
                    'posts_per_page' => 50,
                    'fields'         => 'ids',
                    'exclude'        => array_filter([$postId, $excludePostId]),
                ]);

                if (empty($existingPosts)) {
                    continue;
                }

                $maxCount = count($existingPosts);
                $connectionCount = match ($cardinality) {
                    'one_to_one' => 1,
                    'one_to_many' => rand(1, min(3, $maxCount)),
                    'many_to_many' => rand(1, min(3, $maxCount)),
                    default => 1,
                };
                shuffle($existingPosts);
                $selectedPosts = array_slice($existingPosts, 0, $connectionCount);
            }

            foreach ($selectedPosts as $relatedPostId) {
                if ($role === 'from') {
                    $this->createMBRelationship($relId, $postId, $relatedPostId);
                } else {
                    $this->createMBRelationship($relId, $relatedPostId, $postId);
                }
                $createdConnections[] = [
                    'relationship_id' => $relId,
                    'from_id'         => $role === 'from' ? $postId : $relatedPostId,
                    'to_id'           => $role === 'from' ? $relatedPostId : $postId,
                ];
            }
        }

        return $createdConnections;
    }

    /**
     * Delete MB Relationship connections for a post
     *
     * @param int $postId The post ID
     * @param string $postType The post type
     * @return int Number of relationships cleaned up
     */
    public function deleteMBRelationshipsForPost(int $postId, string $postType): int
    {
        if (!$this->isMBRelationshipsActive()) {
            return 0;
        }

        $relationships = $this->getMBRelationshipsForPostType($postType);
        $deletedCount = 0;

        foreach ($relationships as $relId => $rel) {
            // Delete connections where this post is 'from' (0 = any 'to')
            \MB_Relationships_API::delete($postId, 0, $relId);
            // Delete connections where this post is 'to' (0 = any 'from')
            \MB_Relationships_API::delete(0, $postId, $relId);
            $deletedCount++;
        }

        return $deletedCount;
    }
}
