<?php

namespace WPFaker\Adapters;

use WPFaker\Services\FakerService;

/**
 * ACPT (Advanced Custom Post Type) Adapter
 *
 * Adapter for ACPT plugin. Handles detection and generation of fake data
 * for all ACPT field types. ACPT uses its own custom database tables
 * (NOT wp_postmeta) and provides its own save/get API functions.
 *
 * Data hierarchy: MetaGroupModel -> MetaBoxModel[] -> MetaFieldModel[]
 *
 * @see https://acpt.io/
 */
class AcptAdapter extends AbstractFieldPluginAdapter
{
    /**
     * ACPT field type constants (from MetaFieldModel)
     */
    protected const TYPE_ADDRESS = 'Address';
    protected const TYPE_ADDRESS_MULTI = 'AddressMulti';
    protected const TYPE_AUDIO = 'Audio';
    protected const TYPE_AUDIO_MULTI = 'AudioMulti';
    protected const TYPE_BARCODE = 'Barcode';
    protected const TYPE_CHECKBOX = 'Checkbox';
    protected const TYPE_CLONE = 'Clone';
    protected const TYPE_COLOR = 'Color';
    protected const TYPE_COUNTRY = 'Country';
    protected const TYPE_CURRENCY = 'Currency';
    protected const TYPE_DATE = 'Date';
    protected const TYPE_DATE_RANGE = 'DateRange';
    protected const TYPE_DATE_TIME = 'DateTime';
    protected const TYPE_EDITOR = 'Editor';
    protected const TYPE_EMAIL = 'Email';
    protected const TYPE_EMBED = 'Embed';
    protected const TYPE_FILE = 'File';
    protected const TYPE_FLEXIBLE_CONTENT = 'FlexibleContent';
    protected const TYPE_GALLERY = 'Gallery';
    protected const TYPE_HTML = 'HTML';
    protected const TYPE_ICON = 'Icon';
    protected const TYPE_IMAGE = 'Image';
    protected const TYPE_IMAGE_SLIDER = 'ImageSlider';
    protected const TYPE_LENGTH = 'Length';
    protected const TYPE_LIST = 'List';
    protected const TYPE_NUMBER = 'Number';
    protected const TYPE_PASSWORD = 'Password';
    protected const TYPE_PHONE = 'Phone';
    protected const TYPE_POST = 'Post';
    protected const TYPE_POST_OBJECT = 'PostObject';
    protected const TYPE_POST_OBJECT_MULTI = 'PostObjectMulti';
    protected const TYPE_QR_CODE = 'QRCode';
    protected const TYPE_RADIO = 'Radio';
    protected const TYPE_RANGE = 'Range';
    protected const TYPE_RATING = 'Rating';
    protected const TYPE_REPEATER = 'Repeater';
    protected const TYPE_SELECT = 'Select';
    protected const TYPE_SELECT_MULTI = 'SelectMulti';
    protected const TYPE_TABLE = 'Table';
    protected const TYPE_TERM_OBJECT = 'TermObject';
    protected const TYPE_TERM_OBJECT_MULTI = 'TermObjectMulti';
    protected const TYPE_TEXTAREA = 'Textarea';
    protected const TYPE_TEXT = 'Text';
    protected const TYPE_TIME = 'Time';
    protected const TYPE_TOGGLE = 'Toggle';
    protected const TYPE_URL = 'Url';
    protected const TYPE_USER = 'User';
    protected const TYPE_USER_MULTI = 'UserMulti';
    protected const TYPE_VIDEO = 'Video';
    protected const TYPE_WEIGHT = 'Weight';
    protected const TYPE_ID = 'ID';

    /**
     * ACPT specific field type mapping
     *
     * @var array
     */
    protected array $acptFieldTypeMap = [
        // Text
        'Text'           => 'sentence',
        'Textarea'       => 'paragraphs',
        'Editor'         => 'paragraphs',
        'Email'          => 'safeEmail',
        'Url'            => 'url',
        'Password'       => 'password',
        'Phone'          => 'phoneNumber',

        // Number
        'Number'         => 'randomNumber',
        'Range'          => 'numberBetween',
        'Rating'         => 'numberBetween',
        'Currency'       => 'randomFloat',
        'Length'         => 'randomFloat',
        'Weight'         => 'randomFloat',

        // Date
        'Date'           => 'date',
        'Time'           => 'time',
        'DateTime'       => 'dateTime',
        'DateRange'      => 'date',

        // Media
        'Image'          => 'imageUrl',
        'ImageSlider'    => 'imageUrl',
        'Gallery'        => 'imageUrl',
        'File'           => 'url',
        'Audio'          => 'url',
        'AudioMulti'     => 'url',
        'Video'          => 'url',

        // Selection
        'Select'         => 'randomElement',
        'SelectMulti'    => 'randomElements',
        'Radio'          => 'randomElement',
        'Checkbox'       => 'randomElements',
        'Toggle'         => 'boolean',

        // Relational
        'Post'           => 'randomNumber',
        'PostObject'     => 'randomNumber',
        'PostObjectMulti' => 'randomNumber',
        'TermObject'     => 'randomNumber',
        'TermObjectMulti' => 'randomNumber',
        'User'           => 'randomNumber',
        'UserMulti'      => 'randomNumber',

        // Special
        'HTML'           => 'sentence',
        'Icon'           => 'randomElement',
        'Color'          => 'hexColor',
        'Country'        => 'countryCode',
        'Address'        => 'address',
        'AddressMulti'   => 'address',
        'Embed'          => 'url',
        'Barcode'        => 'ean13',
        'QRCode'         => 'url',
        'ID'             => 'uuid',
    ];

    /**
     * Layout/complex field types that are not directly populatable
     *
     * @var array
     */
    protected array $complexFieldTypes = [
        'Repeater',
        'FlexibleContent',
        'List',
        'Table',
        'Clone',
    ];

    /**
     * Internal map of field_name => box_name for save operations
     *
     * Populated when getFieldsForPostType() or getFieldConfig() is called.
     * This allows saveFieldValue() to find the box_name without requiring
     * an extra parameter, maintaining interface compatibility.
     *
     * @var array
     */
    protected array $fieldToBoxMap = [];

    /**
     * Constructor
     *
     * @param FakerService|null $faker
     */
    public function __construct(?FakerService $faker = null)
    {
        parent::__construct($faker);
        $this->defaultFieldTypeMap = array_merge($this->defaultFieldTypeMap, $this->acptFieldTypeMap);
    }

    /**
     * Convert PascalCase ACPT type to snake_case for pipeline compatibility
     *
     * Examples: PostObject → post_object, FlexibleContent → flexible_content,
     * HTML → html, QRCode → qr_code, DateTime → date_time
     */
    protected static function toSnakeCase(string $pascalCase): string
    {
        $result = preg_replace(
            ['/([A-Z]+)([A-Z][a-z])/', '/([a-z0-9])([A-Z])/'],
            ['$1_$2', '$1_$2'],
            $pascalCase
        );

        return strtolower($result);
    }

    /**
     * Clear all caches including the field-to-box mapping
     *
     * @return void
     */
    public function clearCache(): void
    {
        parent::clearCache();
        $this->fieldToBoxMap = [];
    }

    /**
     * Check if ACPT is active
     *
     * @return bool
     */
    public function isActive(): bool
    {
        return class_exists('ACPT\Includes\ACPT_Plugin') || defined('ACPT_PLUGIN_VERSION');
    }

    /**
     * Get the plugin name
     *
     * @return string
     */
    public function getName(): string
    {
        return 'acpt';
    }

    /**
     * Get the plugin version
     *
     * @return string
     */
    public function getVersion(): string
    {
        if (defined('ACPT_PLUGIN_VERSION')) {
            return ACPT_PLUGIN_VERSION;
        }

        return '0.0.0';
    }

    /**
     * Get all custom post types registered by ACPT
     *
     * Uses ACPT's CustomPostTypeRepository to fetch CPTs from its custom DB tables.
     *
     * @return array
     */
    public function getCustomPostTypes(): array
    {
        if ($this->cachedPostTypes !== null) {
            return $this->cachedPostTypes;
        }

        if (!$this->isActive()) {
            return [];
        }

        try {
            if (class_exists('ACPT\Core\Repository\CustomPostTypeRepository')) {
                $cptModels = \ACPT\Core\Repository\CustomPostTypeRepository::get([]);

                $this->cachedPostTypes = array_map(function ($model) {
                    return [
                        'ID'        => method_exists($model, 'getId') ? $model->getId() : '',
                        'post_type' => method_exists($model, 'getName') ? $model->getName() : '',
                        'title'     => method_exists($model, 'getPlural') ? $model->getPlural() : '',
                    ];
                }, $cptModels);

                return $this->cachedPostTypes;
            }
        } catch (\Exception $e) {
            // Fall through to empty return
        }

        $this->cachedPostTypes = [];
        return $this->cachedPostTypes;
    }

    /**
     * Get all custom taxonomies registered by ACPT
     *
     * Uses ACPT's TaxonomyRepository to fetch taxonomies from its custom DB tables.
     *
     * @return array
     */
    public function getCustomTaxonomies(): array
    {
        if ($this->cachedTaxonomies !== null) {
            return $this->cachedTaxonomies;
        }

        if (!$this->isActive()) {
            return [];
        }

        try {
            if (class_exists('ACPT\Core\Repository\TaxonomyRepository')) {
                $taxModels = \ACPT\Core\Repository\TaxonomyRepository::get([]);

                $this->cachedTaxonomies = array_map(function ($model) {
                    return [
                        'ID'       => method_exists($model, 'getId') ? $model->getId() : '',
                        'taxonomy' => method_exists($model, 'getSlug') ? $model->getSlug() : '',
                        'title'    => method_exists($model, 'getPlural') ? $model->getPlural() : '',
                    ];
                }, $taxModels);

                return $this->cachedTaxonomies;
            }
        } catch (\Exception $e) {
            // Fall through to empty return
        }

        $this->cachedTaxonomies = [];
        return $this->cachedTaxonomies;
    }

    /**
     * Get all field groups (MetaGroupModels)
     *
     * Uses ACPT's MetaRepository::get() to retrieve all meta groups.
     * Each group contains boxes, and each box contains fields.
     *
     * @return array
     */
    public function getFieldGroups(): array
    {
        if ($this->cachedFieldGroups !== null) {
            return $this->cachedFieldGroups;
        }

        if (!$this->isActive()) {
            return [];
        }

        try {
            if (class_exists('ACPT\Core\Repository\MetaRepository')) {
                $this->cachedFieldGroups = \ACPT\Core\Repository\MetaRepository::get([]);
                return $this->cachedFieldGroups;
            }
        } catch (\Exception $e) {
            // Fall through to empty return
        }

        $this->cachedFieldGroups = [];
        return $this->cachedFieldGroups;
    }

    /**
     * Get field groups for a specific post type
     *
     * Uses ACPT's MetaRepository::get() with belongsTo filter to fetch only
     * groups assigned to a specific custom post type via ACPT's BelongModel.
     *
     * @param string $postType The post type slug
     * @return array
     */
    public function getFieldGroupsForPostType(string $postType): array
    {
        if (!$this->isActive()) {
            return [];
        }

        try {
            if (class_exists('ACPT\Core\Repository\MetaRepository')) {
                // First try ACPT's built-in filtering
                $groups = \ACPT\Core\Repository\MetaRepository::get([
                    'belongsTo' => 'customPostType',
                    'find'      => $postType,
                ]);

                // Fallback: ACPT's filter may not work reliably,
                // so fetch all groups and filter manually by belongsTo
                if (empty($groups)) {
                    $allGroups = \ACPT\Core\Repository\MetaRepository::get([]);

                    foreach ($allGroups as $group) {
                        $belongs = method_exists($group, 'getBelongs') ? $group->getBelongs() : [];

                        foreach ($belongs as $belong) {
                            $belongsTo = method_exists($belong, 'getBelongsTo') ? $belong->getBelongsTo() : '';
                            $find = method_exists($belong, 'getFind') ? $belong->getFind() : '';

                            if ($belongsTo === 'customPostType' && $find === $postType) {
                                $groups[] = $group;
                                break;
                            }
                        }
                    }
                }

                return $groups;
            }
        } catch (\Exception $e) {
            error_log("WPFaker ACPT: Error fetching field groups for '{$postType}': " . $e->getMessage());
        }

        return [];
    }

    /**
     * Get fields from a field group
     *
     * Iterates through all boxes in the group and collects their fields.
     *
     * @param int|string $fieldGroupId The field group ID or name
     * @return array
     */
    public function getFields($fieldGroupId): array
    {
        if (!$this->isActive()) {
            return [];
        }

        $allGroups = $this->getFieldGroups();
        $fields = [];

        foreach ($allGroups as $group) {
            $groupId = method_exists($group, 'getId') ? $group->getId() : '';
            $groupName = method_exists($group, 'getName') ? $group->getName() : '';

            if ($groupId === $fieldGroupId || $groupName === $fieldGroupId) {
                $boxes = method_exists($group, 'getBoxes') ? $group->getBoxes() : [];

                foreach ($boxes as $box) {
                    $boxFields = method_exists($box, 'getFields') ? $box->getFields() : [];

                    foreach ($boxFields as $field) {
                        $fields[] = $this->normalizeAcptField($field, $box);
                    }
                }

                break;
            }
        }

        return $fields;
    }

    /**
     * Get all fields for a specific post type
     *
     * Fetches all field groups assigned to the post type, then iterates
     * through their boxes and fields.
     *
     * @param string $postType The post type slug
     * @return array
     */
    public function getFieldsForPostType(string $postType): array
    {
        $fieldGroups = $this->getFieldGroupsForPostType($postType);
        $allFields = [];

        foreach ($fieldGroups as $group) {
            $boxes = method_exists($group, 'getBoxes') ? $group->getBoxes() : [];

            foreach ($boxes as $box) {
                $boxFields = method_exists($box, 'getFields') ? $box->getFields() : [];

                foreach ($boxFields as $field) {
                    // Skip child fields (nested in repeaters) - they are handled by parent
                    if (method_exists($field, 'getParentId') && $field->getParentId() !== null) {
                        continue;
                    }

                    // Skip fields nested in blocks (FlexibleContent) - handled by parent
                    if (method_exists($field, 'getBlockId') && $field->getBlockId() !== null) {
                        continue;
                    }

                    $allFields[] = $this->normalizeAcptField($field, $box);
                }
            }
        }

        return $allFields;
    }

    /**
     * Normalize an ACPT MetaFieldModel to WPFaker's internal format
     *
     * Maps ACPT's object-oriented field model to a plain array format
     * compatible with the adapter pattern. Includes box_name which is
     * required by ACPT's save function.
     *
     * @param object $field ACPT MetaFieldModel
     * @param object $box ACPT MetaBoxModel
     * @return array Normalized field
     */
    protected function normalizeAcptField(object $field, object $box): array
    {
        $fieldName = method_exists($field, 'getName') ? $field->getName() : '';
        $fieldType = method_exists($field, 'getType') ? $field->getType() : 'Text';
        $boxName = method_exists($box, 'getName') ? $box->getName() : '';
        $label = method_exists($field, 'getLabel') ? $field->getLabel() : null;
        $description = method_exists($field, 'getDescription') ? $field->getDescription() : null;
        $isRequired = method_exists($field, 'isRequired') ? $field->isRequired() : false;
        $defaultValue = method_exists($field, 'getDefaultValue') ? $field->getDefaultValue() : null;

        // Extract options (for select, radio, checkbox fields)
        $choices = [];
        if (method_exists($field, 'getOptions')) {
            foreach ($field->getOptions() as $option) {
                $optValue = method_exists($option, 'getValue') ? $option->getValue() : '';
                $optLabel = method_exists($option, 'getLabel') ? $option->getLabel() : $optValue;
                $choices[$optValue] = $optLabel;
            }
        }

        // Extract advanced options (min, max, step, etc.)
        $advancedOptions = $this->extractAdvancedOptions($field);

        // Extract children for repeater fields
        $children = [];
        if (method_exists($field, 'getChildren') && method_exists($field, 'hasChildren') && $field->hasChildren()) {
            foreach ($field->getChildren() as $child) {
                $children[] = $this->normalizeAcptField($child, $box);
            }
        }

        // Extract blocks for FlexibleContent fields
        $blocks = [];
        if (method_exists($field, 'getBlocks') && method_exists($field, 'hasBlocks') && $field->hasBlocks()) {
            foreach ($field->getBlocks() as $block) {
                $blockFields = [];
                if (method_exists($block, 'getFields')) {
                    foreach ($block->getFields() as $blockField) {
                        $blockFields[] = $this->normalizeAcptField($blockField, $box);
                    }
                }

                $blocks[] = [
                    'name'   => method_exists($block, 'getName') ? $block->getName() : '',
                    'label'  => method_exists($block, 'getLabel') ? $block->getLabel() : '',
                    'fields' => $blockFields,
                ];
            }
        }

        // Extract filter_post_type for relational fields
        $filterPostType = $advancedOptions['filter_post_type'] ?? [];
        if (is_string($filterPostType) && !empty($filterPostType)) {
            $filterPostType = array_map('trim', explode(',', $filterPostType));
        }

        // Extract filter_taxonomy for term object fields
        $filterTaxonomy = $advancedOptions['filter_taxonomy'] ?? [];
        if (is_string($filterTaxonomy) && !empty($filterTaxonomy)) {
            $filterTaxonomy = array_map('trim', explode(',', $filterTaxonomy));
        }

        // Register field -> box mapping for save operations
        if (!empty($fieldName) && !empty($boxName)) {
            $this->fieldToBoxMap[$fieldName] = $boxName;
        }

        // Convert PascalCase type to snake_case for pipeline compatibility
        // (FieldConfigSchema, RELATIONAL_FIELD_TYPES, pluginSpecificTypes all use snake_case)
        $snakeType = self::toSnakeCase($fieldType);

        return [
            'name'          => $fieldName,
            'label'         => $label ?? $fieldName,
            'description'   => $description ?? '',
            'type'          => $snakeType,
            'acpt_type'     => $fieldType, // Original PascalCase for adapter's generateFakeValue()
            'required'      => $isRequired,
            'choices'       => $choices,
            'default_value' => $defaultValue,
            'min'           => $advancedOptions['min'] ?? null,
            'max'           => $advancedOptions['max'] ?? null,
            'step'          => $advancedOptions['step'] ?? null,
            'box_name'      => $boxName,
            'post_type'     => $filterPostType,
            'taxonomy'      => $filterTaxonomy,
            'children'      => $children,
            'blocks'        => $blocks,
            'prefix'        => $advancedOptions['before'] ?? '',
            'suffix'        => $advancedOptions['after'] ?? '',
            '_raw'          => $field,
        ];
    }

    /**
     * Extract advanced options from an ACPT MetaFieldModel
     *
     * Advanced options include min, max, step, filter_post_type, etc.
     *
     * @param object $field ACPT MetaFieldModel
     * @return array Key-value pairs of advanced options
     */
    protected function extractAdvancedOptions(object $field): array
    {
        $options = [];

        if (!method_exists($field, 'getAdvancedOption')) {
            return $options;
        }

        $keys = [
            'min', 'max', 'step', 'columns', 'rows', 'cols',
            'filter_post_type', 'filter_post_status', 'filter_taxonomy', 'filter_role',
            'date_format', 'time_format', 'accepts', 'multiple',
            'min_size', 'max_size', 'pattern',
            'before', 'after',
        ];

        foreach ($keys as $key) {
            $value = $field->getAdvancedOption($key);
            if ($value !== null) {
                $options[$key] = $value;
            }
        }

        return $options;
    }

    /**
     * Save a field value for a post
     *
     * Uses ACPT's save_acpt_meta_field_value() function which requires
     * both box_name and field_name. ACPT stores data in its own custom
     * database tables, NOT in wp_postmeta.
     *
     * The box_name is resolved from:
     * 1. The internal fieldToBoxMap (populated by getFieldsForPostType/getFieldConfig)
     * 2. Looking up the field via getFieldConfig() as a fallback
     *
     * @param int $postId The post ID
     * @param string $fieldName The field name
     * @param mixed $value The value to save
     * @return bool
     */
    public function saveFieldValue(int $postId, string $fieldName, $value): bool
    {
        if (!$this->isActive()) {
            return false;
        }

        // Resolve box_name from internal map
        $boxName = $this->fieldToBoxMap[$fieldName] ?? '';

        // Fallback: look up the field config to find the box_name
        if (empty($boxName)) {
            $fieldConfig = $this->getFieldConfig($fieldName);
            $boxName = $fieldConfig['box_name'] ?? '';
        }

        if (empty($boxName)) {
            error_log("WPFaker ACPT DEBUG: saveFieldValue FAILED - no box_name for field={$fieldName}");
            return false;
        }

        // Use ACPT's own save function
        if (function_exists('save_acpt_meta_field_value')) {
            try {
                $result = save_acpt_meta_field_value([
                    'post_id'    => $postId,
                    'box_name'   => $boxName,
                    'field_name' => $fieldName,
                    'value'      => $value,
                ]);

                return $result !== false;
            } catch (\Exception|\Error $e) {
                error_log("WPFaker ACPT: Failed to save field '{$fieldName}' (box='{$boxName}'): " . $e->getMessage());
                return false;
            }
        }

        return false;
    }

    /**
     * Get field configuration by name
     *
     * Searches all field groups and their boxes for a field matching
     * the given name or key.
     *
     * @param string $fieldNameOrKey The field name
     * @return array|null
     */
    public function getFieldConfig(string $fieldNameOrKey): ?array
    {
        if (!$this->isActive()) {
            return null;
        }

        $allGroups = $this->getFieldGroups();

        foreach ($allGroups as $group) {
            $boxes = method_exists($group, 'getBoxes') ? $group->getBoxes() : [];

            foreach ($boxes as $box) {
                $fields = method_exists($box, 'getFields') ? $box->getFields() : [];

                foreach ($fields as $field) {
                    $name = method_exists($field, 'getName') ? $field->getName() : '';

                    if ($name === $fieldNameOrKey) {
                        return $this->normalizeAcptField($field, $box);
                    }

                    // Check children (Repeater sub-fields)
                    if (method_exists($field, 'hasChildren') && $field->hasChildren()) {
                        foreach ($field->getChildren() as $child) {
                            $childName = method_exists($child, 'getName') ? $child->getName() : '';
                            if ($childName === $fieldNameOrKey) {
                                return $this->normalizeAcptField($child, $box);
                            }
                        }
                    }

                    // Check blocks (FlexibleContent sub-fields)
                    if (method_exists($field, 'hasBlocks') && $field->hasBlocks()) {
                        foreach ($field->getBlocks() as $block) {
                            if (method_exists($block, 'getFields')) {
                                foreach ($block->getFields() as $blockField) {
                                    $blockFieldName = method_exists($blockField, 'getName') ? $blockField->getName() : '';
                                    if ($blockFieldName === $fieldNameOrKey) {
                                        return $this->normalizeAcptField($blockField, $box);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return null;
    }

    /**
     * Map ACPT field type to Faker method
     *
     * @param array $field The field configuration
     * @return string The Faker method to use
     */
    public function mapFieldTypeToFaker(array $field): string
    {
        $type = $field['type'] ?? 'Text';
        return $this->acptFieldTypeMap[$type] ?? $this->defaultFieldTypeMap[$type] ?? 'sentence';
    }

    /**
     * Get supported field types
     *
     * @return array
     */
    public function getSupportedFieldTypes(): array
    {
        return [
            // Text
            self::TYPE_TEXT, self::TYPE_TEXTAREA, self::TYPE_EDITOR,
            self::TYPE_EMAIL, self::TYPE_URL, self::TYPE_PASSWORD, self::TYPE_PHONE,

            // Number
            self::TYPE_NUMBER, self::TYPE_RANGE, self::TYPE_RATING,
            self::TYPE_CURRENCY, self::TYPE_LENGTH, self::TYPE_WEIGHT,

            // Date/Time
            self::TYPE_DATE, self::TYPE_TIME, self::TYPE_DATE_TIME, self::TYPE_DATE_RANGE,

            // Media
            self::TYPE_IMAGE, self::TYPE_IMAGE_SLIDER, self::TYPE_GALLERY,
            self::TYPE_FILE, self::TYPE_AUDIO, self::TYPE_AUDIO_MULTI, self::TYPE_VIDEO,

            // Selection
            self::TYPE_SELECT, self::TYPE_SELECT_MULTI,
            self::TYPE_RADIO, self::TYPE_CHECKBOX, self::TYPE_TOGGLE,

            // Relational
            self::TYPE_POST, self::TYPE_POST_OBJECT, self::TYPE_POST_OBJECT_MULTI,
            self::TYPE_TERM_OBJECT, self::TYPE_TERM_OBJECT_MULTI,
            self::TYPE_USER, self::TYPE_USER_MULTI,

            // Complex
            self::TYPE_REPEATER, self::TYPE_FLEXIBLE_CONTENT,
            self::TYPE_LIST, self::TYPE_TABLE, self::TYPE_CLONE,

            // Special
            self::TYPE_HTML, self::TYPE_ICON, self::TYPE_COLOR, self::TYPE_COUNTRY,
            self::TYPE_ADDRESS, self::TYPE_ADDRESS_MULTI, self::TYPE_EMBED,
            self::TYPE_BARCODE, self::TYPE_QR_CODE, self::TYPE_ID,
        ];
    }

    /**
     * Generate a fake value based on field configuration
     *
     * Handles all ACPT field types including complex nested types.
     *
     * @param array $field The field configuration
     * @return mixed The generated value
     */
    public function generateFakeValue(array $field): mixed
    {
        // Use original PascalCase type for internal matching (match uses TYPE_ constants)
        $type = $field['acpt_type'] ?? $field['type'] ?? 'Text';
        $fieldName = $field['name'] ?? '';
        $faker = $this->getLocaleFaker();

        // For text-based fields, try smart detection first
        if (in_array($type, [self::TYPE_TEXT, self::TYPE_TEXTAREA, self::TYPE_NUMBER, self::TYPE_RANGE])) {
            $smartValue = $this->fieldDetector->detectAndGenerate($fieldName, $field, $this->locale);
            if ($smartValue !== null) {
                if (in_array($type, [self::TYPE_NUMBER, self::TYPE_RANGE])) {
                    return is_numeric($smartValue) ? $smartValue : null;
                }
                return $smartValue;
            }
        }

        return match ($type) {
            // Text
            self::TYPE_TEXT        => $faker->sentence(rand(3, 8)),
            self::TYPE_TEXTAREA    => implode("\n\n", $faker->paragraphs(rand(2, 4))),
            self::TYPE_EDITOR      => $this->generateWysiwyg($field),
            self::TYPE_EMAIL       => $faker->safeEmail(),
            self::TYPE_URL         => $faker->url(),
            self::TYPE_PASSWORD    => $faker->password(8, 16),
            self::TYPE_PHONE       => $faker->phoneNumber(),

            // Number
            self::TYPE_NUMBER      => $this->generateNumber($field),
            self::TYPE_RANGE       => $this->generateRange($field),
            self::TYPE_RATING      => rand(1, 5),
            self::TYPE_CURRENCY    => $this->generateCurrencyValue(),
            self::TYPE_LENGTH      => $this->generateLengthValue(),
            self::TYPE_WEIGHT      => $this->generateWeightValue(),

            // Date/Time
            self::TYPE_DATE        => $this->generateSmartDate($fieldName, 'Y-m-d'),
            self::TYPE_TIME        => $faker->time('H:i:s'),
            self::TYPE_DATE_TIME   => $this->generateSmartDate($fieldName, 'Y-m-d H:i:s'),
            self::TYPE_DATE_RANGE  => $this->generateDateRange(),

            // Media
            self::TYPE_IMAGE       => $this->generateImageId($field),
            self::TYPE_IMAGE_SLIDER => $this->generateGallery($field),
            self::TYPE_GALLERY     => $this->generateGallery($field),
            self::TYPE_FILE        => $this->generateFileValue($field),
            self::TYPE_AUDIO       => $this->generateAudioValue(),
            self::TYPE_AUDIO_MULTI => $this->generateAudioMultiValue(),
            self::TYPE_VIDEO       => $this->generateVideoUrl(),

            // Selection — use ACPT-specific methods that handle empty choices
            self::TYPE_SELECT      => $this->generateAcptSelect($field),
            self::TYPE_SELECT_MULTI => $this->generateAcptSelectMulti($field),
            self::TYPE_RADIO       => $this->generateAcptRadio($field),
            self::TYPE_CHECKBOX    => $this->generateAcptCheckbox($field),
            self::TYPE_TOGGLE      => (int) $faker->boolean(),

            // Relational
            self::TYPE_POST,
            self::TYPE_POST_OBJECT      => $this->generatePostObject($field),
            self::TYPE_POST_OBJECT_MULTI => $this->generatePostObjectMulti($field),
            self::TYPE_TERM_OBJECT       => $this->generateTermObject($field),
            self::TYPE_TERM_OBJECT_MULTI => $this->generateTermObjectMulti($field),
            self::TYPE_USER              => $this->generateUser(),
            self::TYPE_USER_MULTI        => $this->generateUserMulti(),

            // Complex
            self::TYPE_REPEATER          => $this->generateRepeaterValue($field),
            self::TYPE_FLEXIBLE_CONTENT  => $this->generateFlexibleContentValue($field),
            self::TYPE_LIST              => $this->generateListValue($field),
            self::TYPE_TABLE             => $this->generateTableValue($field),
            self::TYPE_CLONE             => null, // Clone fields are resolved by ACPT itself

            // Special
            // ACPT's HTML field uses sanitize_text_field() which strips tags
            self::TYPE_HTML        => $faker->paragraph(),
            self::TYPE_ICON        => $this->generateIcon(),
            self::TYPE_COLOR       => $faker->hexColor(),
            self::TYPE_COUNTRY     => $this->generateCountryValue(),
            self::TYPE_ADDRESS     => $this->generateAddressString(),
            self::TYPE_ADDRESS_MULTI => $this->generateAddressMulti(),
            self::TYPE_EMBED       => $this->generateOembed(),
            self::TYPE_BARCODE     => $this->generateBarcodeValue(),
            self::TYPE_QR_CODE     => $faker->url(),
            self::TYPE_ID          => strtoupper(substr(md5(uniqid((string) mt_rand(), true)), 0, 12)),

            // Fallback to parent adapter
            default                => parent::generateFakeValue($field),
        };
    }

    /**
     * Generate currency value in ACPT's expected array format
     */
    protected function generateCurrencyValue(): array
    {
        $faker = $this->getLocaleFaker();
        $currencies = ['EUR', 'USD', 'GBP', 'CHF', 'JPY'];

        return [
            'amount' => round($faker->randomFloat(2, 1, 9999), 2),
            'unit'   => $currencies[array_rand($currencies)],
        ];
    }

    /**
     * Generate weight value in ACPT's expected array format
     */
    protected function generateWeightValue(): array
    {
        $faker = $this->getLocaleFaker();
        $units = ['GRAM', 'KILOGRAM', 'POUND', 'OUNCE'];

        return [
            'weight' => round($faker->randomFloat(2, 0.1, 1000), 2),
            'unit'   => $units[array_rand($units)],
        ];
    }

    /**
     * Generate length value in ACPT's expected array format
     */
    protected function generateLengthValue(): array
    {
        $faker = $this->getLocaleFaker();
        $units = ['METER', 'CENTIMETER', 'KILOMETER', 'INCH', 'FOOT'];

        return [
            'length' => round($faker->randomFloat(2, 0.1, 1000), 2),
            'unit'   => $units[array_rand($units)],
        ];
    }

    /**
     * Generate country value in ACPT's expected array format
     */
    protected function generateCountryValue(): array
    {
        $faker = $this->getLocaleFaker();

        return [
            'value'   => $faker->country(),
            'country' => strtolower($faker->countryCode()),
        ];
    }

    /**
     * Generate address as plain string (ACPT auto-geocodes it)
     */
    protected function generateAddressString(): string
    {
        $faker = $this->getLocaleFaker();

        return $faker->streetAddress() . ', ' . $faker->postcode() . ' ' . $faker->city();
    }

    /**
     * Generate file value in ACPT's expected array format
     */
    protected function generateFileValue(array $field = []): array
    {
        $fileId = $this->generateFileId($field);
        $url = $fileId > 0 ? wp_get_attachment_url($fileId) : '';

        return [
            'id'    => (string) $fileId,
            'url'   => $url ?: '',
            'label' => '',
        ];
    }

    /**
     * Generate barcode value in ACPT's expected array format
     */
    protected function generateBarcodeValue(): array
    {
        $faker = $this->getLocaleFaker();
        $formats = ['code128', 'ean13', 'ean8', 'code39'];

        return [
            'value'  => $faker->ean13(),
            'format' => $formats[array_rand($formats)],
            'color'  => '#000000',
        ];
    }

    /**
     * Generate ACPT Select value with fallback choices
     */
    protected function generateAcptSelect(array $field): string
    {
        $choices = $field['choices'] ?? [];

        if (!empty($choices)) {
            $keys = array_keys($choices);
            return (string) $keys[array_rand($keys)];
        }

        // Fallback: generate contextual options based on field name
        $fallbackChoices = $this->generateFallbackChoices($field['name'] ?? '');
        return $fallbackChoices[array_rand($fallbackChoices)];
    }

    /**
     * Generate ACPT SelectMulti value with fallback choices
     */
    protected function generateAcptSelectMulti(array $field): array
    {
        $choices = $field['choices'] ?? [];

        if (!empty($choices)) {
            $keys = array_keys($choices);
            $count = rand(1, min(3, count($keys)));
            shuffle($keys);
            return array_map('strval', array_slice($keys, 0, $count));
        }

        $fallbackChoices = $this->generateFallbackChoices($field['name'] ?? '');
        $count = rand(1, min(3, count($fallbackChoices)));
        shuffle($fallbackChoices);
        return array_slice($fallbackChoices, 0, $count);
    }

    /**
     * Generate ACPT Radio value with fallback choices
     */
    protected function generateAcptRadio(array $field): string
    {
        $choices = $field['choices'] ?? [];

        if (!empty($choices)) {
            $keys = array_keys($choices);
            return (string) $keys[array_rand($keys)];
        }

        $fallbackChoices = $this->generateFallbackChoices($field['name'] ?? '');
        return $fallbackChoices[array_rand($fallbackChoices)];
    }

    /**
     * Generate ACPT Checkbox value with fallback choices
     */
    protected function generateAcptCheckbox(array $field): array
    {
        $choices = $field['choices'] ?? [];

        if (!empty($choices)) {
            $keys = array_keys($choices);
            $count = rand(1, min(3, count($keys)));
            shuffle($keys);
            return array_map('strval', array_slice($keys, 0, $count));
        }

        $fallbackChoices = $this->generateFallbackChoices($field['name'] ?? '');
        $count = rand(1, min(3, count($fallbackChoices)));
        shuffle($fallbackChoices);
        return array_slice($fallbackChoices, 0, $count);
    }

    /**
     * Generate fallback choices when ACPT field has no defined options
     */
    protected function generateFallbackChoices(string $fieldName): array
    {
        $faker = $this->getLocaleFaker();
        $nameLower = strtolower($fieldName);

        // Try to detect context from field name
        if (str_contains($nameLower, 'status')) {
            return ['active', 'inactive', 'pending', 'archived'];
        }
        if (str_contains($nameLower, 'priorit')) {
            return ['low', 'medium', 'high', 'critical'];
        }
        if (str_contains($nameLower, 'typ') || str_contains($nameLower, 'type') || str_contains($nameLower, 'art')) {
            return ['type_a', 'type_b', 'type_c', 'type_d'];
        }
        if (str_contains($nameLower, 'farbe') || str_contains($nameLower, 'color')) {
            return ['red', 'blue', 'green', 'black', 'white', 'silver'];
        }
        if (str_contains($nameLower, 'size') || str_contains($nameLower, 'groesse') || str_contains($nameLower, 'größe')) {
            return ['small', 'medium', 'large', 'xl'];
        }
        if (str_contains($nameLower, 'kategori') || str_contains($nameLower, 'categor')) {
            return ['category_1', 'category_2', 'category_3', 'category_4'];
        }

        // Generic fallback
        return ['option_1', 'option_2', 'option_3', 'option_4', 'option_5'];
    }

    /**
     * Generate audio value — ACPT expects attachment ID (int) or URL
     */
    protected function generateAudioValue(): int
    {
        $id = $this->generateAudioFile();

        // Return the attachment ID — ACPT resolves URL internally
        return $id > 0 ? $id : 0;
    }

    /**
     * Generate audio multi value — ACPT expects array of attachment IDs
     */
    protected function generateAudioMultiValue(): array
    {
        return $this->generateAudioFiles();
    }

    /**
     * Generate a date range value
     *
     * ACPT DateRange stores start and end dates.
     *
     * @return array
     */
    protected function generateDateRange(): array
    {
        $faker = $this->getLocaleFaker();
        $start = $faker->dateTimeBetween('-1 year', 'now');
        $end = $faker->dateTimeBetween($start, '+1 year');

        // ACPT expects numeric keys [0 => startDate, 1 => endDate]
        return [
            $start->format('Y-m-d'),
            $end->format('Y-m-d'),
        ];
    }

    /**
     * Generate an audio file attachment ID
     *
     * @return int
     */
    protected function generateAudioFile(): int
    {
        $attachments = get_posts([
            'post_type'      => 'attachment',
            'post_mime_type' => 'audio',
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ]);

        if (!empty($attachments)) {
            return $attachments[array_rand($attachments)];
        }

        // Fallback to any attachment
        $allAttachments = get_posts([
            'post_type'      => 'attachment',
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ]);

        return !empty($allAttachments) ? $allAttachments[array_rand($allAttachments)] : 0;
    }

    /**
     * Generate multiple audio file attachment IDs
     *
     * @return array
     */
    protected function generateAudioFiles(): array
    {
        $count = rand(1, 3);
        $ids = [];

        for ($i = 0; $i < $count; $i++) {
            $id = $this->generateAudioFile();
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return $ids;
    }

    /**
     * Generate a video URL
     *
     * @return string
     */
    protected function generateVideoUrl(): string
    {
        $videos = [
            'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
            'https://www.youtube.com/watch?v=9bZkp7q19f0',
            'https://vimeo.com/148751763',
            'https://www.youtube.com/watch?v=jNQXAC9IVRw',
        ];

        return $videos[array_rand($videos)];
    }

    /**
     * Generate post object value (multi-select)
     *
     * @param array $field
     * @return array
     */
    protected function generatePostObjectMulti(array $field): array
    {
        $postTypes = $field['post_type'] ?? ['post'];

        if (!is_array($postTypes)) {
            $postTypes = [$postTypes];
        }

        if (empty($postTypes)) {
            $postTypes = ['post'];
        }

        $posts = get_posts([
            'post_type'      => $postTypes,
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ]);

        if (empty($posts)) {
            return [];
        }

        $count = rand(1, min(3, count($posts)));
        shuffle($posts);

        return array_slice($posts, 0, $count);
    }

    /**
     * Generate term object value (single)
     *
     * @param array $field
     * @return int
     */
    protected function generateTermObject(array $field): int
    {
        $taxonomy = $field['taxonomy'] ?? ['category'];

        if (is_array($taxonomy)) {
            $taxonomy = !empty($taxonomy) ? $taxonomy[0] : 'category';
        }

        $terms = get_terms([
            'taxonomy'   => $taxonomy,
            'hide_empty' => false,
            'fields'     => 'ids',
            'number'     => 50,
        ]);

        if (is_wp_error($terms) || empty($terms)) {
            return 0;
        }

        return $terms[array_rand($terms)];
    }

    /**
     * Generate term object value (multi-select)
     *
     * @param array $field
     * @return array
     */
    protected function generateTermObjectMulti(array $field): array
    {
        $taxonomy = $field['taxonomy'] ?? ['category'];

        if (is_array($taxonomy)) {
            $taxonomy = !empty($taxonomy) ? $taxonomy[0] : 'category';
        }

        $terms = get_terms([
            'taxonomy'   => $taxonomy,
            'hide_empty' => false,
            'fields'     => 'ids',
            'number'     => 50,
        ]);

        if (is_wp_error($terms) || empty($terms)) {
            return [];
        }

        $count = rand(1, min(3, count($terms)));
        shuffle($terms);

        return array_slice($terms, 0, $count);
    }

    /**
     * Generate multi-user value
     *
     * @return array
     */
    protected function generateUserMulti(): array
    {
        $users = get_users([
            'fields' => 'ID',
            'number' => 50,
        ]);

        if (empty($users)) {
            return [get_current_user_id()];
        }

        $count = rand(1, min(3, count($users)));
        shuffle($users);

        return array_slice($users, 0, $count);
    }

    /**
     * Generate repeater value
     *
     * ACPT Repeater fields contain children (sub-fields). Each row is
     * an associative array of sub-field values.
     *
     * @param array $field
     * @return array
     */
    protected function generateRepeaterValue(array $field): array
    {
        $children = $field['children'] ?? [];

        if (empty($children)) {
            return [];
        }

        $min = (int) ($field['min'] ?? 1);
        $max = (int) ($field['max'] ?? 3);
        $count = rand($min, $max);
        $rows = [];

        for ($i = 0; $i < $count; $i++) {
            $row = [];
            foreach ($children as $child) {
                $childName = $child['name'] ?? '';
                if (!empty($childName)) {
                    $row[$childName] = $this->generateFakeValue($child);
                }
            }
            $rows[] = $row;
        }

        return $rows;
    }

    /**
     * Generate FlexibleContent value
     *
     * ACPT FlexibleContent fields contain blocks, each with their own fields.
     *
     * @param array $field
     * @return array
     */
    protected function generateFlexibleContentValue(array $field): array
    {
        $blocks = $field['blocks'] ?? [];

        if (empty($blocks)) {
            return [];
        }

        $count = rand(1, min(3, count($blocks)));
        $rows = [];

        for ($i = 0; $i < $count; $i++) {
            $block = $blocks[array_rand($blocks)];
            $blockName = $block['name'] ?? '';
            $blockFields = $block['fields'] ?? [];

            $row = ['block_name' => $blockName];

            foreach ($blockFields as $blockField) {
                $fieldName = $blockField['name'] ?? '';
                if (!empty($fieldName)) {
                    $row[$fieldName] = $this->generateFakeValue($blockField);
                }
            }

            $rows[] = $row;
        }

        return $rows;
    }

    /**
     * Generate List value
     *
     * ACPT List fields are simple repeating single-value arrays.
     *
     * @param array $field
     * @return array
     */
    protected function generateListValue(array $field): array
    {
        $faker = $this->getLocaleFaker();
        $count = rand(2, 5);
        $items = [];

        for ($i = 0; $i < $count; $i++) {
            $items[] = $faker->sentence(rand(2, 5));
        }

        return $items;
    }

    /**
     * Generate Table value
     *
     * ACPT Table fields store data as a 2D array (rows and columns).
     *
     * @param array $field
     * @return array
     */
    protected function generateTableValue(array $field): array
    {
        $faker = $this->getLocaleFaker();
        $rows = (int) ($field['rows'] ?? rand(2, 4));
        $cols = (int) ($field['cols'] ?? rand(2, 4));
        $table = [];

        // Header row
        $header = [];
        for ($c = 0; $c < $cols; $c++) {
            $header[] = ucfirst($faker->word());
        }
        $table[] = $header;

        // Data rows
        for ($r = 0; $r < $rows; $r++) {
            $row = [];
            for ($c = 0; $c < $cols; $c++) {
                $row[] = $faker->sentence(rand(1, 3));
            }
            $table[] = $row;
        }

        return $table;
    }

    /**
     * Generate an icon value
     *
     * Returns a Font Awesome icon class which is commonly used by ACPT.
     *
     * @return string
     */
    protected function generateIcon(): string
    {
        $icons = [
            'fa-solid fa-house',
            'fa-solid fa-user',
            'fa-solid fa-envelope',
            'fa-solid fa-phone',
            'fa-solid fa-star',
            'fa-solid fa-heart',
            'fa-solid fa-gear',
            'fa-solid fa-check',
            'fa-solid fa-circle-info',
            'fa-solid fa-location-dot',
            'fa-solid fa-calendar',
            'fa-solid fa-clock',
        ];

        return $icons[array_rand($icons)];
    }

    /**
     * Generate an address value
     *
     * ACPT Address field stores structured address data.
     *
     * @return array
     */
    protected function generateAddress(): array
    {
        $faker = $this->getLocaleFaker();

        return [
            'address'   => $faker->streetAddress(),
            'city'      => $faker->city(),
            'state'     => $faker->state(),
            'zip'       => $faker->postcode(),
            'country'   => $faker->country(),
            'lat'       => (string) $faker->latitude(),
            'lng'       => (string) $faker->longitude(),
        ];
    }

    /**
     * Generate an address multi value
     *
     * ACPT stores multiple addresses as a single string separated by ___###___
     * (Address::fetchMulti() calls explode('___###___', $value))
     */
    protected function generateAddressMulti(): string
    {
        $count = rand(1, 3);
        $addresses = [];

        for ($i = 0; $i < $count; $i++) {
            $addresses[] = $this->generateAddressString();
        }

        return implode('___###___', $addresses);
    }

    /**
     * Populate all ACPT fields for a post
     *
     * @param int $postId The post ID to populate
     * @param string|null $postType The post type (auto-detected if null)
     * @return array Array of field names and their generated values
     */
    public function populatePostFields(int $postId, ?string $postType = null): array
    {
        if (!$postType) {
            $postType = get_post_type($postId);
        }

        $fields = $this->getFieldsForPostType($postType);
        $generatedValues = [];

        foreach ($fields as $field) {
            $fieldName = $field['name'] ?? '';
            $boxName = $field['box_name'] ?? '';

            if (empty($fieldName) || empty($boxName)) {
                continue;
            }

            // Generate fake value based on field type
            $value = $this->generateFakeValue($field);

            if ($value === null) {
                continue;
            }

            // Save the field value using ACPT's save function
            // box_name is resolved internally via fieldToBoxMap
            $this->saveFieldValue($postId, $fieldName, $value);

            $generatedValues[$fieldName] = [
                'type'     => $field['type'] ?? 'Text',
                'box_name' => $boxName,
                'value'    => $value,
            ];
        }

        return $generatedValues;
    }
}
