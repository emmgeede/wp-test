<?php

namespace WPFaker\Adapters;

use WPFaker\Services\FakerService;

/**
 * Custom Post Type UI Adapter
 *
 * Adapter for CPT UI plugin. CPT UI only manages custom post types and taxonomies,
 * not custom fields. All field-related methods return empty values.
 */
class CptuiAdapter extends AbstractFieldPluginAdapter
{
    /**
     * Constructor
     *
     * @param FakerService|null $faker
     */
    public function __construct(?FakerService $faker = null)
    {
        parent::__construct($faker);
    }

    /**
     * Check if CPT UI is active
     *
     * @return bool
     */
    public function isActive(): bool
    {
        return function_exists('cptui_get_post_type_data') || defined('CPT_VERSION');
    }

    /**
     * Get the adapter name
     *
     * @return string
     */
    public function getName(): string
    {
        return 'Custom Post Type UI';
    }

    /**
     * Get the CPT UI version
     *
     * @return string
     */
    public function getVersion(): string
    {
        if (defined('CPT_VERSION')) {
            return CPT_VERSION;
        }

        return '0.0.0';
    }

    /**
     * Get custom post types registered by CPT UI
     *
     * @return array Array of normalized post type configurations
     */
    public function getCustomPostTypes(): array
    {
        if ($this->cachedPostTypes !== null) {
            return $this->cachedPostTypes;
        }

        if (!function_exists('cptui_get_post_type_data')) {
            $this->cachedPostTypes = [];
            return $this->cachedPostTypes;
        }

        $cptData = cptui_get_post_type_data();

        if (empty($cptData) || !is_array($cptData)) {
            $this->cachedPostTypes = [];
            return $this->cachedPostTypes;
        }

        $postTypes = [];

        foreach ($cptData as $slug => $config) {
            $postTypes[] = [
                'id' => $slug,
                'slug' => $slug,
                'name' => $config['label'] ?? $slug,
                'labels' => [
                    'singular' => $config['singular_label'] ?? $slug,
                    'plural' => $config['label'] ?? $slug,
                ],
            ];
        }

        $this->cachedPostTypes = $postTypes;
        return $this->cachedPostTypes;
    }

    /**
     * Get custom taxonomies registered by CPT UI
     *
     * @return array Array of normalized taxonomy configurations
     */
    public function getCustomTaxonomies(): array
    {
        if ($this->cachedTaxonomies !== null) {
            return $this->cachedTaxonomies;
        }

        if (!function_exists('cptui_get_taxonomy_data')) {
            $this->cachedTaxonomies = [];
            return $this->cachedTaxonomies;
        }

        $taxData = cptui_get_taxonomy_data();

        if (empty($taxData) || !is_array($taxData)) {
            $this->cachedTaxonomies = [];
            return $this->cachedTaxonomies;
        }

        $taxonomies = [];

        foreach ($taxData as $slug => $config) {
            $taxonomies[] = [
                'id' => $slug,
                'slug' => $slug,
                'name' => $config['label'] ?? $slug,
                'labels' => [
                    'singular' => $config['singular_label'] ?? $slug,
                    'plural' => $config['label'] ?? $slug,
                ],
            ];
        }

        $this->cachedTaxonomies = $taxonomies;
        return $this->cachedTaxonomies;
    }

    /**
     * Get all field groups (none - CPT UI has no fields)
     *
     * @return array
     */
    public function getFieldGroups(): array
    {
        return [];
    }

    /**
     * Get field groups for a specific post type (none - CPT UI has no fields)
     *
     * @param string $postType The post type slug
     * @return array
     */
    public function getFieldGroupsForPostType(string $postType): array
    {
        return [];
    }

    /**
     * Get fields from a field group (none - CPT UI has no fields)
     *
     * @param int|string $fieldGroupId The field group ID or key
     * @return array
     */
    public function getFields($fieldGroupId): array
    {
        return [];
    }

    /**
     * Get all fields for a specific post type (none - CPT UI has no fields)
     *
     * @param string $postType The post type slug
     * @return array
     */
    public function getFieldsForPostType(string $postType): array
    {
        return [];
    }

    /**
     * Save a field value for a post (no-op - CPT UI has no fields)
     *
     * @param int $postId The post ID
     * @param string $fieldName The field name/key
     * @param mixed $value The value to save
     * @return bool
     */
    public function saveFieldValue(int $postId, string $fieldName, $value): bool
    {
        return false;
    }

    /**
     * Get field configuration by name or key (none - CPT UI has no fields)
     *
     * @param string $fieldNameOrKey The field name or key
     * @return array|null
     */
    public function getFieldConfig(string $fieldNameOrKey): ?array
    {
        return null;
    }

    /**
     * Get supported field types (none - CPT UI has no fields)
     *
     * @return array
     */
    public function getSupportedFieldTypes(): array
    {
        return [];
    }
}
