<?php

namespace WPFaker\Adapters;

use WPFaker\Services\FakerService;

/**
 * ACF (Advanced Custom Fields) Adapter
 *
 * Adapter for Advanced Custom Fields (free version).
 * Handles detection and generation of fake data for ACF field types.
 */
class AcfAdapter extends AbstractFieldPluginAdapter
{
    /**
     * Plugin file path for activation check
     */
    protected const PLUGIN_FILE = 'advanced-custom-fields/acf.php';

    /**
     * Constructor
     *
     * @param FakerService|null $faker
     */
    public function __construct(?FakerService $faker = null)
    {
        parent::__construct($faker);
    }

    /**
     * Check if ACF is active
     *
     * @return bool
     */
    public function isActive(): bool
    {
        // Don't report active if ACF Pro is installed (it has its own adapter)
        if (defined('ACF_PRO') && ACF_PRO) {
            return false;
        }

        return class_exists('ACF') || function_exists('acf_get_field_groups');
    }

    /**
     * Get the plugin name
     *
     * @return string
     */
    public function getName(): string
    {
        return 'Advanced Custom Fields';
    }

    /**
     * Get the plugin version
     *
     * @return string
     */
    public function getVersion(): string
    {
        if (defined('ACF_VERSION')) {
            return ACF_VERSION;
        }

        if (defined('ACF_MAJOR_VERSION')) {
            return ACF_MAJOR_VERSION . '.0.0';
        }

        return '0.0.0';
    }

    /**
     * Get all custom post types registered by ACF
     *
     * ACF 6.1+ stores custom post types as posts with post_type 'acf-post-type'
     *
     * @return array
     */
    public function getCustomPostTypes(): array
    {
        if ($this->cachedPostTypes !== null) {
            return $this->cachedPostTypes;
        }

        if (!$this->isActive()) {
            return [];
        }

        // ACF 6.1+ uses acf_get_post_types function
        if (function_exists('acf_get_acf_post_types')) {
            $this->cachedPostTypes = acf_get_acf_post_types();
            return $this->cachedPostTypes;
        }

        // Fallback: Query the database directly
        $postTypes = get_posts([
            'post_type'      => 'acf-post-type',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
        ]);

        $this->cachedPostTypes = array_map(function ($post) {
            $config = maybe_unserialize($post->post_content);
            return array_merge([
                'ID'        => $post->ID,
                'post_type' => $post->post_name,
                'title'     => $post->post_title,
            ], is_array($config) ? $config : []);
        }, $postTypes);

        return $this->cachedPostTypes;
    }

    /**
     * Get all custom taxonomies registered by ACF
     *
     * ACF 6.1+ stores custom taxonomies as posts with post_type 'acf-taxonomy'
     *
     * @return array
     */
    public function getCustomTaxonomies(): array
    {
        if ($this->cachedTaxonomies !== null) {
            return $this->cachedTaxonomies;
        }

        if (!$this->isActive()) {
            return [];
        }

        // ACF 6.1+ uses acf_get_taxonomies function
        if (function_exists('acf_get_acf_taxonomies')) {
            $this->cachedTaxonomies = acf_get_acf_taxonomies();
            return $this->cachedTaxonomies;
        }

        // Fallback: Query the database directly
        $taxonomies = get_posts([
            'post_type'      => 'acf-taxonomy',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
        ]);

        $this->cachedTaxonomies = array_map(function ($post) {
            $config = maybe_unserialize($post->post_content);
            return array_merge([
                'ID'       => $post->ID,
                'taxonomy' => $post->post_name,
                'title'    => $post->post_title,
            ], is_array($config) ? $config : []);
        }, $taxonomies);

        return $this->cachedTaxonomies;
    }

    /**
     * Get all field groups
     *
     * @return array
     */
    public function getFieldGroups(): array
    {
        if ($this->cachedFieldGroups !== null) {
            return $this->cachedFieldGroups;
        }

        if (!$this->isActive() || !function_exists('acf_get_field_groups')) {
            return [];
        }

        $this->cachedFieldGroups = acf_get_field_groups();
        return $this->cachedFieldGroups;
    }

    /**
     * Get field groups for a specific post type
     *
     * @param string $postType The post type slug
     * @return array
     */
    public function getFieldGroupsForPostType(string $postType): array
    {
        if (!$this->isActive() || !function_exists('acf_get_field_groups')) {
            return [];
        }

        // Get all field groups (including local PHP-registered ones)
        $allGroups = acf_get_field_groups();
        $matchingGroups = [];

        foreach ($allGroups as $group) {
            // Check if this field group applies to the post type
            $locations = $group['location'] ?? [];

            foreach ($locations as $locationGroup) {
                foreach ($locationGroup as $rule) {
                    $param = $rule['param'] ?? '';
                    $operator = $rule['operator'] ?? '==';
                    $value = $rule['value'] ?? '';

                    // Check for post_type match
                    if ($param === 'post_type') {
                        if ($operator === '==' && $value === $postType) {
                            $matchingGroups[] = $group;
                            break 2; // Found a match, move to next group
                        }
                        if ($operator === '==' && $value === 'all') {
                            $matchingGroups[] = $group;
                            break 2;
                        }
                    }
                }
            }
        }

        return $matchingGroups;
    }

    /**
     * Get fields from a field group
     *
     * @param int|string $fieldGroupId The field group ID or key
     * @return array
     */
    public function getFields($fieldGroupId): array
    {
        if (!$this->isActive() || !function_exists('acf_get_fields')) {
            return [];
        }

        $fields = acf_get_fields($fieldGroupId);
        return is_array($fields) ? $fields : [];
    }

    /**
     * Get all fields for a specific post type
     *
     * @param string $postType The post type slug
     * @return array
     */
    public function getFieldsForPostType(string $postType): array
    {
        $fieldGroups = $this->getFieldGroupsForPostType($postType);
        $allFields = [];

        foreach ($fieldGroups as $fieldGroup) {
            // For local field groups (PHP registered), use 'key'
            // For database field groups, use 'ID'
            $groupKey = $fieldGroup['key'] ?? null;
            $groupId = $fieldGroup['ID'] ?? null;

            // Try key first (works for local field groups), then ID
            $identifier = $groupKey ?: $groupId;

            if ($identifier) {
                $fields = $this->getFields($identifier);
                $allFields = array_merge($allFields, $this->flattenFields($fields));
            }
        }

        // Deduplicate by field name (keep first occurrence)
        $seen = [];
        $unique = [];
        foreach ($allFields as $field) {
            $name = $field['name'] ?? '';
            if ($name !== '' && !isset($seen[$name])) {
                $seen[$name] = true;
                $unique[] = $field;
            }
        }

        return $unique;
    }

    /**
     * Flatten nested fields (from groups, repeaters, etc.) into a single array
     *
     * @param array $fields
     * @return array
     */
    protected function flattenFields(array $fields): array
    {
        $flattened = [];

        foreach ($fields as $field) {
            // Skip layout-only fields
            $type = $field['type'] ?? '';
            if (in_array($type, ['tab', 'accordion', 'message'])) {
                continue;
            }

            $flattened[] = $field;

            // Include sub-fields for group, repeater, flexible_content
            if (!empty($field['sub_fields'])) {
                foreach ($field['sub_fields'] as $subField) {
                    $subField['parent_field'] = $field['name'];
                    $flattened[] = $subField;
                }
            }

            // Include layout sub-fields for flexible content
            if (!empty($field['layouts'])) {
                foreach ($field['layouts'] as $layout) {
                    if (!empty($layout['sub_fields'])) {
                        foreach ($layout['sub_fields'] as $subField) {
                            $subField['parent_field'] = $field['name'];
                            $subField['layout'] = $layout['name'];
                            $flattened[] = $subField;
                        }
                    }
                }
            }
        }

        return $flattened;
    }

    /**
     * Save a field value for a post
     *
     * @param int $postId The post ID
     * @param string $fieldName The field name/key
     * @param mixed $value The value to save
     * @return bool
     */
    public function saveFieldValue(int $postId, string $fieldName, $value): bool
    {
        if (!$this->isActive() || !function_exists('update_field')) {
            return false;
        }

        // Get field definition to check type
        $field = acf_get_field($fieldName);

        if ($field && in_array($field['type'], ['repeater', 'flexible_content', 'group'])) {
            // Use native format for complex fields - saves BOTH serialized array AND individual meta keys
            return $this->saveComplexFieldValue($postId, $fieldName, $value, $field);
        }

        // Standard save for simple fields
        return update_field($fieldName, $value, $postId) !== false;
    }

    /**
     * Save complex field (repeater, flexible_content, group) in ACF's native format
     *
     * @param int $postId
     * @param string $fieldName
     * @param mixed $value
     * @param array $field ACF field definition
     * @return bool
     */
    protected function saveComplexFieldValue(int $postId, string $fieldName, $value, array $field): bool
    {
        $fieldType = $field['type'];
        $fieldKey = $field['key'];

        // Delete existing data first
        delete_field($fieldName, $postId);

        if ($fieldType === 'group') {
            return $this->saveGroupFieldNative($postId, $fieldName, $fieldKey, $value, $field['sub_fields'] ?? []);
        }

        if ($fieldType === 'repeater') {
            return $this->saveRepeaterFieldNative($postId, $fieldName, $fieldKey, $value, $field['sub_fields'] ?? []);
        }

        if ($fieldType === 'flexible_content') {
            return $this->saveFlexibleContentFieldNative($postId, $fieldName, $fieldKey, $value, $field['layouts'] ?? []);
        }

        return false;
    }

    /**
     * Save a group field in ACF's native format
     */
    protected function saveGroupFieldNative(int $postId, string $fieldName, string $fieldKey, array $value, array $subFields): bool
    {
        // Save the serialized array for the group
        update_post_meta($postId, $fieldName, $value);
        update_post_meta($postId, '_' . $fieldName, $fieldKey);

        // Build sub-field key map
        $subFieldKeys = [];
        foreach ($subFields as $sf) {
            $subFieldKeys[$sf['name']] = $sf['key'];
        }

        // Save each sub-field
        foreach ($value as $subFieldName => $subValue) {
            $metaKey = $fieldName . '_' . $subFieldName;
            $subFieldKey = $subFieldKeys[$subFieldName] ?? '';

            update_post_meta($postId, $metaKey, $subValue);
            if ($subFieldKey) {
                update_post_meta($postId, '_' . $metaKey, $subFieldKey);
            }
        }

        return true;
    }

    /**
     * Save a repeater field in ACF's native format
     *
     * ACF stores repeater as:
     * - Main meta key: row COUNT (integer), e.g., 3
     * - Sub-field meta keys: {fieldname}_{rowindex}_{subfieldname}
     */
    protected function saveRepeaterFieldNative(int $postId, string $fieldName, string $fieldKey, array $rows, array $subFields): bool
    {
        // ACF expects the row COUNT, not the full array!
        $rowCount = count($rows);
        update_post_meta($postId, $fieldName, $rowCount);
        update_post_meta($postId, '_' . $fieldName, $fieldKey);

        // Build sub-field key map
        $subFieldKeys = [];
        foreach ($subFields as $sf) {
            $subFieldKeys[$sf['name']] = $sf['key'];
        }

        // Save each row's sub-fields
        foreach ($rows as $rowIndex => $row) {
            foreach ($row as $subFieldName => $subValue) {
                $metaKey = $fieldName . '_' . $rowIndex . '_' . $subFieldName;
                $subFieldKey = $subFieldKeys[$subFieldName] ?? '';

                update_post_meta($postId, $metaKey, $subValue);
                if ($subFieldKey) {
                    update_post_meta($postId, '_' . $metaKey, $subFieldKey);
                }
            }
        }

        return true;
    }

    /**
     * Save a flexible content field in ACF's native format
     *
     * ACF stores flexible content as:
     * - Main meta key: array of layout names (e.g., ['video', 'image_gallery', 'call_to_action'])
     * - Sub-field meta keys: {fieldname}_{rowindex}_{subfieldname}
     */
    protected function saveFlexibleContentFieldNative(int $postId, string $fieldName, string $fieldKey, array $rows, array $layouts): bool
    {
        // ACF expects the main meta to be just the layout names, NOT the full data!
        $layoutNames = array_map(fn($row) => $row['acf_fc_layout'] ?? '', $rows);
        update_post_meta($postId, $fieldName, $layoutNames);
        update_post_meta($postId, '_' . $fieldName, $fieldKey);

        // Build layout and sub-field key maps
        $layoutSubFieldKeys = [];
        foreach ($layouts as $layout) {
            $layoutName = $layout['name'];
            $layoutSubFieldKeys[$layoutName] = [];
            foreach ($layout['sub_fields'] ?? [] as $sf) {
                $layoutSubFieldKeys[$layoutName][$sf['name']] = $sf['key'];
            }
        }

        // Save each row's sub-fields
        foreach ($rows as $rowIndex => $row) {
            $layoutName = $row['acf_fc_layout'] ?? '';

            foreach ($row as $subFieldName => $subValue) {
                // Skip the layout identifier, it's already saved in the main array
                if ($subFieldName === 'acf_fc_layout') {
                    continue;
                }

                $metaKey = $fieldName . '_' . $rowIndex . '_' . $subFieldName;

                // Get sub-field key from layout
                $subFieldKey = $layoutSubFieldKeys[$layoutName][$subFieldName] ?? '';

                update_post_meta($postId, $metaKey, $subValue);
                if ($subFieldKey) {
                    update_post_meta($postId, '_' . $metaKey, $subFieldKey);
                }
            }
        }

        return true;
    }

    /**
     * Get field configuration by name or key
     *
     * @param string $fieldNameOrKey The field name or key
     * @return array|null
     */
    public function getFieldConfig(string $fieldNameOrKey): ?array
    {
        if (!$this->isActive() || !function_exists('acf_get_field')) {
            return null;
        }

        $field = acf_get_field($fieldNameOrKey);
        return $field ?: null;
    }

    /**
     * Get ACF-specific supported field types
     *
     * @return array
     */
    public function getSupportedFieldTypes(): array
    {
        return [
            // Basic
            'text',
            'textarea',
            'number',
            'range',
            'email',
            'url',
            'password',

            // Content
            'wysiwyg',
            'oembed',
            'image',
            'file',
            'gallery',

            // Choice
            'select',
            'checkbox',
            'radio',
            'button_group',
            'true_false',

            // Relational
            'link',
            'post_object',
            'page_link',
            'relationship',
            'taxonomy',
            'user',

            // jQuery
            'google_map',
            'date_picker',
            'date_time_picker',
            'time_picker',
            'color_picker',

            // Layout (Pro only - will be overridden in AcfProAdapter)
            // 'message',
            // 'accordion',
            // 'tab',
            // 'group',
            // 'repeater',
            // 'flexible_content',
            // 'clone',
        ];
    }

    /**
     * Generate fake data for a post and all its ACF fields
     *
     * @param int $postId The post ID to populate
     * @param string|null $postType The post type (auto-detected if null)
     * @return array Array of field names and their generated values
     */
    public function populatePostFields(int $postId, ?string $postType = null): array
    {
        if (!$postType) {
            $postType = get_post_type($postId);
        }

        $fields = $this->getFieldsForPostType($postType);
        $generatedValues = [];

        foreach ($fields as $field) {
            $fieldName = $field['name'] ?? '';
            $fieldKey = $field['key'] ?? '';

            if (empty($fieldName)) {
                continue;
            }

            // Generate fake value based on field type
            $value = $this->generateFakeValue($field);

            // Save the field value
            $this->saveFieldValue($postId, $fieldKey ?: $fieldName, $value);

            $generatedValues[$fieldName] = [
                'type'  => $field['type'] ?? 'text',
                'value' => $value,
            ];
        }

        return $generatedValues;
    }

    /**
     * Get location rules for field groups
     *
     * This helps understand which post types, taxonomies, etc. a field group applies to.
     *
     * @param array $fieldGroup The field group configuration
     * @return array Parsed location rules
     */
    public function parseLocationRules(array $fieldGroup): array
    {
        $locations = $fieldGroup['location'] ?? [];
        $parsed = [
            'post_types'   => [],
            'taxonomies'   => [],
            'users'        => false,
            'options'      => false,
            'attachments'  => false,
            'nav_menus'    => false,
            'widgets'      => false,
            'comments'     => false,
            'block_editor' => false,
        ];

        foreach ($locations as $group) {
            foreach ($group as $rule) {
                $param = $rule['param'] ?? '';
                $operator = $rule['operator'] ?? '==';
                $value = $rule['value'] ?? '';

                if ($operator !== '==') {
                    continue;
                }

                switch ($param) {
                    case 'post_type':
                        if ($value === 'all') {
                            $parsed['post_types'] = get_post_types(['public' => true]);
                        } else {
                            $parsed['post_types'][] = $value;
                        }
                        break;

                    case 'taxonomy':
                        if ($value === 'all') {
                            $parsed['taxonomies'] = get_taxonomies(['public' => true]);
                        } else {
                            $parsed['taxonomies'][] = $value;
                        }
                        break;

                    case 'current_user_role':
                    case 'user_form':
                    case 'user_role':
                        $parsed['users'] = true;
                        break;

                    case 'options_page':
                        $parsed['options'] = true;
                        break;

                    case 'attachment':
                        $parsed['attachments'] = true;
                        break;

                    case 'nav_menu':
                    case 'nav_menu_item':
                        $parsed['nav_menus'] = true;
                        break;

                    case 'widget':
                        $parsed['widgets'] = true;
                        break;

                    case 'comment':
                        $parsed['comments'] = true;
                        break;

                    case 'block':
                        $parsed['block_editor'] = true;
                        break;
                }
            }
        }

        // Remove duplicates
        $parsed['post_types'] = array_unique($parsed['post_types']);
        $parsed['taxonomies'] = array_unique($parsed['taxonomies']);

        return $parsed;
    }

    /**
     * Get taxonomy assignment constraints from ACF field config.
     *
     * @param array $field Normalized field config
     * @return array ['mode' => 'single'|'multiple', 'min' => int, 'max' => int|null] or [] if not taxonomy
     */
    public function getTaxonomyConstraints(array $field): array
    {
        $fieldType = $field['type'] ?? '';
        if ($fieldType !== 'taxonomy') {
            return [];
        }

        $uiType = $field['field_type'] ?? 'checkbox';

        // radio and select = single term
        if (in_array($uiType, ['radio', 'select'], true)) {
            return [
                'mode' => 'single',
                'min'  => 1,
                'max'  => 1,
            ];
        }

        // checkbox and multi_select = multiple terms
        $min = isset($field['min']) && $field['min'] !== '' ? (int) $field['min'] : 1;
        $max = isset($field['max']) && $field['max'] !== '' ? (int) $field['max'] : null;

        return [
            'mode' => 'multiple',
            'min'  => $min,
            'max'  => $max,
        ];
    }

    /**
     * Get all post types that have ACF field groups assigned
     *
     * @return array Array of post type slugs
     */
    public function getPostTypesWithFields(): array
    {
        $fieldGroups = $this->getFieldGroups();
        $postTypes = [];

        foreach ($fieldGroups as $fieldGroup) {
            $locations = $this->parseLocationRules($fieldGroup);
            $postTypes = array_merge($postTypes, $locations['post_types']);
        }

        return array_unique($postTypes);
    }

    /**
     * Check if a post type has ACF fields
     *
     * @param string $postType
     * @return bool
     */
    public function postTypeHasFields(string $postType): bool
    {
        $fieldGroups = $this->getFieldGroupsForPostType($postType);
        return !empty($fieldGroups);
    }
}
