<?php

namespace WPFaker\Adapters;

/**
 * ACF Pro Adapter
 *
 * Adapter for Advanced Custom Fields Pro.
 * Extends the base ACF adapter with Pro-specific field types.
 */
class AcfProAdapter extends AcfAdapter
{
    /**
     * Plugin file path for activation check
     */
    protected const PLUGIN_FILE = 'advanced-custom-fields-pro/acf.php';

    /**
     * Check if ACF Pro is active
     *
     * @return bool
     */
    public function isActive(): bool
    {
        // Check for Pro-specific constant
        if (defined('ACF_PRO') && ACF_PRO) {
            return true;
        }

        // Alternative check: Pro has repeater field type registered
        // Must check for non-null AND non-false (acf_get_field_type returns null if not found)
        if (function_exists('acf_get_field_type')) {
            $repeater = acf_get_field_type('repeater');
            return $repeater !== null && $repeater !== false;
        }

        return false;
    }

    /**
     * Get the plugin name
     *
     * @return string
     */
    public function getName(): string
    {
        return 'Advanced Custom Fields Pro';
    }

    /**
     * Get ACF Pro supported field types
     *
     * @return array
     */
    public function getSupportedFieldTypes(): array
    {
        // Get base ACF field types
        $baseTypes = parent::getSupportedFieldTypes();

        // Add Pro-specific field types
        $proTypes = [
            'repeater',
            'flexible_content',
            'gallery',
            'clone',
            'group',
        ];

        return array_merge($baseTypes, $proTypes);
    }

    /**
     * Generate fake value for ACF Pro specific fields
     *
     * @param array $field The field configuration
     * @return mixed
     */
    public function generateFakeValue(array $field): mixed
    {
        $type = $field['type'] ?? 'text';

        // Handle Pro-specific fields
        return match ($type) {
            'repeater' => $this->generateRepeater($field),
            'flexible_content' => $this->generateFlexibleContent($field),
            'clone' => $this->generateClone($field),
            'group' => $this->generateGroup($field),
            default => parent::generateFakeValue($field),
        };
    }

    /**
     * Generate clone field value
     *
     * Clone fields duplicate other field(s), so we need to get the cloned field config
     *
     * @param array $field
     * @return mixed
     */
    protected function generateClone(array $field): mixed
    {
        $clonedFields = $field['sub_fields'] ?? [];

        // If it's a seamless clone (no wrapper), return values for each sub-field
        if (isset($field['display']) && $field['display'] === 'seamless') {
            $values = [];
            foreach ($clonedFields as $subField) {
                $values[$subField['name']] = $this->generateFakeValue($subField);
            }
            return $values;
        }

        // If it has a wrapper, treat it like a group
        return $this->generateGroup(['sub_fields' => $clonedFields]);
    }

    /**
     * Save repeater field value properly
     *
     * Repeater fields need special handling for sub-fields
     *
     * @param int $postId
     * @param string $fieldName
     * @param array $rows
     * @param array $field
     * @return bool
     */
    public function saveRepeaterField(int $postId, string $fieldName, array $rows, array $field): bool
    {
        if (!function_exists('update_field')) {
            return false;
        }

        // ACF handles the serialization internally
        return update_field($fieldName, $rows, $postId) !== false;
    }

    /**
     * Save flexible content field value
     *
     * @param int $postId
     * @param string $fieldName
     * @param array $layouts
     * @param array $field
     * @return bool
     */
    public function saveFlexibleContentField(int $postId, string $fieldName, array $layouts, array $field): bool
    {
        if (!function_exists('update_field')) {
            return false;
        }

        return update_field($fieldName, $layouts, $postId) !== false;
    }

    /**
     * Get options pages registered with ACF Pro
     *
     * @return array
     */
    public function getOptionsPages(): array
    {
        if (!function_exists('acf_get_options_pages')) {
            return [];
        }

        return acf_get_options_pages() ?: [];
    }

    /**
     * Get field groups for options pages
     *
     * @return array
     */
    public function getFieldGroupsForOptions(): array
    {
        if (!$this->isActive() || !function_exists('acf_get_field_groups')) {
            return [];
        }

        $allGroups = $this->getFieldGroups();
        $optionsGroups = [];

        foreach ($allGroups as $group) {
            $locations = $this->parseLocationRules($group);
            if ($locations['options']) {
                $optionsGroups[] = $group;
            }
        }

        return $optionsGroups;
    }

    /**
     * Populate options page fields with fake data
     *
     * @param string $optionsPageSlug The options page slug (default: 'options')
     * @return array Generated values
     */
    public function populateOptionsFields(string $optionsPageSlug = 'options'): array
    {
        if (!function_exists('update_field')) {
            return [];
        }

        $fieldGroups = $this->getFieldGroupsForOptions();
        $generatedValues = [];

        foreach ($fieldGroups as $fieldGroup) {
            $fields = $this->getFields($fieldGroup['ID'] ?? $fieldGroup['key']);

            foreach ($fields as $field) {
                $fieldName = $field['name'] ?? '';
                $fieldKey = $field['key'] ?? '';

                if (empty($fieldName)) {
                    continue;
                }

                $value = $this->generateFakeValue($field);

                // Save to options
                update_field($fieldKey ?: $fieldName, $value, $optionsPageSlug);

                $generatedValues[$fieldName] = [
                    'type'  => $field['type'] ?? 'text',
                    'value' => $value,
                ];
            }
        }

        return $generatedValues;
    }

    /**
     * Get registered ACF blocks
     *
     * @return array
     */
    public function getAcfBlocks(): array
    {
        if (!function_exists('acf_get_block_types')) {
            return [];
        }

        return acf_get_block_types() ?: [];
    }

    /**
     * Check if a specific Pro feature is available
     *
     * @param string $feature One of: repeater, flexible_content, gallery, options, blocks
     * @return bool
     */
    public function hasProFeature(string $feature): bool
    {
        if (!$this->isActive()) {
            return false;
        }

        return match ($feature) {
            'repeater' => function_exists('acf_get_field_type') && acf_get_field_type('repeater'),
            'flexible_content' => function_exists('acf_get_field_type') && acf_get_field_type('flexible_content'),
            'gallery' => function_exists('acf_get_field_type') && acf_get_field_type('gallery'),
            'options' => function_exists('acf_add_options_page'),
            'blocks' => function_exists('acf_register_block_type') || function_exists('acf_register_block'),
            default => false,
        };
    }
}
