<?php

namespace WPFaker\Contracts;

/**
 * Interface for Field Type Mappers
 *
 * Maps field types to appropriate Faker methods.
 */
interface FieldTypeMapperInterface
{
    /**
     * Map a field type to a Faker method
     *
     * @param string $fieldType The field type slug
     * @param array $fieldConfig Additional field configuration
     * @return string The Faker method name
     */
    public function mapToFakerMethod(string $fieldType, array $fieldConfig = []): string;

    /**
     * Generate a value for a field type
     *
     * @param string $fieldType The field type slug
     * @param array $fieldConfig Additional field configuration
     * @return mixed The generated value
     */
    public function generateValue(string $fieldType, array $fieldConfig = []): mixed;

    /**
     * Check if a field type is supported
     *
     * @param string $fieldType The field type slug
     * @return bool
     */
    public function isSupported(string $fieldType): bool;

    /**
     * Get all supported field types
     *
     * @return array
     */
    public function getSupportedTypes(): array;

    /**
     * Register a custom mapper for a field type
     *
     * @param string $fieldType The field type slug
     * @param callable $mapper The mapper callback
     * @return self
     */
    public function registerMapper(string $fieldType, callable $mapper): self;
}
