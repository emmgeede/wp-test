<?php

namespace WPFaker\Contracts;

/**
 * AI Provider Interface
 *
 * Contract for AI-powered field type detection providers.
 */
interface AiProviderInterface
{
    /**
     * Get the provider key (e.g. 'gemini', 'anthropic', 'openai')
     */
    public function getProviderKey(): string;

    /**
     * Get the human-readable provider name
     */
    public function getProviderName(): string;

    /**
     * Check if the provider is enabled and has an API key configured
     */
    public function isAvailable(): bool;

    /**
     * Check if AI is enabled (regardless of API key)
     */
    public function isEnabled(): bool;

    /**
     * Get the API key masked for display
     */
    public function getMaskedApiKey(): string;

    /**
     * Detect field type for a single field
     *
     * @param string $fieldName The field name
     * @param string $fieldLabel The field label
     * @param string $fieldType The ACF field type
     * @param string|null $locale The locale for generation
     * @return array|null Detection result with 'type' and 'confidence' keys, or null
     */
    public function detectFieldType(
        string $fieldName,
        string $fieldLabel,
        string $fieldType,
        ?string $locale
    ): ?array;

    /**
     * Detect field types for all fields of a CPT in a single batch API call
     *
     * @param array $fields Array of ['name' => string, 'label' => string, 'type' => string]
     * @param string $postType The CPT slug
     * @param string|null $postTypeLabel The CPT label for context
     * @param string|null $locale The locale
     * @return array|null Associative array: ['field_name' => ['type' => string, 'confidence' => float]]
     */
    public function detectFieldsBatch(
        array $fields,
        string $postType,
        ?string $postTypeLabel,
        ?string $locale
    ): ?array;

    /**
     * Detect field types with complete faker configs
     *
     * @param array $fields Array of ['name' => string, 'label' => string, 'type' => string]
     * @param string $postType The CPT slug
     * @param string|null $postTypeLabel The CPT label for context
     * @param string|null $locale The locale
     * @return array|null Associative array: ['field_name' => ['method' => string, 'params' => array, 'confidence' => float]]
     */
    public function detectFieldsBatchWithConfig(
        array $fields,
        string $postType,
        ?string $postTypeLabel,
        ?string $locale
    ): ?array;

    /**
     * Generate title templates for a CPT using AI
     *
     * @param string $postType The CPT slug
     * @param string|null $postTypeLabel The CPT label for context
     * @param string|null $locale The locale for generation
     * @return array|null Array of ['template' => string, 'placeholderData' => array], or null
     */
    public function generateTitleTemplates(
        string $postType,
        ?string $postTypeLabel = null,
        ?string $locale = null,
        ?array $cptContext = null
    ): ?array;

    /**
     * Generate comprehensive CPT context for unknown/niche post types
     *
     * @param string $cptSlug The CPT slug
     * @param string|null $cptLabel The CPT display label
     * @param string|null $locale The locale for generation
     * @param array|null $taxonomies Taxonomy slugs registered for this CPT
     * @param array|null $parentCptInfo Parent CPT info for relational context cascading
     * @return array|null Context array with domain, topics, image_keywords, etc. or null on failure
     */
    public function generateCptContext(
        string $cptSlug,
        ?string $cptLabel = null,
        ?string $locale = null,
        ?array $taxonomies = null,
        ?array $parentCptInfo = null
    ): ?array;

    /**
     * Test the API connection
     *
     * @return array ['success' => bool, 'message' => string]
     */
    public function testConnection(): array;
}
