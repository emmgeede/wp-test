<?php

namespace WPFaker\Contracts;

/**
 * Interface for Content Generators
 *
 * Defines the contract for generators that create fake WordPress content.
 */
interface ContentGeneratorInterface
{
    /**
     * Generate fake content
     *
     * @param int $count Number of items to generate
     * @param array $options Additional options for generation
     * @return array Array of generated item IDs
     */
    public function generate(int $count, array $options = []): array;

    /**
     * Generate a single item
     *
     * @param array $options Options for generation
     * @return int The generated item ID
     */
    public function generateOne(array $options = []): int;

    /**
     * Delete generated content
     *
     * @param array $ids Array of IDs to delete
     * @param bool $force Whether to force delete (bypass trash)
     * @return int Number of items deleted
     */
    public function delete(array $ids, bool $force = false): int;

    /**
     * Get the content type this generator handles
     *
     * @return string The content type (e.g., 'post', 'user', 'term')
     */
    public function getContentType(): string;

    /**
     * Set the field plugin adapter to use
     *
     * @param FieldPluginAdapterInterface|null $adapter
     * @return self
     */
    public function setAdapter(?FieldPluginAdapterInterface $adapter): self;

    /**
     * Get default options for generation
     *
     * @return array
     */
    public function getDefaultOptions(): array;
}
