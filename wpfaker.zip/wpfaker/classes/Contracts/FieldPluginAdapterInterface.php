<?php

namespace WPFaker\Contracts;

/**
 * Interface for Custom Field Plugin Adapters
 *
 * This interface defines the contract that all field plugin adapters must implement.
 * Each adapter (ACF, JetEngine, MetaBox, etc.) provides plugin-specific implementations.
 */
interface FieldPluginAdapterInterface
{
    /**
     * Check if the plugin is active
     *
     * @return bool
     */
    public function isActive(): bool;

    /**
     * Get the plugin name
     *
     * @return string
     */
    public function getName(): string;

    /**
     * Get the plugin version
     *
     * @return string
     */
    public function getVersion(): string;

    /**
     * Get all custom post types registered by this plugin
     *
     * @return array Array of post type objects/arrays
     */
    public function getCustomPostTypes(): array;

    /**
     * Get all custom taxonomies registered by this plugin
     *
     * @return array Array of taxonomy objects/arrays
     */
    public function getCustomTaxonomies(): array;

    /**
     * Get all field groups
     *
     * @return array Array of field group configurations
     */
    public function getFieldGroups(): array;

    /**
     * Get field groups for a specific post type
     *
     * @param string $postType The post type slug
     * @return array Array of field group configurations
     */
    public function getFieldGroupsForPostType(string $postType): array;

    /**
     * Get fields from a field group
     *
     * @param int|string $fieldGroupId The field group ID or key
     * @return array Array of field configurations
     */
    public function getFields($fieldGroupId): array;

    /**
     * Get all fields for a specific post type (across all field groups)
     *
     * @param string $postType The post type slug
     * @return array Array of field configurations
     */
    public function getFieldsForPostType(string $postType): array;

    /**
     * Save a field value for a post
     *
     * @param int $postId The post ID
     * @param string $fieldName The field name/key
     * @param mixed $value The value to save
     * @return bool Success status
     */
    public function saveFieldValue(int $postId, string $fieldName, $value): bool;

    /**
     * Get field configuration by name or key
     *
     * @param string $fieldNameOrKey The field name or key
     * @return array|null Field configuration or null if not found
     */
    public function getFieldConfig(string $fieldNameOrKey): ?array;

    /**
     * Map internal field type to Faker method
     *
     * @param array $field The field configuration
     * @return string The Faker method to use
     */
    public function mapFieldTypeToFaker(array $field): string;

    /**
     * Get supported field types by this adapter
     *
     * @return array Array of supported field type slugs
     */
    public function getSupportedFieldTypes(): array;

    /**
     * Set CPT context for field-name-aware detection
     *
     * Allows the adapter's field name detector to disambiguate field names
     * based on the post type context (e.g. "model" in a vehicle CPT → vehicle_model).
     *
     * @param string $slug Post type slug
     * @param string|null $label Post type label
     * @return self
     */
    public function setCptContext(string $slug, ?string $label = null): self;
}
