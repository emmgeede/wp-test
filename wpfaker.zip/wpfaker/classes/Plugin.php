<?php

namespace WPFaker;

use WPFaker\Services\FakeFileService;
use WPFaker\Services\FieldDetectionCacheService;
use WPFaker\Services\HistoryService;
use WPFaker\Services\MediaCleanupService;
use WPFaker\Services\SyncService;
use WPFaker\Services\TelemetryService;
use WPFaker\Services\TemplateService;

/**
 * Main Plugin Class
 *
 * Handles plugin initialization, activation, and deactivation.
 */
class Plugin
{
    /**
     * Plugin version
     */
    public const VERSION = '0.11.0';

    /**
     * Singleton instance
     *
     * @var Plugin|null
     */
    private static ?Plugin $instance = null;

    /**
     * Get singleton instance
     *
     * @return Plugin
     */
    public static function getInstance(): Plugin
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Initialize the plugin
     *
     * @return void
     */
    public function init(): void
    {
        // Check for updates
        if (self::needsUpdate()) {
            self::update();
        }

        // Allow addons to register custom adapters and AI providers
        do_action('wpfaker_register_adapters');
        do_action('wpfaker_register_ai_providers');

        // When a template links to a target CPT, unlink all sibling templates (same post type)
        add_action('wpfaker_template_cpt_linked', function (int $templateId, string $postType, string $targetCpt, int $targetTemplateId) {
            (new Services\TemplateService())->unlinkSiblingTemplates($templateId, $postType, $targetCpt, $targetTemplateId);
        }, 10, 4);

        // Create sample files if scheduled (after activation)
        if (is_admin()) {
            self::maybeCreateSampleFiles();

            // Ensure default templates exist for all registered CPTs
            // and perform runtime maintenance (stale detection, CPT reference cleanup)
            add_action('admin_init', function () {
                $templateService = new Services\TemplateService();
                $templateService->ensureDefaultTemplates();

                // Detect stale templates and store for admin notification
                $stale = $templateService->detectStaleTemplates();
                if (!empty($stale)) {
                    set_transient('wpfaker_stale_templates', $stale, HOUR_IN_SECONDS);
                } else {
                    delete_transient('wpfaker_stale_templates');
                }

                $templateService->cleanupRelatedCptReferences();
            }, 20);
        }

        // Initialize Media Cleanup Service (hooks into before_delete_post)
        MediaCleanupService::init();

        // Register telemetry cron hook
        add_action(TelemetryService::CRON_HOOK, [new TelemetryService(), 'send']);

        // Piggyback sync check on WPFaker REST calls
        // Note: maybeSend() is blocking when sync is due (up to 15s timeout).
        // This only triggers when the server-assigned interval has elapsed.
        add_action('rest_api_init', function () {
            add_filter('rest_pre_dispatch', function ($result, $server, $request) {
                if (strpos($request->get_route(), '/wpfaker/v1/') === 0) {
                    SyncService::maybeSend();
                }
                return $result;
            }, 10, 3);
        });

        // Enable SVG uploads (WordPress blocks them by default)
        add_filter('upload_mimes', function ($mimes) {
            $mimes['svg'] = 'image/svg+xml';
            return $mimes;
        });

        add_filter('wp_check_filetype_and_ext', function ($data, $file, $filename, $mimes) {
            if (str_ends_with($filename, '.svg')) {
                $data['ext'] = 'svg';
                $data['type'] = 'image/svg+xml';
            }
            return $data;
        }, 10, 4);

        // Initialize Avatar Service (hooks into pre_get_avatar_data)
        Services\AvatarService::initHooks();

        // Initialize History auto-cleanup (removes history entries when content is deleted)
        Services\HistoryService::initHooks();

        // Initialize Admin
        if (is_admin()) {
            new Admin();
            new AdminColumns();
            new EditorIntegration();
        }

        // Initialize API
        new Api();
    }

    /**
     * Plugin activation hook
     *
     * @return void
     */
    public static function activate(): void
    {
        // Create history table
        HistoryService::createTable();

        // Create templates table
        TemplateService::createTable();

        // Create field detection cache table
        FieldDetectionCacheService::createTable();

        // Set plugin version
        update_option('wpfaker_version', self::VERSION);

        // Set default options
        $defaultOptions = [
            'delete_history_on_deactivate' => false,
            'default_post_count'           => 5,
            'default_user_count'           => 5,
            'default_term_count'           => 5,
            'locale'                       => 'auto',
        ];

        if (!get_option('wpfaker_options')) {
            add_option('wpfaker_options', $defaultOptions);
        }

        // Setup telemetry
        $telemetry = new TelemetryService();
        $telemetry->getInstanceId();
        $telemetry->scheduleCron();

        // Schedule first sync 1 hour after activation
        if (!get_option(SyncService::OPTION_NEXT_SEND)) {
            update_option(SyncService::OPTION_NEXT_SEND, time() + 3600, false);
        }

        // Flush rewrite rules
        flush_rewrite_rules();

        // Schedule sample file creation for after WordPress is fully loaded
        // This is deferred because media functions might not be available during activation
        update_option('wpfaker_create_sample_files', true);

        do_action('wpfaker_activate');
    }

    /**
     * Create sample files if needed (called from init hook)
     *
     * @return void
     */
    public static function maybeCreateSampleFiles(): void
    {
        if (get_option('wpfaker_create_sample_files')) {
            delete_option('wpfaker_create_sample_files');
            $fileService = new FakeFileService();
            $fileService->createSampleFiles();
        }
    }

    /**
     * Plugin deactivation hook
     *
     * @return void
     */
    public static function deactivate(): void
    {
        $options = get_option('wpfaker_options', []);

        // Optionally delete history and templates tables
        if (!empty($options['delete_history_on_deactivate'])) {
            HistoryService::dropTable();
            TemplateService::dropTable();
        }

        $deleteData = !empty($options['delete_history_on_deactivate']);
        do_action('wpfaker_deactivate', $deleteData);

        // Unschedule telemetry cron
        TelemetryService::unscheduleCron();

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Plugin uninstall hook
     *
     * @return void
     */
    public static function uninstall(): void
    {
        // Always delete tables on uninstall
        HistoryService::dropTable();
        TemplateService::dropTable();
        FieldDetectionCacheService::dropTable();

        // Delete options
        delete_option('wpfaker_version');
        delete_option('wpfaker_options');

        // Clean up telemetry options
        TelemetryService::cleanup();

        // Clean up sync options
        SyncService::cleanup();
    }

    /**
     * Check if plugin needs update
     *
     * @return bool
     */
    public static function needsUpdate(): bool
    {
        $currentVersion = get_option('wpfaker_version', '0.0.0');
        return version_compare($currentVersion, self::VERSION, '<');
    }

    /**
     * Run plugin update
     *
     * @return void
     */
    public static function update(): void
    {
        $currentVersion = get_option('wpfaker_version', '0.0.0');

        // Run version-specific updates
        if (version_compare($currentVersion, '0.0.3', '<')) {
            // Create history table if not exists
            HistoryService::createTable();
        }

        if (version_compare($currentVersion, '0.0.4', '<')) {
            // Create templates table if not exists
            TemplateService::createTable();
        }

        if (version_compare($currentVersion, '0.0.5', '<')) {
            // Run migrations to add field_config column
            TemplateService::runMigrations();
        }

        if (version_compare($currentVersion, '0.0.6', '<')) {
            // Schedule sample file creation for existing installations
            update_option('wpfaker_create_sample_files', true);
        }

        if (version_compare($currentVersion, '0.1.3', '<')) {
            // Create field detection cache table
            FieldDetectionCacheService::createTable();
        }

        if (version_compare($currentVersion, '0.1.4', '<')) {
            // Add faker_config column to field detection cache table
            FieldDetectionCacheService::createTable();
        }

        if (version_compare($currentVersion, '0.6.0', '<')) {
            // Setup telemetry for existing installations
            $telemetry = new TelemetryService();
            $telemetry->getInstanceId();
            $telemetry->scheduleCron();
        }

        if (version_compare($currentVersion, '0.8.0', '<')) {
            // Migrate from daily telemetry cron to piggyback sync
            TelemetryService::unscheduleCron();
            // Set initial sync time if not set
            if (!get_option(SyncService::OPTION_NEXT_SEND)) {
                update_option(SyncService::OPTION_NEXT_SEND, time() + 3600, false);
            }
        }

        if (version_compare($currentVersion, '0.10.0', '<')) {
            // Add parent_id and config_overrides columns for template inheritance
            TemplateService::runMigrations();
        }

        if (version_compare($currentVersion, '0.10.1', '<')) {
            // Migrate templates from hardcoded 'picsum' to user's default image provider
            $settings = get_option('wpfaker_options', []);
            $defaultProvider = $settings['default_image_provider'] ?? 'unsplash';
            $templateService = new TemplateService();
            foreach ($templateService->getAll() as $template) {
                if (($template['config']['image_provider'] ?? '') === 'picsum') {
                    $config = $template['config'];
                    $config['image_provider'] = $defaultProvider;
                    $templateService->update($template['id'], ['config' => $config]);
                }
            }
        }

        // Update version
        update_option('wpfaker_version', self::VERSION);
    }
}
