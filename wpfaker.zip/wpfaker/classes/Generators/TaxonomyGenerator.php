<?php

namespace WPFaker\Generators;

use WPFaker\Contracts\ContentGeneratorInterface;
use WPFaker\Contracts\FieldPluginAdapterInterface;
use WPFaker\Services\FakerService;
use WPFaker\Services\AdapterFactory;

/**
 * Taxonomy Generator
 *
 * Generates fake taxonomy terms for any taxonomy.
 */
class TaxonomyGenerator implements ContentGeneratorInterface
{
    /**
     * The Faker service
     *
     * @var FakerService
     */
    protected FakerService $faker;

    /**
     * The field plugin adapter
     *
     * @var FieldPluginAdapterInterface|null
     */
    protected ?FieldPluginAdapterInterface $adapter = null;

    /**
     * The taxonomy to generate terms for
     *
     * @var string
     */
    protected string $taxonomy = 'category';

    /**
     * Generated term IDs
     *
     * @var array
     */
    protected array $generatedIds = [];

    /**
     * Constructor
     *
     * @param FakerService|null $faker
     * @param FieldPluginAdapterInterface|null $adapter
     */
    public function __construct(?FakerService $faker = null, ?FieldPluginAdapterInterface $adapter = null)
    {
        $this->faker = $faker ?? new FakerService();
        $this->adapter = $adapter ?? AdapterFactory::getPrimaryAdapter();
    }

    /**
     * Set the taxonomy to generate terms for
     *
     * @param string $taxonomy
     * @return self
     */
    public function setTaxonomy(string $taxonomy): self
    {
        $this->taxonomy = $taxonomy;
        return $this;
    }

    /**
     * Get the taxonomy
     *
     * @return string
     */
    public function getTaxonomy(): string
    {
        return $this->taxonomy;
    }

    /**
     * Generate multiple terms
     *
     * @param int $count
     * @param array $options
     * @return array Array of generated term IDs
     */
    public function generate(int $count, array $options = []): array
    {
        $taxonomy = $options['taxonomy'] ?? $this->taxonomy;
        $locale = $options['locale'] ?? null;

        // Initialize pool: get existing terms, match patterns, exclude duplicates
        $this->initPoolForTaxonomy($taxonomy, $locale);

        $ids = [];

        for ($i = 0; $i < $count; $i++) {
            $id = $this->generateOne($options);
            if ($id === 0) {
                // Pool exhausted or term creation failed — stop early
                break;
            }
            $ids[] = $id;
        }

        return $ids;
    }

    /**
     * Initialize the term pool on FakerService for a taxonomy.
     * Fetches existing term names from DB and passes them to FakerService
     * so it can exclude them from the pool.
     *
     * @param string $taxonomy
     * @param string|null $locale
     * @return void
     */
    protected function initPoolForTaxonomy(string $taxonomy, ?string $locale = null): void
    {
        // Get existing term names to exclude from pool
        $existingTermNames = get_terms([
            'taxonomy' => $taxonomy,
            'hide_empty' => false,
            'fields' => 'names',
        ]);
        if (is_wp_error($existingTermNames)) {
            $existingTermNames = [];
        }

        // Resolve taxonomy/CPT context
        $taxonomyObj = get_taxonomy($taxonomy);
        $taxonomyLabel = $taxonomyObj ? $taxonomyObj->labels->singular_name : '';
        $cptSlug = '';
        $cptLabel = '';
        if ($taxonomyObj && !empty($taxonomyObj->object_type)) {
            $cptSlug = $taxonomyObj->object_type[0];
            $cptObj = get_post_type_object($cptSlug);
            $cptLabel = $cptObj ? $cptObj->labels->singular_name : '';
        }

        $this->faker->initTermPool($taxonomy, $existingTermNames, $taxonomyLabel, $cptSlug, $cptLabel, $locale);
    }

    /**
     * Generate multiple terms without resetting the term pool.
     * Used internally by generateHierarchy() to maintain pool state across levels.
     *
     * @param int $count
     * @param array $options
     * @return array Array of generated term IDs
     */
    protected function generateWithoutPoolReset(int $count, array $options = []): array
    {
        $ids = [];

        for ($i = 0; $i < $count; $i++) {
            $id = $this->generateOne($options);
            if ($id) {
                $ids[] = $id;
            }
        }

        return $ids;
    }

    /**
     * Generate a single term
     *
     * @param array $options
     * @return int The generated term ID
     */
    public function generateOne(array $options = []): int
    {
        $options = array_merge($this->getDefaultOptions(), $options);

        // Resolve taxonomy/CPT context for contextual term generation
        $taxonomyObj = get_taxonomy($options['taxonomy']);
        $taxonomyLabel = $taxonomyObj ? $taxonomyObj->labels->singular_name : '';
        $cptSlug = '';
        $cptLabel = '';
        if ($taxonomyObj && !empty($taxonomyObj->object_type)) {
            $cptSlug = $taxonomyObj->object_type[0];
            $cptObj = get_post_type_object($cptSlug);
            $cptLabel = $cptObj ? $cptObj->labels->singular_name : '';
        }

        // Use contextual term name based on taxonomy slug/label and CPT context
        if (empty($options['name'])) {
            $locale = $options['locale'] ?? null;
            $termName = $this->faker->contextualTermName($options['taxonomy'], $taxonomyLabel, $cptSlug, $cptLabel, $locale);

            // Empty string = pool exhausted, all possible terms already exist
            if ($termName === '') {
                return 0;
            }
        } else {
            $termName = $options['name'];
        }
        $termSlug = $options['slug'] ?: sanitize_title($termName);

        $args = [
            'slug'        => $termSlug,
            'description' => $options['description'] ?: $this->faker->termDescription(),
        ];

        // Set parent if hierarchical and provided
        if ($options['parent'] !== null) {
            $args['parent'] = $options['parent'];
        } elseif ($options['random_parent'] && $this->isHierarchical()) {
            $args['parent'] = $this->getRandomParent();
        }

        // Insert the term
        $result = wp_insert_term($termName, $options['taxonomy'], $args);

        if (is_wp_error($result)) {
            if ($result->get_error_code() === 'term_exists') {
                // Try next terms from pool (up to 5 retries)
                for ($retry = 0; $retry < 5; $retry++) {
                    $termName = $this->faker->contextualTermName(
                        $options['taxonomy'],
                        $taxonomyLabel,
                        $cptSlug ?? '',
                        $cptLabel ?? '',
                        $locale ?? null
                    );
                    // Pool exhausted — stop, don't append numbers
                    if ($termName === '') {
                        return 0;
                    }
                    $args['slug'] = \sanitize_title($termName);
                    $result = \wp_insert_term($termName, $options['taxonomy'], $args);
                    if (!\is_wp_error($result)) {
                        break;
                    }
                }
            }

            if (is_wp_error($result)) {
                return 0;
            }
        }

        $termId = $result['term_id'];
        $this->generatedIds[] = $termId;

        // Set term meta via adapter
        if ($options['populate_custom_fields'] && $this->adapter) {
            $this->populateTermMeta($termId);
        }

        // Set custom meta if provided
        if (!empty($options['meta'])) {
            foreach ($options['meta'] as $key => $value) {
                update_term_meta($termId, $key, $value);
            }
        }

        return $termId;
    }

    /**
     * Delete generated terms
     *
     * @param array $ids Term IDs to delete
     * @param bool $force Not used for terms
     * @return int Number of terms deleted
     */
    public function delete(array $ids, bool $force = false): int
    {
        $deleted = 0;

        foreach ($ids as $id) {
            $result = wp_delete_term($id, $this->taxonomy);
            if ($result && !is_wp_error($result)) {
                $deleted++;
            }
        }

        return $deleted;
    }

    /**
     * Get content type
     *
     * @return string
     */
    public function getContentType(): string
    {
        return 'term';
    }

    /**
     * Set the field plugin adapter
     *
     * @param FieldPluginAdapterInterface|null $adapter
     * @return self
     */
    public function setAdapter(?FieldPluginAdapterInterface $adapter): self
    {
        $this->adapter = $adapter;
        return $this;
    }

    /**
     * Get default options
     *
     * @return array
     */
    public function getDefaultOptions(): array
    {
        return [
            'taxonomy'               => $this->taxonomy,
            'name'                   => '',
            'slug'                   => '',
            'description'            => '',
            'parent'                 => null,
            'random_parent'          => false,
            'populate_custom_fields' => true,
            'meta'                   => [],
        ];
    }

    /**
     * Check if taxonomy is hierarchical
     *
     * @return bool
     */
    protected function isHierarchical(): bool
    {
        $taxonomy = get_taxonomy($this->taxonomy);
        return $taxonomy && $taxonomy->hierarchical;
    }

    /**
     * Get a random existing parent term
     *
     * @return int
     */
    protected function getRandomParent(): int
    {
        $terms = get_terms([
            'taxonomy'   => $this->taxonomy,
            'hide_empty' => false,
            'fields'     => 'ids',
            'number'     => 20,
        ]);

        if (is_wp_error($terms) || empty($terms)) {
            return 0;
        }

        // 50% chance of no parent even for hierarchical
        if (rand(0, 1) === 0) {
            return 0;
        }

        return $terms[array_rand($terms)];
    }

    /**
     * Populate term meta using the adapter
     *
     * @param int $termId
     * @return array
     */
    protected function populateTermMeta(int $termId): array
    {
        if (!$this->adapter || !$this->adapter->isActive()) {
            return [];
        }

        // ACF stores term fields differently
        if (method_exists($this->adapter, 'getFieldsForTaxonomy')) {
            $fields = $this->adapter->getFieldsForTaxonomy($this->taxonomy);
        } else {
            // Fallback: try to get field groups for this taxonomy
            $fields = [];
        }

        $generatedValues = [];

        foreach ($fields as $field) {
            $fieldName = $field['name'] ?? '';
            $fieldKey = $field['key'] ?? '';

            if (empty($fieldName)) {
                continue;
            }

            $value = $this->adapter->generateFakeValue($field);

            // ACF stores term meta with term_{taxonomy}_{term_id} format
            if (function_exists('update_field')) {
                update_field($fieldKey ?: $fieldName, $value, $this->taxonomy . '_' . $termId);
            } else {
                update_term_meta($termId, $fieldName, $value);
            }

            $generatedValues[$fieldName] = $value;
        }

        return $generatedValues;
    }

    /**
     * Generate a hierarchical term structure
     *
     * @param int $depth Maximum depth
     * @param int $breadth Terms per level
     * @param array $options Additional options
     * @return array Generated term IDs organized by level
     */
    public function generateHierarchy(int $depth = 3, int $breadth = 3, array $options = []): array
    {
        if (!$this->isHierarchical()) {
            return $this->generate($breadth, $options);
        }

        // Initialize pool once for the entire hierarchy so terms don't repeat across levels
        $taxonomy = $options['taxonomy'] ?? $this->taxonomy;
        $locale = $options['locale'] ?? null;
        $this->initPoolForTaxonomy($taxonomy, $locale);

        $levels = [];
        $parentIds = [0]; // Start with root

        for ($level = 0; $level < $depth; $level++) {
            $levels[$level] = [];
            $newParentIds = [];

            foreach ($parentIds as $parentId) {
                $options['parent'] = $parentId;
                $options['random_parent'] = false;

                $count = $level === 0 ? $breadth : rand(1, $breadth);
                $ids = $this->generateWithoutPoolReset($count, $options);

                $levels[$level] = array_merge($levels[$level], $ids);
                $newParentIds = array_merge($newParentIds, $ids);
            }

            $parentIds = $newParentIds;
        }

        return $levels;
    }

    /**
     * Get all generated term IDs
     *
     * @return array
     */
    public function getGeneratedIds(): array
    {
        return $this->generatedIds;
    }

    /**
     * Clear generated IDs tracking
     *
     * @return void
     */
    public function clearGeneratedIds(): void
    {
        $this->generatedIds = [];
    }
}
