<?php

namespace WPFaker\Generators;

use WPFaker\Contracts\ContentGeneratorInterface;
use WPFaker\Contracts\FieldPluginAdapterInterface;
use WPFaker\Services\FakerService;
use WPFaker\Services\AdapterFactory;
use WPFaker\Services\ImageService;
use WPFaker\Services\VariationService;
use WPFaker\Services\TaxonomyAssignmentService;
use WPFaker\Services\FieldAssignmentService;
use WPFaker\Services\AiProviderFactory;
use WPFaker\Services\FieldDetectionCacheService;
use WPFaker\Services\HiveService;
use WPFaker\Services\AvatarService;
use WPFaker\Services\DependencyResolverService;
use WPFaker\Services\CptContextService;
use WPFaker\Schema\FieldConfigSchema;
use WPFaker\Services\GenerationLogService;

/**
 * Post Generator
 *
 * Generates fake posts for any post type with maximum content variation.
 * Supports descriptive titles, auto-creation of taxonomies/authors, and multilingual content.
 */
class PostGenerator implements ContentGeneratorInterface
{
    /**
     * The Faker service
     *
     * @var FakerService
     */
    protected FakerService $faker;

    /**
     * The field plugin adapter
     *
     * @var FieldPluginAdapterInterface|null
     */
    protected ?FieldPluginAdapterInterface $adapter = null;

    /**
     * The image service
     *
     * @var ImageService
     */
    protected ImageService $imageService;

    /**
     * The variation service
     *
     * @var VariationService
     */
    protected VariationService $variation;

    /**
     * The taxonomy assignment service
     *
     * @var TaxonomyAssignmentService
     */
    protected TaxonomyAssignmentService $taxonomyAssignment;

    /**
     * The field assignment service
     *
     * @var FieldAssignmentService
     */
    protected FieldAssignmentService $fieldAssignment;

    /**
     * The post type to generate
     *
     * @var string
     */
    protected string $postType = 'post';

    /**
     * Generated post IDs (for potential cleanup)
     *
     * @var array
     */
    protected array $generatedIds = [];

    /**
     * Generated authors during this run
     *
     * @var array
     */
    protected array $generatedAuthors = [];

    /**
     * Generated terms during this run
     *
     * @var array
     */
    protected array $generatedTerms = [];

    /**
     * Pool of related post IDs from cross-CPT dependency resolution
     * Format: ['post_type' => [id1, id2, ...]]
     *
     * @var array
     */
    protected array $relatedPostPool = [];

    /**
     * Number of related posts auto-created during dependency resolution
     *
     * @var int
     */
    protected int $autoCreatedRelatedCount = 0;

    /**
     * Per-CPT auto-created counts from dependency resolution
     *
     * @var array<string, int>
     */
    protected array $autoCreatedRelatedPerCpt = [];

    /**
     * Per-CPT auto-created post IDs from dependency resolution
     *
     * @var array<string, int[]>
     */
    protected array $autoCreatedRelatedIdsPerCpt = [];

    /**
     * CPT context from AI (shared across pipelines)
     */
    protected ?array $cptContext = null;

    /**
     * Warnings collected during generation (non-fatal issues)
     *
     * @var array<string>
     */
    protected array $warnings = [];

    /**
     * Pool of reusable image attachment IDs (orphaned WPFaker media)
     *
     * @var array<int>
     */
    protected array $imagePool = [];

    /**
     * Constructor
     *
     * @param FakerService|null $faker
     * @param FieldPluginAdapterInterface|null $adapter
     * @param ImageService|null $imageService
     * @param VariationService|null $variation
     * @param TaxonomyAssignmentService|null $taxonomyAssignment
     * @param FieldAssignmentService|null $fieldAssignment
     */
    public function __construct(
        ?FakerService $faker = null,
        ?FieldPluginAdapterInterface $adapter = null,
        ?ImageService $imageService = null,
        ?VariationService $variation = null,
        ?TaxonomyAssignmentService $taxonomyAssignment = null,
        ?FieldAssignmentService $fieldAssignment = null
    ) {
        $this->faker = $faker ?? new FakerService();
        $this->adapter = $adapter ?? AdapterFactory::getPrimaryAdapter();
        $this->imageService = $imageService ?? new ImageService();
        $this->variation = $variation ?? new VariationService();
        $this->taxonomyAssignment = $taxonomyAssignment ?? new TaxonomyAssignmentService();
        $this->fieldAssignment = $fieldAssignment ?? new FieldAssignmentService($this->faker, $this->imageService);

        // Share adapter with FieldAssignmentService
        if ($this->adapter) {
            $this->fieldAssignment->setAdapter($this->adapter);
        }
    }

    /**
     * Set the post type to generate
     *
     * @param string $postType
     * @return self
     */
    public function setPostType(string $postType): self
    {
        $this->postType = $postType;
        return $this;
    }

    /**
     * Consume one image from the reuse pool
     *
     * @return int|null Attachment ID or null if pool is empty
     */
    public function consumeFromPool(): ?int
    {
        if (empty($this->imagePool)) {
            return null;
        }
        return array_pop($this->imagePool);
    }

    /**
     * Get the post type
     *
     * @return string
     */
    public function getPostType(): string
    {
        return $this->postType;
    }

    /**
     * Validate relationship field requirements before generation
     *
     * @param int $count Number of posts to generate
     * @param array $options Generation options
     * @return array ['valid' => bool, 'message' => string]
     */
    public function validateRelationshipRequirements(int $count, array $options = []): array
    {
        $options = array_merge($this->getDefaultOptions(), $options);
        $postType = $options['post_type'] ?? 'post';
        $useVariation = !empty($options['enable_variation']);

        // Check if post type has relational fields via adapter
        $adapter = AdapterFactory::getAdapterForPostType($postType) ?? $this->adapter;
        if (!$adapter || !$adapter->isActive()) {
            return ['valid' => true, 'message' => ''];
        }

        $fields = $adapter->getFieldsForPostType($postType);
        $hasRelationalFields = false;

        foreach ($fields as $field) {
            $fieldType = $field['type'] ?? 'text';
            if (in_array($fieldType, self::RELATIONAL_FIELD_TYPES, true)) {
                $hasRelationalFields = true;
                break;
            }
        }

        // Also check JetEngine relations
        $hasJetEngineRelations = false;
        if (method_exists($adapter, 'getRelationsForPostType')) {
            $relations = $adapter->getRelationsForPostType($postType);
            $hasJetEngineRelations = !empty($relations);
        }

        if (!$hasRelationalFields && !$hasJetEngineRelations) {
            return ['valid' => true, 'message' => ''];
        }

        // Without variation: need at least 2 posts for full interconnection
        if (!$useVariation && $count < 2) {
            return [
                'valid' => false,
                'message' => sprintf(
                    __('This post type has relationship fields. Without variation, at least 2 posts are required for full interconnection (requested: %d).', 'wpfaker'),
                    $count
                ),
            ];
        }

        return ['valid' => true, 'message' => ''];
    }

    /**
     * Generate multiple posts with maximum variation
     *
     * @param int $count Number of posts to generate
     * @param array $options Generation options
     * @return array Array of generated post IDs
     */
    public function generate(int $count, array $options = []): array
    {
        $ids = [];
        $options = array_merge($this->getDefaultOptions(), $options);

        // Chunk awareness — skip setup phases on subsequent chunks
        $chunk = (int) ($options['chunk'] ?? 0);
        $totalChunks = (int) ($options['total_chunks'] ?? 1);
        $isFirstChunk = $chunk <= 1;

        if ($totalChunks > 1) {
            GenerationLogService::log('init', sprintf('— Cycle %d/%d —', max($chunk, 1), $totalChunks));
        }

        // Set post type from options
        $this->postType = $options['post_type'] ?? 'post';

        // Set locale on FakerService BEFORE any taxonomy/author creation
        // so contextualTermName() uses the correct language
        $locale = $options['locale'] ?? null;
        if ($locale) {
            $this->faker->setLocale($locale);
        }

        // Reset generated resources tracking
        $this->generatedAuthors = [];
        $this->generatedTerms = [];
        $this->warnings = [];
        $this->variation->resetStats();

        // Wire Field Intelligence into FakerService for API query/report
        $hive = new HiveService();
        if ($hive->isEnabled()) {
            $this->faker->setHive($hive);
            if ($isFirstChunk) {
                GenerationLogService::log('detect', 'Field Intelligence (Hive) enabled');
            }
        }

        // Wire AI Provider into FakerService for title generation (Stufe 3)
        $aiProvider = AiProviderFactory::getProvider();
        if ($aiProvider && $aiProvider->isAvailable()) {
            $this->faker->setAiProvider($aiProvider);

            // Fetch CPT context (single AI call, cached 24h) — feeds all pipelines
            $cptObject = get_post_type_object($this->postType);
            $cptLabel = $cptObject ? $cptObject->labels->singular_name : null;
            if ($isFirstChunk) {
                GenerationLogService::log('ai', sprintf('Fetching CPT context for "%s"...', $cptLabel ?? $this->postType));
            }
            $contextService = new CptContextService($aiProvider);
            $taxonomySlugs = get_object_taxonomies($this->postType);
            $parentInfo = $options['parent_cpt_info'] ?? null;
            $this->cptContext = $contextService->getContext(
                $this->postType,
                $cptLabel,
                $locale,
                !empty($taxonomySlugs) ? $taxonomySlugs : null,
                $parentInfo
            );

            if ($this->cptContext) {
                $this->faker->setCptContext($this->cptContext);
                $this->fieldAssignment->setCptContextData($this->cptContext);
                if ($isFirstChunk) {
                    GenerationLogService::log('ai', sprintf('CPT context: domain "%s" — %s',
                        $this->cptContext['domain'] ?? 'unknown',
                        $this->cptContext['description'] ?? ''));
                }
            } else {
                $warning = $contextService->getLastWarning();
                if ($warning) {
                    $this->warnings[] = sprintf(
                        "AI context unavailable for '%s': %s. Content was generated using fallback patterns.",
                        $this->postType,
                        $warning
                    );
                }
            }
        }

        // Setup phases only needed on the first chunk — authors, taxonomies,
        // field detection, and dependency resolution are already done
        if ($isFirstChunk) {
            // Ensure we have authors if auto-create is enabled or author_count > 0
            // Only create/assign varied authors when the CPT supports the 'author' feature
            if (post_type_supports($this->postType, 'author')
                && ($options['auto_create_authors'] || ($options['author_count'] ?? 0) > 0)
            ) {
                $this->ensureAuthors($options);
                if (!empty($this->generatedAuthors)) {
                    GenerationLogService::log('init', sprintf('Ensured %d authors', count($this->generatedAuthors)));
                }
            }

            // Ensure we have taxonomies if auto-create is enabled
            // Also ensure terms exist when auto_taxonomies is true (assignment needs terms)
            if ($options['auto_create_taxonomies'] || $options['auto_taxonomies']) {
                GenerationLogService::log('init', 'Ensuring taxonomy terms...');
                $this->ensureTaxonomies($options);
            }

            // Trigger batch AI field detection (one API call per CPT, cached permanently)
            if ($options['populate_custom_fields']) {
                GenerationLogService::log('detect', sprintf('Analyzing custom fields for %s...', $this->postType));
                $this->ensureAiFieldDetections();
            }

            // PHASE 0: Resolve cross-CPT dependencies (auto-create related posts)
            $this->relatedPostPool = [];
            $this->autoCreatedRelatedCount = 0;
            $this->autoCreatedRelatedIdsPerCpt = [];
            $this->autoCreatedRelatedPerCpt = [];
            if ($options['auto_create_related'] ?? true) {
                GenerationLogService::log('init', 'Resolving cross-CPT dependencies...');
                $resolver = new DependencyResolverService();
                // Pass parent CPT context so auto-created related posts get domain-aware context
                $resolverOptions = $options;
                if ($this->cptContext) {
                    $cptObject = get_post_type_object($this->postType);
                    $resolverOptions['parent_cpt_info'] = [
                        'slug'    => $this->postType,
                        'label'   => $cptObject ? $cptObject->labels->singular_name : null,
                        'context' => $this->cptContext,
                    ];
                }
                // Pass main post count so related CPTs create a matching number
                $resolverOptions['count'] = $count;
                // Pass post_budget so related posts respect system capacity limits
                if (isset($options['post_budget'])) {
                    $resolverOptions['post_budget'] = $options['post_budget'];
                }
                $this->relatedPostPool = $resolver->ensureRelatedPosts($this->postType, $resolverOptions);
                $this->autoCreatedRelatedCount = $resolver->getAutoCreatedCount();
                $this->autoCreatedRelatedPerCpt = $resolver->getAutoCreatedPerCpt();
                $this->autoCreatedRelatedIdsPerCpt = $resolver->getAutoCreatedIdsPerCpt();
                if ($this->autoCreatedRelatedCount > 0) {
                    foreach ($this->autoCreatedRelatedPerCpt as $cpt => $c) {
                        GenerationLogService::log('init', sprintf('Auto-created %d %s posts (dependency)', $c, $cpt));
                    }
                }
            }
        } else {
            // Subsequent chunks: initialize empty pools (dependencies already resolved in chunk 1)
            $this->relatedPostPool = [];
            $this->autoCreatedRelatedCount = 0;
            $this->autoCreatedRelatedIdsPerCpt = [];
            $this->autoCreatedRelatedPerCpt = [];
        }

        // Set post type on image service for reuse tracking
        $this->imageService->setForPostType($this->postType);

        // Build reuse pool if media was kept during deletion
        $this->imagePool = [];
        if (!empty($options['reuse_existing_media'])) {
            $this->imagePool = ImageService::getReusablePool($this->postType);
            shuffle($this->imagePool);
        }

        // Share pool with FieldAssignmentService via callback
        $this->fieldAssignment->setImagePoolCallback(fn () => $this->consumeFromPool());

        // Store variation data for second pass (relationship fields)
        $postVariations = [];

        // FIRST PASS: Generate all posts WITHOUT relationship fields
        for ($i = 0; $i < $count; $i++) {
            GenerationLogService::log('gen', sprintf('Generating post %d/%d...', $i + 1, $count));
            $variation = $this->variation->getVariationForIndex($i, $count, $options);
            $id = $this->generateOneWithVariation($i, $count, $options, true); // excludeRelational = true
            if ($id) {
                $ids[] = $id;
                $postVariations[$id] = $variation;
            }
        }

        // SECOND PASS: Populate relationship fields now that all posts exist
        if ($options['populate_custom_fields'] && !empty($ids)) {
            GenerationLogService::log('gen', sprintf('Populating relational fields for %d posts...', count($ids)));
            $this->populateRelationshipFieldsForPosts($ids, $postVariations, $options);
        }

        // THIRD PASS: Populate JetEngine Relations (separate from meta fields)
        if ($options['populate_custom_fields'] && !empty($ids)) {
            GenerationLogService::log('gen', 'Populating JetEngine relations...');
            $this->populateJetEngineRelationsForPosts($ids, $options);
        }

        // FOURTH PASS: Populate MB Relationships (separate table, like JetEngine Relations)
        if ($options['populate_custom_fields'] && !empty($ids)) {
            GenerationLogService::log('gen', 'Populating MB Relationships...');
            $this->populateMBRelationshipsForPosts($ids, $options);
        }

        // FIFTH PASS: Reverse-populate relational fields on OTHER CPTs that point to this CPT
        if ($options['populate_custom_fields'] && !empty($ids)) {
            GenerationLogService::log('gen', 'Reverse-populating relationships...');
            $this->reversePopulateRelationships($ids);

            // Also reverse-populate for auto-created related CPTs (e.g. agencies created for agents)
            foreach ($this->relatedPostPool as $relatedCpt => $relatedIds) {
                if (!empty($relatedIds)) {
                    $this->reversePopulateRelationships($relatedIds, $relatedCpt);
                }
            }
        }

        // Report used taxonomy terms and title templates to Field Intelligence API
        if ($hive->isEnabled() && !empty($ids)) {
            GenerationLogService::log('detect', 'Reporting field usage to Hive...');
            $this->reportUsedTermsAndTemplates($hive, $locale, $options);
        }

        /**
         * Fires after all items are generated (all passes complete).
         *
         * @param string $content_type   The content type ('post').
         * @param array  $generated_ids  Array of generated post IDs.
         * @param array  $options        Generation options.
         */
        do_action('wpfaker_after_generate', 'post', $ids, $options);

        return $ids;
    }

    /**
     * Generate a single post with variation based on index
     *
     * @param int $index Current post index (0-based)
     * @param int $total Total number of posts being generated
     * @param array $options
     * @param bool $excludeRelational Whether to exclude relational fields (for first pass)
     * @return int The generated post ID
     */
    protected function generateOneWithVariation(int $index, int $total, array $options, bool $excludeRelational = false): int
    {
        // Get variation settings for this post
        $variation = $this->variation->getVariationForIndex($index, $total, $options);
        // Use provided locale, or fall back to faker's locale (which uses WordPress locale)
        $locale = !empty($options['locale']) ? $options['locale'] : $this->faker->getLocale();

        // Determine content characteristics based on variation
        $characteristics = [
            'is_complete_example' => $variation['is_complete_example'] ?? false,
            'has_featured_image' => $variation['has_featured_image'],
            'has_excerpt' => $variation['has_excerpt'],
            'category_count' => $variation['taxonomy_count']['categories'] ?? 0,
            'tag_count' => $variation['taxonomy_count']['tags'] ?? 0,
            'custom_field_count' => 0,
            'gallery_count' => $variation['gallery_image_count'],
            'profile' => $variation['profile'],
        ];

        // Get or create author based on variation (only when CPT supports 'author')
        $author = null;
        if (post_type_supports($this->postType, 'author')) {
            $author = $this->getAuthorForVariation($variation['author_index'], $options);
            $characteristics['author_name'] = $author['display_name'] ?? '';
        }

        // Get content with varied length (skip if CPT doesn't support editor)
        $content = '';
        if (post_type_supports($this->postType, 'editor')) {
            $paragraphs = $this->variation->getContentParagraphCount($variation['content_length']);
            $content = $this->faker->contextualPostContent($paragraphs, $locale)
                ?? $this->faker->postContentVaried($paragraphs, true, true, true, $locale);
        }

        // Get date based on spread
        $postDate = $this->variation->getDateForSpread($variation['date_spread']);

        // Get post status - use variation's status if available (handles 'random' option)
        $postStatus = $variation['post_status'] ?? $options['post_status'] ?? 'publish';
        // Fallback for when variation doesn't include post_status
        if ($postStatus === 'random') {
            $statuses = ['publish', 'draft', 'pending', 'private'];
            $postStatus = $statuses[array_rand($statuses)];
        }

        // Build post data (default values)
        $postData = [
            'post_type'    => $options['post_type'],
            'post_status'  => $postStatus,
            'post_author'  => $author['ID'] ?? get_current_user_id(),
            'post_content' => $content,
            'post_date'    => $postDate,
        ];

        // Set excerpt based on variation (skip if CPT doesn't support excerpt)
        if ($variation['has_excerpt'] && post_type_supports($this->postType, 'excerpt')) {
            $postData['post_excerpt'] = $this->faker->postExcerpt(2, $locale);
            $characteristics['has_excerpt'] = true;
        }

        // Set locale on field assignment service BEFORE any field generation
        $this->fieldAssignment->setLocale($locale);
        if ($this->adapter) {
            $this->adapter->setLocale($locale);
        }

        // Apply field_config for core fields (if available)
        // This overrides the default values above based on template configuration
        if (!empty($options['field_config']['core_fields'])) {
            $coreFieldValues = $this->fieldAssignment->assignCoreFields(
                $options['field_config']['core_fields'],
                $index
            );

            // Apply core field values to post data
            foreach ($coreFieldValues as $field => $value) {
                if ($value !== null) {
                    $postData[$field] = $value;
                }
            }

            // Update characteristics based on what was set
            if (isset($coreFieldValues['post_excerpt']) && !empty($coreFieldValues['post_excerpt'])) {
                $characteristics['has_excerpt'] = true;
            }
        }

        // Insert post with temporary or configured title
        // Note: Title might be overridden by field_config or descriptive title generation later
        if (empty($postData['post_title'])) {
            $postData['post_title'] = 'WPfaker Post ' . ($index + 1);
        }

        /**
         * Filter post data before insertion.
         *
         * @param array  $postData  The post data array passed to wp_insert_post().
         * @param string $postType  The post type being generated.
         * @param int    $index     Current item index (0-based).
         * @param int    $total     Total number of items being generated.
         * @param array  $options   Generation options.
         */
        $postData = apply_filters('wpfaker_post_data', $postData, $this->postType, $index, $total, $options);

        $postId = wp_insert_post($postData, true);

        if (is_wp_error($postId)) {
            return 0;
        }

        $this->generatedIds[] = $postId;

        // Set featured image based on variation
        if ($variation['has_featured_image'] && $options['set_featured_image']) {
            // Ensure post type supports thumbnails (ACF CPTs often omit this)
            if (!post_type_supports($this->postType, 'thumbnail')) {
                add_post_type_support($this->postType, 'thumbnail');
            }
            $this->setFeaturedImage($postId, $options);
        }

        // Set custom fields via field_config (template mode) or adapter with variation (default mode)
        // IMPORTANT: This must happen BEFORE taxonomy assignment because ACF's update_field()
        // triggers acf/save_post which re-processes taxonomy fields with save_terms=1,
        // clearing any terms we've already set via wp_set_object_terms().
        if ($options['populate_custom_fields']) {
            // Set CPT context for field name detection
            $cptObject = get_post_type_object($this->postType);
            $cptLabel = $cptObject ? ($cptObject->labels->singular_name ?? null) : null;
            $this->fieldAssignment->setPostType($this->postType);
            $this->fieldAssignment->setCptContext($this->postType, $cptLabel);

            // Check if we have field_config for custom fields (template mode)
            $hasFieldConfig = !empty($options['field_config']['custom_fields']);

            if ($hasFieldConfig) {
                $customFieldValues = $this->fieldAssignment->assignCustomFields(
                    $postId,
                    $options['field_config']['custom_fields'],
                    $index
                );
                $characteristics['custom_field_count'] = count($customFieldValues);
            } elseif ($this->adapter) {
                // Fallback: Auto-generate fields for this post type based on variation
                // Build a field_config that respects the fill percentage from variation
                // In first pass, exclude relational fields (they need existing posts)
                $autoFieldConfig = $this->buildAutoFieldConfig(
                    $this->postType,
                    $variation['field_fill_percentage'],
                    $excludeRelational
                );

                if (!empty($autoFieldConfig)) {
                    $customFieldValues = $this->fieldAssignment->assignCustomFields(
                        $postId,
                        $autoFieldConfig,
                        $index
                    );
                    $characteristics['custom_field_count'] = count($customFieldValues);
                } else {
                    // Final fallback to variation-based custom field population
                    $fieldCount = $this->populateCustomFieldsWithVariation(
                        $postId,
                        $variation['field_fill_percentage']
                    );
                    $characteristics['custom_field_count'] = $fieldCount;
                }
            }
        }

        // Set taxonomies with variation (or template config if provided)
        // Done AFTER custom fields so ACF's save_terms doesn't overwrite our assignments
        $taxonomyResult = $this->setTaxonomiesWithVariation($postId, $variation, $options, $index, $total);
        $characteristics['category_count'] = $taxonomyResult['category_count'];
        $characteristics['tag_count'] = $taxonomyResult['tag_count'];

        // Generate and update title (only if not already set by field_config)
        $currentTitle = get_the_title($postId);
        $titleNeedsUpdate = empty($currentTitle) || strpos($currentTitle, 'WPfaker Post') === 0;

        // Check if field_config set the title to something specific (not a generic sentence)
        $titleConfig = $options['field_config']['core_fields']['post_title'] ?? [];
        $titleMode = $titleConfig['mode'] ?? 'none';
        $titleMethod = $titleConfig['create']['faker_method'] ?? '';
        // Generic sentence/words are NOT specific — contextual titles are better
        $fieldConfigSetTitle = $titleMode !== 'none'
            && !in_array($titleMethod, ['sentence', 'words', ''], true);
        // If field_config set a generic title (sentence/words), override it with contextual title
        $genericTitleWasSet = $titleMode !== 'none'
            && in_array($titleMethod, ['sentence', 'words', ''], true);

        if (!$fieldConfigSetTitle && ($titleNeedsUpdate || $genericTitleWasSet)) {
            $cptSlug = $options['post_type'] ?? $this->postType;
            $cptObj = get_post_type_object($cptSlug);
            $cptLabel = $cptObj ? $cptObj->labels->singular_name : '';

            // Try contextual title first (works for all CPTs, including those
            // without title support like director/actor/studio)
            $title = $this->faker->contextualPostTitle($cptSlug, $cptLabel, $locale);

            // Fall back to generic title generation only for CPTs with title support
            if (empty($title) && post_type_supports($this->postType, 'title')) {
                $title = $this->faker->postTitle(4, 10, $locale, $cptSlug, $cptLabel);
            }

            // Last resort: numbered title
            if (empty($title)) {
                $title = ucfirst($this->postType) . ' ' . ($index + 1);
            }

            wp_update_post([
                'ID' => $postId,
                'post_title' => $title,
                'post_name' => sanitize_title($title),
            ]);
        }

        // Set meta fields if provided
        if (!empty($options['meta'])) {
            foreach ($options['meta'] as $key => $value) {
                update_post_meta($postId, $key, $value);
            }
        }

        // Mark as generated by WPfaker with variation info
        update_post_meta($postId, '_wpfaker_generated', true);
        update_post_meta($postId, '_wpfaker_variation', $variation);
        update_post_meta($postId, '_wpfaker_characteristics', $characteristics);

        // Store template ID if using a template
        if (!empty($options['template_id'])) {
            update_post_meta($postId, '_wpfaker_template_id', (int) $options['template_id']);
        }

        /**
         * Fires after a single item is generated (first pass).
         *
         * @param string $content_type  The content type ('post').
         * @param int    $item_id       The generated post ID.
         * @param int    $index         Current item index (0-based).
         * @param int    $total         Total items being generated.
         * @param array  $options       Generation options.
         */
        do_action('wpfaker_after_generate_item', 'post', $postId, $index, $total, $options);

        return $postId;
    }

    /**
     * Generate a single post (simple version without variation context)
     *
     * @param array $options
     * @return int The generated post ID
     */
    public function generateOne(array $options = []): int
    {
        $options = array_merge($this->getDefaultOptions(), $options);
        return $this->generateOneWithVariation(0, 1, $options);
    }

    /**
     * Delete generated posts
     *
     * @param array $ids Post IDs to delete
     * @param bool $force Force delete (bypass trash)
     * @return int Number of posts deleted
     */
    public function delete(array $ids, bool $force = false): int
    {
        $deleted = 0;

        foreach ($ids as $id) {
            $result = wp_delete_post($id, $force);
            if ($result) {
                $deleted++;
            }
        }

        return $deleted;
    }

    /**
     * Get content type
     *
     * @return string
     */
    public function getContentType(): string
    {
        return 'post';
    }

    /**
     * Set the field plugin adapter
     *
     * @param FieldPluginAdapterInterface|null $adapter
     * @return self
     */
    public function setAdapter(?FieldPluginAdapterInterface $adapter): self
    {
        $this->adapter = $adapter;
        return $this;
    }

    /**
     * Get the adapter
     *
     * @return FieldPluginAdapterInterface|null
     */
    public function getAdapter(): ?FieldPluginAdapterInterface
    {
        return $this->adapter;
    }

    /**
     * Get default options
     *
     * @return array
     */
    public function getDefaultOptions(): array
    {
        return [
            // Post settings
            'post_type'              => $this->postType,
            'post_status'            => 'publish',
            'post_author'            => 0,
            'post_title'             => '',
            'post_content'           => '',
            'post_excerpt'           => '',
            'post_date'              => '',
            'post_name'              => '',
            'post_parent'            => 0,
            'menu_order'             => 0,
            'date_range_start'       => '-1 year',
            'date_range_end'         => 'now',

            // Image settings
            'set_featured_image'     => true,
            'download_images'        => true,
            'image_provider'         => ImageService::PROVIDER_UNSPLASH,
            'image_category'         => null,
            'image_width'            => 1200,
            'image_height'           => 800,

            // Content settings
            'populate_custom_fields' => true,
            'auto_taxonomies'        => true,
            'taxonomies'             => [],
            'meta'                   => [],

            // Variation settings
            'enable_variation'       => true,
            'variation_profile'      => VariationService::PROFILE_RANDOM,

            // Auto-creation settings
            'auto_create_authors'    => true,
            'auto_create_taxonomies' => true,
            'author_count'           => 3,
            'max_categories'         => 5,
            'max_tags'               => 8,

            // Multilingual settings
            'locale'                 => null, // null = use WordPress locale
            'available_locales'      => [FakerService::LANG_ENGLISH, FakerService::LANG_GERMAN],

            // Template settings
            'template_id'            => null, // Template ID if using a template
            'taxonomy_config'        => null, // Taxonomy configuration from template
            'field_config'           => null, // Field configuration from template (core + custom fields)

            // Cross-CPT dependency resolution
            'auto_create_related'    => true, // Auto-create related posts for cross-CPT fields
        ];
    }

    /**
     * Set featured image for a post
     *
     * @param int $postId
     * @param array $options
     * @return bool
     */
    protected function setFeaturedImage(int $postId, array $options = []): bool
    {
        // Try reusing an image from the pool first
        if (!empty($options['reuse_existing_media']) && !empty($this->imagePool)) {
            $attachmentId = array_pop($this->imagePool);
            wp_update_post(['ID' => $attachmentId, 'post_parent' => $postId]);
            return set_post_thumbnail($postId, $attachmentId);
        }

        $downloadImages = $options['download_images'] ?? true;

        if ($downloadImages) {
            $postTitle = get_the_title($postId);
            $category = !empty($options['image_category']) ? $options['image_category'] : $this->guessImageCategory($postId);

            // Use portrait dimensions for portrait/people categories
            $imgWidth = $options['image_width'] ?? 1200;
            $imgHeight = $options['image_height'] ?? 800;
            if (in_array($category, ['portrait', 'people'], true) && $imgWidth > $imgHeight) {
                // Swap to portrait orientation so Unsplash returns portrait-oriented photos
                [$imgWidth, $imgHeight] = [$imgHeight, $imgWidth];
            }

            // Download new image using ImageService
            $this->imageService
                ->setProvider($options['image_provider'] ?? ImageService::PROVIDER_UNSPLASH)
                ->setDimensions($imgWidth, $imgHeight);

            $attachmentId = $this->imageService->downloadImage(
                $postTitle . ' Featured Image',
                $category,
                $postId
            );

            if ($attachmentId) {
                return set_post_thumbnail($postId, $attachmentId);
            }
        }

        // Fallback: use existing random image from media library
        $attachmentId = $this->faker->attachmentId('image');

        if (!$attachmentId) {
            return false;
        }

        return set_post_thumbnail($postId, $attachmentId);
    }

    /**
     * Guess an appropriate image category based on post type
     *
     * @param int $postId
     * @return string|null
     */
    protected function guessImageCategory(int $postId): ?string
    {
        return ImageService::guessCategoryForPostType(get_post_type($postId), $this->cptContext);
    }

    /**
     * Set specific taxonomies for a post
     *
     * @param int $postId
     * @param array $taxonomies Array of taxonomy => terms
     * @return void
     */
    protected function setTaxonomies(int $postId, array $taxonomies): void
    {
        foreach ($taxonomies as $taxonomy => $terms) {
            wp_set_object_terms($postId, $terms, $taxonomy);
        }
    }

    /**
     * Set random taxonomies for a post
     *
     * @param int $postId
     * @return void
     */
    protected function setRandomTaxonomies(int $postId): void
    {
        $postType = get_post_type($postId);
        $taxonomies = get_object_taxonomies($postType);

        foreach ($taxonomies as $taxonomy) {
            // Skip non-public taxonomies
            $taxObject = get_taxonomy($taxonomy);
            if (!$taxObject || !$taxObject->public) {
                continue;
            }

            // Get random terms
            $terms = get_terms([
                'taxonomy'   => $taxonomy,
                'hide_empty' => false,
                'fields'     => 'ids',
                'number'     => 50,
            ]);

            if (is_wp_error($terms) || empty($terms)) {
                continue;
            }

            // Select 1-3 random terms
            $count = rand(1, min(3, count($terms)));
            shuffle($terms);
            $selectedTerms = array_slice($terms, 0, $count);

            wp_set_object_terms($postId, $selectedTerms, $taxonomy);
        }
    }

    /**
     * Populate custom fields using the adapter
     *
     * @param int $postId
     * @return array Generated field values
     */
    protected function populateCustomFields(int $postId): array
    {
        if (!$this->adapter || !$this->adapter->isActive()) {
            return [];
        }

        $postType = get_post_type($postId);
        return $this->adapter->populatePostFields($postId, $postType);
    }

    /**
     * Get all generated post IDs
     *
     * @return array
     */
    public function getGeneratedIds(): array
    {
        return $this->generatedIds;
    }

    /**
     * Clear generated IDs tracking
     *
     * @return void
     */
    public function clearGeneratedIds(): void
    {
        $this->generatedIds = [];
    }

    /**
     * Generate posts with specific templates/patterns
     *
     * @param string $template Template name
     * @param int $count Number to generate
     * @param array $options Additional options
     * @return array Generated post IDs
     */
    public function generateFromTemplate(string $template, int $count, array $options = []): array
    {
        $templateOptions = match ($template) {
            'blog' => [
                'post_type'   => 'post',
                'post_status' => 'publish',
            ],
            'draft' => [
                'post_status' => 'draft',
            ],
            'scheduled' => [
                'post_status'      => 'future',
                'date_range_start' => '+1 day',
                'date_range_end'   => '+1 month',
            ],
            'archived' => [
                'date_range_start' => '-5 years',
                'date_range_end'   => '-1 year',
            ],
            default => [],
        };

        return $this->generate($count, array_merge($templateOptions, $options));
    }

    // =========================================================================
    // Auto-creation Methods
    // =========================================================================

    /**
     * Ensure we have enough authors for varied generation
     *
     * @param array $options
     * @return void
     */
    protected function ensureAuthors(array $options): void
    {
        $neededCount = $options['author_count'] ?? 3;
        $locale = $options['locale'] ?? $this->faker->getLocale();

        // Get WPFaker-generated authors that match the current locale
        $localeAuthors = get_users([
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => '_wpfaker_generated',
                    'compare' => 'EXISTS',
                ],
                [
                    'key' => '_wpfaker_locale',
                    'value' => $locale,
                ],
            ],
            'fields' => ['ID', 'display_name'],
            'number' => 50,
        ]);

        $this->generatedAuthors = array_map(function ($user) {
            return ['ID' => $user->ID, 'display_name' => $user->display_name];
        }, $localeAuthors);

        // Create more locale-matching authors if needed (do NOT include admin/current user)
        $existingCount = count($this->generatedAuthors);
        if ($existingCount < $neededCount) {
            $userGenerator = new UserGenerator($this->faker);
            $toCreate = $neededCount - $existingCount;
            $newAuthorIds = [];

            for ($i = 0; $i < $toCreate; $i++) {
                $userId = $userGenerator->generateOne([
                    'role' => 'author',
                    'locale' => $locale,
                    'generate_avatars' => false, // We handle avatars in batch below
                ]);

                if ($userId) {
                    update_user_meta($userId, '_wpfaker_generated', true);
                    update_user_meta($userId, '_wpfaker_locale', $locale);
                    $newAuthorIds[] = $userId;

                    $user = get_user_by('ID', $userId);
                    $this->generatedAuthors[] = [
                        'ID' => $userId,
                        'display_name' => $user->display_name,
                    ];
                }
            }

            // Download avatar pool and assign to newly created authors
            if (!empty($newAuthorIds)) {
                $avatarService = new AvatarService();
                $poolSize = min(count($newAuthorIds), AvatarService::MAX_POOL_SIZE);
                $provider = $options['image_provider'] ?? 'unsplash';
                $avatarService->downloadAvatarPool($poolSize, $provider);

                foreach ($newAuthorIds as $authorId) {
                    $avatarId = $avatarService->getNextAvatar();
                    if ($avatarId) {
                        $avatarService->assignAvatarToUser($authorId, $avatarId);
                    }
                }
            }
        }
    }

    /**
     * Ensure we have enough taxonomy terms for varied generation
     *
     * @param array $options
     * @return void
     */
    protected function ensureTaxonomies(array $options): void
    {
        $postType = $options['post_type'] ?? $this->postType;
        $taxonomies = get_object_taxonomies($postType, 'objects');
        $taxonomyConfig = $options['taxonomy_config'] ?? [];

        foreach ($taxonomies as $taxonomy) {
            if (!$taxonomy->public) {
                continue;
            }

            // Skip taxonomies explicitly configured in template — TaxonomyAssignmentService handles those
            if (!empty($taxonomyConfig) && isset($taxonomyConfig[$taxonomy->name])) {
                continue;
            }

            $existingTerms = get_terms([
                'taxonomy' => $taxonomy->name,
                'hide_empty' => false,
                'fields' => 'ids',
            ]);

            if (is_wp_error($existingTerms)) {
                $existingTerms = [];
            }

            // Determine needed count based on taxonomy type
            $neededCount = $taxonomy->hierarchical
                ? ($options['max_categories'] ?? 5)
                : ($options['max_tags'] ?? 8);

            $existingCount = count($existingTerms);

            if ($existingCount < $neededCount) {
                $taxonomyGenerator = new TaxonomyGenerator($this->faker);
                $taxonomyGenerator->setTaxonomy($taxonomy->name);

                $toCreate = $neededCount - $existingCount;
                $newTermIds = $taxonomyGenerator->generate($toCreate, [
                    'locale' => $options['locale'] ?? null,
                ]);

                // Mark each new term with meta so cleanup can find them
                // even if they weren't tracked in the History service
                foreach ($newTermIds as $termId) {
                    update_term_meta($termId, '_wpfaker_generated', true);
                }

                $this->generatedTerms[$taxonomy->name] = array_merge($existingTerms, $newTermIds);
            } else {
                $this->generatedTerms[$taxonomy->name] = $existingTerms;
            }
        }

    }

    /**
     * Report used taxonomy terms and title templates to Field Intelligence API.
     * Called once at end of generate(), fire-and-forget.
     */
    protected function reportUsedTermsAndTemplates(HiveService $hive, ?string $locale, array $options): void
    {
        $cptSlug = $options['post_type'] ?? $this->postType;
        $cptObj = get_post_type_object($cptSlug);
        $cptLabel = $cptObj ? $cptObj->labels->singular_name : '';

        // Report taxonomy terms that were used/created during this run
        $taxonomyData = [];
        foreach ($this->generatedTerms as $taxonomySlug => $termIds) {
            if (empty($termIds)) {
                continue;
            }

            $terms = get_terms([
                'taxonomy' => $taxonomySlug,
                'include' => $termIds,
                'hide_empty' => false,
                'fields' => 'names',
            ]);

            if (is_wp_error($terms) || empty($terms)) {
                continue;
            }

            $taxonomyData[] = [
                'pattern' => $taxonomySlug,
                'terms' => $terms,
                'confidence' => 0.8,
            ];
        }

        if (!empty($taxonomyData)) {
            $hive->reportTaxonomyTerms($cptSlug, $cptLabel, $taxonomyData, $locale);
        }
    }

    /**
     * Get author for a specific variation index
     *
     * @param int $authorIndex
     * @param array $options
     * @return array Author data
     */
    protected function getAuthorForVariation(int $authorIndex, array $options): array
    {
        if (empty($this->generatedAuthors)) {
            // Fallback to current user
            $currentUser = wp_get_current_user();
            return [
                'ID' => $currentUser->ID,
                'display_name' => $currentUser->display_name,
            ];
        }

        $index = $authorIndex % count($this->generatedAuthors);
        return $this->generatedAuthors[$index];
    }

    /**
     * Set taxonomies with variation
     *
     * Uses TaxonomyAssignmentService when taxonomy_config is provided (template mode),
     * otherwise falls back to default variation-based assignment.
     *
     * @param int $postId
     * @param array $variation
     * @param array $options
     * @param int $postIndex Current post index (0-based)
     * @param int $totalPosts Total posts being generated
     * @return array Taxonomy counts
     */
    protected function setTaxonomiesWithVariation(int $postId, array $variation, array $options, int $postIndex = 0, int $totalPosts = 1): array
    {
        $result = [
            'category_count' => 0,
            'tag_count' => 0,
        ];

        $postType = get_post_type($postId);
        $taxonomies = get_object_taxonomies($postType, 'objects');
        $configuredTaxonomies = [];
        // Process template taxonomy config for explicitly configured taxonomies
        if (!empty($options['taxonomy_config'])) {
            $assignedTerms = $this->taxonomyAssignment->assignTaxonomies(
                $postId,
                $options['taxonomy_config'],
                $postIndex,
                $totalPosts
            );

            foreach ($assignedTerms as $taxonomyName => $termData) {
                $configuredTaxonomies[] = $taxonomyName;
                $taxonomy = $taxonomies[$taxonomyName] ?? null;
                if (!$taxonomy) {
                    continue;
                }

                $termCount = $termData['count'] ?? 0;
                if ($taxonomy->hierarchical) {
                    $result['category_count'] = $termCount;
                } else {
                    $result['tag_count'] = $termCount;
                }
            }
        }

        // Default variation-based assignment for unconfigured taxonomies
        foreach ($taxonomies as $taxonomy) {
            if (!$taxonomy->public || in_array($taxonomy->name, $configuredTaxonomies, true)) {
                continue;
            }

            // Determine count based on taxonomy type
            $count = $taxonomy->hierarchical
                ? ($variation['taxonomy_count']['categories'] ?? 0)
                : ($variation['taxonomy_count']['tags'] ?? 0);

            if ($count <= 0) {
                continue;
            }

            // Get available terms
            $availableTerms = $this->generatedTerms[$taxonomy->name] ?? [];
            if (empty($availableTerms)) {
                $availableTerms = get_terms([
                    'taxonomy' => $taxonomy->name,
                    'hide_empty' => false,
                    'fields' => 'ids',
                ]);

                if (is_wp_error($availableTerms)) {
                    continue;
                }
            }

            if (empty($availableTerms)) {
                continue;
            }

            // Select random terms
            shuffle($availableTerms);
            $selectedTerms = array_slice($availableTerms, 0, min($count, count($availableTerms)));

            wp_set_object_terms($postId, $selectedTerms, $taxonomy->name);

            // Track counts
            if ($taxonomy->hierarchical) {
                $result['category_count'] = count($selectedTerms);
            } else {
                $result['tag_count'] = count($selectedTerms);
            }
        }

        return $result;
    }

    /**
     * Populate custom fields with variation (some fields left empty)
     *
     * @param int $postId
     * @param int $fillPercentage
     * @return int Number of fields filled
     */
    protected function populateCustomFieldsWithVariation(int $postId, int $fillPercentage): int
    {
        if (!$this->adapter || !$this->adapter->isActive()) {
            return 0;
        }

        $postType = get_post_type($postId);
        $fields = $this->adapter->getFieldsForPostType($postType);
        $filledCount = 0;

        foreach ($fields as $field) {
            $fieldName = $field['name'] ?? '';
            $fieldKey = $field['key'] ?? '';
            $isRequired = $field['required'] ?? false;

            if (empty($fieldName)) {
                continue;
            }

            // Skip sub-fields - they are handled by their parent (group, repeater, etc.)
            // Sub-fields have 'parent_field' set by flattenFields()
            if (!empty($field['parent_field'])) {
                continue;
            }

            // Determine if this field should be filled
            if (!$this->variation->shouldFillField($fieldName, $fillPercentage, $isRequired)) {
                continue;
            }

            // Generate and save value
            $value = $this->adapter->generateFakeValue($field);
            if ($value !== null) {
                // Use field key if available, otherwise field name
                $this->adapter->saveFieldValue($postId, $fieldKey ?: $fieldName, $value);
                $filledCount++;
            }
        }

        return $filledCount;
    }

    /**
     * Get variation statistics from last generation run
     *
     * @return array
     */
    public function getVariationStats(): array
    {
        return $this->variation->getStats();
    }

    /**
     * Get generated authors from last run
     *
     * @return array
     */
    public function getGeneratedAuthors(): array
    {
        return $this->generatedAuthors;
    }

    /**
     * Get generated terms from last run
     *
     * @return array
     */
    public function getGeneratedTerms(): array
    {
        return $this->generatedTerms;
    }

    /**
     * Get the related post pool from cross-CPT dependency resolution
     *
     * @return array Map of post_type => post_ids[]
     */
    public function getRelatedPostPool(): array
    {
        return $this->relatedPostPool;
    }

    /**
     * Get the number of related posts auto-created during Phase 0
     *
     * @return int
     */
    public function getAutoCreatedRelatedCount(): int
    {
        return $this->autoCreatedRelatedCount;
    }

    /**
     * Get per-CPT auto-created related post counts
     *
     * @return array<string, int>
     */
    public function getAutoCreatedRelatedPerCpt(): array
    {
        return $this->autoCreatedRelatedPerCpt;
    }

    /**
     * Get per-CPT auto-created post IDs
     *
     * @return array<string, int[]>
     */
    public function getAutoCreatedIdsPerCpt(): array
    {
        return $this->autoCreatedRelatedIdsPerCpt;
    }

    /**
     * Get warnings collected during generation
     *
     * @return array<string>
     */
    public function getWarnings(): array
    {
        return $this->warnings;
    }

    /**
     * Relational field types that need existing posts to link to
     */
    protected const RELATIONAL_FIELD_TYPES = ['post_object', 'relationship', 'page_link', 'posts', 'post', 'post_object_multi', 'term_object', 'term_object_multi', 'user_multi'];

    /**
     * Populate relationship fields for all generated posts (second pass)
     *
     * This is called after all posts are created, so relationship fields
     * can now link to the newly created posts.
     *
     * @param array $postIds Array of generated post IDs
     * @param array $postVariations Variation data for each post (keyed by post ID)
     * @param array $options Generation options
     */
    protected function populateRelationshipFieldsForPosts(array $postIds, array $postVariations, array $options): void
    {
        if (!$this->adapter || !$this->adapter->isActive()) {
            return;
        }

        // Build field config for ONLY relational fields
        $relationalFieldConfig = $this->buildRelationalFieldConfig($this->postType);

        if (empty($relationalFieldConfig)) {
            return; // No relational fields to populate
        }

        $locale = !empty($options['locale']) ? $options['locale'] : $this->faker->getLocale();
        $this->fieldAssignment->setLocale($locale);

        foreach ($postIds as $index => $postId) {
            $variation = $postVariations[$postId] ?? [];
            $fillPercentage = $variation['field_fill_percentage'] ?? 100;

            // Calculate other batch IDs (all posts except current)
            $otherBatchIds = array_values(array_diff($postIds, [$postId]));

            // Filter relational fields based on fill percentage
            $fieldsToPopulate = [];
            foreach ($relationalFieldConfig as $fieldName => $config) {
                // Required fields always get populated
                $isRequired = $config['required'] ?? false;

                if ($isRequired || $fillPercentage >= 100 || mt_rand(1, 100) <= $fillPercentage) {
                    // Determine batch_post_ids: cross-CPT pool or same-batch
                    $filterPostTypes = $config['create']['filter_by_post_type'] ?? [$this->postType];
                    $crossCptIds = $this->getCrossCptIds($filterPostTypes);

                    if (!empty($crossCptIds)) {
                        // Cross-CPT: use IDs from the related post pool
                        $config['create']['batch_post_ids'] = $crossCptIds;
                    } elseif (!empty($filterPostTypes) && !in_array($this->postType, $filterPostTypes, true)) {
                        // Cross-CPT target but no pool → leave empty so DB fallback runs
                        $config['create']['batch_post_ids'] = [];
                    } else {
                        // Same-CPT: use other posts from this batch
                        $config['create']['batch_post_ids'] = $otherBatchIds;
                    }
                    $config['create']['use_variation'] = !empty($options['enable_variation']);
                    $fieldsToPopulate[$fieldName] = $config;
                }
            }

            if (!empty($fieldsToPopulate)) {
                $this->fieldAssignment->assignCustomFields($postId, $fieldsToPopulate, $index);
            }
        }
    }

    /**
     * Populate JetEngine Relations for all generated posts (third pass)
     *
     * JetEngine Relations are stored in separate database tables, not post meta.
     * This method creates relations between posts using the JetEngine Relations API.
     *
     * @param array $postIds Array of generated post IDs
     * @param array $options Generation options
     */
    protected function populateJetEngineRelationsForPosts(array $postIds, array $options): void
    {
        // Check if we have a JetEngine adapter
        $adapter = AdapterFactory::getAdapterForPostType($this->postType);

        if (!$adapter || !method_exists($adapter, 'getRelations')) {
            return;
        }

        // Check if there are any relations for this post type
        $relations = $adapter->getRelationsForPostType($this->postType);
        if (empty($relations)) {
            return;
        }

        // Populate relations for each post with batch awareness + cross-CPT pool
        $useVariation = !empty($options['enable_variation']);
        foreach ($postIds as $postId) {
            $otherBatchIds = array_values(array_diff($postIds, [$postId]));
            $adapter->populateRelationsForPost(
                $postId,
                $this->postType,
                null,
                $otherBatchIds,
                $useVariation,
                $this->relatedPostPool
            );
        }
    }

    /**
     * Populate MB Relationships for generated posts.
     *
     * MB Relationships are stored in a separate table (wp_mb_relationships),
     * not in post meta. This method creates connections using MB_Relationships_API.
     *
     * @param array $postIds Array of generated post IDs
     * @param array $options Generation options
     */
    protected function populateMBRelationshipsForPosts(array $postIds, array $options): void
    {
        $adapter = AdapterFactory::getAdapterForPostType($this->postType);

        if (!$adapter || !method_exists($adapter, 'getMBRelationships')) {
            return;
        }

        $relationships = $adapter->getMBRelationshipsForPostType($this->postType);
        if (empty($relationships)) {
            return;
        }

        $useVariation = !empty($options['enable_variation']);
        foreach ($postIds as $postId) {
            $otherBatchIds = array_values(array_diff($postIds, [$postId]));
            $adapter->populateMBRelationshipsForPost(
                $postId,
                $this->postType,
                null,
                $otherBatchIds,
                $useVariation,
                $this->relatedPostPool
            );
        }
    }

    /**
     * Reverse-populate relational fields on existing posts of OTHER CPTs that target
     * the CPT we just generated. E.g. after generating agents, find existing property
     * posts whose "agent" field is empty and assign newly created agents to them.
     *
     * Only touches WPFaker-generated posts with empty relational fields.
     *
     * @param int[] $newIds IDs of the posts we just generated
     */
    protected function reversePopulateRelationships(array $newIds, ?string $targetPostType = null): void
    {
        $targetPostType = $targetPostType ?? $this->postType;

        $otherPostTypes = get_post_types(['public' => true], 'names');
        unset($otherPostTypes[$targetPostType]);

        foreach ($otherPostTypes as $otherCpt) {
            $relConfig = $this->buildRelationalFieldConfig($otherCpt);
            if (empty($relConfig)) {
                continue;
            }

            // Filter to fields that target the specified CPT
            $targetFields = [];
            foreach ($relConfig as $fieldName => $config) {
                $filterTypes = $config['create']['filter_by_post_type'] ?? [];
                if (in_array($targetPostType, $filterTypes, true)) {
                    $targetFields[$fieldName] = $config;
                }
            }

            if (empty($targetFields)) {
                continue;
            }

            // Find WPFaker-generated posts of this CPT
            $existingPosts = get_posts([
                'post_type'      => $otherCpt,
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'post_status'    => ['publish', 'draft'],
                'meta_key'       => '_wpfaker_generated',
                'meta_value'     => '1',
            ]);

            if (empty($existingPosts)) {
                continue;
            }

            foreach ($existingPosts as $existingPostId) {
                foreach ($targetFields as $fieldName => $config) {
                    $currentValue = get_post_meta($existingPostId, $fieldName, true);

                    // Skip if already has a value
                    if (!empty($currentValue)) {
                        continue;
                    }

                    // Assign from newly generated IDs
                    $config['create']['batch_post_ids'] = $newIds;
                    $config['create']['use_variation'] = true;
                    $this->fieldAssignment->assignCustomFields($existingPostId, [$fieldName => $config], 0);
                }
            }
        }
    }

    /**
     * Get cross-CPT post IDs from the related post pool
     *
     * Checks if the filter_by_post_type targets a different CPT than the one being generated.
     * If so, returns the pooled IDs for that CPT from Phase 0 dependency resolution.
     *
     * @param array $filterPostTypes The post types this field targets
     * @return int[] Array of post IDs from the cross-CPT pool, or empty if same-CPT
     */
    protected function getCrossCptIds(array $filterPostTypes): array
    {
        if (empty($this->relatedPostPool)) {
            return [];
        }

        $crossCptIds = [];
        foreach ($filterPostTypes as $targetType) {
            // Only use pool for other CPTs, not the one currently being generated
            if ($targetType !== $this->postType && isset($this->relatedPostPool[$targetType])) {
                $crossCptIds = array_merge($crossCptIds, $this->relatedPostPool[$targetType]);
            }
        }

        return array_values(array_unique($crossCptIds));
    }

    /**
     * Ensure AI field detections exist for the current post type
     *
     * Makes one batch Gemini API call per CPT to get domain-aware faker configs,
     * then caches them permanently in the DB. Skips if AI is disabled or already cached.
     */
    protected function ensureAiFieldDetections(): void
    {
        $cacheService = new FieldDetectionCacheService();

        // 1. Check local cache — return if AI detections already exist
        if ($cacheService->hasAiDetectionsFor($this->postType)) {
            return;
        }

        // Get adapter for this post type
        $adapter = AdapterFactory::getAdapterForPostType($this->postType) ?? $this->adapter;
        if (!$adapter || !$adapter->isActive()) {
            return;
        }

        $fields = $adapter->getFieldsForPostType($this->postType);
        if (empty($fields)) {
            return;
        }

        // Filter to text/numeric/datetime categories, skip sub-fields
        $fieldsForAi = $this->filterFieldsForAi($fields);
        if (empty($fieldsForAi)) {
            return;
        }

        // Get CPT label for domain context
        $cptObject = get_post_type_object($this->postType);
        $cptLabel = $cptObject ? ($cptObject->labels->singular_name ?? null) : null;
        $locale = $this->faker->getLocale();

        // 2. Query Field Intelligence API (if opt-in enabled)
        $hive = new HiveService();
        if ($hive->isEnabled()) {
            $apiConfigs = $hive->queryFieldConfigs($this->postType, $fieldsForAi, $locale);

            if ($apiConfigs && count($apiConfigs) >= count($fieldsForAi) * 0.5) {
                // API covers >= 50% of fields — use it
                $this->cacheFieldConfigs($cacheService, $apiConfigs, 'hive');
                return;
            }
        }

        // 3. Fall back to AI provider batch detection (existing)
        $aiProvider = AiProviderFactory::getProvider();
        if (!$aiProvider) {
            return;
        }

        GenerationLogService::log('ai', sprintf('Requesting AI field detection for %d fields...', count($fieldsForAi)));
        $results = $aiProvider->detectFieldsBatchWithConfig($fieldsForAi, $this->postType, $cptLabel, $locale);
        if (!$results) {
            return;
        }

        $this->cacheFieldConfigs($cacheService, $results, 'ai_batch');

        // 4. Report Gemini results to Field Intelligence API (if opt-in, fire-and-forget)
        if ($hive->isEnabled()) {
            $hive->reportFieldConfigs($this->postType, $cptLabel, $results, $locale);
        }
    }

    /**
     * Filter fields to only those suitable for AI detection
     *
     * @param array $fields Raw fields from adapter
     * @return array Filtered fields with name, label, type keys
     */
    protected function filterFieldsForAi(array $fields): array
    {
        $fieldsForAi = [];
        foreach ($fields as $field) {
            $fieldName = $field['name'] ?? '';
            $fieldType = $field['type'] ?? 'text';
            $parentField = $field['parent_field'] ?? null;

            if (empty($fieldName) || $parentField) {
                continue;
            }

            $category = FieldConfigSchema::getFieldCategory($fieldType);
            if (!in_array($category, ['text', 'numeric', 'datetime'], true)) {
                continue;
            }

            $fieldsForAi[] = [
                'name' => $fieldName,
                'label' => $field['label'] ?? '',
                'type' => $fieldType,
            ];
        }
        return $fieldsForAi;
    }

    /**
     * Cache field configs from any source (hive, gemini_batch)
     *
     * @param FieldDetectionCacheService $cacheService Cache service
     * @param array $configs Associative array: ['field_name' => ['method' => string, 'params' => array, 'confidence' => float]]
     * @param string $source Source identifier
     */
    protected function cacheFieldConfigs(FieldDetectionCacheService $cacheService, array $configs, string $source): void
    {
        foreach ($configs as $fieldName => $config) {
            $confidence = $config['confidence'] ?? 0.5;
            if ($confidence < 0.7) {
                continue;
            }

            $cacheService->saveDetection(
                $this->postType,
                $fieldName,
                $config['method'] ?? 'unknown',
                $source,
                $confidence,
                null,
                null,
                $config
            );
        }
    }

    /**
     * Build field configuration for ONLY relational fields
     *
     * Used in second pass to populate relationship fields after all posts exist.
     *
     * @param string $postType The post type
     * @return array Field configuration for relational fields only
     */
    protected function buildRelationalFieldConfig(string $postType): array
    {
        $adapter = AdapterFactory::getAdapterForPostType($postType) ?? $this->adapter;

        if (!$adapter || !$adapter->isActive()) {
            return [];
        }

        $fields = $adapter->getFieldsForPostType($postType);
        if (empty($fields)) {
            return [];
        }

        $fieldConfig = [];

        foreach ($fields as $field) {
            $fieldName = $field['name'] ?? '';
            $fieldKey = $field['key'] ?? $fieldName;
            $fieldType = $field['type'] ?? 'text';
            $parentField = $field['parent_field'] ?? null;

            if (empty($fieldName) || $parentField) {
                continue;
            }

            // Only include relational fields
            if (!in_array($fieldType, self::RELATIONAL_FIELD_TYPES, true)) {
                continue;
            }

            // Set filter_by_post_type - use field's setting or default to current post type
            $fieldPostTypes = $field['post_type'] ?? null;
            if (empty($fieldPostTypes) || $fieldPostTypes === 'all') {
                $filterPostTypes = [$postType];
            } elseif (is_array($fieldPostTypes)) {
                $filterPostTypes = $fieldPostTypes;
            } else {
                $filterPostTypes = [$fieldPostTypes];
            }

            $relConfig = [
                'mode' => 'create',
                'field_type' => $fieldType,
                'field_key' => $fieldKey,
                'required' => !empty($field['required']),
                'create' => [
                    'filter_by_post_type' => $filterPostTypes,
                    'post_type' => $filterPostTypes,  // For JetEngine adapter compatibility
                    'is_multiple' => !empty($field['multiple']) || !empty($field['is_multiple']),
                    'count_min' => $field['min'] ?? 1,
                    'count_max' => $field['max'] ?? 3,
                ],
            ];

            // ACPT fields: pass through original PascalCase type for adapter delegation
            if (!empty($field['acpt_type'])) {
                $relConfig['acpt_type'] = $field['acpt_type'];
            }

            $fieldConfig[$fieldName] = $relConfig;
        }

        return $fieldConfig;
    }

    /**
     * Build auto field configuration from adapter's field definitions
     *
     * Creates a default field_config with all fields set to 'create' mode,
     * allowing automatic generation of custom fields for a post type.
     * Respects the fill percentage from variation to only fill some fields.
     *
     * @param string $postType The post type to get fields for
     * @param int $fillPercentage Percentage of fields to fill (0-100)
     * @param bool $excludeRelational Whether to exclude relational fields (post_object, relationship, page_link)
     * @return array Field configuration array for assignCustomFields()
     */
    protected function buildAutoFieldConfig(string $postType, int $fillPercentage = 100, bool $excludeRelational = false): array
    {
        // Try to get the best adapter for this post type (may differ from primary adapter)
        $adapter = AdapterFactory::getAdapterForPostType($postType);

        if (!$adapter) {
            // Fallback to primary adapter if no post-type-specific adapter found
            $adapter = $this->adapter;
        }

        if (!$adapter || !$adapter->isActive()) {
            return [];
        }

        $fields = $adapter->getFieldsForPostType($postType);
        if (empty($fields)) {
            return [];
        }

        $fieldConfig = [];

        foreach ($fields as $field) {
            $fieldName = $field['name'] ?? '';
            $fieldKey = $field['key'] ?? $fieldName;
            $fieldType = $field['type'] ?? 'text';
            $parentField = $field['parent_field'] ?? null;

            if (empty($fieldName)) {
                continue;
            }

            // Skip sub-fields that have a parent - they'll be handled by their parent field
            if ($parentField) {
                continue;
            }

            // Check if this is a relational field
            $isRelationalField = in_array($fieldType, self::RELATIONAL_FIELD_TYPES, true);

            // Skip relational fields in first pass (they need existing posts)
            if ($excludeRelational && $isRelationalField) {
                continue;
            }

            // Check if field is required
            $isRequired = !empty($field['required']);

            // Skip non-required fields based on fill percentage (for variation)
            // Required fields are always included
            if (!$isRequired && $fillPercentage < 100) {
                // If fillPercentage is 0, skip all non-required fields
                if ($fillPercentage === 0) {
                    continue;
                }
                // Otherwise, randomly decide based on percentage
                if (mt_rand(1, 100) > $fillPercentage) {
                    continue;
                }
            }

            // Create config with 'create' mode for included fields
            // Transfer relevant field attributes to create config
            $createConfig = [];

            // Transfer numeric constraints
            if (isset($field['min'])) {
                $createConfig['min'] = $field['min'];
            }
            if (isset($field['max'])) {
                $createConfig['max'] = $field['max'];
            }
            if (isset($field['step'])) {
                $createConfig['step'] = $field['step'];
            }

            // Transfer selection choices
            if (!empty($field['choices'])) {
                $createConfig['choices'] = $field['choices'];
            }

            // Transfer ACFE-specific attributes
            // Code Editor mode (html, css, javascript, php)
            if (isset($field['mode'])) {
                $createConfig['mode'] = $field['mode'];
            }

            // Multiple selection for ACFE selector fields
            if (isset($field['multiple'])) {
                $createConfig['multiple'] = $field['multiple'];
            }

            // Taxonomy for ACFE taxonomy-related fields
            if (isset($field['taxonomy'])) {
                $createConfig['taxonomy'] = $field['taxonomy'];
            }

            // Return format for various fields
            if (isset($field['return_format'])) {
                $createConfig['return_format'] = $field['return_format'];
            }

            // JetEngine-specific attributes
            // Timestamp conversion for date fields
            if (isset($field['is_timestamp'])) {
                $createConfig['is_timestamp'] = $field['is_timestamp'];
            }

            // Media value format (id, url, both)
            if (isset($field['value_format'])) {
                $createConfig['value_format'] = $field['value_format'];
            }

            // Iconpicker library (dashicons, fontawesome)
            if (isset($field['iconpicker_library'])) {
                $createConfig['iconpicker_library'] = $field['iconpicker_library'];
            }

            // is_array for checkbox fields
            if (isset($field['is_array'])) {
                $createConfig['is_array'] = $field['is_array'];
            }

            // JetEngine posts field - post_type (normalized from search_post_type)
            if (isset($field['post_type'])) {
                $createConfig['post_type'] = $field['post_type'];
            }
            if (isset($field['search_post_type'])) {
                $createConfig['search_post_type'] = $field['search_post_type'];
            }

            // is_multiple for JetEngine multi-select fields
            if (isset($field['is_multiple'])) {
                $createConfig['is_multiple'] = $field['is_multiple'];
            }
            // Also check multiple (ACF uses this)
            if (isset($field['multiple'])) {
                $createConfig['multiple'] = $field['multiple'];
            }

            // ACPT-specific: box_name is required for save operations
            if (isset($field['box_name'])) {
                $createConfig['box_name'] = $field['box_name'];
            }

            // For relational fields, set filter_by_post_type to current post type as default
            // This ensures relationship fields link to posts of the same type
            if ($isRelationalField) {
                // Use field's post_type setting if available, otherwise default to current post type
                $fieldPostTypes = $field['post_type'] ?? null;
                if (empty($fieldPostTypes) || $fieldPostTypes === 'all') {
                    // Default to current post type for better relationships
                    $createConfig['filter_by_post_type'] = [$postType];
                } elseif (is_array($fieldPostTypes)) {
                    $createConfig['filter_by_post_type'] = $fieldPostTypes;
                } else {
                    $createConfig['filter_by_post_type'] = [$fieldPostTypes];
                }

                // Set sensible defaults for count
                $createConfig['count_min'] = $field['min'] ?? 1;
                $createConfig['count_max'] = $field['max'] ?? 3;
            }

            $config = [
                'mode' => 'create',
                'field_type' => $fieldType,
                'field_key' => $fieldKey,
                'create' => $createConfig,
            ];

            // For complex fields (repeater, group, flexible_content), include sub_fields/layouts
            // This is important because acf_get_field() can't find nested fields
            if (!empty($field['sub_fields'])) {
                $config['acf_sub_fields'] = $field['sub_fields'];
            }
            if (!empty($field['layouts'])) {
                $config['acf_layouts'] = $field['layouts'];
            }

            // Meta Box group/cloneable fields: transfer sub-fields and clone flag
            if (!empty($field['fields'])) {
                $config['mb_fields'] = $field['fields'];
            }
            if (!empty($field['clone'])) {
                $config['clone'] = true;
            }

            // ACPT fields: pass through original PascalCase type and complex field data
            if (!empty($field['acpt_type'])) {
                $config['acpt_type'] = $field['acpt_type'];
            }
            if (!empty($field['children'])) {
                $config['acpt_children'] = $field['children'];
            }
            if (!empty($field['blocks'])) {
                $config['acpt_blocks'] = $field['blocks'];
            }

            $fieldConfig[$fieldName] = $config;
        }

        return $fieldConfig;
    }
}
