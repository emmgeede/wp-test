<?php

namespace WPFaker\Generators;

use WPFaker\Contracts\ContentGeneratorInterface;
use WPFaker\Contracts\FieldPluginAdapterInterface;
use WPFaker\Services\FakerService;
use WPFaker\Services\AdapterFactory;
use WPFaker\Services\AvatarService;

/**
 * User Generator
 *
 * Generates fake WordPress users.
 */
class UserGenerator implements ContentGeneratorInterface
{
    /**
     * The Faker service
     *
     * @var FakerService
     */
    protected FakerService $faker;

    /**
     * The field plugin adapter
     *
     * @var FieldPluginAdapterInterface|null
     */
    protected ?FieldPluginAdapterInterface $adapter = null;

    /**
     * Generated user IDs
     *
     * @var array
     */
    protected array $generatedIds = [];

    /**
     * Available WordPress roles
     *
     * @var array
     */
    protected array $defaultRoles = [
        'subscriber',
        'contributor',
        'author',
        'editor',
        'administrator',
    ];

    /**
     * Constructor
     *
     * @param FakerService|null $faker
     * @param FieldPluginAdapterInterface|null $adapter
     */
    public function __construct(?FakerService $faker = null, ?FieldPluginAdapterInterface $adapter = null)
    {
        $this->faker = $faker ?? new FakerService();
        $this->adapter = $adapter ?? AdapterFactory::getPrimaryAdapter();
    }

    /**
     * Generate multiple users
     *
     * @param int $count
     * @param array $options
     * @return array Array of generated user IDs
     */
    public function generate(int $count, array $options = []): array
    {
        $options = array_merge($this->getDefaultOptions(), $options);
        $ids = [];

        for ($i = 0; $i < $count; $i++) {
            $id = $this->generateOne($options);
            if ($id) {
                $ids[] = $id;
            }
        }

        // Download avatar pool and assign to generated users
        if (!empty($options['generate_avatars']) && !empty($ids)) {
            $avatarService = new AvatarService();
            $poolSize = min(count($ids), AvatarService::MAX_POOL_SIZE);
            $avatarService->downloadAvatarPool($poolSize, $options['avatar_provider'] ?? 'unsplash');

            foreach ($ids as $userId) {
                $avatarId = $avatarService->getNextAvatar();
                if ($avatarId) {
                    $avatarService->assignAvatarToUser($userId, $avatarId);
                }
            }
        }

        return $ids;
    }

    /**
     * Generate a single user
     *
     * @param array $options
     * @return int The generated user ID
     */
    public function generateOne(array $options = []): int
    {
        $options = array_merge($this->getDefaultOptions(), $options);
        // Always resolve locale: use explicit option, fall back to FakerService's locale (WordPress locale)
        $locale = !empty($options['locale']) ? $options['locale'] : $this->faker->getLocale();
        $faker = $this->faker->forLocale($locale);

        // Generate unique username using raw Faker instance
        $userLogin = $options['user_login'] ?: sanitize_user(strtolower($faker->unique()->userName()), true);

        // Ensure uniqueness
        $originalLogin = $userLogin;
        $counter = 1;
        while (username_exists($userLogin)) {
            $userLogin = $originalLogin . $counter;
            $counter++;
        }

        // Generate email
        $email = $options['user_email'] ?: $faker->unique()->safeEmail();

        // Ensure email uniqueness
        $originalEmail = $email;
        $counter = 1;
        while (email_exists($email)) {
            $parts = explode('@', $originalEmail);
            $email = $parts[0] . $counter . '@' . $parts[1];
            $counter++;
        }

        $userData = [
            'user_login'      => $userLogin,
            'user_pass'       => $options['user_pass'] ?: $faker->password(12, 20),
            'user_email'      => $email,
            'user_nicename'   => $options['user_nicename'] ?: sanitize_title($userLogin),
            'display_name'    => $options['display_name'] ?: $this->faker->displayName($locale),
            'first_name'      => $options['first_name'] ?: $faker->firstName(),
            'last_name'       => $options['last_name'] ?: $faker->lastName(),
            'nickname'        => $options['nickname'] ?: $userLogin,
            'description'     => $options['description'] ?: $faker->paragraph(),
            'user_url'        => $options['user_url'] ?: ($faker->boolean(30) ? $faker->url() : ''),
            'role'            => $options['role'] ?: $this->getRandomRole($options['allowed_roles']),
            'user_registered' => $options['user_registered'] ?: $this->faker->wpDate($options['date_range_start'], $options['date_range_end']),
        ];

        // Insert user
        $userId = wp_insert_user($userData);

        if (is_wp_error($userId)) {
            return 0;
        }

        $this->generatedIds[] = $userId;

        // Set user meta via adapter
        if ($options['populate_custom_fields'] && $this->adapter) {
            $this->populateUserMeta($userId);
        }

        // Set custom meta if provided
        if (!empty($options['meta'])) {
            foreach ($options['meta'] as $key => $value) {
                update_user_meta($userId, $key, $value);
            }
        }

        return $userId;
    }

    /**
     * Delete users
     *
     * @param array $ids User IDs to delete
     * @param bool $force Not used for users
     * @return int Number of users deleted
     */
    public function delete(array $ids, bool $force = false): int
    {
        // wp_delete_user() is in wp-admin/includes/user.php, not loaded during REST requests
        if (!function_exists('wp_delete_user')) {
            require_once ABSPATH . 'wp-admin/includes/user.php';
        }

        $deleted = 0;

        foreach ($ids as $id) {
            // Don't delete the current user
            if ($id === get_current_user_id()) {
                continue;
            }

            $result = wp_delete_user($id);
            if ($result) {
                $deleted++;
            }
        }

        return $deleted;
    }

    /**
     * Get content type
     *
     * @return string
     */
    public function getContentType(): string
    {
        return 'user';
    }

    /**
     * Set the field plugin adapter
     *
     * @param FieldPluginAdapterInterface|null $adapter
     * @return self
     */
    public function setAdapter(?FieldPluginAdapterInterface $adapter): self
    {
        $this->adapter = $adapter;
        return $this;
    }

    /**
     * Get default options
     *
     * @return array
     */
    public function getDefaultOptions(): array
    {
        return [
            'user_login'             => '',
            'user_pass'              => '',
            'user_email'             => '',
            'user_nicename'          => '',
            'display_name'           => '',
            'first_name'             => '',
            'last_name'              => '',
            'nickname'               => '',
            'description'            => '',
            'user_url'               => '',
            'role'                   => '',
            'user_registered'        => '',
            'allowed_roles'          => ['subscriber', 'contributor', 'author'],
            'date_range_start'       => '-2 years',
            'date_range_end'         => 'now',
            'populate_custom_fields' => true,
            'generate_avatars'       => true,
            'avatar_provider'        => 'unsplash',
            'locale'                 => null, // null = use WordPress locale via FakerService
            'meta'                   => [],
        ];
    }

    /**
     * Get a random role from allowed roles
     *
     * @param array $allowedRoles
     * @return string
     */
    protected function getRandomRole(array $allowedRoles): string
    {
        if (empty($allowedRoles)) {
            $allowedRoles = $this->defaultRoles;
        }

        return $allowedRoles[array_rand($allowedRoles)];
    }

    /**
     * Populate user meta using the adapter
     *
     * @param int $userId
     * @return array
     */
    protected function populateUserMeta(int $userId): array
    {
        if (!$this->adapter || !$this->adapter->isActive()) {
            return [];
        }

        // Get field groups that apply to users
        $fieldGroups = [];
        if (method_exists($this->adapter, 'getFieldGroups')) {
            $allGroups = $this->adapter->getFieldGroups();

            foreach ($allGroups as $group) {
                if (method_exists($this->adapter, 'parseLocationRules')) {
                    $locations = $this->adapter->parseLocationRules($group);
                    if (!empty($locations['users'])) {
                        $fieldGroups[] = $group;
                    }
                }
            }
        }

        $generatedValues = [];

        foreach ($fieldGroups as $fieldGroup) {
            $fields = $this->adapter->getFields($fieldGroup['ID'] ?? $fieldGroup['key'] ?? 0);

            foreach ($fields as $field) {
                $fieldName = $field['name'] ?? '';
                $fieldKey = $field['key'] ?? '';

                if (empty($fieldName)) {
                    continue;
                }

                $value = $this->adapter->generateFakeValue($field);

                // ACF stores user meta with user_{user_id} format
                if (function_exists('update_field')) {
                    update_field($fieldKey ?: $fieldName, $value, 'user_' . $userId);
                } else {
                    update_user_meta($userId, $fieldName, $value);
                }

                $generatedValues[$fieldName] = $value;
            }
        }

        return $generatedValues;
    }

    /**
     * Generate users with specific role distribution
     *
     * @param array $roleDistribution e.g., ['subscriber' => 10, 'author' => 5, 'editor' => 2]
     * @param array $options Additional options
     * @return array Generated user IDs grouped by role
     */
    public function generateWithRoleDistribution(array $roleDistribution, array $options = []): array
    {
        $result = [];

        foreach ($roleDistribution as $role => $count) {
            $options['role'] = $role;
            $result[$role] = $this->generate($count, $options);
        }

        return $result;
    }

    /**
     * Get all generated user IDs
     *
     * @return array
     */
    public function getGeneratedIds(): array
    {
        return $this->generatedIds;
    }

    /**
     * Clear generated IDs tracking
     *
     * @return void
     */
    public function clearGeneratedIds(): void
    {
        $this->generatedIds = [];
    }

    /**
     * Get available WordPress roles
     *
     * @return array
     */
    public function getAvailableRoles(): array
    {
        global $wp_roles;

        if (!isset($wp_roles)) {
            $wp_roles = new \WP_Roles();
        }

        return array_keys($wp_roles->roles);
    }
}
