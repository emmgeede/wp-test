<?php

namespace WPFaker\Generators;

use WPFaker\Contracts\ContentGeneratorInterface;
use WPFaker\Contracts\FieldPluginAdapterInterface;
use WPFaker\Services\AvatarService;
use WPFaker\Services\FakerService;

/**
 * Comment Generator
 *
 * Generates fake comments with threading, varying lengths,
 * and a mix of anonymous and registered-user authors.
 */
class CommentGenerator implements ContentGeneratorInterface
{
    protected FakerService $faker;
    protected array $generatedIds = [];
    protected ?array $cptContext = null;

    /**
     * Common user agents for realistic comment metadata
     */
    protected const USER_AGENTS = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
        'Mozilla/5.0 (X11; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1',
        'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    ];

    public function __construct(?FakerService $faker = null)
    {
        $this->faker = $faker ?? new FakerService();
    }

    /**
     * Set CPT context for domain-aware comment generation
     */
    public function setCptContext(?array $context): self
    {
        $this->cptContext = $context;
        return $this;
    }

    /**
     * Generate comments distributed across eligible posts
     *
     * Each eligible post gets between comments_per_post_min and
     * comments_per_post_max comments. The $count parameter is ignored
     * in favor of per-post min/max settings.
     *
     * @param int $count Unused (kept for interface compatibility)
     * @param array $options Generation options
     * @return array Array of generated comment IDs
     */
    public function generate(int $count, array $options = []): array
    {
        $options = array_merge($this->getDefaultOptions(), $options);
        $this->generatedIds = [];

        if (!empty($options['locale'])) {
            $this->faker->setLocale($options['locale']);
        }

        // Delete existing generated comments first if requested
        if (!empty($options['delete_existing'])) {
            $this->deleteGeneratedComments($options['post_type'] ?? 'post');
        }

        // Find posts to comment on
        $postIds = $options['post_ids'] ?? [];
        if (empty($postIds)) {
            $postIds = $this->getEligiblePosts($options['post_type'] ?? 'post', 100);
        }

        if (empty($postIds)) {
            return [];
        }

        // Generate comments for each eligible post (min-max per post)
        foreach ($postIds as $postId) {
            $ids = $this->generateForPost($postId, $options);
            $this->generatedIds = array_merge($this->generatedIds, $ids);
        }

        // Assign avatars to a percentage of generated comments
        $avatarPercentage = (int) ($options['avatar_percentage'] ?? 60);
        if ($avatarPercentage > 0 && !empty($this->generatedIds)) {
            $avatarCount = (int) ceil(count($this->generatedIds) * $avatarPercentage / 100);
            $poolSize = min($avatarCount, 15);

            $avatarService = new AvatarService();
            $avatarService->downloadAvatarPool($poolSize, $options['avatar_provider'] ?? 'unsplash');

            // Randomly select which comments get avatars
            $commentIdsForAvatars = $this->generatedIds;
            shuffle($commentIdsForAvatars);
            $commentIdsForAvatars = array_slice($commentIdsForAvatars, 0, $avatarCount);

            foreach ($commentIdsForAvatars as $commentId) {
                $avatarId = $avatarService->getNextAvatar();
                if ($avatarId) {
                    $avatarService->assignAvatarToComment($commentId, $avatarId);
                }
            }
        }

        return $this->generatedIds;
    }

    /**
     * Delete all WPFaker-generated comments, optionally filtered by post type
     *
     * @param string|null $postType Filter by post type, or null for all
     * @return int Number of comments deleted
     */
    public function deleteGeneratedComments(?string $postType = null): int
    {
        global $wpdb;

        // Find comments with _wpfaker_generated meta
        if ($postType) {
            $commentIds = $wpdb->get_col($wpdb->prepare(
                "SELECT c.comment_ID FROM {$wpdb->comments} c
                 INNER JOIN {$wpdb->commentmeta} cm ON c.comment_ID = cm.comment_id
                 INNER JOIN {$wpdb->posts} p ON c.comment_post_ID = p.ID
                 WHERE cm.meta_key = '_wpfaker_generated' AND cm.meta_value = '1'
                 AND p.post_type = %s",
                $postType
            ));
        } else {
            $commentIds = $wpdb->get_col(
                "SELECT comment_id FROM {$wpdb->commentmeta}
                 WHERE meta_key = '_wpfaker_generated' AND meta_value = '1'"
            );
        }

        $deleted = 0;
        foreach ($commentIds as $id) {
            if (wp_delete_comment((int) $id, true) !== false) {
                $deleted++;
            }
        }

        return $deleted;
    }

    /**
     * Generate comments for a specific post with threading
     *
     * @param int $postId The post to add comments to
     * @param array $options Generation options
     * @return array Array of generated comment IDs
     */
    public function generateForPost(int $postId, array $options = []): array
    {
        $options = array_merge($this->getDefaultOptions(), $options);
        $ids = [];

        if (!empty($options['locale'])) {
            $this->faker->setLocale($options['locale']);
        }

        $min = max(1, $options['comments_per_post_min']);
        $max = max($min, $options['comments_per_post_max']);
        $count = rand($min, $max);

        $post = get_post($postId);
        if (!$post) {
            return [];
        }

        $postDate = $post->post_date;
        $enableThreading = $options['enable_threading'] ?? true;
        $replyProbability = (int) ($options['reply_probability'] ?? 40);
        $pendingPercentage = (int) ($options['pending_percentage'] ?? 10);
        $anonymousPercentage = (int) ($options['anonymous_percentage'] ?? 70);
        $maxDepth = (int) get_option('thread_comments_depth', 5);

        // Get existing WordPress users for non-anonymous comments
        $wpUsers = get_users(['fields' => ['ID', 'display_name', 'user_email'], 'number' => 50]);

        // Phase 1: Create some top-level comments (at least 30% top-level)
        $topLevelCount = max(1, (int) ceil($count * 0.3));
        $replyCount = $count - $topLevelCount;

        for ($i = 0; $i < $topLevelCount; $i++) {
            $commentData = $this->buildCommentData($postId, 0, $postDate, $options, $wpUsers, $anonymousPercentage, $pendingPercentage);
            $commentId = wp_insert_comment($commentData);

            if ($commentId) {
                update_comment_meta($commentId, '_wpfaker_generated', true);
                $ids[] = $commentId;
            }
        }

        // Phase 2: Create replies (with reply_probability chance of being a reply)
        for ($i = 0; $i < $replyCount; $i++) {
            $parentId = 0;

            if ($enableThreading && !empty($ids) && rand(1, 100) <= $replyProbability) {
                // Pick a random existing comment as parent
                $potentialParent = $ids[array_rand($ids)];

                // Check depth
                if ($this->getCommentDepth($potentialParent) < $maxDepth) {
                    $parentId = $potentialParent;
                }
            }

            // Determine date reference: after parent comment date, or after post date
            $dateAfter = $postDate;
            if ($parentId > 0) {
                $parentComment = get_comment($parentId);
                if ($parentComment) {
                    $dateAfter = $parentComment->comment_date;
                }
            }

            $commentData = $this->buildCommentData($postId, $parentId, $dateAfter, $options, $wpUsers, $anonymousPercentage, $pendingPercentage);
            $commentId = wp_insert_comment($commentData);

            if ($commentId) {
                update_comment_meta($commentId, '_wpfaker_generated', true);
                $ids[] = $commentId;
            }
        }

        return $ids;
    }

    /**
     * Generate a single comment (required by interface, uses generateForPost internally)
     */
    public function generateOne(array $options = []): int
    {
        $options = array_merge($this->getDefaultOptions(), $options);
        $postId = $options['post_ids'][0] ?? 0;

        if (!$postId) {
            $postIds = $this->getEligiblePosts($options['post_type'] ?? 'post', 1);
            $postId = $postIds[0] ?? 0;
        }

        if (!$postId) {
            return 0;
        }

        $ids = $this->generateForPost($postId, array_merge($options, [
            'comments_per_post_min' => 1,
            'comments_per_post_max' => 1,
        ]));

        return $ids[0] ?? 0;
    }

    /**
     * Delete comments
     *
     * @param array $ids Comment IDs to delete
     * @param bool $force Force delete (always true for comments)
     * @return int Number of comments deleted
     */
    public function delete(array $ids, bool $force = false): int
    {
        $deleted = 0;

        foreach ($ids as $id) {
            if (wp_delete_comment($id, true) !== false) {
                $deleted++;
            }
        }

        return $deleted;
    }

    public function getContentType(): string
    {
        return 'comment';
    }

    public function setAdapter(?FieldPluginAdapterInterface $adapter): self
    {
        // Comments don't use field plugin adapters
        return $this;
    }

    public function getDefaultOptions(): array
    {
        return [
            'post_type'             => 'post',
            'post_ids'              => [],
            'comments_per_post_min' => 1,
            'comments_per_post_max' => 15,
            'enable_threading'      => true,
            'reply_probability'     => 40,
            'pending_percentage'    => 10,
            'anonymous_percentage'  => 70,
            'delete_existing'       => false,
            'avatar_percentage'     => 60,
            'avatar_provider'       => 'unsplash',
            'locale'                => null,
        ];
    }

    /**
     * Get published posts where comments are open
     */
    public function getEligiblePosts(string $postType = 'post', int $limit = 100): array
    {
        return get_posts([
            'post_type'      => $postType,
            'post_status'    => 'publish',
            'comment_status' => 'open',
            'posts_per_page' => $limit,
            'fields'         => 'ids',
            'orderby'        => 'rand',
        ]);
    }

    /**
     * Get generated comment IDs from last run
     */
    public function getGeneratedComments(): array
    {
        return $this->generatedIds;
    }

    /**
     * Build comment data array for wp_insert_comment
     */
    protected function buildCommentData(
        int $postId,
        int $parentId,
        string $dateAfter,
        array $options,
        array $wpUsers,
        int $anonymousPercentage,
        int $pendingPercentage
    ): array {
        $isAnonymous = rand(1, 100) <= $anonymousPercentage || empty($wpUsers);
        $approved = rand(1, 100) > $pendingPercentage ? 1 : 0;

        if ($isAnonymous) {
            $authorName = $this->faker->name();
            $authorEmail = $this->faker->safeEmail();
            $authorUrl = $this->faker->boolean(30) ? $this->faker->url() : '';
            $userId = 0;
        } else {
            $wpUser = $wpUsers[array_rand($wpUsers)];
            $authorName = $wpUser->display_name;
            $authorEmail = $wpUser->user_email;
            $authorUrl = '';
            $userId = (int) $wpUser->ID;
        }

        // Generate date between $dateAfter and now
        $dateAfterTs = strtotime($dateAfter);
        $nowTs = time();
        if ($dateAfterTs >= $nowTs) {
            $commentTs = $nowTs;
        } else {
            $commentTs = rand($dateAfterTs + 60, $nowTs); // At least 1 minute after reference
        }
        $commentDate = gmdate('Y-m-d H:i:s', $commentTs);

        return [
            'comment_post_ID'      => $postId,
            'comment_author'       => $authorName,
            'comment_author_email' => $authorEmail,
            'comment_author_url'   => $authorUrl,
            'comment_content'      => $this->generateCommentContent(),
            'comment_type'         => 'comment',
            'comment_parent'       => $parentId,
            'user_id'              => $userId,
            'comment_author_IP'    => $this->faker->ipv4(),
            'comment_agent'        => self::USER_AGENTS[array_rand(self::USER_AGENTS)],
            'comment_date'         => $commentDate,
            'comment_date_gmt'     => $commentDate,
            'comment_approved'     => $approved,
        ];
    }

    /**
     * Generate varying comment content
     *
     * Distribution:
     * - 30%: 1 short sentence
     * - 40%: 1-2 sentences
     * - 20%: 1 paragraph (3-4 sentences)
     * - 10%: 2 paragraphs
     */
    protected function generateCommentContent(): string
    {
        // Try contextual comment first (50% chance when context available)
        if ($this->cptContext && !empty($this->cptContext['topics']) && rand(1, 100) <= 50) {
            return $this->generateContextualComment();
        }

        $roll = rand(1, 100);

        if ($roll <= 30) {
            // Short: 1 sentence
            return $this->faker->sentence(rand(4, 10));
        } elseif ($roll <= 70) {
            // Medium: 1-2 sentences
            $sentences = rand(1, 2);
            $parts = [];
            for ($i = 0; $i < $sentences; $i++) {
                $parts[] = $this->faker->sentence(rand(5, 12));
            }
            return implode(' ', $parts);
        } elseif ($roll <= 90) {
            // Long: 3-4 sentences (1 paragraph)
            return $this->faker->paragraph(rand(3, 4));
        } else {
            // Very long: 2 paragraphs
            return $this->faker->paragraph(rand(3, 4)) . "\n\n" . $this->faker->paragraph(rand(3, 4));
        }
    }

    /**
     * Generate a contextual comment using CPT context topics and themes
     */
    protected function generateContextualComment(): string
    {
        $topics = $this->cptContext['topics'];
        $themes = $this->cptContext['content_themes'] ?? $topics;
        $topic = $topics[array_rand($topics)];
        $theme = $themes[array_rand($themes)];

        $templates = [
            "Great article about {topic}!",
            "The section on {theme} was really informative.",
            "I learned a lot about {topic}. {sentence}",
            "Very interesting perspective on {theme}!",
            "Thanks for covering {topic}. {sentence}",
            "{topic} is such a fascinating subject. {sentence}",
            "I've always been curious about {theme}. This was helpful!",
            "Could you write more about {topic}? {sentence}",
            "The part about {theme} was my favorite. {sentence}",
            "Excellent overview of {topic}!",
        ];

        $template = $templates[array_rand($templates)];
        $comment = str_replace(
            ['{topic}', '{theme}', '{sentence}'],
            [$topic, $theme, $this->faker->sentence(rand(5, 10))],
            $template
        );

        // Sometimes add a second sentence for variety
        if (rand(1, 100) <= 40) {
            $comment .= ' ' . $this->faker->sentence(rand(4, 8));
        }

        return $comment;
    }

    /**
     * Get the nesting depth of a comment
     */
    protected function getCommentDepth(int $commentId): int
    {
        $depth = 0;
        $current = get_comment($commentId);

        while ($current && (int) $current->comment_parent > 0) {
            $depth++;
            $current = get_comment($current->comment_parent);

            // Safety: prevent infinite loops
            if ($depth > 20) {
                break;
            }
        }

        return $depth;
    }
}
