<?php

declare(strict_types=1);

namespace WPFaker\Providers;

use Faker\Provider\Text;

/**
 * Modern Text Provider
 *
 * Replaces FakerPHP's archaic source texts (Goethe 1774, Alice in Wonderland 1865, etc.)
 * with more modern public domain literature for realText() generation.
 *
 * Texts are loaded from resources/texts/{locale}.txt on first use.
 * Supported locales: en_US, de_DE, fr_FR, es_ES, pt_BR.
 * Unsupported locales fall through to FakerPHP's built-in Text provider.
 *
 * Sources:
 * - en_US: F. Scott Fitzgerald, "The Great Gatsby" (1925)
 * - de_DE: Franz Kafka, "Die Verwandlung" (1915)
 * - fr_FR: Maurice Leblanc, "Arsène Lupin, gentleman-cambrioleur" (1907)
 * - es_ES: Miguel de Unamuno, "Niebla" (1914)
 * - pt_BR: Machado de Assis, "Dom Casmurro" (1899)
 */
class ModernTextProvider extends Text
{
    /** @var string The loaded modern text for this instance */
    private string $modernText;

    /**
     * Available locale text files
     */
    private const AVAILABLE_LOCALES = ['en_US', 'de_DE', 'fr_FR', 'es_ES', 'pt_BR'];

    public function __construct($generator, string $locale)
    {
        parent::__construct($generator);

        $textFile = dirname(__DIR__, 2) . '/resources/texts/' . $locale . '.txt';

        if (!file_exists($textFile)) {
            // Map locale variants to base locales (e.g. de_AT → de_DE)
            $baseLocale = $this->resolveBaseLocale($locale);
            $textFile = dirname(__DIR__, 2) . '/resources/texts/' . $baseLocale . '.txt';
        }

        $this->modernText = file_get_contents($textFile) ?: '';
    }

    /**
     * Check if a modern text is available for this locale
     */
    public static function hasLocale(string $locale): bool
    {
        if (in_array($locale, self::AVAILABLE_LOCALES, true)) {
            return true;
        }

        $baseLocale = self::resolveBaseLocaleStatic($locale);

        return in_array($baseLocale, self::AVAILABLE_LOCALES, true);
    }

    /**
     * Override getExplodedText to use instance property instead of static::$baseText.
     * This avoids static property conflicts when multiple locales share the same class.
     */
    protected function getExplodedText()
    {
        if ($this->explodedText === null) {
            $this->explodedText = static::explode(preg_replace('/\s+/u', ' ', $this->modernText));
        }

        return $this->explodedText;
    }

    /**
     * Map locale variants to base locales with available texts
     */
    private function resolveBaseLocale(string $locale): string
    {
        return self::resolveBaseLocaleStatic($locale);
    }

    private static function resolveBaseLocaleStatic(string $locale): string
    {
        $map = [
            'de_AT' => 'de_DE',
            'de_CH' => 'de_DE',
            'en_GB' => 'en_US',
            'en_AU' => 'en_US',
            'en_CA' => 'en_US',
            'fr_CA' => 'fr_FR',
            'fr_CH' => 'fr_FR',
            'fr_BE' => 'fr_FR',
            'es_MX' => 'es_ES',
            'es_AR' => 'es_ES',
            'pt_PT' => 'pt_BR',
        ];

        return $map[$locale] ?? $locale;
    }
}
