<?php

namespace WPFaker;

/**
 * Editor Integration
 *
 * Adds a WPFaker panel to the Gutenberg editor sidebar for posts
 * generated with a template, showing template info and an "Edit Template" link.
 */
class EditorIntegration
{
    public function __construct()
    {
        // Use late priority so all CPTs are registered first
        add_action('init', [$this, 'registerMeta'], 999);
        add_action('enqueue_block_editor_assets', [$this, 'enqueueEditorAssets']);
    }

    /**
     * Register post meta for REST API visibility (Gutenberg needs show_in_rest)
     */
    public function registerMeta(): void
    {
        $metaConfig = [
            '_wpfaker_generated' => [
                'show_in_rest'  => true,
                'single'        => true,
                'type'          => 'boolean',
                'default'       => false,
                'auth_callback' => function () {
                    return current_user_can('edit_posts');
                },
            ],
            '_wpfaker_template_id' => [
                'show_in_rest'  => true,
                'single'        => true,
                'type'          => 'integer',
                'default'       => 0,
                'auth_callback' => function () {
                    return current_user_can('edit_posts');
                },
            ],
        ];

        // Register for all post types (empty string = global fallback)
        foreach ($metaConfig as $key => $config) {
            register_post_meta('', $key, $config);
        }

        // Also register explicitly for each public post type
        // (some WP versions don't expose global meta via useEntityProp for CPTs)
        $postTypes = get_post_types(['public' => true], 'names');
        foreach ($postTypes as $postType) {
            foreach ($metaConfig as $key => $config) {
                register_post_meta($postType, $key, $config);
            }
        }
    }

    /**
     * Enqueue the editor sidebar script in the block editor
     */
    public function enqueueEditorAssets(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        // Only enqueue in the block editor (not classic editor or other admin screens)
        $screen = get_current_screen();
        if (!$screen || !$screen->is_block_editor()) {
            return;
        }

        $buildDir = WPF_PLUGIN_DIR . '/build/';
        $buildUrl = WPF_PLUGIN_URL . 'build/';
        $assetFile = $buildDir . 'editor-sidebar.asset.php';

        if (!file_exists($assetFile)) {
            return;
        }

        $assets = include $assetFile;

        // Verify all script dependencies are registered before enqueuing
        $deps = $assets['dependencies'] ?? [];
        foreach ($deps as $dep) {
            if (!wp_script_is($dep, 'registered')) {
                return;
            }
        }

        wp_enqueue_script(
            'wpfaker-editor-sidebar',
            $buildUrl . 'editor-sidebar.js',
            $deps,
            $assets['version'],
            true
        );

        wp_localize_script('wpfaker-editor-sidebar', 'wpfakerEditorData', [
            'adminUrl' => admin_url(),
        ]);
    }
}
