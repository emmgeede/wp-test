<?php

namespace WPFaker;

use WPFaker\Services\AdapterFactory;
use WPFaker\Services\FieldNameDetector;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin Columns
 *
 * Adds dynamic admin list table columns for WPFaker-generated post types.
 * Shows featured image thumbnail, author, variation profile, and one column per taxonomy.
 */
class AdminColumns
{
    /**
     * Cache of dynamic field column configs per post type.
     * @var array<string, array>
     */
    protected $fieldColumnConfig = [];

    public function __construct()
    {
        add_action('admin_init', [$this, 'registerColumns']);
        add_action('admin_head', [$this, 'injectStyles']);
    }

    /**
     * Register columns for all public post types.
     */
    public function registerColumns(): void
    {
        $postTypes = get_post_types(['public' => true], 'names');

        foreach ($postTypes as $postType) {
            add_filter("manage_{$postType}_posts_columns", [$this, 'addColumns'], 20);
            add_action("manage_{$postType}_posts_custom_column", [$this, 'renderColumn'], 10, 2);
        }
    }

    /**
     * Add featured image, author, variation, and dynamic taxonomy columns.
     */
    public function addColumns(array $columns): array
    {
        $screen = get_current_screen();
        if (!$screen || empty($screen->post_type)) {
            return $columns;
        }

        $postType = $screen->post_type;
        $newColumns = [];

        foreach ($columns as $key => $label) {
            // Insert image column right after checkbox
            if ($key === 'cb') {
                $newColumns[$key] = $label;
                $newColumns['wpfaker_thumb'] = __('Image', 'wpfaker');
                continue;
            }

            // Insert author + variation after the title column
            if ($key === 'title') {
                $newColumns[$key] = $label;
                // Only add author column if WP hasn't already
                if (!isset($columns['author'])) {
                    $newColumns['wpfaker_author'] = __('Author', 'wpfaker');
                }
                $newColumns['wpfaker_variation'] = __('Variation', 'wpfaker');
                continue;
            }

            $newColumns[$key] = $label;
        }

        // Add taxonomy columns (one per taxonomy) — skip if WP already has them
        $taxonomies = get_object_taxonomies($postType, 'objects');
        foreach ($taxonomies as $taxonomy) {
            if (!$taxonomy->show_ui) {
                continue;
            }
            $colKey = 'wpfaker_tax_' . $taxonomy->name;
            if (isset($newColumns['taxonomy-' . $taxonomy->name])) {
                continue;
            }
            $newColumns[$colKey] = $taxonomy->labels->name;
        }

        // Dynamic field columns (relational + repeater fields)
        $fieldColumns = $this->getFieldColumns($postType);
        $this->fieldColumnConfig[$postType] = $fieldColumns;
        foreach ($fieldColumns as $fc) {
            $colKey = 'wpfaker_field_' . $fc['key'];
            $newColumns[$colKey] = $fc['label'];
        }

        return $newColumns;
    }

    /**
     * Render the content for custom columns.
     */
    public function renderColumn(string $column, int $postId): void
    {
        if ($column === 'wpfaker_thumb') {
            $this->renderThumbnail($postId);
            return;
        }

        if ($column === 'wpfaker_author') {
            $this->renderAuthor($postId);
            return;
        }

        if ($column === 'wpfaker_variation') {
            $this->renderVariation($postId);
            return;
        }

        if (strpos($column, 'wpfaker_tax_') === 0) {
            $taxonomy = substr($column, strlen('wpfaker_tax_'));
            $this->renderTaxonomyTerms($postId, $taxonomy);
            return;
        }

        // Dynamic field columns
        if (strpos($column, 'wpfaker_field_') === 0) {
            $fieldKey = substr($column, strlen('wpfaker_field_'));
            $postType = get_post_type($postId);
            $config = $this->fieldColumnConfig[$postType] ?? [];

            foreach ($config as $fc) {
                if ($fc['key'] === $fieldKey) {
                    if ($fc['type'] === 'relational') {
                        $this->renderRelationalColumn($postId, $fc['type'], $fieldKey);
                    } elseif ($fc['type'] === 'repeater') {
                        $this->renderRepeaterColumn($postId, $fieldKey);
                    }
                    return;
                }
            }
        }
    }

    /**
     * Render a small featured image thumbnail.
     */
    private function renderThumbnail(int $postId): void
    {
        $thumbId = get_post_thumbnail_id($postId);
        if (!$thumbId) {
            $thumbId = $this->findLogoAttachmentId($postId);
        }

        if ($thumbId) {
            $img = wp_get_attachment_image($thumbId, [40, 40], false, [
                'style' => 'width:40px;height:40px;object-fit:cover;border-radius:4px;',
            ]);
            echo $img;
        } else {
            echo '<span style="color:#999;">—</span>';
        }
    }

    /**
     * Find a logo attachment ID from the post's meta fields.
     *
     * @return int Attachment ID or 0
     */
    private function findLogoAttachmentId(int $postId): int
    {
        $allMeta = get_post_meta($postId);
        foreach ($allMeta as $key => $values) {
            if (strpos($key, '_') === 0) {
                continue; // Skip internal/private meta
            }
            if (FieldNameDetector::isLogoField($key)) {
                $value = is_array($values) ? ($values[0] ?? 0) : $values;
                $attachmentId = (int) $value;
                if ($attachmentId > 0) {
                    return $attachmentId;
                }
            }
        }
        return 0;
    }

    /**
     * Render the post author name.
     */
    private function renderAuthor(int $postId): void
    {
        $post = get_post($postId);
        if ($post && $post->post_author) {
            $author = get_the_author_meta('display_name', $post->post_author);
            echo esc_html($author ?: '—');
        } else {
            echo '<span style="color:#999;">—</span>';
        }
    }

    /**
     * Render the WPFaker variation profile used for this post.
     */
    private function renderVariation(int $postId): void
    {
        $variation = get_post_meta($postId, '_wpfaker_variation', true);
        if (!$variation || !is_array($variation)) {
            $isGenerated = get_post_meta($postId, '_wpfaker_generated', true);
            if (!$isGenerated) {
                echo '<span style="color:#999;">—</span>';
                return;
            }
            echo '<span style="color:#999;">N/A</span>';
            return;
        }

        $profile = $variation['profile'] ?? 'unknown';
        $colors = [
            'complete' => '#22c55e',
            'partial'  => '#9B67FF',
            'minimal'  => '#ef4444',
            'random'   => '#8b5cf6',
        ];
        $color = $colors[$profile] ?? '#6b7280';

        echo '<span style="display:inline-block;padding:2px 8px;border-radius:3px;font-size:12px;font-weight:500;background:' . $color . '22;color:' . $color . ';border:1px solid ' . $color . '44;">' . esc_html(ucfirst($profile)) . '</span>';
    }

    /**
     * Render taxonomy terms as comma-separated links.
     */
    private function renderTaxonomyTerms(int $postId, string $taxonomy): void
    {
        $terms = get_the_terms($postId, $taxonomy);
        if (!$terms || is_wp_error($terms)) {
            echo '<span style="color:#999;">—</span>';
            return;
        }

        $links = [];
        foreach ($terms as $term) {
            $url = add_query_arg([
                'post_type' => get_post_type($postId),
                'taxonomy'  => $taxonomy,
                'term'      => $term->slug,
            ], admin_url('edit.php'));
            $links[] = '<a href="' . esc_url($url) . '">' . esc_html($term->name) . '</a>';
        }

        echo implode(', ', $links);
    }

    /**
     * Detect relevant custom fields for dynamic columns.
     * Returns max 3 columns: relational first, then repeaters.
     *
     * @return array [['key' => field_name, 'label' => display_name, 'type' => field_type], ...]
     */
    protected function getFieldColumns(string $postType): array
    {
        $columns = [];

        try {
            $adapters = AdapterFactory::getActiveAdapters();
        } catch (\Throwable $e) {
            return [];
        }

        $relationalTypes = ['post_object', 'relationship', 'page_link', 'posts', 'post'];
        $repeaterTypes = ['repeater', 'group', 'flexible_content'];

        foreach ($adapters as $adapter) {
            try {
                $fields = $adapter->getFieldsForPostType($postType);
            } catch (\Throwable $e) {
                continue;
            }

            foreach ($fields as $field) {
                $type = $field['type'] ?? '';
                $name = $field['name'] ?? '';
                if (empty($name)) {
                    continue;
                }

                if (in_array($type, $relationalTypes)) {
                    $columns[] = [
                        'key'   => $name,
                        'label' => $field['label'] ?? ucfirst(str_replace('_', ' ', $name)),
                        'type'  => 'relational',
                    ];
                } elseif (in_array($type, $repeaterTypes)) {
                    $columns[] = [
                        'key'   => $name,
                        'label' => $field['label'] ?? ucfirst(str_replace('_', ' ', $name)),
                        'type'  => 'repeater',
                    ];
                }
            }
        }

        // Priority: relational first, then repeaters. Max 3.
        usort($columns, function ($a, $b) {
            $priority = ['relational' => 0, 'repeater' => 1];
            return ($priority[$a['type']] ?? 2) <=> ($priority[$b['type']] ?? 2);
        });

        return array_slice($columns, 0, 3);
    }

    /**
     * Render a relational field column — shows linked post titles.
     */
    protected function renderRelationalColumn(int $postId, string $type, string $fieldKey): void
    {
        $value = get_post_meta($postId, $fieldKey, true);
        $ids = is_array($value) ? $value : [$value];
        $ids = array_filter(array_map('intval', $ids));

        if (empty($ids)) {
            echo '<span class="wpfaker-column-empty">—</span>';
            return;
        }

        $maxShow = 3;
        $shown = array_slice($ids, 0, $maxShow);
        $links = [];

        foreach ($shown as $id) {
            $title = get_the_title($id);
            if (empty($title)) {
                continue;
            }
            $editLink = get_edit_post_link($id);
            $links[] = $editLink
                ? '<a href="' . esc_url($editLink) . '">' . esc_html($title) . '</a>'
                : esc_html($title);
        }

        echo implode(', ', $links);

        $remaining = count($ids) - $maxShow;
        if ($remaining > 0) {
            echo ' <span class="wpfaker-column-more">+' . $remaining . '</span>';
        }
    }

    /**
     * Render a repeater/group field column — shows item count badge.
     */
    protected function renderRepeaterColumn(int $postId, string $fieldKey): void
    {
        $count = (int) get_post_meta($postId, $fieldKey, true);
        if ($count <= 0) {
            echo '<span class="wpfaker-column-empty">—</span>';
            return;
        }

        $label = sprintf(_n('%d item', '%d items', $count, 'wpfaker'), $count);
        echo '<span class="wpfaker-badge wpfaker-badge-count">' . esc_html($label) . '</span>';
    }

    /**
     * Inject minimal CSS for column widths.
     */
    public function injectStyles(): void
    {
        $screen = get_current_screen();
        if (!$screen || $screen->base !== 'edit') {
            return;
        }
        echo '<style>.column-wpfaker_thumb{width:50px;}.column-wpfaker_variation{width:90px;}.wpfaker-column-empty{color:#999;}.wpfaker-column-more{color:#666;font-size:0.85em;}.wpfaker-badge-count{display:inline-block;padding:2px 8px;border-radius:10px;background:#e0e0e0;font-size:0.85em;color:#333;}</style>';
    }
}
