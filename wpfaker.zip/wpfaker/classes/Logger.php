<?php

namespace WPFaker;

use function defined;
use const WPfaker\WPF_PLUGIN_DIR;

if (!defined('ABSPATH')) {exit;} // Exit if accessed directly


/**
 * WPfaker Logger class.
 */
class Logger {

	const LOG_LEVEL_BASE    = 0;
	const LOG_LEVEL_ERROR   = 1;
	const LOG_LEVEL_WARNING = 2;
	const LOG_LEVEL_NOTICE  = 3;
	const LOG_LEVEL_INFO    = 4;

	/**
	 * Undocumented function
	 *
	 * @param boolean $enabled Enable or disable debugging.
	 */
	public function __construct( $enabled = false ) {
		if ( ! defined( 'WPF_DEBUG_LOG' ) ) {
			define( 'WIP_DEBUG_LOG', (bool) $enabled );
		}

		date_default_timezone_set( 'CET' );
	}

	/**
	 * Log whatever is being passed as parameter.
	 *
	 * @param mixed $what      What to log.
	 * @param int   $log_level Log level.
	 *
	 * @return void
	 */
	public static function log( $what, $log_level = self::LOG_LEVEL_BASE ) {
		if ( ! defined( 'WPF_DEBUG_LOG' ) || true !== WPF_DEBUG_LOG ) {
			return;
		}
		if ( ! defined( 'WPF_DEBUG_LOG_LEVEL' ) ) {
			define( 'WPF_DEBUG_LOG_LEVEL', self::LOG_LEVEL_ERROR );
		}
		if ( $log_level > WPF_DEBUG_LOG_LEVEL ) {
			return;
		}
		$message   = is_array( $what ) || is_object( $what ) ? print_r( $what, true ) : $what;
		$debug_dir = WPF_PLUGIN_DIR . DIRECTORY_SEPARATOR . 'debug';
		if ( ! file_exists( $debug_dir ) ) {
			wp_mkdir_p( $debug_dir );
		}
		$debug_file = $debug_dir . DIRECTORY_SEPARATOR . 'debug.log';
		$error_log  = defined( WP_DEBUG ) ? (bool) WP_DEBUG : false;
		if ( is_writable( $debug_file ) || ( ! file_exists( $debug_file ) && is_writable( $debug_dir ) ) ) {
			// either the file exists and is writable, or it doesn't exist but the directory is writable.
			$message .= "\n";
			file_put_contents(
				$debug_file,
				date( 'd-m-Y H:i', time() ) . '| LEVEL: ' . $log_level . ' - ' . $message,
				FILE_APPEND
			);
			$error_log = false; // don't error_log this.
		}
		if ( $error_log ) {
			error_log( $message );
		}
	}
}
