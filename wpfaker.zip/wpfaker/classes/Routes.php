<?php

namespace WPFaker;

use WP_REST_Controller;
use WP_REST_Server;
use WPFaker\Controllers\PostTypesController;
use WPFaker\Controllers\GeneratorController;
use WPFaker\Controllers\SettingsController;
use WPFaker\Controllers\TemplateController;
use WPFaker\Services\ImageService;
use WPFaker\Services\FakerService;
use WPFaker\Services\FieldDetectionCacheService;
use WPFaker\Services\MediaCleanupService;
use WPFaker\Services\VariationService;
use WPFaker\Services\PluginDetectorService;
use WPFaker\Services\SystemCapacityService;
use WPFaker\Services\VideoService;
use WPFaker\Services\NewsService;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * REST API Routes
 *
 * Registers all REST API endpoints for the WPfaker plugin.
 */
class Routes extends WP_REST_Controller
{
    /**
     * @var string API namespace
     */
    protected $namespace = 'wpfaker/v1';

    /**
     * @var PostTypesController
     */
    protected PostTypesController $postTypes;

    /**
     * @var GeneratorController
     */
    protected GeneratorController $generator;

    /**
     * @var SettingsController
     */
    protected SettingsController $settings;

    /**
     * @var TemplateController
     */
    protected TemplateController $templates;

    /**
     * @var \WPFaker\Tour
     */
    protected \WPFaker\Tour $tour;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->postTypes = new PostTypesController();
        $this->generator = new GeneratorController();
        $this->settings = new SettingsController();
        $this->templates = new TemplateController();
        $this->tour = new \WPFaker\Tour();
    }

    /**
     * Register all routes
     */
    public function wpf_register_routes(): void
    {
        // =====================================================================
        // Information Endpoints
        // =====================================================================

        // Get all post types
        register_rest_route($this->namespace, '/cpts/all', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'wpf_get_all_cpt'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get post type supports
        register_rest_route($this->namespace, '/cpts/supports/(?P<cpt>[a-zA-Z0-9_-]+)', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'wpf_get_type_supports'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'cpt' => [
                    'required'          => true,
                    'validate_callback' => function ($param) {
                        return is_string($param) && post_type_exists($param);
                    },
                ],
            ],
        ]);

        // Get all taxonomies
        register_rest_route($this->namespace, '/taxonomies/all', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'wpf_get_all_taxonomies'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get plugin URLs
        register_rest_route($this->namespace, '/urls', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'wpf_get_urls'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get field plugins info (adapters)
        register_rest_route($this->namespace, '/field-plugins', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->generator, 'getFieldPlugins'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get all detected custom field plugins (comprehensive)
        register_rest_route($this->namespace, '/detected-plugins', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'wpf_get_detected_plugins'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get fields for a post type
        register_rest_route($this->namespace, '/fields/(?P<post_type>[a-zA-Z0-9_-]+)', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->generator, 'getFieldsForPostType'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'post_type' => [
                    'required' => true,
                ],
            ],
        ]);

        // Get cross-CPT dependencies for a post type
        register_rest_route($this->namespace, '/dependencies/(?P<post_type>[a-zA-Z0-9_-]+)', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->generator, 'getDependencies'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'post_type' => [
                    'required' => true,
                ],
            ],
        ]);

        // Get image providers
        register_rest_route($this->namespace, '/image-providers', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'wpf_get_image_providers'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get supported languages
        register_rest_route($this->namespace, '/languages', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'wpf_get_languages'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get variation profiles
        register_rest_route($this->namespace, '/variation-profiles', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'wpf_get_variation_profiles'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get WPFaker post meta (for editor sidebar)
        register_rest_route($this->namespace, '/post-meta/(?P<id>\d+)', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'wpf_get_post_meta'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // =====================================================================
        // Generation Endpoints
        // =====================================================================

        // Generate posts — shared args for both standard and SSE stream endpoints
        $generatePostsArgs = [
            'post_type' => [
                'required' => false,
                'default'  => 'post',
                'type'     => 'string',
            ],
            'count' => [
                'required' => false,
                'default'  => 5,
                'type'     => 'integer',
                'minimum'  => 1,
                'maximum'  => SystemCapacityService::ABSOLUTE_MAX,
            ],
            'post_status' => [
                'required' => false,
                'default'  => 'publish',
                'type'     => 'string',
                'enum'     => ['publish', 'draft', 'pending', 'private', 'future', 'random'],
            ],
            'set_featured_image' => [
                'required' => false,
                'default'  => true,
                'type'     => 'boolean',
            ],
            'download_images' => [
                'required' => false,
                'default'  => true,
                'type'     => 'boolean',
            ],
            'image_provider' => [
                'required' => false,
                'default'  => 'unsplash',
                'type'     => 'string',
                'enum'     => ['unsplash', 'picsum', 'pexels', 'pixabay', 'placeholder'],
            ],
            'image_category' => [
                'required' => false,
                'default'  => null,
                'type'     => 'string',
            ],
            'image_width' => [
                'required' => false,
                'default'  => 1200,
                'type'     => 'integer',
                'minimum'  => 100,
                'maximum'  => 4000,
            ],
            'image_height' => [
                'required' => false,
                'default'  => 800,
                'type'     => 'integer',
                'minimum'  => 100,
                'maximum'  => 4000,
            ],
            'populate_custom_fields' => [
                'required' => false,
                'default'  => true,
                'type'     => 'boolean',
            ],
            'auto_taxonomies' => [
                'required' => false,
                'default'  => true,
                'type'     => 'boolean',
            ],
            'delete_existing_before_generate' => [
                'required' => false,
                'default'  => false,
                'type'     => 'boolean',
            ],
            'delete_related_media' => [
                'required' => false,
                'default'  => false,
                'type'     => 'boolean',
            ],
            'delete_related_terms' => [
                'required' => false,
                'default'  => false,
                'type'     => 'boolean',
            ],
            'delete_related_authors' => [
                'required' => false,
                'default'  => false,
                'type'     => 'boolean',
            ],
            'delete_related_comments' => [
                'required' => false,
                'default'  => false,
                'type'     => 'boolean',
            ],
            'delete_scope' => [
                'required' => false,
                'default'  => 'current_type',
                'type'     => 'string',
                'enum'     => ['current_type', 'all'],
            ],
            'template_id' => [
                'required'          => false,
                'validate_callback' => function ($value) {
                    return $value === null || is_numeric($value);
                },
                'sanitize_callback' => function ($value) {
                    return $value === null ? null : (int) $value;
                },
            ],
            'taxonomy_config' => [
                'required'          => false,
                'validate_callback' => '__return_true',
            ],
            'field_config' => [
                'required'          => false,
                'validate_callback' => '__return_true',
            ],
            'auto_comments' => [
                'required' => false,
                'default'  => false,
                'type'     => 'boolean',
            ],
            'comments_per_post_min' => [
                'required' => false,
                'default'  => 0,
                'type'     => 'integer',
            ],
            'comments_per_post_max' => [
                'required' => false,
                'default'  => 10,
                'type'     => 'integer',
            ],
            'enable_comment_threading' => [
                'required' => false,
                'default'  => true,
                'type'     => 'boolean',
            ],
            'comment_reply_probability' => [
                'required' => false,
                'default'  => 40,
                'type'     => 'integer',
            ],
            'related_cpt_options' => [
                'required'          => false,
                'default'           => null,
                'validate_callback' => '__return_true',
            ],
        ];

        register_rest_route($this->namespace, '/generate/posts', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->generator, 'generatePosts'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => $generatePostsArgs,
        ]);

        // Delete posts (standalone, for chunked generation)
        register_rest_route($this->namespace, '/generate/posts/delete', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->generator, 'deletePostsEndpoint'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'post_type'              => ['type' => 'string', 'required' => true],
                'delete_scope'           => ['type' => 'string', 'default' => 'current_type'],
                'delete_related_media'   => ['type' => 'boolean', 'default' => false],
                'delete_related_terms'   => ['type' => 'boolean', 'default' => false],
                'delete_related_authors' => ['type' => 'boolean', 'default' => false],
                'delete_related_comments'=> ['type' => 'boolean', 'default' => false],
                'delete_related_cpts'    => ['type' => 'boolean', 'default' => false],
            ],
        ]);

        // Generate posts with SSE streaming (real-time log events)
        register_rest_route($this->namespace, '/generate/posts/stream', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->generator, 'generatePostsStream'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => $generatePostsArgs,
        ]);

        // Generate taxonomy terms
        register_rest_route($this->namespace, '/generate/terms', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->generator, 'generateTerms'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'taxonomy' => [
                    'required' => false,
                    'default'  => 'category',
                    'type'     => 'string',
                ],
                'count' => [
                    'required' => false,
                    'default'  => 5,
                    'type'     => 'integer',
                    'minimum'  => 1,
                    'maximum'  => SystemCapacityService::ABSOLUTE_MAX,
                ],
                'generate_hierarchy' => [
                    'required' => false,
                    'default'  => false,
                    'type'     => 'boolean',
                ],
                'depth' => [
                    'required' => false,
                    'default'  => 3,
                    'type'     => 'integer',
                ],
                'breadth' => [
                    'required' => false,
                    'default'  => 3,
                    'type'     => 'integer',
                ],
                'delete_existing' => [
                    'required' => false,
                    'default'  => false,
                    'type'     => 'boolean',
                ],
            ],
        ]);

        // Generate users
        register_rest_route($this->namespace, '/generate/users', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->generator, 'generateUsers'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'count' => [
                    'required' => false,
                    'default'  => 5,
                    'type'     => 'integer',
                    'minimum'  => 1,
                    'maximum'  => SystemCapacityService::ABSOLUTE_MAX,
                ],
                'role' => [
                    'required' => false,
                    'default'  => '',
                    'type'     => 'string',
                ],
                'allowed_roles' => [
                    'required' => false,
                    'default'  => ['subscriber', 'contributor', 'author'],
                    'type'     => 'array',
                ],
                'generate_avatars' => [
                    'required' => false,
                    'default'  => true,
                    'type'     => 'boolean',
                ],
                'avatar_provider' => [
                    'required' => false,
                    'default'  => 'unsplash',
                    'type'     => 'string',
                    'enum'     => ['picsum', 'unsplash', 'pexels', 'pixabay', 'placeholder'],
                ],
                'delete_existing' => [
                    'required' => false,
                    'default'  => false,
                    'type'     => 'boolean',
                ],
            ],
        ]);

        // Generate comments
        register_rest_route($this->namespace, '/generate/comments', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->generator, 'generateComments'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'post_type' => [
                    'required' => false,
                    'default'  => 'post',
                    'type'     => 'string',
                ],
                'delete_existing' => [
                    'required' => false,
                    'default'  => false,
                    'type'     => 'boolean',
                ],
                'post_ids' => [
                    'required' => false,
                    'default'  => [],
                    'type'     => 'array',
                ],
                'comments_per_post_min' => [
                    'required' => false,
                    'default'  => 1,
                    'type'     => 'integer',
                    'minimum'  => 1,
                    'maximum'  => 100,
                ],
                'comments_per_post_max' => [
                    'required' => false,
                    'default'  => 15,
                    'type'     => 'integer',
                    'minimum'  => 1,
                    'maximum'  => 100,
                ],
                'enable_threading' => [
                    'required' => false,
                    'default'  => true,
                    'type'     => 'boolean',
                ],
                'reply_probability' => [
                    'required' => false,
                    'default'  => 40,
                    'type'     => 'integer',
                    'minimum'  => 0,
                    'maximum'  => 100,
                ],
                'pending_percentage' => [
                    'required' => false,
                    'default'  => 10,
                    'type'     => 'integer',
                    'minimum'  => 0,
                    'maximum'  => 100,
                ],
                'anonymous_percentage' => [
                    'required' => false,
                    'default'  => 70,
                    'type'     => 'integer',
                    'minimum'  => 0,
                    'maximum'  => 100,
                ],
                'avatar_percentage' => [
                    'required' => false,
                    'default'  => 60,
                    'type'     => 'integer',
                    'minimum'  => 0,
                    'maximum'  => 100,
                ],
                'avatar_provider' => [
                    'required' => false,
                    'default'  => 'unsplash',
                    'type'     => 'string',
                    'enum'     => ['picsum', 'unsplash', 'pexels', 'pixabay', 'placeholder'],
                ],
                'locale' => [
                    'required' => false,
                    'type'     => 'string',
                ],
            ],
        ]);

        // Delete generated content
        register_rest_route($this->namespace, '/generate/delete', [
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => [$this->generator, 'deleteGenerated'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'type' => [
                    'required' => true,
                    'type'     => 'string',
                    'enum'     => ['post', 'term', 'user', 'comment'],
                ],
                'ids' => [
                    'required' => false,
                    'type'     => 'array',
                    'default'  => [],
                ],
                'force' => [
                    'required' => false,
                    'type'     => 'boolean',
                    'default'  => false,
                ],
            ],
        ]);

        // =====================================================================
        // History Endpoints
        // =====================================================================

        // Get generation statistics
        register_rest_route($this->namespace, '/history/stats', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->generator, 'getStats'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get time savings report
        register_rest_route($this->namespace, '/time-saved', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->generator, 'getTimeSavingsReport'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Reset time savings data
        register_rest_route($this->namespace, '/time-saved', [
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => [$this->generator, 'resetTimeSavings'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get generation history
        register_rest_route($this->namespace, '/history', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->generator, 'getHistory'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'type' => [
                    'required' => false,
                    'type'     => 'string',
                ],
                'limit' => [
                    'required' => false,
                    'type'     => 'integer',
                    'default'  => 50,
                ],
                'offset' => [
                    'required' => false,
                    'type'     => 'integer',
                    'default'  => 0,
                ],
            ],
        ]);

        // Clear history
        register_rest_route($this->namespace, '/history/clear', [
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => [$this, 'wpf_clear_history'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Cleanup orphaned history entries
        register_rest_route($this->namespace, '/history/cleanup', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'wpf_cleanup_history'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Delete single history entry
        register_rest_route($this->namespace, '/history/(?P<id>\d+)', [
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => [$this, 'wpf_delete_history_entry'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'id' => [
                    'required'          => true,
                    'type'              => 'integer',
                    'validate_callback' => function ($param) {
                        return is_numeric($param) && $param > 0;
                    },
                ],
                'delete_content' => [
                    'required' => false,
                    'type'     => 'boolean',
                    'default'  => true,
                ],
            ],
        ]);

        // =====================================================================
        // Cleanup Endpoints
        // =====================================================================

        // Delete all WPfaker-generated data
        register_rest_route($this->namespace, '/cleanup/all', [
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => [$this, 'wpf_delete_all_data'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // =====================================================================
        // Field Detection Cache Endpoints
        // =====================================================================

        // Clear field detection cache for a specific post type
        register_rest_route($this->namespace, '/field-detections/(?P<post_type>[a-zA-Z0-9_-]+)', [
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => [$this, 'wpf_clear_field_detections_for_type'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'post_type' => [
                    'required' => true,
                    'type'     => 'string',
                ],
            ],
        ]);

        // Clear all field detection cache
        register_rest_route($this->namespace, '/field-detections', [
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => [$this, 'wpf_clear_all_field_detections'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // =====================================================================
        // Settings Endpoints
        // =====================================================================

        // Get all settings
        register_rest_route($this->namespace, '/settings', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->settings, 'getSettings'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Save general settings
        register_rest_route($this->namespace, '/settings', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->settings, 'saveSettings'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get AI settings
        register_rest_route($this->namespace, '/settings/ai', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->settings, 'getAiSettings'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Save AI settings
        register_rest_route($this->namespace, '/settings/ai', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->settings, 'saveAiSettings'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Test AI connection
        register_rest_route($this->namespace, '/settings/ai/test', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->settings, 'testAiConnection'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Clear AI cache
        register_rest_route($this->namespace, '/settings/ai/clear-cache', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->settings, 'clearAiCache'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get image provider settings
        register_rest_route($this->namespace, '/settings/image-providers', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->settings, 'getImageProviderSettings'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Save image provider settings
        register_rest_route($this->namespace, '/settings/image-providers', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->settings, 'saveImageProviderSettings'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Addon system
        register_rest_route($this->namespace, '/addons', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'getAddons'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Sync status
        register_rest_route($this->namespace, '/sync/status', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->settings, 'getSyncStatus'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Mark sync result as seen
        register_rest_route($this->namespace, '/sync/mark-seen', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->settings, 'markSyncSeen'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // =====================================================================
        // License Endpoints
        // =====================================================================

        // Get license status
        register_rest_route($this->namespace, '/license', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->settings, 'getLicenseStatus'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Activate license
        register_rest_route($this->namespace, '/license/activate', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->settings, 'activateLicense'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Deactivate license
        register_rest_route($this->namespace, '/license/deactivate', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->settings, 'deactivateLicense'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Refresh license status
        register_rest_route($this->namespace, '/license/refresh', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->settings, 'refreshLicense'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // =====================================================================
        // Template Endpoints
        // =====================================================================

        // List all templates
        register_rest_route($this->namespace, '/templates', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->templates, 'list'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'post_type' => [
                    'required' => false,
                    'type'     => 'string',
                ],
                'is_system' => [
                    'required' => false,
                    'type'     => 'boolean',
                ],
            ],
        ]);

        // Create new template
        register_rest_route($this->namespace, '/templates', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->templates, 'create'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get single template
        register_rest_route($this->namespace, '/templates/(?P<id>\d+)', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->templates, 'get'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'id' => [
                    'required'          => true,
                    'type'              => 'integer',
                    'validate_callback' => function ($param) {
                        return is_numeric($param) && $param > 0;
                    },
                ],
            ],
        ]);

        // Update template
        register_rest_route($this->namespace, '/templates/(?P<id>\d+)', [
            'methods'             => WP_REST_Server::EDITABLE,
            'callback'            => [$this->templates, 'update'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'id' => [
                    'required' => true,
                    'type'     => 'integer',
                ],
            ],
        ]);

        // Delete template
        register_rest_route($this->namespace, '/templates/(?P<id>\d+)', [
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => [$this->templates, 'delete'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'id' => [
                    'required' => true,
                    'type'     => 'integer',
                ],
                'new_default_id' => [
                    'required' => false,
                    'type'     => 'integer',
                ],
            ],
        ]);

        // Set template as default
        register_rest_route($this->namespace, '/templates/(?P<id>\d+)/default', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->templates, 'setDefault'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'id' => [
                    'required' => true,
                    'type'     => 'integer',
                ],
            ],
        ]);

        // Duplicate template
        register_rest_route($this->namespace, '/templates/(?P<id>\d+)/duplicate', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->templates, 'duplicate'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'id' => [
                    'required' => true,
                    'type'     => 'integer',
                ],
            ],
        ]);

        // Export templates
        register_rest_route($this->namespace, '/templates/export', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->templates, 'export'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'ids' => [
                    'required' => false,
                    'type'     => 'array',
                ],
                'post_type' => [
                    'required' => false,
                    'type'     => 'string',
                ],
            ],
        ]);

        // Import templates
        register_rest_route($this->namespace, '/templates/import', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->templates, 'import'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get taxonomies for a post type (for template editor)
        register_rest_route($this->namespace, '/templates/taxonomies/(?P<post_type>[a-zA-Z0-9_-]+)', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->templates, 'getPostTypeTaxonomies'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'post_type' => [
                    'required' => true,
                    'type'     => 'string',
                ],
            ],
        ]);

        // Get terms for a taxonomy (for multiselect)
        register_rest_route($this->namespace, '/taxonomies/(?P<taxonomy>[a-zA-Z0-9_-]+)/terms', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->templates, 'getTaxonomyTerms'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'taxonomy' => [
                    'required' => true,
                    'type'     => 'string',
                ],
                'search' => [
                    'required' => false,
                    'type'     => 'string',
                ],
                'parent' => [
                    'required' => false,
                    'type'     => 'integer',
                ],
                'per_page' => [
                    'required' => false,
                    'type'     => 'integer',
                    'default'  => 100,
                ],
            ],
        ]);

        // =====================================================================
        // Field Configuration Endpoints
        // =====================================================================

        // Get all fields for a post type (Core + Custom)
        register_rest_route($this->namespace, '/templates/fields/(?P<post_type>[a-zA-Z0-9_-]+)', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->templates, 'getFields'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'post_type' => [
                    'required' => true,
                    'type'     => 'string',
                ],
            ],
        ]);

        // Get field schema for a specific field type
        register_rest_route($this->namespace, '/field-schema/(?P<field_type>[a-zA-Z0-9_-]+)', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->templates, 'getFieldSchema'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'field_type' => [
                    'required' => true,
                    'type'     => 'string',
                ],
            ],
        ]);

        // =====================================================================
        // Template Variant & Inheritance Endpoints
        // =====================================================================

        // Variant creation
        register_rest_route($this->namespace, '/templates/(?P<id>\d+)/variant', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->templates, 'createVariant'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'id' => [
                    'required' => true,
                    'type'     => 'integer',
                ],
            ],
        ]);

        // Effective config (merged for variants)
        register_rest_route($this->namespace, '/templates/(?P<id>\d+)/effective-config', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->templates, 'getEffectiveConfig'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'id' => [
                    'required' => true,
                    'type'     => 'integer',
                ],
            ],
        ]);

        // Stale templates
        register_rest_route($this->namespace, '/templates/stale', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->templates, 'getStaleTemplates'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get images from media library (for Choose mode)
        register_rest_route($this->namespace, '/media/images', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->templates, 'getMediaImages'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'per_page' => [
                    'required' => false,
                    'type'     => 'integer',
                    'default'  => 20,
                ],
                'page' => [
                    'required' => false,
                    'type'     => 'integer',
                    'default'  => 1,
                ],
                'search' => [
                    'required' => false,
                    'type'     => 'string',
                ],
            ],
        ]);

        // Download images to media library
        register_rest_route($this->namespace, '/media/download', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'downloadImages'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'count' => [
                    'required' => false,
                    'type'     => 'integer',
                    'default'  => 5,
                ],
                'provider' => [
                    'required' => false,
                    'type'     => 'string',
                    'default'  => 'picsum',
                ],
                'category' => [
                    'required' => false,
                    'type'     => 'string',
                    'default'  => '',
                ],
                'width' => [
                    'required' => false,
                    'type'     => 'integer',
                    'default'  => 1200,
                ],
                'height' => [
                    'required' => false,
                    'type'     => 'integer',
                    'default'  => 800,
                ],
                'aspect_ratio' => [
                    'required' => false,
                    'type'     => 'string',
                    'default'  => '3:2',
                ],
                'random_size' => [
                    'required' => false,
                    'type'     => 'boolean',
                    'default'  => false,
                ],
                'width_min' => [
                    'required' => false,
                    'type'     => 'integer',
                    'default'  => 800,
                ],
                'width_max' => [
                    'required' => false,
                    'type'     => 'integer',
                    'default'  => 1600,
                ],
            ],
        ]);

        // Get files from media library (non-images, for file fields)
        register_rest_route($this->namespace, '/media/files', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->templates, 'getMediaFiles'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'per_page' => [
                    'required' => false,
                    'type'     => 'integer',
                    'default'  => 50,
                ],
                'page' => [
                    'required' => false,
                    'type'     => 'integer',
                    'default'  => 1,
                ],
                'file_type' => [
                    'required' => false,
                    'type'     => 'string',
                ],
            ],
        ]);

        // Upload file from URL
        register_rest_route($this->namespace, '/media/upload-url', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'uploadFileFromUrl'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'url' => [
                    'required' => true,
                    'type'     => 'string',
                ],
            ],
        ]);

        // Upload file from local filesystem
        register_rest_route($this->namespace, '/media/upload', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'uploadFile'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // Get users (for Choose mode)
        register_rest_route($this->namespace, '/users', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->templates, 'getUsers'],
            'permission_callback' => [$this, 'check_admin_permission'],
            'args'                => [
                'roles' => [
                    'required' => false,
                    'type'     => 'array',
                ],
                'search' => [
                    'required' => false,
                    'type'     => 'string',
                ],
                'per_page' => [
                    'required' => false,
                    'type'     => 'integer',
                    'default'  => 50,
                ],
            ],
        ]);

        // Get available user roles
        register_rest_route($this->namespace, '/users/roles', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->templates, 'getUserRoles'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // =====================================================================
        // Tour Endpoints
        // =====================================================================

        register_rest_route($this->namespace, '/tour/state', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->tour, 'handleGetState'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        register_rest_route($this->namespace, '/tour/complete', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->tour, 'handleComplete'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        register_rest_route($this->namespace, '/tour/reset', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->tour, 'handleReset'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        register_rest_route($this->namespace, '/tour/setup-demo', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->tour, 'handleSetupDemo'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        register_rest_route($this->namespace, '/tour/cleanup-demo', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this->tour, 'handleCleanupDemo'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        register_rest_route($this->namespace, '/tour/check-cpts', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this->tour, 'handleCheckCpts'],
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // =====================================================================
        // Tutorial Videos Endpoint
        // =====================================================================

        register_rest_route($this->namespace, '/tutorial-videos', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => function () {
                return new \WP_REST_Response(VideoService::getVideos(), 200);
            },
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);

        // =====================================================================
        // News Endpoint
        // =====================================================================

        register_rest_route($this->namespace, '/news', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => function () {
                return new \WP_REST_Response(NewsService::getNews(), 200);
            },
            'permission_callback' => [$this, 'check_admin_permission'],
        ]);
    }

    // =========================================================================
    // Callback Methods
    // =========================================================================

    /**
     * Get plugin URLs
     */
    public function wpf_get_urls($request): \WP_REST_Response
    {
        return rest_ensure_response([
            'status' => 200,
            'urls'   => [
                'plugin_url'  => WPF_PLUGIN_URL,
                'api_url'     => rest_url('wpfaker/v1/'),
                'admin_url'   => admin_url('/'),
                'ajax_url'    => admin_url('admin-ajax.php'),
                'logo_url'    => WPF_PLUGIN_URL . 'assets/images/icons/wp-icon-white.png',
                'plugin_dir'  => WPF_PLUGIN_DIR,
                'plugin_file' => WPF_PLUGIN_FILE,
                'plugin_name' => WPF_PLUGIN_NAME,
                'nonce'       => wp_create_nonce('wp_rest'),
            ],
        ]);
    }

    /**
     * Get all detected custom field plugins
     *
     * Returns comprehensive information about installed/active
     * custom field and CPT plugins.
     */
    public function wpf_get_detected_plugins($request): \WP_REST_Response
    {
        return rest_ensure_response([
            'success' => true,
            'plugins' => PluginDetectorService::getAllPluginStatus(),
            'summary' => PluginDetectorService::getSummary(),
        ]);
    }

    /**
     * Get all post types
     */
    public function wpf_get_all_cpt($request): \WP_REST_Response
    {
        return rest_ensure_response([
            'status' => 200,
            'result' => $this->postTypes->wpf_get_all_cpts(),
        ]);
    }

    /**
     * Get post type supports
     */
    public function wpf_get_type_supports($request): \WP_REST_Response
    {
        return rest_ensure_response([
            'status' => 200,
            'result' => $this->postTypes->wpf_get_type_supports($request),
        ]);
    }

    /**
     * Get all taxonomies
     */
    public function wpf_get_all_taxonomies($request): \WP_REST_Response
    {
        $taxonomies = get_taxonomies(['public' => true], 'objects');
        $result = [];

        foreach ($taxonomies as $taxonomy) {
            $result[] = [
                'name'         => $taxonomy->name,
                'label'        => $taxonomy->label,
                'labels'       => $taxonomy->labels,
                'hierarchical' => $taxonomy->hierarchical,
                'public'       => $taxonomy->public,
                'post_types'   => $taxonomy->object_type,
                'count'        => wp_count_terms(['taxonomy' => $taxonomy->name, 'hide_empty' => false]),
            ];
        }

        return rest_ensure_response([
            'status' => 200,
            'result' => $result,
        ]);
    }

    /**
     * Get available image providers
     */
    public function wpf_get_image_providers($request): \WP_REST_Response
    {
        return rest_ensure_response([
            'success'           => true,
            'providers'         => ImageService::getProviders(),
            'categories'        => ImageService::getCategories(),
            'default'           => ImageService::PROVIDER_PICSUM,
            'provider_settings' => ImageService::getProviderSettings(),
        ]);
    }

    /**
     * Get supported languages
     */
    public function wpf_get_languages($request): \WP_REST_Response
    {
        return rest_ensure_response([
            'success'   => true,
            'languages' => FakerService::getSupportedLanguages(),
            'default'   => FakerService::LANG_ENGLISH,
        ]);
    }

    /**
     * Get variation profiles
     */
    public function wpf_get_variation_profiles($request): \WP_REST_Response
    {
        return rest_ensure_response([
            'success'  => true,
            'profiles' => [
                VariationService::PROFILE_RANDOM => [
                    'name'        => 'Random',
                    'description' => 'Random variation of content (recommended for testing)',
                ],
                VariationService::PROFILE_MINIMAL => [
                    'name'        => 'Minimal',
                    'description' => 'Only required fields, no optional content',
                ],
                VariationService::PROFILE_PARTIAL => [
                    'name'        => 'Partial',
                    'description' => 'About 50% of optional fields filled',
                ],
                // Note: 'complete' is not listed here because disabling variation = complete (all fields filled)
            ],
            'default' => VariationService::PROFILE_RANDOM,
        ]);
    }

    /**
     * Get WPFaker meta for a specific post (used by editor sidebar)
     */
    public function wpf_get_post_meta(\WP_REST_Request $request): \WP_REST_Response
    {
        $postId = (int) $request->get_param('id');

        return rest_ensure_response([
            'is_generated' => (bool) get_post_meta($postId, '_wpfaker_generated', true),
            'template_id'  => (int) get_post_meta($postId, '_wpfaker_template_id', true),
        ]);
    }

    /**
     * Clear field detection cache for a specific post type
     */
    public function wpf_clear_field_detections_for_type(\WP_REST_Request $request): \WP_REST_Response
    {
        $postType = sanitize_key($request->get_param('post_type'));
        $cache = new FieldDetectionCacheService();
        $deleted = $cache->clearForPostType($postType);

        return rest_ensure_response([
            'success' => true,
            'message' => sprintf(__('%d Erkennungen für "%s" gelöscht', 'wpfaker'), $deleted, $postType),
            'deleted' => $deleted,
        ]);
    }

    /**
     * Clear all field detection cache
     */
    public function wpf_clear_all_field_detections(\WP_REST_Request $request): \WP_REST_Response
    {
        $cache = new FieldDetectionCacheService();
        $deleted = $cache->clearAll();

        return rest_ensure_response([
            'success' => true,
            'message' => sprintf(__('%d Erkennungen gelöscht', 'wpfaker'), $deleted),
            'deleted' => $deleted,
        ]);
    }

    /**
     * Clear all history
     */
    public function wpf_clear_history($request): \WP_REST_Response
    {
        $history = new \WPfaker\Services\HistoryService();
        $cleared = $history->clearAll();

        \WPFaker\Services\TelemetryService::incrementCounter('history_deletes');

        return rest_ensure_response([
            'success' => true,
            'message' => 'History cleared',
        ]);
    }

    /**
     * Cleanup orphaned history entries
     */
    public function wpf_cleanup_history($request): \WP_REST_Response
    {
        $history = new \WPfaker\Services\HistoryService();
        $cleaned = $history->cleanup();

        return rest_ensure_response([
            'success' => true,
            'cleaned' => $cleaned,
            'message' => sprintf('%d orphaned entries cleaned up', $cleaned),
        ]);
    }

    /**
     * Delete a single history entry
     */
    public function wpf_delete_history_entry(\WP_REST_Request $request): \WP_REST_Response
    {
        $id = (int) $request->get_param('id');
        $deleteContent = (bool) $request->get_param('delete_content');

        $history = new \WPfaker\Services\HistoryService();
        $result = $history->deleteEntry($id, $deleteContent);

        if ($result['success']) {
            \WPFaker\Services\TelemetryService::incrementCounter('history_deletes');
        }

        if (!$result['success']) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => $result['message'] ?? __('Löschen fehlgeschlagen', 'wpfaker'),
            ], 404);
        }

        return rest_ensure_response([
            'success'         => true,
            'message'         => __('Eintrag gelöscht', 'wpfaker'),
            'entry_deleted'   => $result['entry_deleted'],
            'content_deleted' => $result['content_deleted'],
        ]);
    }

    /**
     * Delete all WPfaker-generated data
     */
    public function wpf_delete_all_data(\WP_REST_Request $request): \WP_REST_Response
    {
        $stats = MediaCleanupService::deleteAllGeneratedData();

        return rest_ensure_response([
            'success' => true,
            'message' => sprintf(
                __('%d Posts, %d Terms, %d Users und %d Medien gelöscht', 'wpfaker'),
                $stats['posts'],
                $stats['terms'],
                $stats['users'],
                $stats['media']
            ),
            'stats'   => $stats,
        ]);
    }

    /**
     * Download images to media library
     */
    public function downloadImages(\WP_REST_Request $request): \WP_REST_Response
    {
        $count = min(20, max(1, (int) $request->get_param('count')));
        $provider = sanitize_key($request->get_param('provider') ?: 'picsum');
        $category = sanitize_key($request->get_param('category') ?: '');
        $width = min(4000, max(100, (int) ($request->get_param('width') ?: 1200)));
        $aspectRatio = sanitize_text_field($request->get_param('aspect_ratio') ?: '3:2');
        $randomSize = (bool) $request->get_param('random_size');
        $widthMin = min(4000, max(100, (int) ($request->get_param('width_min') ?: 800)));
        $widthMax = min(4000, max(100, (int) ($request->get_param('width_max') ?: 1600)));

        $imageService = new ImageService();
        $imageService->setProvider($provider);
        $imageService->setAspectRatio($aspectRatio);

        if ($randomSize) {
            // Use random size mode
            $imageService->setRandomSize($widthMin, $widthMax);
        } else {
            // Use fixed size - height calculated from aspect ratio
            $ratioValue = ImageService::ASPECT_RATIOS[$aspectRatio] ?? 1.5;
            $height = (int) round($width / $ratioValue);
            $imageService->setDimensions($width, $height);
        }

        $attachmentIds = $imageService->downloadImages($count, $category ?: null);

        // Get image details for the response
        $images = [];
        foreach ($attachmentIds as $id) {
            $images[] = [
                'id'        => $id,
                'title'     => get_the_title($id),
                'url'       => wp_get_attachment_url($id),
                'thumbnail' => wp_get_attachment_image_url($id, 'thumbnail'),
                'dimensions' => get_post_meta($id, '_wpfaker_dimensions', true),
                'ratio'     => get_post_meta($id, '_wpfaker_aspect_ratio', true),
            ];
        }

        return rest_ensure_response([
            'success'   => true,
            'message'   => sprintf(__('%d Bilder heruntergeladen', 'wpfaker'), count($attachmentIds)),
            'count'     => count($attachmentIds),
            'images'    => $images,
        ]);
    }

    /**
     * Upload file from URL
     */
    public function uploadFileFromUrl(\WP_REST_Request $request): \WP_REST_Response
    {
        $url = esc_url_raw($request->get_param('url'));

        if (empty($url)) {
            return rest_ensure_response([
                'success' => false,
                'message' => __('Keine URL angegeben', 'wpfaker'),
            ]);
        }

        // Download the file
        $temp_file = download_url($url, 30);

        if (is_wp_error($temp_file)) {
            return rest_ensure_response([
                'success' => false,
                'message' => $temp_file->get_error_message(),
            ]);
        }

        // Get filename from URL
        $filename = basename(parse_url($url, PHP_URL_PATH));
        if (empty($filename)) {
            $filename = 'uploaded-file-' . time();
        }

        // Check file type
        $file_info = wp_check_filetype($filename);
        if (empty($file_info['type'])) {
            @unlink($temp_file);
            return rest_ensure_response([
                'success' => false,
                'message' => __('Dateityp nicht erlaubt', 'wpfaker'),
            ]);
        }

        // Prepare file array for media_handle_sideload
        $file = [
            'name'     => $filename,
            'tmp_name' => $temp_file,
        ];

        // Upload to media library
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        $attachment_id = media_handle_sideload($file, 0);

        if (is_wp_error($attachment_id)) {
            @unlink($temp_file);
            return rest_ensure_response([
                'success' => false,
                'message' => $attachment_id->get_error_message(),
            ]);
        }

        // Mark as WPfaker uploaded
        update_post_meta($attachment_id, '_wpfaker_uploaded', true);

        return rest_ensure_response([
            'success' => true,
            'message' => __('Datei erfolgreich hochgeladen', 'wpfaker'),
            'file'    => [
                'id'       => $attachment_id,
                'title'    => get_the_title($attachment_id),
                'url'      => wp_get_attachment_url($attachment_id),
                'filename' => $filename,
            ],
        ]);
    }

    /**
     * Upload file from local filesystem (multipart form data)
     */
    public function uploadFile(\WP_REST_Request $request): \WP_REST_Response
    {
        $files = $request->get_file_params();

        if (empty($files['file'])) {
            return rest_ensure_response([
                'success' => false,
                'message' => __('Keine Datei hochgeladen', 'wpfaker'),
            ]);
        }

        $file = $files['file'];

        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $error_messages = [
                UPLOAD_ERR_INI_SIZE   => __('Datei zu groß (PHP-Limit)', 'wpfaker'),
                UPLOAD_ERR_FORM_SIZE  => __('Datei zu groß (Formular-Limit)', 'wpfaker'),
                UPLOAD_ERR_PARTIAL    => __('Datei nur teilweise hochgeladen', 'wpfaker'),
                UPLOAD_ERR_NO_FILE    => __('Keine Datei hochgeladen', 'wpfaker'),
                UPLOAD_ERR_NO_TMP_DIR => __('Temporäres Verzeichnis fehlt', 'wpfaker'),
                UPLOAD_ERR_CANT_WRITE => __('Fehler beim Schreiben der Datei', 'wpfaker'),
            ];

            return rest_ensure_response([
                'success' => false,
                'message' => $error_messages[$file['error']] ?? __('Unbekannter Upload-Fehler', 'wpfaker'),
            ]);
        }

        // Check file type
        $file_info = wp_check_filetype($file['name']);
        if (empty($file_info['type'])) {
            return rest_ensure_response([
                'success' => false,
                'message' => __('Dateityp nicht erlaubt', 'wpfaker'),
            ]);
        }

        // Prepare file array for media_handle_sideload
        $upload_file = [
            'name'     => $file['name'],
            'tmp_name' => $file['tmp_name'],
        ];

        // Upload to media library
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        $attachment_id = media_handle_sideload($upload_file, 0);

        if (is_wp_error($attachment_id)) {
            return rest_ensure_response([
                'success' => false,
                'message' => $attachment_id->get_error_message(),
            ]);
        }

        // Mark as WPfaker uploaded
        update_post_meta($attachment_id, '_wpfaker_uploaded', true);

        return rest_ensure_response([
            'success' => true,
            'message' => __('Datei erfolgreich hochgeladen', 'wpfaker'),
            'file'    => [
                'id'       => $attachment_id,
                'title'    => get_the_title($attachment_id),
                'url'      => wp_get_attachment_url($attachment_id),
                'filename' => $file['name'],
            ],
        ]);
    }

    // =========================================================================
    // Addon System
    // =========================================================================

    /**
     * Get registered addons info
     *
     * @return \WP_REST_Response
     */
    public function getAddons(): \WP_REST_Response
    {
        $adapters = \WPFaker\Services\AdapterFactory::getAdapterInfo();

        // Filter to only show non-core adapters (registered via register())
        $coreAdapters = ['acf', 'acf_pro', 'acfe', 'jet_engine', 'meta_box', 'acpt', 'cptui', 'native_meta'];
        $addonAdapters = array_filter($adapters, function ($key) use ($coreAdapters) {
            return !in_array($key, $coreAdapters);
        }, ARRAY_FILTER_USE_KEY);

        $aiProviders = \WPFaker\Services\AiProviderFactory::getProviderOptions();
        $coreProviders = ['gemini', 'anthropic', 'openai'];
        $addonProviders = array_filter($aiProviders, function ($option) use ($coreProviders) {
            return !in_array($option['key'], $coreProviders);
        });

        return new \WP_REST_Response([
            'adapters'     => $addonAdapters,
            'ai_providers' => array_values($addonProviders),
        ]);
    }

    // =========================================================================
    // Permission Callbacks
    // =========================================================================

    /**
     * Check if current user has admin permissions
     */
    public function check_admin_permission($request): bool
    {
        return current_user_can('manage_options');
    }

    /**
     * Legacy permission check (always true - deprecated)
     *
     * @deprecated Use check_admin_permission instead
     */
    public function wpf_get_settings_permissions_check($request): bool
    {
        return $this->check_admin_permission($request);
    }
}
