<?php

namespace WPFaker;

use WPFaker\Services\SystemCapacityService;
use WPFaker\Tour;
use function add_action;
use function current_user_can;
use function defined;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin Class
 *
 * Handles WordPress admin interface and asset management.
 */
class Admin
{
    /**
     * Admin page hook suffix
     *
     * @var string
     */
    private string $hookSuffix = '';

    /**
     * Constructor
     */
    public function __construct()
    {
        add_action('admin_menu', [$this, 'addPluginPage']);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAssets']);
    }

    /**
     * Add plugin admin menu page
     */
    public function addPluginPage(): void
    {
        global $submenu;
        $capability = 'manage_options';

        $this->hookSuffix = add_menu_page(
            __('WPfaker', 'wpfaker'),
            __('WPfaker', 'wpfaker'),
            $capability,
            WPF_PLUGIN_SLUG,
            [$this, 'renderAdminPage'],
            $this->getMenuIcon(),
            30
        );

        // Add submenu items
        if (current_user_can($capability)) {
            $submenu[WPF_PLUGIN_SLUG][] = [
                __('Dashboard', 'wpfaker'),
                $capability,
                'admin.php?page=' . WPF_PLUGIN_SLUG,
            ];
            $submenu[WPF_PLUGIN_SLUG][] = [
                __('Generate Posts', 'wpfaker'),
                $capability,
                'admin.php?page=' . WPF_PLUGIN_SLUG . '#posts',
            ];
            $submenu[WPF_PLUGIN_SLUG][] = [
                __('History', 'wpfaker'),
                $capability,
                'admin.php?page=' . WPF_PLUGIN_SLUG . '#history',
            ];
            $submenu[WPF_PLUGIN_SLUG][] = [
                __('Settings', 'wpfaker'),
                $capability,
                'admin.php?page=' . WPF_PLUGIN_SLUG . '#settings',
            ];
        }
    }

    /**
     * Get the menu icon as base64-encoded SVG
     *
     * @return string Base64-encoded SVG data URI
     */
    private function getMenuIcon(): string
    {
        $svg = '<svg width="20" height="20" viewBox="0 0 120 77" xmlns="http://www.w3.org/2000/svg"><path fill="black" d="M42.597,62.947c3.607,-6.342 13.677,-24.402 26.456,-50.283c3.584,-7.259 8.234,-10.694 12.874,-12.019c4.794,-1.369 9.949,-0.505 14.924,2.086c7.583,3.949 14.847,12.178 18.826,18.263c5.475,8.372 4.562,17.054 -0.644,24.513c-6.35,9.098 -20.158,16.315 -35.304,16.768c-3.818,0.114 -7.01,-2.893 -7.124,-6.71c-0.114,-3.818 2.893,-7.01 6.71,-7.124c8.786,-0.263 17.055,-3.49 22.108,-8.269c3.504,-3.313 5.357,-7.496 2.671,-11.603c-2.918,-4.461 -8.075,-10.667 -13.635,-13.562c-1.6,-0.833 -3.19,-1.493 -4.732,-1.053c-1.699,0.485 -2.951,2.18 -4.263,4.838c-16.68,33.783 -26.739,51.451 -29.006,54.654c-2.482,3.505 -5.492,3.443 -6.076,3.446c-14.864,0.068 -25.036,-4.322 -32.036,-10.658c-10.388,-9.403 -13.863,-23.559 -14.295,-35.991c-0.45,-12.937 2.257,-23.73 2.257,-23.73c0.922,-3.706 4.68,-5.967 8.386,-5.045c3.706,0.922 5.967,4.68 5.045,8.386c0,0 -2.233,9.057 -1.855,19.908c0.312,8.978 2.25,19.421 9.751,26.211c4.32,3.91 10.462,6.443 18.963,6.975Z"/><path fill="black" d="M30.247,45.726c-0.361,-0.832 -4.654,-11.212 -0.971,-26.198c0.912,-3.709 4.663,-5.98 8.372,-5.068c3.709,0.912 5.98,4.663 5.068,8.372c-3.117,12.681 0.802,18.859 0.92,19.53c0.665,3.761 -1.848,7.355 -5.61,8.02c-3.433,0.607 -6.726,-1.434 -7.781,-4.655Z"/></svg>';

        return 'data:image/svg+xml;base64,' . base64_encode($svg);
    }

    /**
     * Render the admin page container
     */
    public function renderAdminPage(): void
    {
        // Inline style to override WP admin backgrounds — un-layered, wins over WP core CSS
        echo '<style>
            html, body, body.wp-admin, #wpwrap, #wpcontent, #wpbody, #wpbody-content, .wrap {
                background: var(--app-bg, #fff) !important;
                border: none !important;
                box-shadow: none !important;
                outline: none !important;
            }
            .wrap { margin: 0 !important; }
            #wpcontent { padding-left: 0 !important; }
            #wpbody { padding-right: 0 !important; }
            #wpbody-content { float: none !important; padding-right: 0 !important; }
            #adminmenuwrap, #adminmenuback, #adminmenumain, #adminmenu, #adminmenu .wp-submenu {
                border: none !important; border-right: none !important;
                box-shadow: none !important; outline: none !important;
            }
            #adminmenuback::after, #adminmenuwrap::after, #adminmenu::after { display: none !important; }
        </style>';
        echo '<div class="wrap" style="margin:0!important"><div id="wpf-admin-app"></div></div>';
        // Blocking inline script to prevent FOUC
        echo '<script>try{if(localStorage.getItem("wpfaker-theme")==="dark"){document.getElementById("wpf-admin-app").setAttribute("data-theme","dark");document.body.setAttribute("data-theme","dark")}}catch(e){}</script>';
    }

    /**
     * Enqueue admin assets
     *
     * @param string $hook Current admin page hook
     */
    public function enqueueAssets(string $hook): void
    {
        // Only load on our plugin page
        if ($hook !== $this->hookSuffix) {
            return;
        }

        $buildDir = WPF_PLUGIN_DIR . '/build/';
        $buildUrl = WPF_PLUGIN_URL . 'build/';

        // Check if build files exist
        $assetFile = $buildDir . 'admin.asset.php';

        if (file_exists($assetFile)) {
            $assets = include $assetFile;
            // Append file modification time to bust OPcache
            $assets['version'] .= '.' . filemtime($buildDir . 'admin.js');
        } else {
            // Fallback for development or if build doesn't exist
            $assets = [
                'dependencies' => [
                    'wp-element',
                    'wp-components',
                    'wp-api-fetch',
                    'wp-i18n',
                ],
                'version' => WPF_PLUGIN_SLUG . '-dev',
            ];
        }

        // Enqueue the main admin script
        if (file_exists($buildDir . 'admin.js')) {
            wp_enqueue_script(
                'wpfaker-admin',
                $buildUrl . 'admin.js',
                $assets['dependencies'],
                $assets['version'],
                true
            );

            // Get settings
            $settings = get_option('wpfaker_settings', []);

            // Get license status
            $licenseValid = License::isValid();
            $licenseStatus = License::getStatus();

            // Collect addon sub-tabs via filter
            $addonSubTabs = apply_filters('wpfaker_generate_sub_tabs', []);

            // Localize script with data
            wp_localize_script('wpfaker-admin', 'wpfakerData', [
                'nonce'         => wp_create_nonce('wp_rest'),
                'apiUrl'        => rest_url('wpfaker/v1/'),
                'adminUrl'      => admin_url(),
                'pluginUrl'     => WPF_PLUGIN_URL,
                'version'       => Plugin::VERSION,
                'fakerLocale'   => $settings['locale'] ?? 'auto',
                'defaultImageProvider' => $settings['default_image_provider'] ?? 'unsplash',
                'licenseValid'  => $licenseValid,
                'licenseStatus' => $licenseStatus['status'] ?? 'inactive',
                'systemCapacity' => SystemCapacityService::getCapacity(),
                'tourCompleted' => (bool) get_option(Tour::OPTION_COMPLETED, false),
                'tourDemoActive' => (bool) get_option(Tour::OPTION_DEMO_ACTIVE, false),
                'addonSubTabs'  => $addonSubTabs,
            ]);

            // NOTE: Admin UI locale override disabled for now.
            // To re-enable, restore the admin_locale setting check and
            // the load_script_translation_file filter here.

            wp_set_script_translations('wpfaker-admin', 'wpfaker', WPF_PLUGIN_DIR . '/languages');
        }

        // Enqueue Google Fonts
        wp_enqueue_style(
            'wpfaker-fonts',
            'https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&display=swap',
            [],
            null
        );

        // Enqueue styles
        if (file_exists($buildDir . 'admin.css')) {
            wp_enqueue_style(
                'wpfaker-admin',
                $buildUrl . 'admin.css',
                ['wpfaker-fonts'],
                $assets['version']
            );
        }

        // WP admin overrides — loaded OUTSIDE Tailwind's @layer system
        // so these rules actually win over WordPress core CSS.
        wp_enqueue_style(
            'wpfaker-wp-overrides',
            WPF_PLUGIN_URL . 'src/admin/styles/wp-overrides.css',
            ['wpfaker-admin'],
            $assets['version']
        );
    }
}
