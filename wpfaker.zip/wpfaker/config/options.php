<?php
/**
 * File: options.php
 * Author: michael
 * Created at: 12.12.23
 */

return $GLOBALS['wpf_options'] = [
    'delete_history_table_on_deactivate' => false,
];