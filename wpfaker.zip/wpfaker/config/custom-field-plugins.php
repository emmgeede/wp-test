<?php

namespace WPFaker\Config;

/**
 * File: custom-field-plugins.php
 * Author: michael
 * Created at: 12.12.23
 */
return $GLOBALS['WPF_CUSTOM_FIELD_PLUGINS'] = [
    'WPF_ACF'         => [
        'path'     => 'advanced-custom-fields/acf.php',
        'constant' => 'WPF_ACF',
        'class'    => 'Acf',
    ],
    'WPF_ACF_PRO'     => [
        'path'     => 'advanced-custom-fields-pro/acf.php',
        'constant' => 'WPF_ACF_PRO',
        'class'    => 'AcfPro',
    ],
    'WPF_JET_ENGINE'  => [
        'path'     => 'jet-engine/jet-engine.php',
        'constant' => 'WPF_JET_ENGINE',
        'class'    => 'JetEngine',
    ],
    'WPF_CUBEWP'      => [
        'path'     => 'cubepress/cubepress.php',
        'constant' => 'WPF_CUBEWP',
        'class'    => 'CubePress',
    ],
    'WPF_META_BOX'    => [
        'path'     => 'meta-box/meta-box.php',
        'constant' => 'WPF_META_BOX',
        'class'    => 'MetaBox',
    ],
    'WPF_TOOLSET'     => [
        'path'     => 'types/wpcf.php',
        'constant' => 'WPF_TOOLSET',
        'class'    => 'Toolset',
    ],
    'WPF_HAPPY_FILES' => [
        'path'     => 'happyfiles/happyfiles.php',
        'constant' => 'WPF_HAPPY_FILES',
        'class'    => 'HappyFiles',
    ],
];