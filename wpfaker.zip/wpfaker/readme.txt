=== WPFaker ===
Contributors: emmgee
Tags: fake data, test data, development, faker, dummy content
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 0.11.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Generate realistic fake data for WordPress development. Create posts, pages, users, taxonomies, and WooCommerce products with a single click.

== Description ==

WPFaker is a powerful fake data generator for WordPress developers. It helps you quickly populate your development or staging site with realistic test content.

**Features:**

* **Posts & Pages** - Generate blog posts and pages with realistic titles, content, and featured images
* **Custom Post Types** - Full support for all registered custom post types
* **Users** - Create fake users with different roles (admin, editor, author, subscriber)
* **Taxonomies** - Auto-generate categories, tags, and custom taxonomies
* **WooCommerce** - Generate products, variations, orders, and customers
* **Multilingual** - WPML and Polylang integration for translated content
* **AI-Powered** - Gemini AI integration for intelligent field detection
* **REST API** - Full REST API for programmatic access

**Use Cases:**

* Theme development and testing
* Plugin development and testing
* Client demonstrations
* Performance testing with realistic data volumes
* Training and documentation screenshots

== Installation ==

1. Download the plugin ZIP file from the releases page
2. Go to WordPress Admin → Plugins → Add New → Upload Plugin
3. Upload the ZIP file and click "Install Now"
4. Activate the plugin
5. Navigate to Tools → WPFaker to start generating content

== Frequently Asked Questions ==

= Does this work with custom post types? =

Yes, WPFaker automatically detects all registered custom post types and allows you to generate content for them.

= Does it support WooCommerce? =

Yes, WPFaker has full WooCommerce support including simple products, variable products, product variations, orders, and customers.

= Can I generate content in multiple languages? =

Yes, WPFaker integrates with WPML and Polylang for multilingual content generation.

= Is there a REST API? =

Yes, WPFaker provides a full REST API for programmatic content generation.

== Screenshots ==

1. Main dashboard with generation options
2. Post generation settings
3. WooCommerce product generation
4. User generation interface

== Changelog ==

= 0.0.3 =
* Added AI-powered field detection with Gemini
* Added multilingual support (WPML, Polylang)
* Added admin UI language selector
* Improved WooCommerce integration

= 0.0.2 =
* Added WooCommerce support
* Added REST API
* Added taxonomy generation

= 0.0.1 =
* Initial release
* Basic post and page generation
* User generation
* Category and tag support

== Upgrade Notice ==

= 0.0.3 =
New AI-powered field detection and multilingual support.
